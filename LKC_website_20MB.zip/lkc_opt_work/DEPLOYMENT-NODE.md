# Livingstone Kolobeng College (LKC)
## Production Deployment Guide — Full-Stack Node.js + Live Admin CMS

This guide walks through deploying the full-stack LKC web application (`server.ts` + React/Vite frontend + built-in SQLite CMS & media uploads) to a production server, including **cPanel ("Setup Node.js App")**, **environment variables**, **building with `npm install` & `npm run build`**, and **configuring the `storage/` persistence directory**.

---

## 1. Architecture & Runtime Requirements

- **Runtime:** **Node.js `22.18.0+`** (minimum `22.5.0+` for built-in `node:sqlite`; `22.18+` runs `node server.ts` natively without extra flags).
- **Database:** Built-in SQLite stored on disk at `storage/lkc_cms.db` — **no MySQL, PostgreSQL, or external database server is required**.
- **How Production Mode Works:**
  1. `npm run build` compiles the React application into `dist/` (keeping the `#admin` / `#cms` UI inside `dist/assets/lkc-app.js`).
  2. `npm start` runs `node server.ts` (`server.ts` loads `dotenv/config`, initializes `storage/`, serves `/uploads/*` and `/api/*`, and serves `dist/index.html`).
  3. When `NODE_ENV=production` is set, `server.ts` automatically flips `window.__LKC_STATIC_MODE__` to `false` on every HTML response, enabling `#admin` and `#cms` login, content editing, and media uploads.

---

## 2. Preparing & Uploading Project Files

### What to Upload
Download the complete project source from AI Studio (or clone your repository), excluding `node_modules/` and `.env`:

- `package.json`, `package-lock.json`
- `server.ts`, `tsconfig.json`, `vite.config.ts`, `index.html`, `metadata.json`
- `src/`
- `public/` *(includes static portraits and school assets under `public/assets/`)*
- `scripts/`
- `storage/` *(optional: upload if migrating an existing `lkc_cms.db` and `storage/uploads/`; omit if starting fresh)*

> **Important:** Do **not** upload only `dist/` (that leaves out `server.ts` and `src/server/`), and do **not** upload `node_modules/` from another machine (install packages directly on the production server).

---

## 3. Setting Up on cPanel ("Setup Node.js App")

### Step 3.1 — Verify cPanel Node.js Version
1. Log in to **cPanel** → **Software** → **Setup Node.js App**.
2. Click **Create Application** and inspect the **Node.js version** dropdown.
3. Confirm **`22.x`** (`22.5.0+`, ideally `22.18+`) is selectable.
   - *If your cPanel host only offers Node 16, 18, or 20, built-in `node:sqlite` will not load — deploy to a Linux VPS, Render, or Railway instead (see Section 7).*

### Step 3.2 — Place Project Files Outside `public_html`
1. Open **cPanel → File Manager**.
2. Navigate to your account home directory (`/home/<cpanel_user>/`) — **not** inside `public_html/`.
3. Create a folder named `lkc-web` (`/home/<cpanel_user>/lkc-web`).
4. Upload your project ZIP inside `lkc-web/` and extract it so `package.json` and `server.ts` live directly at:
   - `/home/<cpanel_user>/lkc-web/package.json`
   - `/home/<cpanel_user>/lkc-web/server.ts`
   *(If extraction created an extra nested folder, move its contents up one level into `lkc-web/`.)*
5. **Clear conflicting static files from `public_html/`:** If you previously uploaded a static build to `public_html/`, back up and remove old `index.html`, `api.php`, `index.php`, `.htaccess`, and `assets/` from `public_html/` so Apache/LiteSpeed routes traffic to the Node.js Passenger app cleanly.

### Step 3.3 — Create the Application in "Setup Node.js App"
Fill in the form as follows:
- **Node.js version:** `22.x` (highest `22.x` available)
- **Application mode:** `Production`
- **Application root:** `lkc-web`
- **Application URL:** your domain (e.g. `yourdomain.com`)
- **Application startup file:** `server.ts`

Click **Create** (without starting yet if dependencies are not installed).

---

## 4. Configuring Environment Variables

In the cPanel **Setup Node.js App** edit screen, scroll to **Environment variables** (or create `.env` in the app root on a VPS) and configure:

| Variable | Required | Recommended Value | Purpose |
| --- | --- | --- | --- |
| `NODE_ENV` | **Yes** | `production` | Serves `dist/` and disables static-only lock (`__LKC_STATIC_MODE__ = false`) |
| `CMS_SESSION_SECRET` | **Yes** | 64-char random hex string | Signs session tokens in `auth.ts` (generate via `openssl rand -hex 32`) |
| `CMS_BOOTSTRAP_ADMIN_EMAIL` | On fresh DB | `admin@yourdomain.com` | Automatically creates an active `super_admin` if none exists in `storage/lkc_cms.db` |
| `CMS_BOOTSTRAP_ADMIN_PASSWORD` | On fresh DB | Strong password (`>= 8` chars) | Password for that bootstrap `super_admin` |
| `PORT` | VPS / PaaS | `3000` (or host-assigned) | **Leave unset in cPanel** — cPanel Passenger binds the port automatically |
| `COOKIE_SECURE` | Optional | *(leave unset)* | Auto-detects HTTPS via `X-Forwarded-Proto`; set `false` only for temporary plain `http://` testing |
| `CMS_SEED_PASSWORD_<NAME>` | Optional | Strong password (`>= 8` chars) | Overrides initial passwords for the 5 seeded admin accounts (`MAKONI`, `SEREFETHE`, `MUTENHERI`, `CHAMBWERA`, `MADZIVANYIKA`) |

Click **Save** after adding all variables.

---

## 5. Installing Dependencies & Building (`npm install` & `npm run build`)

### On cPanel Terminal
1. At the top of your **Setup Node.js App** page, copy the virtual-environment activation command shown in the blue banner (for example):
   ```bash
   source /home/<cpanel_user>/nodevenv/lkc-web/22/bin/activate && cd /home/<cpanel_user>/lkc-web
   ```
2. Open **cPanel → Advanced → Terminal**, paste that command, and press **Enter**.
3. Verify the active Node.js version is `22.5+` (ideally `22.18+`):
   ```bash
   node -v
   ```
4. Install packages cleanly:
   ```bash
   npm install --legacy-peer-deps
   ```
5. Compile the production frontend and asset bundle:
   ```bash
   npm run build
   ```
   Wait for `[LKC Shared-Hosting Build] Complete.` and confirm `dist/index.html` and `dist/assets/lkc-app.js` were generated.
6. Return to **cPanel → Setup Node.js App** and click **Restart**.

> **Note if `server.ts` fails on Node `22.6–22.17`:** Node `22.18+` executes `.ts` files natively. If your host uses Node `22.6`–`22.17` where `--experimental-strip-types` is still flagged, check `node -v`; you can verify startup directly in Terminal with `NODE_ENV=production node --experimental-strip-types server.ts`.

---

## 6. Setting Up & Protecting the `storage/` Persistence Folder

### How `storage/` Works
`src/server/db.ts` resolves all persistent state relative to the working directory (`process.cwd()/storage`):

```text
<app-root>/
└── storage/
    ├── lkc_cms.db                      # Main SQLite CMS, users, sessions, audit logs & enquiries
    ├── lkc_cms.db-wal                  # SQLite write-ahead log (present while active)
    ├── lkc_cms.db-shm                  # SQLite shared-memory index (present while active)
    ├── .initial_admin_credentials.txt  # Mode 0600 auto-generated temp passwords for seeded admins
    ├── .password_reset_tokens.json     # Mode 0600 out-of-band password reset token dispatches
    └── uploads/                        # All images/videos/PDFs uploaded through Admin CMS (/uploads/*)
```

### Persistence Setup Checklist
1. **Working Directory & Ownership:**
   - Ensure the Node process starts inside the application root (`lkc-web/`) so `storage/` resolves consistently and is never placed inside `public_html/`.
   - Ensure the user running Node owns `storage/` and `storage/uploads/` with writable directory permissions (`0755` on `storage/` and `storage/uploads/`, `0644` on database/upload files, `0600` on `.initial_admin_credentials.txt` and `.password_reset_tokens.json`).
   ```bash
   mkdir -p storage/uploads
   chmod 755 storage storage/uploads
   ```
2. **Migrating an Existing Database (`lkc_cms.db`) + Uploads:**
   - Stop the old/source app (or export a clean copy) before copying so WAL changes are flushed, **or** copy `lkc_cms.db`, `lkc_cms.db-wal`, and `lkc_cms.db-shm` together along with `storage/uploads/*`.
3. **Fresh Database Initialization:**
   - If `storage/` is empty on first boot, `server.ts` automatically creates `storage/lkc_cms.db` and `storage/uploads/`, seeds all 8 academic departments, pages, and default staff/media data, and creates your bootstrap `super_admin` if `CMS_BOOTSTRAP_ADMIN_EMAIL` / `CMS_BOOTSTRAP_ADMIN_PASSWORD` were set.
4. **Never Overwrite `storage/` During Code Updates:**
   - Because `.gitignore` excludes `storage/`, future code updates must **only** update `src/`, `public/`, `scripts/`, `server.ts`, `package.json`, and rebuild `dist/` — leave `storage/` untouched on the server.
5. **Regular Backups:**
   - Inside `#admin` → **Governance / Backup**, Super Admins can download a full JSON snapshot at any time, and you should also back up the `storage/` directory (`lkc_cms.db` + `uploads/`) via cPanel File Manager / cron.

---

## 7. Alternative Hosts (VPS / Render / Railway)

### Linux VPS (Ubuntu + Nginx + PM2)
1. Install Node.js `22.x`:
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```
2. Upload project to `/var/www/lkc-web`, copy `.env.example` to `.env`, and fill in `NODE_ENV=production`, `PORT=3000`, `CMS_SESSION_SECRET`, and bootstrap credentials.
3. Run:
   ```bash
   npm install --legacy-peer-deps
   npm run build
   mkdir -p storage/uploads
   ```
4. Launch under PM2:
   ```bash
   sudo npm install -g pm2
   NODE_ENV=production pm2 start "npm start" --name lkc-web
   pm2 save
   pm2 startup
   ```
5. Reverse-proxy Nginx to `http://127.0.0.1:3000`, forwarding `Host $host` and `X-Forwarded-Proto $scheme`, and configure SSL (Certbot).

### Render / Railway
- **Build Command:** `npm install --legacy-peer-deps && npm run build`
- **Start Command:** `npm start`
- **Persistent Disk / Volume (Critical):** Without a persistent disk, containers wipe local files on redeploy. Mount a persistent volume to `<repo-root>/storage` (`/opt/render/project/src/storage` on Render; `/app/storage` on Railway).
- Set `NODE_ENV=production`, `CMS_SESSION_SECRET`, `CMS_BOOTSTRAP_ADMIN_EMAIL`, and `CMS_BOOTSTRAP_ADMIN_PASSWORD` in dashboard environment variables.

---

## 8. Post-Deployment Verification

1. **API & Database Health:**
   Open `https://yourdomain.com/api/health` — expected response (`200 OK`):
   ```json
   {"ok":true,"database":"connected","timestamp":"..."}
   ```
2. **Dynamic Mode Check:**
   View page source on `https://yourdomain.com/` and verify `window.__LKC_STATIC_MODE__=false;` is present.
3. **Admin CMS Access:**
   Visit `https://yourdomain.com/#admin`:
   - Existing migrated DB: sign in with your existing Super Admin account (e.g. `tapiwanorman95@gmail.com`).
   - Fresh DB with bootstrap env vars: sign in with `CMS_BOOTSTRAP_ADMIN_EMAIL` / `CMS_BOOTSTRAP_ADMIN_PASSWORD`.
   - Fresh DB without bootstrap env vars: complete the **Initial Super Administrator Setup** form shown on screen.
4. **Test Upload Persistence:**
   Upload a test image inside `#admin`, verify it loads at `/uploads/<filename>`, then restart the Node app in cPanel/PM2 and confirm both the edited record and uploaded image persist.
