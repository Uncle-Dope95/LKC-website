# Livingstone Kolobeng College (LKC) — Complete Step-by-Step Deployment & Configuration Documentation

This guide provides complete **step-by-step instructions** and **every supported configuration scenario** for deploying the LKC web platform (`server.ts` + React/Vite frontend + SQLite CMS & media uploads, or static shared PHP hosting).

---

## 1. Quick Decision Matrix: Choose Your Deployment Mode

| Scenario | Recommended Mode | Live `#admin` CMS? | Server Requirements |
| --- | --- | --- | --- |
| **cPanel with Node `22.x` in "Setup Node.js App"** | Mode A1 (cPanel Passenger) | **Yes** | Node `22.5+` (`22.18+` ideal), no MySQL needed |
| **Linux VPS / Cloud VM (Ubuntu, Debian, CentOS)** | Mode A2 (PM2 + Nginx/Apache) | **Yes** | Node `22.18+`, PM2, Nginx or Apache proxy |
| **cPanel Terminal with PM2 (instead of Passenger)** | Mode A3 (PM2 + Cron + Proxy) | **Yes** | Node `22.5+`, local port + `.htaccess` `mod_proxy` `[P]` |
| **Render / Railway / Fly.io** | Mode A4 (Cloud PaaS + Volume) | **Yes** | Node `22.5+` + Persistent Disk mounted at `storage/` |
| **Ordinary cPanel / Shared PHP Host (no Node `22+`)** | Mode B (Static `dist/` + `api.php`) | No (snapshot only) | Apache/LiteSpeed + PHP (`7.4+` / `8.x`) |

---

## 2. Mode A — Step-by-Step Full-Stack Node.js Deployment

### Step 1: Prepare the Upload Package
Download or clone the full workspace onto your computer.

**Include:**
- `package.json`, `package-lock.json`
- `server.ts`, `tsconfig.json`, `vite.config.ts`, `index.html`, `metadata.json`
- `src/` (React UI + `src/server/` Express & SQLite backend)
- `public/` (logos, PDFs, portraits under `public/assets/`)
- `scripts/` (`build.mjs`, `exportStaticSite.mjs`)
- `storage/` *(only if migrating an existing `lkc_cms.db` and `storage/uploads/`)*

**Exclude:**
- `node_modules/` (always install on the target server)
- `.env` (configure environment variables directly on the server)
- Do **not** upload only `dist/` (that excludes `server.ts` and `src/server/`)

---

### Step 2: Possible Server Configurations (Pick One)

#### Configuration A1 — cPanel via "Setup Node.js App" (Phusion Passenger)
> Do **not** also run PM2 on the same directory—Passenger already restarts crashed processes.

1. **Check Node version:** Open **cPanel → Software → Setup Node.js App → Create Application** and confirm **`22.x`** (`22.18+` recommended) is listed.
2. **Upload files outside `public_html/`:**
   - Open **cPanel → Files → File Manager**, go to `/home/<cpanel_user>/`.
   - Create `/home/<cpanel_user>/lkc-web/`.
   - Upload and extract your archive so `package.json` and `server.ts` sit directly at `/home/<cpanel_user>/lkc-web/package.json` and `/home/<cpanel_user>/lkc-web/server.ts`.
   - Remove any old static files (`index.html`, `index.php`, `api.php`, `.htaccess`, `assets/`) from `public_html/` so Apache routes requests cleanly to the Node app.
3. **Create the Application in Setup Node.js App:**
   - **Node.js version:** Highest `22.x` available
   - **Application mode:** `Production`
   - **Application root:** `lkc-web`
   - **Application URL:** Your domain or subdomain (e.g. `yourdomain.com`)
   - **Application startup file:** `server.ts`
4. **Add Environment Variables** (see **Step 3** below — leave `PORT` unset in cPanel), click **Create**, and click **Save**.
5. **Install & Build in cPanel Terminal:**
   - Copy the blue virtual-environment activation banner from Setup Node.js App:
     ```bash
     source /home/<cpanel_user>/nodevenv/lkc-web/22/bin/activate && cd /home/<cpanel_user>/lkc-web
     ```
   - Open **cPanel → Advanced → Terminal**, paste it, and run:
     ```bash
     node -v
     npm install --legacy-peer-deps
     npm run build
     mkdir -p storage/uploads
     chmod 755 storage storage/uploads
     ```
6. **Start:** Return to **Setup Node.js App** and click **Restart**.

---

#### Configuration A2 — Linux VPS (Ubuntu + PM2 + Nginx Reverse Proxy)
1. **Install Node.js `22.x` & build tools:**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
   sudo apt-get install -y nodejs nginx certbot python3-certbot-nginx
   node -v   # Confirm v22.18.0+
   ```
2. **Deploy files to `/var/www/lkc-web`:**
   ```bash
   sudo mkdir -p /var/www/lkc-web
   sudo chown -R $USER:$USER /var/www/lkc-web
   cd /var/www/lkc-web
   # Extract/clone project files here
   ```
3. **Create `.env`, install dependencies, and build:**
   ```bash
   cp .env.example .env
   nano .env   # Fill in Step 3 variables (include PORT=3000)
   npm install --legacy-peer-deps
   npm run build
   mkdir -p storage/uploads && chmod 755 storage storage/uploads
   ```
4. **Start & persist with PM2** *(create `ecosystem.config.cjs` from Configuration A3 below)*:
   ```bash
   sudo npm install -g pm2
   pm2 start ecosystem.config.cjs
   pm2 save
   pm2 startup        # Copy and run the sudo command printed by PM2
   pm2 save
   ```
5. **Configure Nginx (`/etc/nginx/sites-available/lkc-web`):**
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com www.yourdomain.com;

       client_max_body_size 55M;

       location / {
           proxy_pass http://127.0.0.1:3000;
           proxy_http_version 1.1;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection "upgrade";
       }
   }
   ```
   Enable and secure with SSL:
   ```bash
   sudo ln -s /etc/nginx/sites-available/lkc-web /etc/nginx/sites-enabled/
   sudo nginx -t && sudo systemctl reload nginx
   sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
   ```

---

#### Configuration A3 — PM2 in cPanel Terminal (With Reboot Cron & `.htaccess` Proxy)
> Use this only *instead of* Setup Node.js App (ensure Setup Node.js App is stopped/deleted first).

1. **Locate Node `22.5+` and install user-scoped PM2:**
   ```bash
   cd ~/lkc-web
   which node && node -v
   mkdir -p ~/.npm-global
   npm config set prefix "$HOME/.npm-global"
   export PATH="$HOME/.npm-global/bin:$PATH"
   echo 'export PATH="$HOME/.npm-global/bin:$PATH"' >> ~/.bashrc
   npm install -g pm2
   ```
2. **Create `.env`, build, and prepare `storage/`:**
   ```bash
   cp .env.example .env
   nano .env
   npm install --legacy-peer-deps
   npm run build
   mkdir -p storage/uploads && chmod 755 storage storage/uploads
   ```
3. **Create `ecosystem.config.cjs`** *(must use `.cjs` because `package.json` uses `"type": "module"`)*:
   ```js
   module.exports = {
     apps: [
       {
         name: 'lkc-web',
         cwd: '/home/YOUR_CPANEL_USER/lkc-web',
         script: 'server.ts',
         interpreter: '/FULL/PATH/TO/node',
         // If node -v is 22.6-22.17 instead of 22.18+, uncomment next line:
         // interpreter_args: '--experimental-strip-types',
         exec_mode: 'fork',
         instances: 1, // Single instance required for SQLite locking
         autorestart: true,
         watch: false,
         max_restarts: 10,
         min_uptime: '10s',
         restart_delay: 3000,
         max_memory_restart: '512M',
         env: { NODE_ENV: 'production', PORT: '3000' },
         out_file: '/home/YOUR_CPANEL_USER/lkc-web/storage/pm2-out.log',
         error_file: '/home/YOUR_CPANEL_USER/lkc-web/storage/pm2-error.log',
         merge_logs: true,
         time: true,
       },
     ],
   };
   ```
4. **Start & save process list:**
   ```bash
   pm2 start ecosystem.config.cjs
   pm2 save
   ```
5. **Auto-start after server reboot (non-root cPanel):**
   In **cPanel → Advanced → Cron Jobs**, add a **Once Per Reboot (`@reboot`)** job:
   ```bash
   PATH=/FULL/PATH/TO/NODE_BIN_DIR:/home/YOUR_CPANEL_USER/.npm-global/bin:/usr/local/bin:/usr/bin:/bin cd /home/YOUR_CPANEL_USER/lkc-web && pm2 resurrect >/dev/null 2>&1
   ```
6. **Proxy domain traffic (`~/public_html/.htaccess`):** *(requires Apache `mod_proxy` enabled by your host)*
   ```apache
   RewriteEngine On
   RewriteRule ^(.*)$ http://127.0.0.1:3000/$1 [P,L]
   ```

---

#### Configuration A4 — Render / Railway
1. Connect your private Git repo (excluding `node_modules/` and `.env`).
2. Set:
   - **Build Command:** `npm install --legacy-peer-deps && npm run build`
   - **Start Command:** `npm start`
3. **Attach Persistent Storage (Required):** Mount a persistent disk/volume to `<app-root>/storage` (`/opt/render/project/src/storage` on Render; `/app/storage` on Railway) so `lkc_cms.db` and `storage/uploads/` survive redeploys.
4. Add Step 3 environment variables in the platform dashboard and deploy.

---

### Step 3: Possible Environment Variable Configurations

| Variable | Value | When to Set | Behavior |
| --- | --- | --- | --- |
| `NODE_ENV` | `production` | **Always in production** | Serves `dist/index.html` and rewrites `__LKC_STATIC_MODE__ = false` |
| `PORT` | `3000` *(or host port)* | VPS, PM2, Docker | **Do not set in cPanel Setup Node.js App** (Passenger binds automatically) |
| `CMS_SESSION_SECRET` | 64-char random hex (`openssl rand -hex 32`) | **Always in production** | Signs HMAC-SHA256 session tokens (`src/server/auth.ts`) |
| `CMS_BOOTSTRAP_ADMIN_EMAIL` | `admin@yourdomain.com` | **Fresh DB** | Creates an initial active `super_admin` if none exists in SQLite |
| `CMS_BOOTSTRAP_ADMIN_PASSWORD` | Password (`>= 8` chars) | **Fresh DB** | Sets password for that bootstrap `super_admin` (`must_change_password = 0`) |
| `COOKIE_SECURE` | *(unset)* / `true` / `false` | Optional | Unset = auto-detect HTTPS from `X-Forwarded-Proto`; set `false` only for plain `http://` testing; set `true` to force HTTPS cookies |
| `CMS_SEED_PASSWORD_MAKONI` *(also `SEREFETHE`, `MUTENHERI`, `CHAMBWERA`, `MADZIVANYIKA`)* | Password (`>= 8` chars) | Optional (first boot only) | Overrides CSPRNG passwords written to `storage/.initial_admin_credentials.txt` |

#### Node Version Configuration Edge Case
- **Node `22.18.0+` (Recommended):** `npm start` (`node server.ts`) executes natively with zero flags.
- **Node `22.6.0` – `22.17.x`:** TypeScript execution still uses the flag `--experimental-strip-types`. If `node -v` falls in this range, use `node --experimental-strip-types server.ts` (or set `interpreter_args: '--experimental-strip-types'` in PM2).
- **Node `<= 22.4`:** Unsupported (`node:sqlite` does not exist). Upgrade to Node `22.18+`.

---

### Step 4: Configure `storage/` Persistence, Database & Backups

`src/server/db.ts` reads and writes runtime data relative to the working directory (`<app-root>/storage`):

```text
<app-root>/storage/
├── lkc_cms.db                      # Main SQLite database (pages, staff, users, sessions, audit logs, enquiries)
├── lkc_cms.db-wal                  # SQLite write-ahead log (created while server runs)
├── lkc_cms.db-shm                  # SQLite shared-memory index (created while server runs)
├── .initial_admin_credentials.txt  # Mode 0600 CSPRNG temporary passwords for seeded admins
├── .password_reset_tokens.json     # Mode 0600 one-time password recovery tokens
└── uploads/                        # All uploaded photos/videos/PDFs served at /uploads/*
```

#### Possible Database Initialization Configurations
1. **Fresh Server Start (No `storage/` uploaded):**
   - On startup, `server.ts` creates `storage/lkc_cms.db` and `storage/uploads/`, applies migrations `v1`–`v16`, seeds all 8 departments/faculty/media, and creates:
     - Either your `CMS_BOOTSTRAP_ADMIN_EMAIL` / `CMS_BOOTSTRAP_ADMIN_PASSWORD` Super Admin, **or**
     - Prompts you with the **Initial Super Administrator Setup** screen the first time you open `/#admin`.
2. **Migrating Existing `storage/` from AI Studio / Another Server:**
   - Stop the source server cleanly first (so SQLite flushes WAL), or copy `lkc_cms.db`, `lkc_cms.db-wal`, and `lkc_cms.db-shm` **together** along with `storage/uploads/*`.
   - Ensure permissions after upload:
     ```bash
     chmod 755 storage storage/uploads
     chmod 644 storage/lkc_cms.db*
     ```
   - All existing admin users (e.g., `tapiwanorman95@gmail.com`), portraits, and edits carry over immediately.
3. **Safe Code Updates Later:**
   - Never delete or overwrite `storage/` when deploying code updates.
   - Replace only `src/`, `public/`, `scripts/`, `server.ts`, `package.json`, then run `npm install --legacy-peer-deps && npm run build` and restart the server.

---

## 3. Mode B — Step-by-Step Static + PHP Hosting Deployment (`dist/`)

Use this mode if your host does not run Node `22.5+` (e.g., standard PHP shared hosting).

1. **Make content edits first:** Edit and save any changes in a live Node instance (AI Studio or local `npm run dev`).
2. **Build the self-contained static export:**
   ```bash
   npm run build
   ```
   *(Or click **Export Static Website (.zip)** inside `#admin`.)*
3. **Upload `dist/` contents to `public_html/`:**
   - Extract/upload **every file and folder inside `dist/`** directly into `public_html/`:
     - `index.html`, `index.php`, `api.php`, `.htaccess`, `robots.txt`
     - `assets/` (CSS, `lkc-app.js`, logos, portraits in `assets/aistudio/`)
     - `uploads/` (static copies of uploaded media)
4. **Configure PHP Permissions & Mail (`api.php`):**
   - Ensure PHP (`7.4+` or `8.x`) has write permission to create `php_data/submissions.json` inside the web root (`chmod 755 public_html`).
   - Public forms (`admission`, `tour`, `prospectus`, `alumni`, `contact`, `boarding`) post to `api.php`, which stores submissions in `php_data/submissions.json` and sends email via PHP `mail()` (`From: no-reply@yourdomain.com`, delivered to `admissions@livingstonekolobeng.ac.bw, principal@lkc.ac.bw`).
   - Ensure `.htaccess` exists in `public_html/` for clean SPA routing and cache headers.
5. **Confirm expected behavior:** `#admin` and `#cms` are intentionally turned off in static mode (`__LKC_STATIC_MODE__ = true`). To publish future updates, rebuild `npm run build` and re-upload `dist/`.

---

## 4. Post-Deployment Verification Checklist

1. **Health Endpoint:** Visit `https://yourdomain.com/api/health` (Node mode) → returns `200 OK`:
   ```json
   {"ok":true,"database":"connected","timestamp":"..."}
   ```
2. **Static Flag Check:** View source on `https://yourdomain.com/` → confirms `window.__LKC_STATIC_MODE__=false;` in Node mode (or `true` in Static mode).
3. **Admin Login & Permissions:** Open `https://yourdomain.com/#admin`, sign in, and confirm overview counts and sections load cleanly.
4. **Upload & Restart Persistence Test:** Upload a test portrait inside `#admin`, verify it loads at `/uploads/<filename>`, restart Passenger/PM2, and verify both the CMS record and uploaded file remain intact.
5. **Theme & Shortcuts Check:** Toggle light/dark mode in the top header and press `?` to verify keyboard navigation shortcuts work cleanly.
