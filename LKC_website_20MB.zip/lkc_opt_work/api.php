<?php
/**
 * Livingstone Kolobeng College (LKC) - Shared Hosting PHP Form & Info Endpoint
 * Validates and sanitizes form submissions and emails admissions@livingstonekolobeng.ac.bw
 * and principal@lkc.ac.bw via PHP mail(). Returns JSON responses.
 */

header('Content-Type: application/json; charset=UTF-8');
header('X-Content-Type-Options: nosniff');

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

function lkc_clean_text($value, int $maxLen = 1000): string {
    $str = is_scalar($value) ? (string)$value : '';
    $str = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $str);
    $str = trim(strip_tags($str));
    if (function_exists('mb_substr')) {
        return mb_substr($str, 0, $maxLen, 'UTF-8');
    }
    return substr($str, 0, $maxLen);
}

function lkc_clean_header_value($value, int $maxLen = 200): string {
    $str = lkc_clean_text($value, $maxLen);
    return preg_replace('/[\r\n\t]+/', ' ', $str);
}

function lkc_clean_email($value): string {
    $raw = lkc_clean_header_value($value, 254);
    if ($raw === '' || preg_match('/[\r\n]/', $raw)) {
        return '';
    }
    $valid = filter_var($raw, FILTER_VALIDATE_EMAIL);
    return $valid !== false ? $valid : '';
}

function lkc_get_payload(): array {
    $raw = file_get_contents('php://input');
    if (is_string($raw) && $raw !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return array_merge($_POST, $decoded);
        }
    }
    return $_POST;
}

function lkc_send_college_mail(string $subject, string $body, string $replyToEmail = '', string $replyToName = ''): bool {
    $to = 'admissions@livingstonekolobeng.ac.bw, principal@lkc.ac.bw';
    $host = preg_replace('/[^a-zA-Z0-9.\-]/', '', $_SERVER['HTTP_HOST'] ?? 'lkcportal.com');
    if ($host === '' || $host === 'localhost') {
        $host = 'lkcportal.com';
    }
    $fromEmail = 'no-reply@' . preg_replace('/^www\./i', '', $host);

    $headers = [
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'From: Livingstone Kolobeng College Website <' . $fromEmail . '>',
        'X-Mailer: PHP/' . phpversion(),
    ];

    if ($replyToEmail !== '') {
        $safeName = lkc_clean_header_value($replyToName !== '' ? $replyToName : 'Website Visitor', 120);
        $headers[] = 'Reply-To: ' . $safeName . ' <' . $replyToEmail . '>';
    }

    return @mail($to, lkc_clean_header_value($subject, 180), $body, implode("\r\n", $headers));
}

function lkc_save_submission(string $action, string $reference, array $record): bool {
    $dir = __DIR__ . DIRECTORY_SEPARATOR . 'php_data';
    if (!is_dir($dir)) {
        if (!@mkdir($dir, 0750, true) && !is_dir($dir)) {
            return false;
        }
    }
    $htaccessPath = $dir . DIRECTORY_SEPARATOR . '.htaccess';
    if (!file_exists($htaccessPath)) {
        @file_put_contents($htaccessPath, "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
    }
    $indexGuard = $dir . DIRECTORY_SEPARATOR . 'index.php';
    if (!file_exists($indexGuard)) {
        @file_put_contents($indexGuard, "<?php http_response_code(403); exit;");
    }

    $storePath = $dir . DIRECTORY_SEPARATOR . 'submissions.json';
    $fp = @fopen($storePath, 'c+');
    if (!$fp) {
        return false;
    }
    if (!@flock($fp, LOCK_EX)) {
        @fclose($fp);
        return false;
    }
    $raw = stream_get_contents($fp);
    $existing = [];
    if (is_string($raw) && trim($raw) !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            $existing = $decoded;
        }
    }
    $existing[] = [
        'reference' => $reference,
        'action' => $action,
        'submittedAt' => gmdate('c'),
        'data' => $record,
    ];
    if (count($existing) > 500) {
        $existing = array_slice($existing, -500);
    }
    @ftruncate($fp, 0);
    @rewind($fp);
    $written = @fwrite($fp, json_encode($existing, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @fflush($fp);
    @flock($fp, LOCK_UN);
    @fclose($fp);
    return $written !== false;
}

function lkc_respond(int $code, array $payload): void {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

$data = lkc_get_payload();
$action = lkc_clean_header_value($_GET['action'] ?? ($data['action'] ?? ($data['type'] ?? 'info')), 40);
$action = strtolower($action);

if ($method === 'GET' && ($action === 'info' || $action === 'health')) {
    lkc_respond(200, [
        'status' => 'success',
        'ok' => true,
        'backend' => 'php',
        'institution' => 'Livingstone Kolobeng College',
        'cambridgeCentre' => 'BW812',
        'contacts' => [
            'phones' => ['+267 316 1140', '+267 316 2208'],
            'whatsapp' => 'https://wa.me/26778465196',
            'admissionsEmail' => 'admissions@livingstonekolobeng.ac.bw',
            'principalEmail' => 'principal@lkc.ac.bw',
        ],
    ]);
}

if ($method !== 'POST') {
    lkc_respond(405, [
        'status' => 'error',
        'ok' => false,
        'message' => 'Invalid request method. Please submit the form using POST or call +267 316 1140 / +267 316 2208.',
    ]);
}

$fallbackNotice = 'Unable to send email or save automatically on this server right now. Please contact our Admissions Office on +267 316 1140, +267 316 2208, or WhatsApp +267 78 465 196.';

switch ($action) {
    case 'admission':
    case 'admissions':
    case 'apply': {
        $first = lkc_clean_text($data['studentFirstName'] ?? '');
        $last = lkc_clean_text($data['studentLastName'] ?? '');
        $studentName = trim($first . ' ' . $last);
        if ($studentName === '') {
            $studentName = lkc_clean_text($data['studentName'] ?? ($data['student_name'] ?? ''));
        }
        $parentName = lkc_clean_text($data['parentName'] ?? ($data['parent_name'] ?? ''));
        $email = lkc_clean_email($data['parentEmail'] ?? ($data['email'] ?? ''));
        $phone = lkc_clean_text($data['parentPhone'] ?? ($data['phone'] ?? ''), 60);
        $grade = lkc_clean_text($data['gradeApplying'] ?? ($data['grade'] ?? 'Form 1'), 120);
        $boarding = lkc_clean_text($data['boardingStatus'] ?? 'Day', 80);
        $dob = lkc_clean_text($data['dob'] ?? '', 40);
        $currentSchool = lkc_clean_text($data['currentSchool'] ?? '', 200);
        $address = lkc_clean_text($data['parentAddress'] ?? '', 250);
        $assessmentDate = lkc_clean_text($data['assessmentDate'] ?? '', 120);
        $notes = lkc_clean_text($data['notes'] ?? '', 1500);
        $refCode = lkc_clean_header_value($data['referenceCode'] ?? '', 60);
        if ($refCode === '') {
            $refCode = 'LKC-ADM-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        }

        if ($studentName === '' || $parentName === '' || $email === '' || $phone === '') {
            lkc_respond(400, [
                'status' => 'error',
                'ok' => false,
                'message' => 'Please complete student name, parent/guardian name, a valid email address, and phone number.',
            ]);
        }

        $body = implode("\n", [
            "LIVINGSTONE KOLOBENG COLLEGE — NEW ADMISSIONS APPLICATION",
            "Reference Code: {$refCode}",
            "Submitted At: " . gmdate('Y-m-d H:i:s') . " UTC",
            "------------------------------------------------------------",
            "Student Name: {$studentName}",
            "Date of Birth: " . ($dob !== '' ? $dob : 'Not provided'),
            "Current / Previous School: " . ($currentSchool !== '' ? $currentSchool : 'Not provided'),
            "Grade Applying For: {$grade}",
            "Boarding Preference: {$boarding}",
            "Preferred Assessment Date: " . ($assessmentDate !== '' ? $assessmentDate : 'Not specified'),
            "",
            "Parent / Guardian: {$parentName}",
            "Email: {$email}",
            "Phone / WhatsApp: {$phone}",
            "Address: " . ($address !== '' ? $address : 'Not provided'),
            "",
            "Additional Notes:",
            $notes !== '' ? $notes : 'None provided.',
        ]);

        $saved = lkc_save_submission('admission', $refCode, [
            'studentName' => $studentName,
            'parentName' => $parentName,
            'email' => $email,
            'phone' => $phone,
            'grade' => $grade,
            'boarding' => $boarding,
            'assessmentDate' => $assessmentDate,
        ]);
        $mailed = lkc_send_college_mail("LKC Admissions Application [{$refCode}] — {$studentName}", $body, $email, $parentName);
        if (!$saved && !$mailed) {
            lkc_respond(500, [
                'status' => 'error',
                'ok' => false,
                'message' => $fallbackNotice,
            ]);
        }

        lkc_respond(200, [
            'status' => 'success',
            'ok' => true,
            'saved' => $saved,
            'mailSent' => $mailed,
            'reference' => $refCode,
            'message' => $mailed
                ? "Application {$refCode} for {$studentName} ({$grade}) has been emailed to LKC Admissions."
                : "Application {$refCode} for {$studentName} ({$grade}) has been recorded on the server. Please keep your reference or call +267 316 1140 if urgent.",
        ]);
    }

    case 'tour': {
        $name = lkc_clean_text($data['name'] ?? '', 150);
        $email = lkc_clean_email($data['email'] ?? '');
        $phone = lkc_clean_text($data['phone'] ?? '', 60);
        $date = lkc_clean_text($data['date'] ?? '', 120);
        $timeSlot = lkc_clean_text($data['timeSlot'] ?? '', 80);
        $interest = lkc_clean_text($data['interest'] ?? '', 120);
        $boardingInterest = lkc_clean_text($data['boardingInterest'] ?? '', 40);

        if ($name === '' || $email === '' || $phone === '') {
            lkc_respond(400, [
                'status' => 'error',
                'ok' => false,
                'message' => 'Please enter your full name, a valid email address, and telephone/WhatsApp number.',
            ]);
        }

        $refCode = 'LKC-TOUR-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        $body = implode("\n", [
            "LIVINGSTONE KOLOBENG COLLEGE — GUIDED CAMPUS TOUR BOOKING",
            "Booking Ref: {$refCode}",
            "Submitted At: " . gmdate('Y-m-d H:i:s') . " UTC",
            "------------------------------------------------------------",
            "Parent / Visitor Name: {$name}",
            "Email: {$email}",
            "Phone / WhatsApp: {$phone}",
            "Preferred Date: {$date}",
            "Time Slot: {$timeSlot}",
            "Academic Level Interest: {$interest}",
            "Include Boarding Tour: {$boardingInterest}",
        ]);

        $saved = lkc_save_submission('tour', $refCode, [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'date' => $date,
            'timeSlot' => $timeSlot,
            'interest' => $interest,
        ]);
        $mailed = lkc_send_college_mail("LKC Campus Tour Request [{$refCode}] — {$name}", $body, $email, $name);
        if (!$saved && !$mailed) {
            lkc_respond(500, [
                'status' => 'error',
                'ok' => false,
                'message' => $fallbackNotice,
            ]);
        }

        lkc_respond(200, [
            'status' => 'success',
            'ok' => true,
            'saved' => $saved,
            'mailSent' => $mailed,
            'reference' => $refCode,
            'message' => $mailed
                ? "Campus tour reservation {$refCode} confirmed and forwarded to LKC Admissions."
                : "Campus tour reservation {$refCode} recorded on the server. Please call +267 316 1140 to confirm your slot if urgent.",
        ]);
    }

    case 'prospectus': {
        $name = lkc_clean_text($data['name'] ?? '', 150);
        $email = lkc_clean_email($data['email'] ?? '');
        $phone = lkc_clean_text($data['phone'] ?? '', 60);
        $level = lkc_clean_text($data['level'] ?? 'General (Preschool to A-Levels)', 120);

        if ($name === '' || $email === '') {
            lkc_respond(400, [
                'status' => 'error',
                'ok' => false,
                'message' => 'Please enter your name and a valid email address to request the prospectus.',
            ]);
        }

        $refCode = 'LKC-PRO-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        $body = implode("\n", [
            "LIVINGSTONE KOLOBENG COLLEGE — PROSPECTUS & FEE PACK REQUEST",
            "Reference: {$refCode}",
            "Submitted At: " . gmdate('Y-m-d H:i:s') . " UTC",
            "------------------------------------------------------------",
            "Requester Name: {$name}",
            "Email: {$email}",
            "Phone / WhatsApp: " . ($phone !== '' ? $phone : 'Not provided'),
            "Intended Entry Level: {$level}",
        ]);

        $saved = lkc_save_submission('prospectus', $refCode, [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'level' => $level,
        ]);
        $mailed = lkc_send_college_mail("LKC Prospectus Request [{$refCode}] — {$name}", $body, $email, $name);
        if (!$saved && !$mailed) {
            lkc_respond(500, [
                'status' => 'error',
                'ok' => false,
                'message' => $fallbackNotice,
            ]);
        }

        lkc_respond(200, [
            'status' => 'success',
            'ok' => true,
            'saved' => $saved,
            'mailSent' => $mailed,
            'reference' => $refCode,
            'message' => $mailed
                ? "Prospectus request {$refCode} has been sent to our Admissions Registry."
                : "Prospectus request {$refCode} has been recorded on the server.",
        ]);
    }

    case 'alumni': {
        $name = lkc_clean_text($data['name'] ?? '', 150);
        $gradYear = lkc_clean_text($data['gradYear'] ?? '', 20);
        $email = lkc_clean_email($data['email'] ?? '');
        $phone = lkc_clean_text($data['phone'] ?? '', 60);
        $university = lkc_clean_text($data['university'] ?? ($data['organization'] ?? ''), 200);
        $location = lkc_clean_text($data['location'] ?? '', 150);
        $role = lkc_clean_text($data['currentRole'] ?? ($data['course'] ?? ''), 150);
        $honors = lkc_clean_text($data['cambridgeHonors'] ?? '', 150);
        $quote = lkc_clean_text($data['quote'] ?? '', 1000);

        if ($name === '' || $email === '' || $gradYear === '') {
            lkc_respond(400, [
                'status' => 'error',
                'ok' => false,
                'message' => 'Please enter your full name, graduation year, and a valid email address.',
            ]);
        }

        $refCode = 'LKC-ALU-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        $body = implode("\n", [
            "LIVINGSTONE KOLOBENG COLLEGE — ALUMNI REGISTRY SUBMISSION",
            "Reference: {$refCode}",
            "Submitted At: " . gmdate('Y-m-d H:i:s') . " UTC",
            "------------------------------------------------------------",
            "Alumnus Name: {$name}",
            "Graduation Year: {$gradYear}",
            "Email: {$email}",
            "Phone: " . ($phone !== '' ? $phone : 'Not provided'),
            "University / Organization: {$university}",
            "Location: {$location}",
            "Role / Degree: {$role}",
            "Cambridge Honors: {$honors}",
            "Message:",
            $quote !== '' ? $quote : 'None',
        ]);

        $saved = lkc_save_submission('alumni', $refCode, [
            'name' => $name,
            'gradYear' => $gradYear,
            'email' => $email,
            'phone' => $phone,
            'university' => $university,
            'location' => $location,
            'role' => $role,
        ]);
        $mailed = lkc_send_college_mail("LKC Alumni Registration [{$refCode}] — {$name}", $body, $email, $name);
        if (!$saved && !$mailed) {
            lkc_respond(500, [
                'status' => 'error',
                'ok' => false,
                'message' => $fallbackNotice,
            ]);
        }

        lkc_respond(200, [
            'status' => 'success',
            'ok' => true,
            'saved' => $saved,
            'mailSent' => $mailed,
            'id' => $refCode,
            'message' => $mailed
                ? "Thank you {$name}! Your alumni registration ({$refCode}) has been forwarded to College Administration for verification."
                : "Thank you {$name}! Your alumni registration ({$refCode}) has been recorded on the server for verification.",
        ]);
    }

    case 'contact':
    case 'enquiry': {
        $name = lkc_clean_text($data['name'] ?? '', 150);
        $email = lkc_clean_email($data['email'] ?? '');
        $phone = lkc_clean_text($data['phone'] ?? '', 60);
        $subject = lkc_clean_text($data['subject'] ?? 'General Admissions Query', 180);
        $message = lkc_clean_text($data['message'] ?? '', 3000);

        if ($name === '' || $email === '' || $message === '') {
            lkc_respond(400, [
                'status' => 'error',
                'ok' => false,
                'message' => 'Please provide your full name, a valid email address, and enquiry message.',
            ]);
        }

        $ticket = 'LKC-MSG-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        $body = implode("\n", [
            "LIVINGSTONE KOLOBENG COLLEGE — WEBSITE ENQUIRY",
            "Ticket Reference: {$ticket}",
            "Submitted At: " . gmdate('Y-m-d H:i:s') . " UTC",
            "------------------------------------------------------------",
            "From: {$name}",
            "Email: {$email}",
            "Phone: " . ($phone !== '' ? $phone : 'Not provided'),
            "Subject: {$subject}",
            "",
            "Message:",
            $message,
        ]);

        $saved = lkc_save_submission('contact', $ticket, [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'subject' => $subject,
            'message' => $message,
        ]);
        $mailed = lkc_send_college_mail("LKC Website Enquiry [{$ticket}]: {$subject}", $body, $email, $name);
        if (!$saved && !$mailed) {
            lkc_respond(500, [
                'status' => 'error',
                'ok' => false,
                'message' => $fallbackNotice,
            ]);
        }

        lkc_respond(200, [
            'status' => 'success',
            'ok' => true,
            'saved' => $saved,
            'mailSent' => $mailed,
            'ticket' => $ticket,
            'message' => $mailed
                ? "Enquiry {$ticket} has been delivered to Livingstone Kolobeng College Admissions & Principal's Office."
                : "Enquiry {$ticket} has been recorded securely on the server. For immediate assistance call +267 316 1140.",
        ]);
    }

    case 'boarding': {
        $name = lkc_clean_text($data['name'] ?? ($data['parentName'] ?? ''), 150);
        $email = lkc_clean_email($data['email'] ?? ($data['parentEmail'] ?? ''));
        $phone = lkc_clean_text($data['phone'] ?? ($data['parentPhone'] ?? ''), 60);
        $studentName = lkc_clean_text($data['studentName'] ?? '', 150);
        $gender = lkc_clean_text($data['gender'] ?? '', 40);
        $gradeApplying = lkc_clean_text($data['gradeApplying'] ?? '', 120);
        $entryTerm = lkc_clean_text($data['entryTerm'] ?? '', 80);
        $notes = lkc_clean_text($data['notes'] ?? ($data['specialNotes'] ?? ''), 1500);

        if ($name === '' || $email === '' || $phone === '') {
            lkc_respond(400, [
                'status' => 'error',
                'ok' => false,
                'message' => 'Please enter parent/guardian name, a valid email address, and telephone/WhatsApp number.',
            ]);
        }

        $ticket = 'LKC-BRD-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        $body = implode("\n", [
            "LIVINGSTONE KOLOBENG COLLEGE — BOARDING PLACEMENT INQUIRY",
            "Ticket Reference: {$ticket}",
            "Submitted At: " . gmdate('Y-m-d H:i:s') . " UTC",
            "------------------------------------------------------------",
            "Parent / Guardian: {$name}",
            "Email: {$email}",
            "Phone / WhatsApp: {$phone}",
            "Student Name: " . ($studentName !== '' ? $studentName : 'Not provided'),
            "House Allocation Preference: " . ($gender !== '' ? $gender : 'Not specified'),
            "Grade Applying For: " . ($gradeApplying !== '' ? $gradeApplying : 'Not specified'),
            "Intended Entry Term: " . ($entryTerm !== '' ? $entryTerm : 'Not specified'),
            "",
            "Notes / Dietary / Pastoral Requests:",
            $notes !== '' ? $notes : 'None provided.',
        ]);

        $saved = lkc_save_submission('boarding', $ticket, [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'studentName' => $studentName,
            'gender' => $gender,
            'gradeApplying' => $gradeApplying,
            'entryTerm' => $entryTerm,
        ]);
        $mailed = lkc_send_college_mail("LKC Boarding Inquiry [{$ticket}] — {$name}", $body, $email, $name);
        if (!$saved && !$mailed) {
            lkc_respond(500, [
                'status' => 'error',
                'ok' => false,
                'message' => $fallbackNotice,
            ]);
        }

        lkc_respond(200, [
            'status' => 'success',
            'ok' => true,
            'saved' => $saved,
            'mailSent' => $mailed,
            'ticket' => $ticket,
            'message' => $mailed
                ? "Boarding inquiry {$ticket} has been delivered to Livingstone Kolobeng College Administration."
                : "Boarding inquiry {$ticket} has been recorded securely on the server.",
        ]);
    }

    default:
        lkc_respond(404, [
            'status' => 'error',
            'ok' => false,
            'message' => 'Unsupported form action requested.',
        ]);
}
