<?php
/**
 * Livingstone Kolobeng College (LKC)
 * Cambridge Assessment International Education Examination Centre BW812
 * Gaborone, Botswana · Est. 2008 · Motto: "Thuto Ke Botshelo" (Education is Life)
 * 
 * PHP Server-Compatible Index & SPA Gateway
 */

// Start session for CSRF & flash messages
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle Form Submissions (PHP Server-side capability)
$feedback = null;
$calculatedFee = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'quick_apply') {
        $studentName = htmlspecialchars(trim($_POST['student_name'] ?? ''));
        $parentEmail = filter_var(trim($_POST['parent_email'] ?? ''), FILTER_VALIDATE_EMAIL);
        $phone = htmlspecialchars(trim($_POST['phone'] ?? ''));
        $grade = htmlspecialchars(trim($_POST['grade'] ?? 'Form 1'));
        $boarding = !empty($_POST['boarding']) ? 'Yes (Boarding Scholar)' : 'No (Day Scholar)';

        if ($studentName && $parentEmail && $phone) {
            $refId = 'LKC-' . date('Y') . '-' . strtoupper(substr(md5(uniqid()), 0, 5));
            $feedback = [
                'type' => 'success',
                'title' => 'Admissions Application Lodged Successfully!',
                'message' => "Application reference <strong>{$refId}</strong> generated for <strong>{$studentName}</strong> ({$grade}, {$boarding}). The Admissions Desk (+267 316 1140 / +267 316 2208) has been notified. You may also complete your enrollment documents directly on the official portal.",
                'portalLink' => 'https://lkcportal.com/?form=apply'
            ];
        } else {
            $feedback = [
                'type' => 'error',
                'title' => 'Incomplete Submission',
                'message' => 'Please provide the applicant student name, a valid parent email address, and a contact phone number.'
            ];
        }
    } elseif ($action === 'quick_contact') {
        $name = htmlspecialchars(trim($_POST['contact_name'] ?? ''));
        $email = filter_var(trim($_POST['contact_email'] ?? ''), FILTER_VALIDATE_EMAIL);
        $phone = htmlspecialchars(trim($_POST['contact_phone'] ?? ''));
        $department = htmlspecialchars(trim($_POST['department'] ?? 'Admissions & General'));
        $msg = htmlspecialchars(trim($_POST['message'] ?? ''));

        if ($name && $email && $msg) {
            $feedback = [
                'type' => 'success',
                'title' => 'Message Sent to Livingstone Kolobeng College',
                'message' => "Thank you, <strong>{$name}</strong>. Your enquiry regarding <strong>{$department}</strong> has been routed to our administrative registry. For urgent assistance, please telephone +267 316 1140 or message WhatsApp +267 78 465 196."
            ];
        } else {
            $feedback = [
                'type' => 'error',
                'title' => 'Missing Required Fields',
                'message' => 'Please ensure your name, email, and message are filled out correctly.'
            ];
        }
    } elseif ($action === 'calc_fees') {
        $level = $_POST['calc_level'] ?? 'form-1';
        $boardingReq = !empty($_POST['calc_boarding']);
        $transportZone = intval($_POST['calc_transport'] ?? 0);
        $siblings = max(0, intval($_POST['calc_siblings'] ?? 0));
        $payAnnual = !empty($_POST['calc_annual']);
        $isTrustFund = !empty($_POST['calc_trust_fund']);

        $tuitionRates = [
            'preschool' => ['name' => 'Preschool (Ages 3–5)', 'term' => 12500, 'terms' => 3, 'annual' => 37500],
            'form-1' => ['name' => 'Form 1 (Lower Secondary)', 'term' => 20000, 'terms' => 3, 'annual' => 60000],
            'form-2-3' => ['name' => 'Forms 2 & 3 (Lower Secondary & Pre-IGCSE)', 'term' => 22000, 'terms' => 3, 'annual' => 66000],
            'form-4' => ['name' => 'Form 4 (Cambridge IGCSE)', 'term' => 24000, 'terms' => 3, 'annual' => 72000],
            'form-5' => ['name' => 'Form 5 (Cambridge IGCSE - 2 Terms)', 'term' => 36000, 'terms' => 2, 'annual' => 72000],
            'a-levels' => ['name' => 'Cambridge AS & A-Levels (Sixth Form)', 'term' => 26667, 'terms' => 3, 'annual' => 80000],
        ];

        $selectedTuition = $tuitionRates[$level] ?? $tuitionRates['form-1'];
        $baseTuition = $selectedTuition['term'];
        $termsCount = $selectedTuition['terms'];
        
        // 5% per younger sibling discount on tuition only (ineligible if trust fund)
        $discountPct = (!$isTrustFund && $siblings > 0) ? min(15, $siblings * 5) : 0;
        $siblingDiscount = $baseTuition * ($discountPct / 100);
        $netTuition = $baseTuition - $siblingDiscount;

        $termBoarding = $boardingReq ? 24000 : 0;
        $annualBoarding = $boardingReq ? 70000 : 0;
        $transportFee = $transportZone;

        $termTotal = $netTuition + $termBoarding + $transportFee;
        $annualTotal = ($netTuition * $termsCount) + $annualBoarding + ($transportFee * $termsCount);

        $annualDiscount = 0;
        if ($payAnnual && !$isTrustFund) {
            $annualDiscount = $annualTotal * 0.025; // 2.5% prompt discount per Policy Item 8
            $annualTotal -= $annualDiscount;
        }

        $calculatedFee = [
            'levelName' => $selectedTuition['name'],
            'termsCount' => $termsCount,
            'baseTuition' => $baseTuition,
            'siblingDiscount' => $siblingDiscount,
            'discountPct' => $discountPct,
            'netTuition' => $netTuition,
            'termBoarding' => $termBoarding,
            'annualBoarding' => $annualBoarding,
            'transportFee' => $transportFee,
            'termTotal' => $termTotal,
            'annualTotal' => $annualTotal,
            'payAnnual' => $payAnnual,
            'annualDiscount' => $annualDiscount
        ];
    }
}

// Locate compiled Vite assets in dist/ if built
$cssFiles = glob(__DIR__ . '/dist/assets/*.css');
$jsFiles = glob(__DIR__ . '/dist/assets/*.js');
$distCss = !empty($cssFiles) ? str_replace(__DIR__, '', $cssFiles[0]) : null;
$distJs = !empty($jsFiles) ? str_replace(__DIR__, '', $jsFiles[0]) : null;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Livingstone Kolobeng College – Cambridge Syllabus Examination Centre · Gaborone, Botswana</title>
    <meta name="description" content="Official website and portal for Livingstone Kolobeng College (LKC) in Gaborone, Botswana. Cambridge International Examination Centre BW812. Preschool, Lower Secondary, IGCSE, and Cambridge A-Levels. Thuto Ke Botshelo.">
    <meta property="og:title" content="Livingstone Kolobeng College – Cambridge Syllabus Examination Centre · Est. 2008">
    <meta property="og:description" content="Discover world-class Cambridge education at Livingstone Kolobeng College in Gaborone, Botswana. Preschool to A-Levels across eight specialized departments.">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Livingstone Kolobeng College">
    <meta name="twitter:card" content="summary_large_image">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..800;1,400..800&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- CSS Loading: Built Vite CSS or Tailwind CDN fallback -->
    <?php if ($distCss): ?>
        <link rel="stylesheet" href="<?php echo htmlspecialchars($distCss); ?>">
    <?php else: ?>
        <script src="https://cdn.tailwindcss.com"></script>
        <script>
            tailwind.config = {
                theme: {
                    extend: {
                        colors: {
                            stone: {
                                50: '#fafaf9',
                                100: '#f5f5f4',
                                200: '#e7e5e4',
                                300: '#d6d3d1',
                                400: '#a8a29e',
                                500: '#78716c',
                                600: '#57534e',
                                700: '#44403c',
                                800: '#292524',
                                900: '#1c1917',
                                950: '#0c0a09'
                            },
                            amber: {
                                400: '#fbbf24',
                                500: '#f59e0b',
                                600: '#d97706',
                                700: '#b45309'
                            }
                        },
                        fontFamily: {
                            serif: ['"Playfair Display"', 'Georgia', 'serif'],
                            sans: ['"Plus Jakarta Sans"', 'sans-serif']
                        }
                    }
                }
            }
        </script>
    <?php endif; ?>

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .font-serif { font-family: 'Playfair Display', Georgia, serif; }
        html { scroll-behavior: smooth; }
    </style>

    <!-- Schema.org Educational Organization Structured Data -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "EducationalOrganization",
      "name": "Livingstone Kolobeng College",
      "alternateName": "LKC",
      "slogan": "Thuto Ke Botshelo",
      "foundingDate": "2008",
      "description": "Premier independent Cambridge International Examination Centre (BW812) in Gaborone, Botswana offering Preschool to Cambridge A-Levels.",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Plot 37225, Block 8, Extension 38",
        "addressLocality": "Gaborone",
        "addressRegion": "Gaborone West",
        "addressCountry": "BW"
      },
      "telephone": "+2673161140",
      "email": "principal@lkc.ac.bw",
      "url": "https://lkcportal.com"
    }
    </script>
</head>
<body class="bg-stone-50 text-stone-900 antialiased selection:bg-amber-100 selection:text-amber-900">

<!-- Server Notification Banners -->
<?php if ($feedback): ?>
<div class="fixed top-4 right-4 z-50 max-w-lg p-5 rounded-xl shadow-2xl border <?php echo $feedback['type'] === 'success' ? 'bg-emerald-950 text-white border-emerald-500' : 'bg-red-950 text-white border-red-500'; ?> transition-all duration-300">
    <div class="flex items-start gap-3">
        <div class="text-xl"><?php echo $feedback['type'] === 'success' ? '✓' : '⚠'; ?></div>
        <div class="flex-1">
            <h4 class="font-bold text-sm tracking-wide mb-1"><?php echo $feedback['title']; ?></h4>
            <p class="text-xs text-stone-200 leading-relaxed"><?php echo $feedback['message']; ?></p>
            <?php if (!empty($feedback['portalLink'])): ?>
                <div class="mt-3">
                    <a href="<?php echo htmlspecialchars($feedback['portalLink']); ?>" target="_blank" rel="noopener noreferrer" class="inline-block px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-semibold text-xs rounded transition">
                        Proceed to Portal Form →
                    </a>
                </div>
            <?php endif; ?>
        </div>
        <button onclick="this.parentElement.parentElement.remove()" class="text-stone-400 hover:text-white text-xs">✕</button>
    </div>
</div>
<?php endif; ?>

<!-- Mount container for React SPA or standalone PHP view -->
<div id="root">
    <div class="min-h-screen flex flex-col bg-stone-50 text-stone-900">

        <!-- Top Notification & Contact Bar -->
        <div class="bg-stone-950 text-stone-200 text-xs py-2 px-4 border-b border-stone-800">
            <div class="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
                <div class="flex flex-wrap items-center gap-2">
                    <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        Cambridge Centre BW812
                    </span>
                    <span class="text-stone-500">·</span>
                    <span class="text-stone-300">Plot 37225, Block 8, Gaborone West, Botswana</span>
                    <span class="text-stone-500">·</span>
                    <span class="text-amber-400 font-medium">Preschool to A-Levels Admissions Open</span>
                </div>
                <div class="flex items-center gap-4 text-xs font-mono">
                    <a href="tel:+2673161140" class="text-stone-300 hover:text-white">+267 316 1140</a>
                    <span class="text-stone-700">|</span>
                    <a href="tel:+2673162208" class="text-stone-300 hover:text-white">+267 316 2208</a>
                    <span class="text-stone-700">|</span>
                    <a href="https://wa.me/26778465196" target="_blank" rel="noopener noreferrer" class="text-emerald-400 hover:text-emerald-300 font-semibold">
                        WhatsApp: +267 78 465 196
                    </a>
                </div>
            </div>
        </div>

        <!-- Header -->
        <header class="bg-white border-b border-stone-200 sticky top-0 z-40 backdrop-blur-md bg-white/95">
            <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
                <a href="#" class="flex items-center gap-3">
                    <div class="w-12 h-12 flex items-center justify-center shrink-0">
                        <img src="/assets/aistudio/logo_33a39ff7.png" alt="Livingstone Kolobeng College Logo" class="w-12 h-12 object-contain">
                    </div>
                    <div>
                        <div class="font-serif font-bold text-lg sm:text-xl text-stone-900 tracking-tight">Livingstone Kolobeng College</div>
                        <div class="text-[11px] text-stone-500 flex items-center gap-2">
                            <span>Gaborone · Est. 2008</span>
                            <span>•</span>
                            <span class="text-amber-700 italic">"Thuto Ke Botshelo"</span>
                        </div>
                    </div>
                </a>

                <!-- Desktop Navigation Links -->
                <nav class="hidden lg:flex items-center gap-5 text-xs font-semibold uppercase tracking-wider text-stone-600">
                    <a href="#about" class="hover:text-stone-950 transition">Ethos</a>
                    <a href="#boarding" class="hover:text-stone-950 text-blue-900 transition">Boarding (100 Beds)</a>
                    <a href="#excursions" class="hover:text-stone-950 text-cyan-800 transition">Excursions</a>
                    <a href="#alumni" class="hover:text-stone-950 text-amber-800 transition">Alumni</a>
                    <a href="#departments" class="hover:text-stone-950 transition">8 Departments</a>
                    <a href="#academics" class="hover:text-stone-950 transition">Curriculum</a>
                    <a href="#fees" class="hover:text-stone-950 transition">Fees Schedule</a>
                    <a href="#contact" class="hover:text-stone-950 transition">Contact</a>
                </nav>

                <div class="flex items-center gap-3">
                    <a href="#admissions-form" class="px-4 py-2 text-xs font-semibold border border-stone-300 rounded-lg text-stone-800 hover:bg-stone-100 transition hidden sm:inline-block">
                        Quick Apply
                    </a>
                    <a href="https://lkcportal.com/?form=apply" target="_blank" rel="noopener noreferrer" class="px-5 py-2.5 bg-stone-950 hover:bg-stone-800 text-amber-400 rounded-lg text-xs font-semibold shadow-sm transition">
                        Official Portal ↗
                    </a>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="flex-1">

            <!-- Hero Section -->
            <section class="relative bg-stone-950 text-white overflow-hidden py-20 lg:py-28 px-6 border-b border-stone-800">
                <div class="absolute inset-0 opacity-15 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:24px_24px]"></div>
                
                <div class="relative max-w-5xl mx-auto text-center">
                    <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-stone-900/90 border border-stone-800 text-amber-400 text-xs font-mono uppercase tracking-widest mb-6">
                        <span>Cambridge Assessment International Education</span>
                        <span>·</span>
                        <span>Centre BW812</span>
                    </div>

                    <h1 class="text-4xl sm:text-6xl font-serif font-bold tracking-tight text-balance mb-6 leading-tight">
                        Excellence in Cambridge Education in Gaborone
                    </h1>

                    <p class="text-stone-300 text-base sm:text-xl max-w-3xl mx-auto mb-10 leading-relaxed">
                        Named in honor of the historic Kolobeng mission founded in 1847. Livingstone Kolobeng College delivers rigorous, values-based scholarship from Preschool to Cambridge A-Levels across eight specialized academic departments.
                    </p>

                    <div class="flex flex-wrap items-center justify-center gap-4 mb-16">
                        <a href="https://lkcportal.com/?form=apply" target="_blank" rel="noopener noreferrer" class="px-7 py-3.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-sm rounded-xl shadow-lg transition">
                            Apply for 2026 / 2027 Academic Year
                        </a>
                        <a href="#fees" class="px-6 py-3.5 bg-stone-800/90 hover:bg-stone-700 text-white font-medium text-sm rounded-xl border border-stone-700 transition">
                            Calculate Tuition & Boarding Fees
                        </a>
                        <a href="#departments" class="px-6 py-3.5 bg-transparent hover:bg-stone-900 text-stone-300 font-medium text-sm rounded-xl border border-stone-800 transition">
                            Explore 8 Departments
                        </a>
                    </div>

                    <!-- Authentic Key Statistics Grid -->
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-left pt-10 border-t border-stone-800/80">
                        <div class="p-4 rounded-xl bg-stone-900/80 border border-stone-800">
                            <div class="text-3xl font-serif font-bold text-amber-400">98.4%</div>
                            <div class="text-xs font-semibold text-white mt-1">Cambridge Pass Rate</div>
                            <div class="text-[11px] text-stone-400 mt-0.5">A* to C grades across IGCSE & A-Levels</div>
                        </div>
                        <div class="p-4 rounded-xl bg-stone-900/80 border border-stone-800">
                            <div class="text-3xl font-serif font-bold text-amber-400">100</div>
                            <div class="text-xs font-semibold text-white mt-1">Boarding Capacity</div>
                            <div class="text-[11px] text-stone-400 mt-0.5">39 enrolled · 61 spaces open</div>
                        </div>
                        <div class="p-4 rounded-xl bg-stone-900/80 border border-stone-800">
                            <div class="text-3xl font-serif font-bold text-amber-400">80</div>
                            <div class="text-xs font-semibold text-white mt-1">Specialist Faculty</div>
                            <div class="text-[11px] text-stone-400 mt-0.5">10:1 student-to-educator ratio</div>
                        </div>
                        <div class="p-4 rounded-xl bg-stone-900/80 border border-stone-800">
                            <div class="text-3xl font-serif font-bold text-amber-400">100%</div>
                            <div class="text-xs font-semibold text-white mt-1">University Progression</div>
                            <div class="text-[11px] text-stone-400 mt-0.5">Global placements in UK, RSA, USA & EU</div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Institutional Heritage, Managing Director, Principal & SMT -->
            <section id="about" class="py-20 px-6 max-w-7xl mx-auto">
                <div class="max-w-3xl mb-12">
                    <div class="text-xs uppercase font-mono font-bold tracking-widest text-amber-600 mb-2">Heritage & Ethos</div>
                    <h2 class="text-3xl sm:text-4xl font-serif font-bold text-stone-900 mb-4">
                        Rooted in History, Focused on Global Leadership
                    </h2>
                    <p class="text-stone-600 text-sm sm:text-base leading-relaxed">
                        Named in honor of the historic Kolobeng mission founded in 1847 by Dr. David Livingstone and Kgosi Sechele I. Guided by our national motto <span class="font-serif italic font-semibold text-stone-900">"Thuto Ke Botshelo"</span> (Education is Life), we prepare young men and women for entry to premier global universities and purposeful leadership.
                    </p>
                </div>

                <!-- 1. MANAGING DIRECTOR'S ADDRESS (ON TOP OF PRINCIPAL) -->
                <div class="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden mb-10">
                    <div class="p-4 bg-stone-900 text-white flex items-center justify-between border-b border-stone-800">
                        <div class="flex items-center gap-2">
                            <span class="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                            <span class="text-xs font-mono font-bold uppercase tracking-wider text-amber-400">Managing Directorate · Executive Governance</span>
                        </div>
                        <span class="text-xs text-stone-400 font-mono">Est. 2008 · Gaborone</span>
                    </div>
                    <div class="p-6 sm:p-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                        <div class="md:col-span-4 flex flex-col items-center text-center">
                            <div class="w-44 h-52 rounded-2xl overflow-hidden border-2 border-stone-300 shadow-md bg-stone-100">
                                <img src="/assets/aistudio/managing_director_nilima_bakaya_e0a81873.jpg" alt="Mrs Nilima Bakaya" class="w-full h-full object-cover object-top">
                            </div>
                            <div class="mt-4">
                                <h3 class="font-serif font-bold text-lg text-stone-900">Mrs Nilima Bakaya</h3>
                                <div class="text-xs font-semibold text-amber-800">Managing Director & Executive Governance</div>
                            </div>
                        </div>
                        <div class="md:col-span-8">
                            <div class="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold mb-2">Message from the Managing Director</div>
                            <p class="text-stone-700 text-xs sm:text-sm leading-relaxed mb-4">
                                "Welcome to Livingstone Kolobeng College. Since our inception in 2008, our mission has been clear: to provide learners in Botswana with a world-class Cambridge education grounded in character, ambition, and cultural heritage. We have invested substantially in specialized science laboratories, digital learning spaces, modern residential boarding hostels, and passionate master teachers. At LKC, our vision is to equip every child with the intellectual competence and moral fortitude required to thrive in a rapidly changing global society. We welcome you to experience education where excellence is a lived reality."
                            </p>
                            <div class="text-[11px] text-stone-500 font-mono pt-3 border-t border-stone-100">
                                Institutional Stewardship, Campus Infrastructure & Governance
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 2. PRINCIPAL'S ADDRESS (UNDERNEATH MANAGING DIRECTOR) -->
                <div class="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden mb-12">
                    <div class="p-4 bg-stone-900 text-white flex items-center justify-between border-b border-stone-800">
                        <div class="flex items-center gap-2">
                            <span class="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                            <span class="text-xs font-mono font-bold uppercase tracking-wider text-amber-400">Principal's Desk · Academic Standards</span>
                        </div>
                        <span class="text-xs text-stone-400 font-mono">Cambridge Centre BW812</span>
                    </div>
                    <div class="p-6 sm:p-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                        <div class="md:col-span-4 flex flex-col items-center text-center">
                            <div class="w-44 h-52 rounded-2xl overflow-hidden border-2 border-stone-300 shadow-md bg-stone-100">
                                <img src="/assets/aistudio/principal_dr_jeff_ramsay_a61fcb25.jpg" alt="Dr Jeff Ramsay" class="w-full h-full object-cover object-top">
                            </div>
                            <div class="mt-4">
                                <h3 class="font-serif font-bold text-lg text-stone-900">Dr Jeff Ramsay</h3>
                                <div class="text-xs font-semibold text-amber-800">Principal & Senior Academician</div>
                            </div>
                        </div>
                        <div class="md:col-span-8">
                            <div class="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold mb-2">Address from the Principal's Desk</div>
                            <p class="text-stone-700 text-xs sm:text-sm leading-relaxed mb-4">
                                "It is an honor to guide the academic destiny of Livingstone Kolobeng College. As Cambridge International Examination Centre BW812, we hold ourselves and our students to uncompromising standards of intellectual inquiry. Our educational philosophy blends British Cambridge curricular rigor with the cherished Setswana principle of Botho—fostering mutual respect, resilience, and civic integrity. From Preschool to Cambridge A-Levels, we nurture curious minds, critical thinkers, and leaders ready to excel in top global universities."
                            </p>
                            <div class="text-[11px] text-stone-500 font-mono pt-3 border-t border-stone-100">
                                Cambridge Assessment Standards, Academic Direction & Faculty Mentorship
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 3. SENIOR MANAGEMENT TEAM (SMT) -->
                <div>
                    <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6">
                        <div>
                            <div class="text-xs uppercase font-mono font-bold tracking-widest text-amber-600 mb-1">Executive Directorate</div>
                            <h3 class="text-2xl font-serif font-bold text-stone-900">Senior Management Team (SMT)</h3>
                        </div>
                        <span class="text-xs font-mono text-stone-500 bg-stone-200/80 px-2.5 py-1 rounded">LKC SMT</span>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        <!-- Mr K Adu -->
                        <div class="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden flex flex-col justify-between">
                            <div>
                                <div class="h-48 bg-stone-100 overflow-hidden">
                                    <img src="/assets/aistudio/Mr_K_Adu_portrait_c3a680c6.jpg" alt="Mr K Adu" class="w-full h-full object-cover object-top">
                                </div>
                                <div class="p-4">
                                    <h4 class="font-serif font-bold text-stone-900 text-base">Mr K Adu</h4>
                                    <div class="text-xs font-semibold text-amber-800 mt-0.5 mb-2">Director of A-Levels</div>
                                    <p class="text-xs text-stone-600 leading-relaxed">
                                        Directs the Cambridge International AS and A-Level Sixth Form program, pre-university specialization, and university matriculation.
                                    </p>
                                </div>
                            </div>
                            <div class="p-3 bg-stone-50 border-t border-stone-100 text-[11px] font-mono text-stone-500">
                                Sixth Form & Placements
                            </div>
                        </div>

                        <!-- Dr Fedious Mutenheri -->
                        <div class="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden flex flex-col justify-between">
                            <div>
                                <div class="h-48 bg-stone-100 overflow-hidden">
                                    <img src="/assets/aistudio/vp_dr_fedious_mutenheri_e1569921.jpg" alt="Dr Fedious Mutenheri" class="w-full h-full object-cover object-top">
                                </div>
                                <div class="p-4">
                                    <h4 class="font-serif font-bold text-stone-900 text-base">Dr Fedious Mutenheri</h4>
                                    <div class="text-xs font-semibold text-amber-800 mt-0.5 mb-2">Vice Principal of All School Affairs</div>
                                    <p class="text-xs text-stone-600 leading-relaxed">
                                        Coordinates academic curriculum delivery, Cambridge examination compliance, departmental quality audits, and pastoral care.
                                    </p>
                                </div>
                            </div>
                            <div class="p-3 bg-stone-50 border-t border-stone-100 text-[11px] font-mono text-stone-500">
                                Academic Standards & Welfare
                            </div>
                        </div>

                        <!-- Mr R Nyika -->
                        <div class="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden flex flex-col justify-between">
                            <div>
                                <div class="h-48 bg-stone-100 overflow-hidden">
                                    <img src="/assets/aistudio/vp_mr_r_nyika_88c39b96.jpg" alt="Mr R Nyika" class="w-full h-full object-cover object-top">
                                </div>
                                <div class="p-4">
                                    <h4 class="font-serif font-bold text-stone-900 text-base">Mr R Nyika</h4>
                                    <div class="text-xs font-semibold text-amber-800 mt-0.5 mb-2">Vice Principal Administration</div>
                                    <p class="text-xs text-stone-600 leading-relaxed">
                                        Directs campus operations, residential boarding hostels (Sir Ketumile and Lady Olebile Masire dormitories), and health & safety.
                                    </p>
                                </div>
                            </div>
                            <div class="p-3 bg-stone-50 border-t border-stone-100 text-[11px] font-mono text-stone-500">
                                Operations & Boarding Hostels
                            </div>
                        </div>

                        <!-- Ms Tracey Munodawafa -->
                        <div class="bg-white rounded-xl border border-stone-200 shadow-xs overflow-hidden flex flex-col justify-between">
                            <div>
                                <div class="h-48 bg-stone-100 overflow-hidden">
                                    <img src="/assets/aistudio/Ms_Tracey_Munodawafa_portrait_311fd817.jpg" alt="Ms Tracey Munodawafa" class="w-full h-full object-cover object-top">
                                </div>
                                <div class="p-4">
                                    <h4 class="font-serif font-bold text-stone-900 text-base">Ms Tracey Munodawafa</h4>
                                    <div class="text-xs font-semibold text-amber-800 mt-0.5 mb-2">Deputy Vice Principal Administration</div>
                                    <p class="text-xs text-stone-600 leading-relaxed">
                                        Assists in administrative oversight, staff scheduling, parent liaison communications, and institutional regulatory compliance.
                                    </p>
                                </div>
                            </div>
                            <div class="p-3 bg-stone-50 border-t border-stone-100 text-[11px] font-mono text-stone-500">
                                Administration & Public Liaison
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Eight Specialized Academic Departments -->
            <section id="departments" class="py-20 px-6 bg-stone-100 border-y border-stone-200">
                <div class="max-w-7xl mx-auto">
                    <div class="text-center max-w-3xl mx-auto mb-14">
                        <div class="text-xs uppercase font-mono font-bold tracking-widest text-amber-600 mb-2">Cambridge Faculty Structure</div>
                        <h2 class="text-3xl sm:text-4xl font-serif font-bold text-stone-900 mb-4">
                            Eight Specialized Academic Departments
                        </h2>
                        <p class="text-stone-600 text-sm sm:text-base leading-relaxed">
                            Each department at Livingstone Kolobeng College is staffed by dedicated Cambridge specialists, equipped with modern laboratories, libraries, and multimedia resources.
                        </p>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <!-- 1. Mathematics -->
                        <div class="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm flex flex-col justify-between hover:border-amber-400 transition">
                            <div>
                                <div class="text-xs font-mono font-bold text-amber-700 uppercase">Syllabus 0580 / 9709</div>
                                <h3 class="font-serif font-bold text-lg text-stone-900 mt-1 mb-2">Mathematics</h3>
                                <p class="text-xs text-stone-600 leading-relaxed mb-4">
                                    Pure Mathematics, Statistics, Mechanics, and Additional Maths from Form 1 through A-Level Further Calculus.
                                </p>
                            </div>
                            <div class="text-[11px] font-mono text-stone-500 pt-3 border-t border-stone-100">
                                Maths Olympiads · Calculus Workshops
                            </div>
                        </div>

                        <!-- 2. Science -->
                        <div class="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm flex flex-col justify-between hover:border-amber-400 transition">
                            <div>
                                <div class="text-xs font-mono font-bold text-amber-700 uppercase">Physics · Chem · Bio</div>
                                <h3 class="font-serif font-bold text-lg text-stone-900 mt-1 mb-2">Science Department</h3>
                                <p class="text-xs text-stone-600 leading-relaxed mb-4">
                                    State-of-the-art wet chemistry, mechanics physics, and biology laboratories equipped for UCLES experimental examinations.
                                </p>
                            </div>
                            <div class="text-[11px] font-mono text-stone-500 pt-3 border-t border-stone-100">
                                3 Science Labs · Weekly Practicals
                            </div>
                        </div>

                        <!-- 3. Creatives -->
                        <div class="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm flex flex-col justify-between hover:border-amber-400 transition">
                            <div>
                                <div class="text-xs font-mono font-bold text-amber-700 uppercase">Art · Music · Marimba</div>
                                <h3 class="font-serif font-bold text-lg text-stone-900 mt-1 mb-2">Creatives & Performing Arts</h3>
                                <p class="text-xs text-stone-600 leading-relaxed mb-4">
                                    Visual fine arts, portfolio design, traditional African marimba ensembles, and choral performance.
                                </p>
                            </div>
                            <div class="text-[11px] font-mono text-stone-500 pt-3 border-t border-stone-100">
                                Marimba Band · Fine Arts Studio
                            </div>
                        </div>

                        <!-- 4. PE & Athletics -->
                        <div class="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm flex flex-col justify-between hover:border-amber-400 transition">
                            <div>
                                <div class="text-xs font-mono font-bold text-amber-700 uppercase">Jaguars Athletics</div>
                                <h3 class="font-serif font-bold text-lg text-stone-900 mt-1 mb-2">Physical Education</h3>
                                <p class="text-xs text-stone-600 leading-relaxed mb-4">
                                    Home of the Kolobeng Jaguars. Competitive athletics, rugby, basketball, swimming, netball, and fitness conditioning.
                                </p>
                            </div>
                            <div class="text-[11px] font-mono text-stone-500 pt-3 border-t border-stone-100">
                                BISA Champions · Swimming Pool
                            </div>
                        </div>

                        <!-- 5. Humanities -->
                        <div class="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm flex flex-col justify-between hover:border-amber-400 transition">
                            <div>
                                <div class="text-xs font-mono font-bold text-amber-700 uppercase">History · Geography</div>
                                <h3 class="font-serif font-bold text-lg text-stone-900 mt-1 mb-2">Humanities Department</h3>
                                <p class="text-xs text-stone-600 leading-relaxed mb-4">
                                    Botswana and Southern African history, 20th-century world diplomacy, geomorphology, and development studies.
                                </p>
                            </div>
                            <div class="text-[11px] font-mono text-stone-500 pt-3 border-t border-stone-100">
                                Model UN · Field Expeditions
                            </div>
                        </div>

                        <!-- 6. Languages -->
                        <div class="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm flex flex-col justify-between hover:border-amber-400 transition">
                            <div>
                                <div class="text-xs font-mono font-bold text-amber-700 uppercase">English · Setswana · French</div>
                                <h3 class="font-serif font-bold text-lg text-stone-900 mt-1 mb-2">Languages Department</h3>
                                <p class="text-xs text-stone-600 leading-relaxed mb-4">
                                    First Language English, English Literature, Setswana language & cultural traditions, and French diplomatic fluency.
                                </p>
                            </div>
                            <div class="text-[11px] font-mono text-stone-500 pt-3 border-t border-stone-100">
                                SADC Debating · Public Speaking
                            </div>
                        </div>

                        <!-- 7. Commercials -->
                        <div class="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm flex flex-col justify-between hover:border-amber-400 transition">
                            <div>
                                <div class="text-xs font-mono font-bold text-amber-700 uppercase">Accounting · Economics · Business</div>
                                <h3 class="font-serif font-bold text-lg text-stone-900 mt-1 mb-2">Commercials Department</h3>
                                <p class="text-xs text-stone-600 leading-relaxed mb-4">
                                    Financial accounting, managerial ledgers, micro & macroeconomics, and enterprise management.
                                </p>
                            </div>
                            <div class="text-[11px] font-mono text-stone-500 pt-3 border-t border-stone-100">
                                Young Entrepreneurs · Bank of Botswana
                            </div>
                        </div>

                        <!-- 8. ICT & Logistics -->
                        <div class="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm flex flex-col justify-between hover:border-amber-400 transition">
                            <div>
                                <div class="text-xs font-mono font-bold text-amber-700 uppercase">Computer Science · Robotics</div>
                                <h3 class="font-serif font-bold text-lg text-stone-900 mt-1 mb-2">ICT & Logistics</h3>
                                <p class="text-xs text-stone-600 leading-relaxed mb-4">
                                    Python programming, algorithmic thinking, database SQL, computer architecture, and VEX robotics.
                                </p>
                            </div>
                            <div class="text-[11px] font-mono text-stone-500 pt-3 border-t border-stone-100">
                                2 Fiber Computer Labs · Robotics Club
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Curriculum Streams (Preschool to A-Levels) -->
            <section id="academics" class="py-20 px-6 max-w-7xl mx-auto">
                <div class="text-center max-w-3xl mx-auto mb-14">
                    <div class="text-xs uppercase font-mono font-bold tracking-widest text-amber-600 mb-2">Structured Academic Continuum</div>
                    <h2 class="text-3xl sm:text-4xl font-serif font-bold text-stone-900 mb-4">
                        Preschool to Cambridge A-Levels
                    </h2>
                    <p class="text-stone-600 text-sm sm:text-base leading-relaxed">
                        Accredited Cambridge Assessment International Education Centre (BW812). Our students develop the independent analytical faculties required for world-class tertiary institutions.
                    </p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Preschool & Lower Secondary -->
                    <div class="p-6 bg-stone-50 rounded-2xl border border-stone-200">
                        <div class="text-xs font-mono font-bold text-amber-700 uppercase mb-1">Foundational Tiers</div>
                        <h3 class="font-serif font-bold text-xl text-stone-900 mb-2">Preschool & Lower Secondary</h3>
                        <p class="text-xs text-stone-600 leading-relaxed mb-4">
                            Preschool (Ages 3–5) builds foundational literacy and motor development. Forms 1–2 deliver the broad 11-subject Cambridge framework covering sciences, languages, humanities, and arts.
                        </p>
                        <div class="text-xs text-stone-700 space-y-1 font-mono">
                            <div>• Early Years Discovery & Phonics</div>
                            <div>• Cambridge Lower Secondary (0862)</div>
                            <div>• Form 3 Pre-IGCSE Bridge Year</div>
                        </div>
                    </div>

                    <!-- Cambridge IGCSE -->
                    <div class="p-6 bg-stone-900 text-white rounded-2xl border border-stone-800 shadow-md">
                        <div class="text-xs font-mono font-bold text-amber-400 uppercase mb-1">Forms 4 & 5 (Ages 14–16)</div>
                        <h3 class="font-serif font-bold text-xl text-white mb-2">Cambridge IGCSE</h3>
                        <p class="text-xs text-stone-300 leading-relaxed mb-4">
                            The world's most popular international secondary qualification. Rigorous two-year syllabus leading to external Cambridge examinations across 8 to 9 subjects.
                        </p>
                        <div class="text-xs text-stone-300 space-y-1 font-mono">
                            <div>• Sciences (0625, 0620, 0610)</div>
                            <div>• Extended Maths (0580) & First Lang English (0500)</div>
                            <div>• Commercials, ICT (0478), and French</div>
                        </div>
                    </div>

                    <!-- Cambridge A-Levels -->
                    <div class="p-6 bg-stone-50 rounded-2xl border border-stone-200">
                        <div class="text-xs font-mono font-bold text-amber-700 uppercase mb-1">Sixth Form (Forms 6.1 & 6.2)</div>
                        <h3 class="font-serif font-bold text-xl text-stone-900 mb-2">Cambridge AS & A Levels</h3>
                        <p class="text-xs text-stone-600 leading-relaxed mb-4">
                            The gold standard for admission into Ivy League, Russell Group, and top southern African universities. In-depth subject mastery across 3 to 4 specialized subjects.
                        </p>
                        <div class="text-xs text-stone-700 space-y-1 font-mono">
                            <div>• Pure Maths, Mechanics & Statistics (9709)</div>
                            <div>• Advanced Physics, Chemistry, Biology</div>
                            <div>• Economics, Accounting & Business</div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Campus Life & Boarding -->
            <section id="campus-life" class="py-20 px-6 bg-stone-100 border-y border-stone-200">
                <div class="max-w-7xl mx-auto">
                    <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
                        <div class="lg:col-span-6">
                            <div class="text-xs uppercase font-mono font-bold tracking-widest text-amber-600 mb-2">Residential Life & Pastoral Care</div>
                            <h2 class="text-3xl sm:text-4xl font-serif font-bold text-stone-900 mb-6">
                                Masire Boarding Hostels & The Kolobeng Jaguars
                            </h2>
                            <p class="text-stone-600 text-sm sm:text-base leading-relaxed mb-6">
                                At Livingstone Kolobeng College, our state-of-the-art boarding facilities accommodate up to 100 students (with 39 currently in residence across both wings and 61 spaces open for admission), with dedicated residences for boys and girls: the <strong>Lady Olebile Masire Boarding House</strong> (up to 50 girls) and the <strong>Sir Ketumile Masire Boarding House</strong> (up to 50 boys).
                            </p>
                            <div class="space-y-3 text-xs text-stone-700">
                                <div class="flex items-start gap-2">
                                    <span class="text-emerald-600 font-bold">✓</span>
                                    <span><strong>Two Historic Houses:</strong> Lady Olebile Masire (House Mistress Ms T Tumotumo) & Sir Ketumile Masire (House Master Mr Anderson Dube).</span>
                                </div>
                                <div class="flex items-start gap-2">
                                    <span class="text-emerald-600 font-bold">✓</span>
                                    <span><strong>Nutritional Dining:</strong> 3 hot balanced meals daily (Breakfast 06:15–06:30, Lunch 13:00–14:00, Dinner 18:00–18:30).</span>
                                </div>
                                <div class="flex items-start gap-2">
                                    <span class="text-emerald-600 font-bold">✓</span>
                                    <span><strong>Evening Prep Hall:</strong> Structured supervised study (18:30–20:30) with academic tutors and staggered lights-out.</span>
                                </div>
                                <div class="flex items-start gap-2">
                                    <span class="text-emerald-600 font-bold">✓</span>
                                    <span><strong>Biometric Security:</strong> 24/7 security perimeter, study suites, high-speed internet, and on-site nurse.</span>
                                </div>
                            </div>
                        </div>

                        <div class="lg:col-span-6 grid grid-cols-2 gap-4">
                            <div class="p-5 bg-white rounded-2xl border border-stone-200 shadow-sm">
                                <div class="text-2xl font-serif font-bold text-stone-900">100 Beds</div>
                                <div class="text-xs font-semibold text-stone-700 mt-1">Boarding Capacity</div>
                                <div class="text-[11px] text-amber-700 font-semibold mt-1">39 Enrolled · 61 Open Spaces</div>
                            </div>
                            <div class="p-5 bg-white rounded-2xl border border-stone-200 shadow-sm">
                                <div class="text-2xl font-serif font-bold text-stone-900">50 / 50</div>
                                <div class="text-xs font-semibold text-stone-700 mt-1">Girls & Boys Wings</div>
                                <div class="text-[11px] text-stone-500 mt-1">Dedicated campus bus transit across Gaborone zones</div>
                            </div>
                            <div class="p-5 bg-white rounded-2xl border border-stone-200 shadow-sm">
                                <div class="text-2xl font-serif font-bold text-stone-900">4 Houses</div>
                                <div class="text-xs font-semibold text-stone-700 mt-1">Inter-House Championship</div>
                                <div class="text-[11px] text-stone-500 mt-1">Livingstone, Kolobeng, Khama & Sechele</div>
                            </div>
                            <div class="p-5 bg-white rounded-2xl border border-stone-200 shadow-sm">
                                <div class="text-2xl font-serif font-bold text-stone-900">Jaguars</div>
                                <div class="text-xs font-semibold text-stone-700 mt-1">Varsity Athletics</div>
                                <div class="text-[11px] text-stone-500 mt-1">Rugby, basketball, football, swimming & track</div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Transparent Fee Schedule & PHP Calculator -->
            <section id="fees" class="py-20 px-6 max-w-7xl mx-auto">
                <div class="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
                    <div class="max-w-3xl">
                        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-amber-500/10 border border-amber-500/20 text-amber-900 text-xs font-mono uppercase tracking-wider mb-2">
                            <span>Official 2026 Academic Year</span>
                            <span>·</span>
                            <span class="font-semibold">IGCSE School Fees Policy</span>
                        </div>
                        <h2 class="text-3xl sm:text-4xl font-serif font-bold text-stone-900 mb-2">
                            2026 Tuition, Boarding & Installments Policy
                        </h2>
                        <p class="text-stone-600 text-sm sm:text-base leading-relaxed">
                            Approved schedules in Botswana Pula (BWP). Includes installment schedules, 2.5% prompt payment discount, sibling concessions, and 3 official bank accounts.
                        </p>
                    </div>
                    <div class="flex items-center gap-3">
                        <a href="/assets/aistudio/School_Fees_Policy_2026_IGCSE_f50e8781.pdf" target="_blank" download="Livingstone_Kolobeng_College_Fees_Policy_2026.pdf" class="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs rounded-lg transition shadow-xs flex items-center gap-2">
                            <span>Download Official Policy PDF ↗</span>
                        </a>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-12">
                    <!-- Standard Fee Table -->
                    <div class="lg:col-span-7 bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
                        <div class="p-6 bg-stone-900 text-white flex items-center justify-between">
                            <div>
                                <h3 class="font-serif font-bold text-lg">Official 2026 Tuition Schedules</h3>
                                <div class="text-xs text-stone-300">Payable in two installments per term</div>
                            </div>
                            <span class="text-xs font-mono text-amber-400">Currency: BWP</span>
                        </div>
                        <div class="divide-y divide-stone-200 text-xs sm:text-sm">
                            <div class="p-4 flex items-center justify-between">
                                <div>
                                    <div class="font-bold text-stone-900">Form 1 (Entry)</div>
                                    <div class="text-stone-500 text-xs">Term Fees: P 20,000.00 (1st Pay P10k / 2nd Pay P10k)</div>
                                </div>
                                <div class="text-right">
                                    <div class="font-bold text-stone-900">BWP 20,000 <span class="text-xs font-normal text-stone-500">/ term</span></div>
                                    <div class="text-stone-500 text-xs font-mono">BWP 60,000 / year</div>
                                </div>
                            </div>
                            <div class="p-4 flex items-center justify-between">
                                <div>
                                    <div class="font-bold text-stone-900">Form 2 & 3 (Lower Secondary & Pre-IGCSE)</div>
                                    <div class="text-stone-500 text-xs">Term Fees: P 22,000.00 (1st Pay P11k / 2nd Pay P11k)</div>
                                </div>
                                <div class="text-right">
                                    <div class="font-bold text-stone-900">BWP 22,000 <span class="text-xs font-normal text-stone-500">/ term</span></div>
                                    <div class="text-stone-500 text-xs font-mono">BWP 66,000 / year</div>
                                </div>
                            </div>
                            <div class="p-4 flex items-center justify-between">
                                <div>
                                    <div class="font-bold text-stone-900">Form 4 (Cambridge IGCSE Year 1)</div>
                                    <div class="text-stone-500 text-xs">Term Fees: P 24,000.00 (1st Pay P12k / 2nd Pay P12k)</div>
                                </div>
                                <div class="text-right">
                                    <div class="font-bold text-stone-900">BWP 24,000 <span class="text-xs font-normal text-stone-500">/ term</span></div>
                                    <div class="text-stone-500 text-xs font-mono">BWP 72,000 / year</div>
                                </div>
                            </div>
                            <div class="p-4 flex items-center justify-between bg-amber-50/50">
                                <div>
                                    <div class="font-bold text-stone-900">Form 5 (Cambridge IGCSE Final - 2 Terms)</div>
                                    <div class="text-stone-500 text-xs">Billed over 2 Terms: Term 1 & Term 2 (P 36,000 each)</div>
                                </div>
                                <div class="text-right">
                                    <div class="font-bold text-stone-900">BWP 36,000 <span class="text-xs font-normal text-stone-500">/ term</span></div>
                                    <div class="text-stone-500 text-xs font-mono">BWP 72,000 / year</div>
                                </div>
                            </div>
                            <div class="p-4 flex items-center justify-between">
                                <div>
                                    <div class="font-bold text-stone-900">Cambridge AS & A Levels (Sixth Form)</div>
                                    <div class="text-stone-500 text-xs">Forms 6.1 & 6.2 Pre-University Specialization</div>
                                </div>
                                <div class="text-right">
                                    <div class="font-bold text-stone-900">BWP 26,667 <span class="text-xs font-normal text-stone-500">/ term</span></div>
                                    <div class="text-stone-500 text-xs font-mono">BWP 80,000 / year</div>
                                </div>
                            </div>
                            <div class="p-4 bg-amber-50 flex items-center justify-between">
                                <div>
                                    <div class="font-bold text-amber-950">Residential Boarding (Masire Hostels)</div>
                                    <div class="text-amber-800 text-xs">Term 1: P 24,000 · Term 2: P 24,000 · Term 3: P 22,000</div>
                                </div>
                                <div class="text-right">
                                    <div class="font-bold text-amber-950">BWP 70,000 <span class="text-xs font-normal text-amber-800">/ year</span></div>
                                    <div class="text-amber-800 text-xs font-mono">P 24k / P 24k / P 22k</div>
                                </div>
                            </div>
                        </div>
                        <div class="p-4 bg-stone-50 border-t border-stone-200 text-xs text-stone-500 space-y-1">
                            <div><strong>One-off Levies:</strong> Entrance Assessment (P 300) · Registration Fee (P 500) · Development Levy Form 1-5 (P 10,000 once-off).</div>
                            <div><strong>Discounts:</strong> 2.5% discount if full year paid before Term 1 · 5% sibling discount on tuition for 2nd and subsequent children (No trust fund discounts).</div>
                        </div>
                    </div>

                    <!-- Interactive PHP Fee Estimation Calculator -->
                    <div class="lg:col-span-5 bg-stone-900 text-white p-6 rounded-2xl border border-stone-800 shadow-lg">
                        <div class="text-xs uppercase font-mono font-bold tracking-widest text-amber-400 mb-1">Interactive Tool</div>
                        <h3 class="font-serif font-bold text-xl text-white mb-4">Fee Estimate Calculator</h3>

                        <form method="POST" action="#fees" class="space-y-4">
                            <input type="hidden" name="action" value="calc_fees">

                            <div>
                                <label class="block text-xs font-mono text-stone-300 mb-1">Academic Grade Level</label>
                                <select name="calc_level" class="w-full bg-stone-800 border border-stone-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400">
                                    <option value="form-1" selected>Form 1 – P 20,000/term (Annual P 60k)</option>
                                    <option value="form-2-3">Forms 2 & 3 – P 22,000/term (Annual P 66k)</option>
                                    <option value="form-4">Form 4 (IGCSE) – P 24,000/term (Annual P 72k)</option>
                                    <option value="form-5">Form 5 (2 Terms) – P 36,000/term (Annual P 72k)</option>
                                    <option value="a-levels">Cambridge A-Levels – P 26,667/term (Annual P 80k)</option>
                                    <option value="preschool">Preschool (Ages 3–5) – P 12,500/term (Annual P 37.5k)</option>
                                </select>
                            </div>

                            <div class="flex items-center gap-3 p-3 bg-stone-800/80 rounded-lg border border-stone-700">
                                <input type="checkbox" id="calc_boarding" name="calc_boarding" value="1" class="rounded text-amber-500 focus:ring-0">
                                <label for="calc_boarding" class="text-xs text-stone-200 cursor-pointer">
                                    Include Masire Boarding (T1: P 24k · Annual P 70,000)
                                </label>
                            </div>

                            <div>
                                <label class="block text-xs font-mono text-stone-300 mb-1">Bus Route Transit</label>
                                <select name="calc_transport" class="w-full bg-stone-800 border border-stone-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400">
                                    <option value="0">No Campus Bus (Day Scholar or Boarder)</option>
                                    <option value="3200">Zone A (Block 8, Block 6, Gaborone West) – BWP 3,200</option>
                                    <option value="3800">Zone B (Broadhurst, Extension 8, CBD) – BWP 3,800</option>
                                    <option value="4500">Zone C (Phakalane, Mogoditshane, Tlokweng) – BWP 4,500</option>
                                </select>
                            </div>

                            <div>
                                <label class="block text-xs font-mono text-stone-300 mb-1">Younger Siblings (5% discount each on tuition)</label>
                                <input type="number" name="calc_siblings" min="0" max="3" value="0" class="w-full bg-stone-800 border border-stone-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400">
                            </div>

                            <div class="flex items-center gap-3 p-3 bg-stone-800/80 rounded-lg border border-stone-700">
                                <input type="checkbox" id="calc_annual" name="calc_annual" value="1" class="rounded text-amber-500 focus:ring-0">
                                <label for="calc_annual" class="text-xs text-stone-200 cursor-pointer">
                                    Full Annual Advance Payment (2.5% discount per Policy Item 8)
                                </label>
                            </div>

                            <button type="submit" class="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs rounded-lg transition">
                                Calculate Estimated Total (BWP)
                            </button>
                        </form>

                        <?php if ($calculatedFee): ?>
                        <div class="mt-4 p-4 rounded-xl bg-stone-800 border border-amber-500/40 text-xs space-y-2">
                            <div class="font-bold text-amber-400 text-sm">Estimated Fee Breakdown</div>
                            <div class="flex justify-between text-stone-300">
                                <span><?php echo htmlspecialchars($calculatedFee['levelName']); ?>:</span>
                                <span class="font-mono">BWP <?php echo number_format($calculatedFee['baseTuition']); ?></span>
                            </div>
                            <?php if ($calculatedFee['siblingDiscount'] > 0): ?>
                            <div class="flex justify-between text-emerald-400">
                                <span>Sibling Discount (<?php echo $calculatedFee['discountPct']; ?>%):</span>
                                <span class="font-mono">-BWP <?php echo number_format($calculatedFee['siblingDiscount']); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if ($calculatedFee['annualDiscount'] > 0): ?>
                            <div class="flex justify-between text-amber-400">
                                <span>2.5% Full Year Advance Rebate:</span>
                                <span class="font-mono">-BWP <?php echo number_format($calculatedFee['annualDiscount']); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if ($calculatedFee['termBoarding'] > 0): ?>
                            <div class="flex justify-between text-stone-300">
                                <span>Boarding (Masire Hostels):</span>
                                <span class="font-mono">BWP <?php echo number_format($calculatedFee['payAnnual'] ? $calculatedFee['annualBoarding'] : $calculatedFee['termBoarding']); ?></span>
                            </div>
                            <?php endif; ?>
                            <div class="pt-2 border-t border-stone-700 flex justify-between font-bold text-white text-sm">
                                <span>Total Amount:</span>
                                <span class="font-mono text-amber-400">BWP <?php echo number_format($calculatedFee['payAnnual'] ? $calculatedFee['annualTotal'] : $calculatedFee['termTotal']); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Official Bank Accounts Grid -->
                <div class="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm mb-6">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 mb-6">
                        <div>
                            <div class="text-xs uppercase font-mono font-bold tracking-widest text-amber-700">Official Banking Information</div>
                            <h3 class="text-lg font-serif font-bold text-stone-900">Account Name: Lavender Projects</h3>
                        </div>
                        <div class="text-xs text-stone-600">
                            Bursar WhatsApp: <a href="https://wa.me/26772820327" target="_blank" rel="noopener noreferrer" class="font-mono font-bold text-emerald-700">+267 72 820 327</a>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-stone-700">
                        <div class="p-4 bg-stone-50 rounded-xl border border-stone-200">
                            <div class="font-bold text-stone-900 text-sm mb-1">Stanbic Bank</div>
                            <div>Acc Number: <strong class="font-mono text-stone-950">9060003561815</strong></div>
                            <div>Branch: Fairgrounds (Code: 064967)</div>
                            <div>Swift Code: <span class="font-mono">SBICBWGX</span></div>
                        </div>
                        <div class="p-4 bg-stone-50 rounded-xl border border-stone-200">
                            <div class="font-bold text-stone-900 text-sm mb-1">First Capital Bank</div>
                            <div>Acc Number: <strong class="font-mono text-stone-950">0004704076626</strong></div>
                            <div>Branch: Broadhurst (Code: 800467)</div>
                            <div>Swift Code: <span class="font-mono">FRCGBWGA</span></div>
                        </div>
                        <div class="p-4 bg-stone-50 rounded-xl border border-stone-200">
                            <div class="font-bold text-stone-900 text-sm mb-1">Bank of Baroda</div>
                            <div>Acc Number: <strong class="font-mono text-stone-950">5210200002480</strong></div>
                            <div>Branch: Main Mall (Code: 110167)</div>
                            <div>Swift Code: <span class="font-mono">BARBBWGXXXX</span></div>
                        </div>
                    </div>
                    <div class="mt-4 pt-4 border-t border-stone-100 text-[11px] text-stone-500 flex flex-col sm:flex-row items-center justify-between gap-2">
                        <span>Kindly Reference all payments with student's full name. Email proof to <a href="mailto:accountslkc@yahoo.com" class="text-stone-900 underline">accountslkc@yahoo.com</a> or WhatsApp +267 72 820 327.</span>
                        <a href="/assets/aistudio/School_Fees_Policy_2026_IGCSE_f50e8781.pdf" target="_blank" class="text-amber-800 font-semibold hover:underline">View Policy Document PDF →</a>
                    </div>
                </div>
            </section>

            <!-- 2026 Academic Term Calendar -->
            <section class="py-16 px-6 bg-stone-100 border-y border-stone-200">
                <div class="max-w-7xl mx-auto">
                    <div class="text-center max-w-2xl mx-auto mb-10">
                        <div class="text-xs uppercase font-mono font-bold tracking-widest text-amber-600 mb-1">Academic Almanac</div>
                        <h2 class="text-2xl sm:text-3xl font-serif font-bold text-stone-900">2026 Term Dates & Schedule</h2>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
                        <div class="p-5 bg-white rounded-xl border border-stone-200">
                            <span class="inline-block px-2 py-0.5 rounded bg-blue-100 text-blue-900 font-semibold mb-2">Term 1 (Autumn)</span>
                            <div class="font-bold text-stone-900 text-sm mb-1">13 January – 10 April 2026</div>
                            <div class="text-stone-500 mb-3">Mid-Term: 19 – 23 February 2026</div>
                            <ul class="text-stone-600 space-y-1 list-disc list-inside">
                                <li>New Scholars Orientation</li>
                                <li>Inter-House Swimming Gala</li>
                                <li>Form 5 Cambridge Diagnostics</li>
                            </ul>
                        </div>
                        <div class="p-5 bg-white rounded-xl border border-stone-200">
                            <span class="inline-block px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-semibold mb-2">Term 2 (Winter)</span>
                            <div class="font-bold text-stone-900 text-sm mb-1">5 May – 7 August 2026</div>
                            <div class="text-stone-500 mb-3">Mid-Term: 18 – 22 June 2026</div>
                            <ul class="text-stone-600 space-y-1 list-disc list-inside">
                                <li>Inter-House Track & Field Gala</li>
                                <li>Cambridge Mock Examinations</li>
                                <li>Parent-Teacher Conferences</li>
                            </ul>
                        </div>
                        <div class="p-5 bg-white rounded-xl border border-stone-200">
                            <span class="inline-block px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 font-semibold mb-2">Term 3 (Spring)</span>
                            <div class="font-bold text-stone-900 text-sm mb-1">8 September – 4 December 2026</div>
                            <div class="text-stone-500 mb-3">Mid-Term: 15 – 19 October 2026</div>
                            <ul class="text-stone-600 space-y-1 list-disc list-inside">
                                <li>Botswana Independence Day (30 Sep)</li>
                                <li>Cambridge IGCSE & A-Level External Exams</li>
                                <li>Annual Speech & Valedictory Banquet</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Admissions Application & General Inquiries Section -->
            <section id="admissions-form" class="py-20 px-6 max-w-7xl mx-auto">
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-12">
                    <!-- Left: Contact info -->
                    <div id="contact" class="lg:col-span-5">
                        <div class="text-xs uppercase font-mono font-bold tracking-widest text-amber-600 mb-2">Admissions & Registry</div>
                        <h2 class="text-3xl font-serif font-bold text-stone-900 mb-6">Connect With Livingstone Kolobeng College</h2>
                        
                        <div class="space-y-4 text-xs sm:text-sm text-stone-600 mb-8">
                            <div>
                                <strong class="text-stone-900 block font-mono text-xs uppercase text-amber-800">Campus Physical Location:</strong>
                                <span>Plot 37225, Block 8, Extension 38, Gaborone West, Botswana</span>
                                <div class="text-stone-500 text-xs">P.O. Box 403388, Gaborone, Botswana</div>
                            </div>
                            <div>
                                <strong class="text-stone-900 block font-mono text-xs uppercase text-amber-800">Telephone Lines:</strong>
                                <a href="tel:+2673161140" class="hover:text-stone-950 font-mono">+267 316 1140</a> / 
                                <a href="tel:+2673162208" class="hover:text-stone-950 font-mono">+267 316 2208</a>
                                <div class="text-stone-500 text-xs">Fax: +267 316 1139 · Mobile: +267 75 474 970</div>
                            </div>
                            <div>
                                <strong class="text-stone-900 block font-mono text-xs uppercase text-amber-800">WhatsApp Admissions Helpline:</strong>
                                <a href="https://wa.me/26778465196" target="_blank" rel="noopener noreferrer" class="text-emerald-700 hover:text-emerald-800 font-mono font-bold">
                                    +267 78 465 196 (Instant WhatsApp Chat)
                                </a>
                            </div>
                            <div>
                                <strong class="text-stone-900 block font-mono text-xs uppercase text-amber-800">Official Electronic Mail:</strong>
                                <div>Principal: <a href="mailto:principal@lkc.ac.bw" class="text-stone-900 underline">principal@lkc.ac.bw</a></div>
                                <div>Admissions: <a href="mailto:admissions@livingstonekolobeng.ac.bw" class="text-stone-900 underline">admissions@livingstonekolobeng.ac.bw</a></div>
                                <div>Accounts: <a href="mailto:accountslkc@yahoo.com" class="text-stone-900 underline">accountslkc@yahoo.com</a></div>
                            </div>
                            <div>
                                <strong class="text-stone-900 block font-mono text-xs uppercase text-amber-800">Office Working Hours:</strong>
                                <span>Monday – Friday: 07:30 – 16:30 CAT</span>
                            </div>
                        </div>

                        <div class="p-5 bg-stone-100 rounded-xl border border-stone-200">
                            <div class="font-serif font-bold text-stone-900 mb-1">Official Online Student Portal</div>
                            <p class="text-xs text-stone-600 mb-3">
                                Enrolled scholars, parents, and registered applicants can access term grades, attendance records, and direct digital applications:
                            </p>
                            <a href="https://lkcportal.com/?form=apply" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-2 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-amber-400 rounded-lg text-xs font-semibold">
                                Launch lkcportal.com Form ↗
                            </a>
                        </div>
                    </div>

                    <!-- Right: Quick Admissions Form -->
                    <div class="lg:col-span-7 bg-white p-8 rounded-2xl border border-stone-200 shadow-sm">
                        <div class="text-xs uppercase font-mono font-bold tracking-widest text-amber-600 mb-1">Admissions Application</div>
                        <h3 class="text-2xl font-serif font-bold text-stone-900 mb-2">Submit Online Admissions Inquiry</h3>
                        <p class="text-xs text-stone-500 mb-6">
                            Complete this application form to register your child for entry into Livingstone Kolobeng College for the 2026 / 2027 academic sessions.
                        </p>

                        <form method="POST" action="#admissions-form" class="space-y-4">
                            <input type="hidden" name="action" value="quick_apply">

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-stone-700 mb-1">Student Full Name *</label>
                                    <input type="text" name="student_name" required placeholder="e.g. Kagiso Khama" class="w-full bg-stone-50 border border-stone-300 rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-stone-700 mb-1">Grade Level Applying For *</label>
                                    <select name="grade" class="w-full bg-stone-50 border border-stone-300 rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none">
                                        <option value="Preschool (Ages 3-5)">Preschool (Ages 3–5)</option>
                                        <option value="Form 1 (Lower Secondary)" selected>Form 1 (Lower Secondary)</option>
                                        <option value="Form 2 (Lower Secondary)">Form 2 (Lower Secondary)</option>
                                        <option value="Form 3 (Pre-IGCSE)">Form 3 (Pre-IGCSE)</option>
                                        <option value="Form 4 (Cambridge IGCSE)">Form 4 (Cambridge IGCSE)</option>
                                        <option value="Form 5 (Cambridge IGCSE)">Form 5 (Cambridge IGCSE)</option>
                                        <option value="Form 6.1 (Cambridge A-Level)">Form 6.1 (Cambridge AS / A-Level)</option>
                                    </select>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-stone-700 mb-1">Parent / Guardian Email *</label>
                                    <input type="email" name="parent_email" required placeholder="parent@example.com" class="w-full bg-stone-50 border border-stone-300 rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-stone-700 mb-1">Contact Phone Number *</label>
                                    <input type="tel" name="phone" required placeholder="+267 7x xxx xxx" class="w-full bg-stone-50 border border-stone-300 rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none">
                                </div>
                            </div>

                            <div class="p-3 bg-stone-50 rounded-lg border border-stone-200 flex items-center gap-3">
                                <input type="checkbox" id="boarding" name="boarding" value="1" class="rounded text-amber-600 focus:ring-0">
                                <label for="boarding" class="text-xs text-stone-700 cursor-pointer">
                                    Apply for Masire Residential Boarding accommodation (100 beds total capacity · 61 spaces open)
                                </label>
                            </div>

                            <div>
                                <label class="block text-xs font-semibold text-stone-700 mb-1">Previous School & Academic Highlights (Optional)</label>
                                <textarea name="notes" rows="3" placeholder="Current school attended, exam results, sports or cultural interests..." class="w-full bg-stone-50 border border-stone-300 rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"></textarea>
                            </div>

                            <div class="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                                <button type="submit" class="w-full sm:w-auto px-6 py-2.5 bg-stone-950 hover:bg-stone-800 text-amber-400 font-bold text-xs rounded-lg transition shadow">
                                    Submit Application to Registry
                                </button>
                                <span class="text-[11px] text-stone-500 text-center sm:text-right">
                                    Admissions Hotline: +267 316 1140
                                </span>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </main>

        <!-- Footer -->
        <footer class="bg-stone-950 text-stone-400 text-xs py-12 px-6 border-t border-stone-800">
            <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
                <div class="md:col-span-1">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-9 h-9 rounded-lg bg-stone-900 text-amber-400 border border-stone-800 flex items-center justify-center font-serif font-bold text-base">
                            LK
                        </div>
                        <div class="font-serif font-bold text-base text-white">Livingstone Kolobeng College</div>
                    </div>
                    <p class="text-stone-400 text-xs leading-relaxed mb-4">
                        Independent Cambridge Assessment International Education Examination Centre BW812. Established 2008 in Gaborone, Botswana.
                    </p>
                    <div class="font-serif italic text-amber-400/90 text-sm">"Thuto Ke Botshelo"</div>
                </div>

                <div>
                    <h4 class="text-white font-mono uppercase text-xs tracking-wider mb-3">Academic Departments</h4>
                    <ul class="space-y-1.5 text-stone-400">
                        <li>Mathematics Department</li>
                        <li>Science Department</li>
                        <li>Creatives & Performing Arts</li>
                        <li>Physical Education & Jaguars</li>
                        <li>Humanities Department</li>
                        <li>Languages Department</li>
                        <li>Commercials Department</li>
                        <li>ICT & Logistics Department</li>
                    </ul>
                </div>

                <div>
                    <h4 class="text-white font-mono uppercase text-xs tracking-wider mb-3">Quick Directory</h4>
                    <ul class="space-y-1.5 text-stone-400">
                        <li><a href="#about" class="hover:text-white">Ethos & Leadership</a></li>
                        <li><a href="#academics" class="hover:text-white">Cambridge Curriculum</a></li>
                        <li><a href="#campus-life" class="hover:text-white">Masire Hostels & Houses</a></li>
                        <li><a href="#fees" class="hover:text-white">Fee Schedule & Calculator</a></li>
                        <li><a href="https://lkcportal.com/?form=apply" target="_blank" rel="noopener noreferrer" class="hover:text-amber-400">Admissions Portal Form ↗</a></li>
                        <li><a href="/api.php?action=info" target="_blank" class="hover:text-amber-400 font-mono">LKC REST API (/api.php)</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="text-white font-mono uppercase text-xs tracking-wider mb-3">Official Social & Contact</h4>
                    <div class="space-y-2 text-stone-400">
                        <div>Telephone: <a href="tel:+2673161140" class="text-stone-200">+267 316 1140</a> / <a href="tel:+2673162208" class="text-stone-200">316 2208</a></div>
                        <div>WhatsApp: <a href="https://wa.me/26778465196" target="_blank" class="text-emerald-400 font-mono">+267 78 465 196</a></div>
                        <div>TikTok: <a href="https://www.tiktok.com/@lkc_college" target="_blank" class="text-stone-200 hover:text-white">@lkc_college</a></div>
                        <div>Instagram: <a href="https://www.instagram.com/lkc_livingstonekolobeng" target="_blank" class="text-stone-200 hover:text-white">@lkc_livingstonekolobeng</a></div>
                        <div class="pt-2 text-stone-500 text-[11px]">Plot 37225, Block 8, Gaborone West, Botswana</div>
                    </div>
                </div>
            </div>

            <div class="max-w-7xl mx-auto pt-8 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-stone-500">
                <div>© 2026 Livingstone Kolobeng College. All rights reserved. Cambridge Centre BW812.</div>
                <div>Compatible with PHP 7.4+, PHP 8.x, Apache & Vite React SPA.</div>
            </div>
        </footer>
    </div>
</div>

<!-- React SPA Hydration Script if built -->
<?php if ($distJs): ?>
<script type="module" src="<?php echo htmlspecialchars($distJs); ?>"></script>
<?php endif; ?>

</body>
</html>
