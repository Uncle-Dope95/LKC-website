<?php
header('Content-Type: text/html; charset=UTF-8');
$indexHtml = __DIR__ . '/index.html';
if (is_file($indexHtml) && is_readable($indexHtml)) {
    readfile($indexHtml);
    exit;
}
http_response_code(500);
echo '<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Livingstone Kolobeng College</title></head><body style="font-family:system-ui,sans-serif;padding:40px;color:#0c1a40;background:#f8fafc;"><div style="max-width:560px;margin:40px auto;background:#fff;border:1px solid #bfdbfe;border-radius:16px;padding:28px;"><h1 style="margin-top:0;">Livingstone Kolobeng College</h1><p>The website entry file (<code>index.html</code>) could not be found in this directory.</p><p>Please contact reception at <strong>+267 316 1140</strong> or <strong>+267 316 2208</strong>.</p></div></body></html>';

