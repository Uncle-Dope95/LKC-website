import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');
const DIST_DIR = path.join(ROOT_DIR, 'dist');

const PRODUCTION_HTACCESS = `# ----------------------------------------------------------------------
# Livingstone Kolobeng College (.htaccess)
# Minimal & Safe Apache / cPanel Shared Hosting Configuration (Hash SPA + PHP)
# ----------------------------------------------------------------------

DirectoryIndex index.html index.php

<IfModule mod_mime.c>
    AddCharset UTF-8 .html .css .js .json .xml .php .txt
</IfModule>

<IfModule mod_authz_core.c>
    <FilesMatch "(^\\.|^server\\.|^tsconfig\\.json$|^package(-lock)?\\.json$|^vite\\.config\\.|\\.(db|sqlite|sqlite3|log|ts|tsx|mjs)$)">
        Require all denied
    </FilesMatch>
</IfModule>

<IfModule mod_headers.c>
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"

    <FilesMatch "\\.(html|htm|php|json)$">
        Header set Cache-Control "no-cache, no-store, must-revalidate"
        Header set Pragma "no-cache"
    </FilesMatch>

    <FilesMatch "\\.(css|js|png|jpe?g|webp|gif|svg|ico|woff2?|pdf|mp4|webm|mov)$">
        Header set Cache-Control "public, max-age=31536000"
    </FilesMatch>
</IfModule>

<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain text/html text/xml text/css application/xml application/xhtml+xml application/javascript application/x-javascript application/json image/svg+xml
</IfModule>

<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresDefault "access plus 1 month"
    ExpiresByType text/html "access plus 0 seconds"
    ExpiresByType application/json "access plus 0 seconds"
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType application/x-javascript "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/webp "access plus 1 year"
    ExpiresByType application/pdf "access plus 1 month"
</IfModule>
`;

function enforceRelativeViteBase() {
  const viteConfigPath = path.join(ROOT_DIR, 'vite.config.ts');
  if (!fs.existsSync(viteConfigPath)) {
    throw new Error('vite.config.ts not found in workspace root.');
  }
  const content = fs.readFileSync(viteConfigPath, 'utf8');
  if (!/\bbase\s*:\s*['"]\.\/['"]/.test(content)) {
    throw new Error("vite.config.ts must specify base: './' for shared hosting compatibility.");
  }
}

function writeProductionHtaccess() {
  const rootHtaccess = path.join(ROOT_DIR, '.htaccess');
  fs.writeFileSync(rootHtaccess, PRODUCTION_HTACCESS, 'utf8');
  if (fs.existsSync(DIST_DIR)) {
    fs.writeFileSync(path.join(DIST_DIR, '.htaccess'), PRODUCTION_HTACCESS, 'utf8');
  }
}

function normalizePermissions(dirPath) {
  if (!fs.existsSync(dirPath)) return;
  fs.chmodSync(dirPath, 0o755);
  for (const entry of fs.readdirSync(dirPath, { withFileTypes: true })) {
    const full = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      normalizePermissions(full);
    } else if (entry.isFile()) {
      fs.chmodSync(full, 0o644);
    }
  }
}

function verifyDistSelfContained() {
  const requiredFiles = [
    'index.html',
    '.htaccess',
    'index.php',
    'api.php',
    'robots.txt',
    'assets/lkc-app.js',
    'assets/aistudio/school_video_5ac9eb5b.mp4',
  ];

  for (const rel of requiredFiles) {
    const full = path.join(DIST_DIR, rel);
    if (!fs.existsSync(full)) {
      throw new Error(`Missing required shared-hosting build artifact: dist/${rel}`);
    }
  }

  const forbiddenEntries = ['node_modules', 'src', 'storage', 'server.ts', 'package.json', 'tsconfig.json'];
  for (const forbidden of forbiddenEntries) {
    if (fs.existsSync(path.join(DIST_DIR, forbidden))) {
      throw new Error(`Forbidden runtime/source entry found in dist/: ${forbidden}`);
    }
  }

  const html = fs.readFileSync(path.join(DIST_DIR, 'index.html'), 'utf8');
  const appJs = fs.readFileSync(path.join(DIST_DIR, 'assets/lkc-app.js'), 'utf8');

  if (html.includes('/src/main.tsx')) {
    throw new Error('dist/index.html still references /src/main.tsx.');
  }
  if (/type=["']module["']/i.test(html)) {
    throw new Error('dist/index.html still contains type="module" scripts which fail under file://.');
  }
  if (!/<script\s+defer\s+src=["']\.\/assets\/lkc-app\.js["']><\/script>/i.test(html)) {
    throw new Error('dist/index.html is missing classic deferred ./assets/lkc-app.js script tag.');
  }

  // Verify no hardcoded root-relative local URLs (/assets/..., /uploads/...) in HTML
  const rootRelativeRefs = html.match(/(?:src|href)=["']\/(?!\/)[^"']*["']/gi) || [];
  if (rootRelativeRefs.length > 0) {
    throw new Error(`Hardcoded root-relative URL(s) in dist/index.html: ${rootRelativeRefs.join(', ')}`);
  }

  // Verify no hardcoded machine paths, dev origins, or secrets in output
  const secretAndPathChecks = [
    { label: 'GEMINI_API_KEY', regex: /GEMINI_API_KEY/ },
    { label: 'AIza API key pattern', regex: /AIza[0-9A-Za-z_-]{20,}/ },
    { label: 'CMS_SESSION_SECRET', regex: /CMS_SESSION_SECRET/ },
    { label: 'Hardcoded workspace path', regex: /\/app\/applet\b/ },
    { label: 'Hardcoded dev origin', regex: /https?:\/\/(?:localhost|127\.0\.0\.1):\d+/ },
  ];

  for (const [name, content] of [
    ['dist/index.html', html],
    ['dist/assets/lkc-app.js', appJs],
  ]) {
    for (const check of secretAndPathChecks) {
      if (check.regex.test(content)) {
        throw new Error(`Security/portability violation (${check.label}) detected in ${name}`);
      }
    }
  }

  // Verify local relative ./assets/ and ./uploads/ references in HTML and JS resolve with exact letter case on disk
  function existsCaseSensitive(baseDir, relPath) {
    const parts = relPath.split('/').filter(Boolean);
    let current = baseDir;
    for (const part of parts) {
      if (!fs.existsSync(current)) return false;
      const entries = fs.readdirSync(current);
      if (!entries.includes(part)) return false;
      current = path.join(current, part);
    }
    return fs.existsSync(current);
  }

  const assetRegex = /\.\/(?:assets|uploads)\/[A-Za-z0-9_.-]+(?:\/[A-Za-z0-9_.-]+)*/g;
  const htmlAssets = html.match(assetRegex) || [];
  const jsAssets = appJs.match(assetRegex) || [];
  const allAssets = Array.from(new Set([...htmlAssets, ...jsAssets])).filter(
    (rel) => !rel.includes('..')
  );
  const missingAssets = [];
  for (const rel of allAssets) {
    const cleanRel = rel.replace(/^\.\//, '');
    if (!existsCaseSensitive(DIST_DIR, cleanRel)) {
      missingAssets.push(rel);
    }
  }
  if (missingAssets.length > 0) {
    throw new Error(`Unresolved or case-mismatched local asset path(s) in dist/: ${missingAssets.join(', ')}`);
  }

  console.log(
    `[LKC Shared-Hosting Build] Verified dist/: ${allAssets.length} unique relative asset refs checked (case-sensitive), 0 hardcoded paths, 0 secrets.`
  );
}

async function main() {
  enforceRelativeViteBase();

  const staticEnv = { ...process.env, VITE_STATIC_MODE: 'true' };
  const viteBin = path.join(ROOT_DIR, 'node_modules', 'vite', 'bin', 'vite.js');
  const tsxBin = path.join(ROOT_DIR, 'node_modules', 'tsx', 'dist', 'cli.mjs');

  console.log('[LKC Shared-Hosting Build] Running Vite static build (base: "./")...');
  execFileSync(process.execPath, [viteBin, 'build'], {
    cwd: ROOT_DIR,
    stdio: 'inherit',
    env: staticEnv,
  });

  console.log('[LKC Shared-Hosting Build] Finalizing classic IIFE bundle, snapshot & support files...');
  execFileSync(process.execPath, [tsxBin, path.join(ROOT_DIR, 'scripts', 'exportStaticSite.mjs'), '--dist'], {
    cwd: ROOT_DIR,
    stdio: 'inherit',
    env: staticEnv,
  });

  writeProductionHtaccess();
  normalizePermissions(DIST_DIR);
  verifyDistSelfContained();

  console.log('[LKC Shared-Hosting Build] Complete. Upload dist/ contents to public_html/.');
}

main().catch((err) => {
  console.error('[LKC Shared-Hosting Build] FAILED:', err instanceof Error ? err.message : err);
  process.exit(1);
});
