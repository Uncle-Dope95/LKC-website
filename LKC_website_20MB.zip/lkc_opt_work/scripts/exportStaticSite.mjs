import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { build as esbuild } from 'esbuild';
import {
  getAcademicLeadershipBundle,
  getAllSections,
  listCmsItems,
  UPLOADS_DIR,
} from '../src/server/db.ts';
import { sortTeachersForDirectory } from '../src/utils/staffHierarchy.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');
const DIST_DIR = path.join(ROOT_DIR, 'dist');
const DIST_STATIC_DIR = path.join(ROOT_DIR, 'dist-static');

function rewriteStaticPathsRecursively(value) {
  if (typeof value === 'string') {
    if (value.startsWith('/uploads/') || value.startsWith('/assets/')) {
      return `.${value}`;
    }
    return value;
  }
  if (Array.isArray(value)) {
    return value.map(rewriteStaticPathsRecursively);
  }
  if (value && typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      out[k] = rewriteStaticPathsRecursively(v);
    }
    return out;
  }
  return value;
}

function buildSanitizedPublicSnapshot() {
  // Build strictly sanitized public-only snapshot (no users, sessions, audit logs, enquiries, tokens)
  const rawSections = getAllSections();
  const safeAlumni = (rawSections.alumni || [])
    .filter((a) => a.status === 'approved')
    .map(({ email: _e, phone: _p, ...safe }) => safe);

  const safeAbout = {
    ...rawSections.about,
    leadership: (rawSections.about?.leadership || [])
      .filter((l) => l.status !== 'unpublished' && l.status !== 'archived')
      .sort((a, b) => (a.order ?? 99) - (b.order ?? 99)),
    directors: (rawSections.about?.directors || [])
      .filter((d) => d.status !== 'unpublished' && d.status !== 'archived')
      .sort((a, b) => (a.order ?? 99) - (b.order ?? 99)),
  };

  const safeTeachers = sortTeachersForDirectory(
    (rawSections.teachers || [])
      .filter((t) => t.status !== 'unpublished' && t.status !== 'archived')
      .map(({ qualifications: _q, ...safeTeacher }) => safeTeacher),
    rawSections.departments || []
  );

  const safeAnnouncements = (rawSections.announcements || []).filter(
    (a) => a.active && (!a.status || a.status === 'published')
  );

  const filterPublicPhotos = (photos) =>
    (photos || []).filter(
      (p) =>
        Boolean(p.url && p.url.trim()) &&
        p.status !== 'unpublished' &&
        p.status !== 'archived'
    );

  const safeAthletics = rawSections.athletics
    ? {
        ...rawSections.athletics,
        photos: filterPublicPhotos(rawSections.athletics.photos),
      }
    : rawSections.athletics;

  const safeSports = rawSections.sports
    ? {
        ...rawSections.sports,
        photos: filterPublicPhotos(rawSections.sports.photos),
      }
    : rawSections.sports;

  const safeJaguars = rawSections.jaguars
    ? {
        ...rawSections.jaguars,
        photos: filterPublicPhotos(rawSections.jaguars.photos),
      }
    : rawSections.jaguars;

  // Strip internal usedIn metadata if present on media registry
  const safeMedia = (rawSections.media || []).map(({ usedIn: _u, ...m }) => m);

  const publicSections = {
    ...rawSections,
    about: safeAbout,
    athletics: safeAthletics,
    sports: safeSports,
    jaguars: safeJaguars,
    teachers: safeTeachers,
    alumni: safeAlumni,
    announcements: safeAnnouncements,
    media: safeMedia,
  };

  const publishedItems = listCmsItems({ status: 'published' });
  const maxFeatured = Math.max(
    1,
    Number(publicSections.settings?.homepageMaxFeaturedItems || 6)
  );
  const featuredItems = publishedItems
    .filter((i) => i.featureOnHomepage)
    .slice(0, maxFeatured);

  const academicLeadership = getAcademicLeadershipBundle(true);

  return rewriteStaticPathsRecursively({
    exportedAt: new Date().toISOString(),
    sections: publicSections,
    publishedItems,
    featuredItems,
    academicLeadership,
  });
}

function copyDirectoryClean(srcDir, destDir) {
  fs.rmSync(destDir, { recursive: true, force: true });
  fs.mkdirSync(destDir, { recursive: true });
  if (!fs.existsSync(srcDir)) return;

  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      copyDirectoryClean(srcPath, destPath);
    } else if (entry.isFile()) {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function copyHostingSupportFiles(targetDir) {
  const supportFiles = ['.htaccess', 'api.php'];
  for (const file of supportFiles) {
    const src = path.join(ROOT_DIR, file);
    if (fs.existsSync(src)) {
      fs.copyFileSync(src, path.join(targetDir, file));
    }
  }
  const publicFallbacks = ['robots.txt', 'index.php'];
  for (const file of publicFallbacks) {
    const dest = path.join(targetDir, file);
    const src = path.join(ROOT_DIR, 'public', file);
    if (!fs.existsSync(dest) && fs.existsSync(src)) {
      fs.copyFileSync(src, dest);
    }
  }
}

function cleanupViteRollupChunks(assetsDir, keepNames = new Set()) {
  if (!fs.existsSync(assetsDir)) return;
  for (const entry of fs.readdirSync(assetsDir, { withFileTypes: true })) {
    if (!entry.isFile()) continue;
    if (keepNames.has(entry.name)) continue;
    if (/\.(js|css|map)$/i.test(entry.name)) {
      try {
        fs.unlinkSync(path.join(assetsDir, entry.name));
      } catch {
        // Ignore cleanup failure
      }
    }
  }
}

async function inlineCssAndBuildClassicBundle({
  targetDir,
  bundleFileName,
  styleTagId,
  forceRebuild = false,
  stripAdminCms = true,
}) {
  const indexHtmlPath = path.join(targetDir, 'index.html');
  const assetsDir = path.join(targetDir, 'assets');
  const bundleOut = path.join(assetsDir, bundleFileName);

  let html = fs.readFileSync(indexHtmlPath, 'utf8');

  const existingInlineStyleMatch = html.match(
    new RegExp(`<style id="${styleTagId}">([\\s\\S]*?)<\\/style>`, 'i')
  );
  let inlinedCss = existingInlineStyleMatch ? existingInlineStyleMatch[1] : '';

  const cssMatches = Array.from(
    html.matchAll(/<link\b[^>]*rel=["']stylesheet["'][^>]*href=["']([^"']+)["'][^>]*>/gi)
  );
  if (cssMatches.length > 0) {
    inlinedCss = '';
    for (const match of cssMatches) {
      const relHref = match[1].replace(/^\.\//, '').replace(/^\//, '');
      const cssPath = path.join(targetDir, relHref);
      if (fs.existsSync(cssPath)) {
        inlinedCss += `\n${fs.readFileSync(cssPath, 'utf8')}`;
      }
      html = html.replace(match[0], '');
    }
  }

  // Strip Vite modulepreload links and ES module scripts (which fail under file:// CORS)
  html = html.replace(/<link\b[^>]*rel=["']modulepreload["'][^>]*>\s*/gi, '');
  html = html.replace(/<script\b[^>]*type=["']module["'][^>]*src=["']([^"']+)["'][^>]*><\/script>\s*/gi, '');

  // Clean up hashed Rollup ESM JS/CSS chunks from assetsDir
  cleanupViteRollupChunks(assetsDir, new Set([bundleFileName]));

  const isStatic = process.env.VITE_STATIC_MODE !== 'false';

  if (forceRebuild || !fs.existsSync(bundleOut)) {
    fs.mkdirSync(assetsDir, { recursive: true });
    await esbuild({
      entryPoints: [path.join(ROOT_DIR, 'src', 'main.tsx')],
      bundle: true,
      minify: true,
      format: 'iife',
      platform: 'browser',
      target: ['es2020'],
      jsx: 'automatic',
      define: {
        'process.env.NODE_ENV': '"production"',
        'import.meta.env.VITE_STATIC_MODE': JSON.stringify(isStatic ? 'true' : 'false'),
      },
      plugins: [
        {
          name: 'ignore-css-imports',
          setup(build) {
            build.onResolve({ filter: /\.css$/ }, (args) => ({
              path: args.path,
              namespace: 'empty-css',
            }));
            build.onLoad({ filter: /.*/, namespace: 'empty-css' }, () => ({
              contents: '',
              loader: 'js',
            }));
            if (stripAdminCms) {
              build.onResolve({ filter: /AdminCmsModal|^\.\/cms\// }, (args) => ({
                path: args.path,
                namespace: 'empty-static-admin',
              }));
              build.onLoad({ filter: /.*/, namespace: 'empty-static-admin' }, () => ({
                contents: 'export const AdminCmsModal = () => null; export default AdminCmsModal;',
                loader: 'js',
              }));
            }
          },
        },
      ],
      outfile: bundleOut,
    });
  }

  return { html, inlinedCss, indexHtmlPath, bundleOut };
}

export async function finalizeDistBuild() {
  if (!fs.existsSync(path.join(DIST_DIR, 'index.html'))) {
    throw new Error('dist/index.html not found. Run vite build first.');
  }

  // Copy uploaded media assets so static/PHP hosting of dist/ resolves ./uploads/ cleanly
  copyDirectoryClean(UPLOADS_DIR, path.join(DIST_DIR, 'uploads'));
  copyHostingSupportFiles(DIST_DIR);

  const { html: baseHtml, inlinedCss, indexHtmlPath, bundleOut } =
    await inlineCssAndBuildClassicBundle({
      targetDir: DIST_DIR,
      bundleFileName: 'lkc-app.js',
      styleTagId: 'lkc-dist-styles',
      forceRebuild: true,
      stripAdminCms: false,
    });

  const snapshot = buildSanitizedPublicSnapshot();
  const serializedSnapshot = JSON.stringify(snapshot).replace(/</g, '\\u003c');
  const injectionTag = `<script id="lkc-static-snapshot">window.__LKC_STATIC_MODE__=true;window.__LKC_STATIC_SNAPSHOT__=${serializedSnapshot};</script>`;

  const styleBlock = inlinedCss
    ? `<style id="lkc-dist-styles">${inlinedCss.replace(/<\/style/gi, '<\\/style')}</style>`
    : '';
  const bundleScriptTag = `<script defer src="./assets/lkc-app.js"></script>`;

  let html = baseHtml
    .replace(/<style id="lkc-dist-styles">[\s\S]*?<\/style>\s*/i, '')
    .replace(/<script id="lkc-static-snapshot">[\s\S]*?<\/script>\s*/i, '')
    .replace(/<script[^>]*src=["']\.\/assets\/lkc-app\.js["'][^>]*><\/script>\s*/i, '');

  if (styleBlock) {
    html = html.replace('</head>', `  ${styleBlock}\n  </head>`);
  }
  html = html.replace('</body>', `  ${injectionTag}\n  ${bundleScriptTag}\n  </body>`);

  fs.writeFileSync(indexHtmlPath, html, 'utf8');

  const appKb = Math.round(fs.statSync(bundleOut).size / 1024);
  console.log(`Bundle size: lkc-app.js=${appKb} KB`);

  return DIST_DIR;
}

export async function buildStaticExport({ rebuildViteIfMissing = false } = {}) {
  const indexHtmlPath = path.join(DIST_STATIC_DIR, 'index.html');
  const assetsDir = path.join(DIST_STATIC_DIR, 'assets');
  const staticBundleOut = path.join(assetsDir, 'lkc-static-app.js');

  const needsViteBuild =
    !rebuildViteIfMissing ||
    !fs.existsSync(indexHtmlPath) ||
    !fs.existsSync(assetsDir) ||
    !fs.existsSync(staticBundleOut);

  if (needsViteBuild) {
    const viteBin = path.join(ROOT_DIR, 'node_modules', 'vite', 'bin', 'vite.js');
    execFileSync(process.execPath, [viteBin, 'build', '--outDir', 'dist-static'], {
      cwd: ROOT_DIR,
      stdio: 'pipe',
      env: { ...process.env, VITE_STATIC_MODE: 'true' },
    });
  }

  // Copy uploaded portraits/media from storage/uploads into dist-static/uploads
  copyDirectoryClean(UPLOADS_DIR, path.join(DIST_STATIC_DIR, 'uploads'));
  copyHostingSupportFiles(DIST_STATIC_DIR);

  const { html: baseHtml, inlinedCss } = await inlineCssAndBuildClassicBundle({
    targetDir: DIST_STATIC_DIR,
    bundleFileName: 'lkc-static-app.js',
    styleTagId: 'lkc-static-styles',
    forceRebuild: needsViteBuild,
    stripAdminCms: true,
  });

  const snapshot = buildSanitizedPublicSnapshot();
  const serializedSnapshot = JSON.stringify(snapshot).replace(/</g, '\\u003c');
  const styleBlock = inlinedCss
    ? `<style id="lkc-static-styles">${inlinedCss.replace(/<\/style/gi, '<\\/style')}</style>`
    : '';
  const injectionTag = `<script id="lkc-static-snapshot">window.__LKC_STATIC_MODE__=true;window.__LKC_STATIC_SNAPSHOT__=${serializedSnapshot};</script>`;
  const inlinedBundleJs = fs
    .readFileSync(staticBundleOut, 'utf8')
    .replace(/<\/script/gi, '<\\/script');
  const bundleScriptTag = `<script id="lkc-static-app-bundle">${inlinedBundleJs}</script>`;

  let html = baseHtml
    .replace(/<style id="lkc-static-styles">[\s\S]*?<\/style>\s*/i, '')
    .replace(/<script id="lkc-static-snapshot">[\s\S]*?<\/script>\s*/i, '')
    .replace(/<script id="lkc-static-app-bundle">[\s\S]*?<\/script>\s*/i, '')
    .replace(/<script[^>]*src=["']\.\/assets\/lkc-static-app\.js["'][^>]*><\/script>\s*/i, '');

  if (styleBlock) {
    html = html.replace('</head>', `  ${styleBlock}\n  </head>`);
  }
  html = html.replace('</body>', `  ${injectionTag}\n    ${bundleScriptTag}\n  </body>`);

  fs.writeFileSync(indexHtmlPath, html, 'utf8');
  fs.writeFileSync(path.join(DIST_STATIC_DIR, '.nojekyll'), '', 'utf8');
  fs.writeFileSync(
    path.join(DIST_STATIC_DIR, 'README-DEPLOYMENT.txt'),
    [
      'LIVINGSTONE KOLOBENG COLLEGE — STATIC PUBLIC WEBSITE EXPORT',
      `Exported: ${new Date().toISOString()}`,
      '',
      '1. OPENING LOCALLY:',
      '   - Extract this entire ZIP archive into a normal folder first so that',
      '     index.html sits alongside the assets/ and uploads/ folders.',
      '   - Open index.html in Chrome, Edge, Safari, or Firefox.',
      '',
      '2. DEPLOYING TO WEB HOSTING (cPanel / Apache / Nginx / GitHub Pages / Cloudflare / Netlify):',
      '   - Upload the entire extracted contents of this folder (index.html,',
      '     index.php, api.php, .htaccess, robots.txt, assets/, uploads/) to your web root (e.g. public_html/).',
      '',
      '3. NOTES:',
      '   - This static archive is strictly sanitized of all CMS user accounts,',
      '     passwords, sessions, audit logs, and unpublished items.',
      '   - For live CMS editing and database uploads, deploy the full Node.js',
      '     + Express + SQLite application server (server.ts + dist/ + storage/).',
      '',
    ].join('\n'),
    'utf8'
  );

  return DIST_STATIC_DIR;
}

const isCli =
  process.argv[1] &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;

if (isCli) {
  const isDistMode = process.argv.includes('--dist');
  const task = isDistMode
    ? finalizeDistBuild().then((outDir) => {
        console.log(`Finalized portable dist build in: ${outDir}`);
      })
    : buildStaticExport({ rebuildViteIfMissing: false }).then((outDir) => {
        console.log(`Static public LKC website exported cleanly to: ${outDir}`);
      });

  task.catch((err) => {
    console.error(isDistMode ? 'Dist finalization failed:' : 'Static export failed:', err);
    process.exit(1);
  });
}
