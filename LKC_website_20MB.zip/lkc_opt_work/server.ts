import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import cookieParser from 'cookie-parser';
import { createApiRouter } from './src/server/routes.ts';
import { getDb, UPLOADS_DIR } from './src/server/db.ts';

async function startServer(): Promise<void> {
  // Ensure SQLite DB and storage directories are initialized on startup
  getDb();
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });

  const app = express();
  app.set('trust proxy', 1);
  const port = Number(process.env.PORT || 3000);
  const isProd = process.env.NODE_ENV === 'production';
  const distDir = path.resolve(process.cwd(), 'dist');
  const distIndexPath = path.join(distDir, 'index.html');

  app.use(cookieParser());
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true }));

  // Normalize nested relative asset/upload URLs on deep-linked SPA routes (e.g. /campus/assets/... -> /assets/...)
  app.use((req, _res, next) => {
    if (!req.url.startsWith('/api/')) {
      const assetsIdx = req.url.indexOf('/assets/');
      if (assetsIdx > 0) {
        req.url = req.url.slice(assetsIdx);
      } else {
        const uploadsIdx = req.url.indexOf('/uploads/');
        if (uploadsIdx > 0) {
          req.url = req.url.slice(uploadsIdx);
        }
      }
    }
    next();
  });

  // Serve persistent uploaded media files cleanly from storage/uploads, with fallback to dist/uploads
  app.use('/uploads', express.static(UPLOADS_DIR, { maxAge: '7d' }));
  app.use('/uploads', express.static(path.join(distDir, 'uploads'), { maxAge: '7d' }));
  app.use('/uploads', (_req, res) => {
    res.status(404).end();
  });

  // Mount API routes and ensure unknown /api/* requests always return JSON 404
  app.use('/api', createApiRouter());
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  // Error handler for upload / malformed JSON / unexpected server errors
  app.use(
    (
      err: Error & { status?: number; statusCode?: number },
      _req: express.Request,
      res: express.Response,
      _next: express.NextFunction
    ) => {
      const statusCode = err.status || err.statusCode || 500;
      if (statusCode >= 500) {
        console.error('[LKC Server Error]', err);
      }
      res.status(statusCode).json({ error: err.message || 'Internal server error' });
    }
  );

  if (isProd && fs.existsSync(distIndexPath)) {
    app.use(express.static(distDir, { index: false, maxAge: '1h' }));
    app.get('*', (_req, res) => {
      const html = fs
        .readFileSync(distIndexPath, 'utf8')
        .replace(/window\.__LKC_STATIC_MODE__\s*=\s*true\s*;/g, 'window.__LKC_STATIC_MODE__=false;');
      res.setHeader('Content-Type', 'text/html; charset=UTF-8');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.send(html);
    });
  } else {
    if (isProd && !fs.existsSync(distIndexPath)) {
      console.warn('[LKC Server] dist/index.html not found in production mode; falling back to Vite middleware.');
    }
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`LKC CMS & Portal server listening on http://localhost:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start LKC server:', err);
  process.exit(1);
});
