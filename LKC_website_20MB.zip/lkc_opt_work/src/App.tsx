/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, Suspense, lazy } from 'react';
import { motion, MotionConfig } from 'motion/react';
import { Header } from './components/Header';
import { HomePage } from './components/HomePage';
import { CampusPage } from './components/CampusPage';
import { DepartmentsSection } from './components/DepartmentsSection';
import { CurriculumSection } from './components/CurriculumSection';
import { SportsPage } from './components/SportsPage';
import { AthleticsPage } from './components/AthleticsPage';
import { JaguarsPage } from './components/JaguarsPage';
import { FeeCalculator } from './components/FeeCalculator';
import { FaqContactSection } from './components/FaqContactSection';
import { BoardingPage } from './components/BoardingPage';
import { ExcursionsPage } from './components/ExcursionsPage';
import { AlumniPage } from './components/AlumniPage';
import { AchieversPage } from './components/AchieversPage';
import { NewsEventsPage } from './components/NewsEventsPage';
import { Footer } from './components/Footer';
import { AdmissionsModal } from './components/AdmissionsModal';
import { ProspectusModal } from './components/ProspectusModal';
import { PortalModal } from './components/PortalModal';
import { ImageLightboxHost } from './components/ImageLightboxModal';
import { ShortcutsHelpModal } from './components/ShortcutsHelpModal';
import { applyTheme, getInitialTheme, type ThemeMode } from './utils/theme';
import {
  initializeDefaultData,
  isStaticSiteMode,
  recordDiagnosticError,
  useCmsDiagnostics,
  useCmsSection,
} from './services/cmsDataService';
import type { PageKey } from './types';

const AdminCmsModal = lazy(() =>
  import('./components/AdminCmsModal').then((m) => ({ default: m.AdminCmsModal }))
);

export type PageRoute = PageKey;

const VALID_PAGES = new Set<PageRoute>([
  'home',
  'campus',
  'boarding',
  'excursions',
  'alumni',
  'achievers',
  'sports',
  'athletics',
  'jaguars',
  'departments',
  'curriculum',
  'fees',
  'contact',
  'news',
  'events',
]);

const SECTION_TO_PAGE_MAP: Record<string, PageRoute> = {
  about: 'campus',
  'campus-life': 'campus',
  'heads-of-year': 'departments',
  'a-level-coordinator': 'departments',
  'pastoral-care-a-level': 'departments',
  residences: 'boarding',
  routine: 'boarding',
  cafeteria: 'boarding',
  'excursions-list': 'excursions',
  profiles: 'alumni',
  register: 'alumni',
  'house-trophy': 'sports',
  facilities: 'sports',
  fixtures: 'jaguars',
  directors: 'home',
};

function resolvePageFromHash(): PageRoute {
  if (typeof window === 'undefined') return 'home';
  const rawHash = window.location.hash
    .replace(/^#\/?/, '')
    .split('?')[0]
    .trim()
    .toLowerCase();
  if (!rawHash) return 'home';
  if (VALID_PAGES.has(rawHash as PageRoute)) {
    return rawHash as PageRoute;
  }
  if (rawHash in SECTION_TO_PAGE_MAP) {
    return SECTION_TO_PAGE_MAP[rawHash];
  }
  return 'home';
}

function checkDebugModeEnabled(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const searchParams = new URLSearchParams(window.location.search);
    if (searchParams.get('debug') === '1') return true;
    const hashQueryIdx = window.location.hash.indexOf('?');
    if (hashQueryIdx !== -1) {
      const hashParams = new URLSearchParams(window.location.hash.slice(hashQueryIdx + 1));
      if (hashParams.get('debug') === '1') return true;
    }
  } catch {
    // Ignore URL parsing issues
  }
  return false;
}

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

export class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      message: error?.message || 'An unexpected rendering issue occurred.',
    };
  }

  componentDidCatch(error: Error) {
    recordDiagnosticError(`React render error: ${error?.message || String(error)}`);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-white text-[#0c1a40] flex items-center justify-center p-6">
          <div className="max-w-lg w-full rounded-2xl border border-blue-200 bg-blue-50/50 p-8 text-center shadow-sm space-y-4">
            <div className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold">
              Livingstone Kolobeng College
            </div>
            <h1 className="text-2xl font-serif font-bold text-[#0c1a40]">
              Unable to Display This Page
            </h1>
            <p className="text-sm text-blue-900/80 leading-relaxed">
              {this.state.message}
            </p>
            <div className="p-3.5 rounded-xl bg-white border border-blue-100 text-xs text-blue-950 space-y-1">
              <div className="font-semibold text-[#0c1a40]">Need immediate assistance?</div>
              <div>
                Telephone:{' '}
                <a href="tel:+2673161140" className="font-mono font-bold underline">
                  +267 316 1140
                </a>{' '}
                ·{' '}
                <a href="tel:+2673162208" className="font-mono font-bold underline">
                  +267 316 2208
                </a>
              </div>
              <div>
                WhatsApp:{' '}
                <a
                  href="https://wa.me/26778465196"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono font-bold underline text-amber-700"
                >
                  +267 78 465 196
                </a>
              </div>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="px-5 py-2.5 rounded-lg bg-[#0c1a40] text-amber-300 font-semibold text-xs hover:bg-[#162a6b] cursor-pointer"
              >
                Reload Website
              </button>
              <button
                type="button"
                onClick={() => {
                  window.location.hash = '#home';
                  this.setState({ hasError: false, message: '' });
                }}
                className="px-5 py-2.5 rounded-lg bg-white border border-blue-200 text-[#0c1a40] font-semibold text-xs hover:bg-blue-50 cursor-pointer"
              >
                Return to Homepage
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  const [activePage, setActivePage] = useState<PageRoute>(() => resolvePageFromHash());
  const [isAdmissionsOpen, setIsAdmissionsOpen] = useState<boolean>(false);
  const [isProspectusOpen, setIsProspectusOpen] = useState<boolean>(false);
  const [isPortalOpen, setIsPortalOpen] = useState<boolean>(false);
  const [isAdminCmsOpen, setIsAdminCmsOpen] = useState<boolean>(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState<boolean>(false);
  const [theme, setTheme] = useState<ThemeMode>(() => getInitialTheme());
  const [isDebugVisible, setIsDebugVisible] = useState<boolean>(() => checkDebugModeEnabled());

  const settings = useCmsSection('settings');
  const diagnostics = useCmsDiagnostics();
  const staticMode = isStaticSiteMode();

  useEffect(() => {
    initializeDefaultData();

    const syncAdminHash = (rawHash: string) => {
      if ((rawHash === 'admin' || rawHash === 'cms') && !isStaticSiteMode()) {
        setIsAdminCmsOpen(true);
      }
    };

    const initialHash = window.location.hash
      .replace(/^#\/?/, '')
      .split('?')[0]
      .trim()
      .toLowerCase();
    syncAdminHash(initialHash);

    const syncFromHash = () => {
      const rawHash = window.location.hash
        .replace(/^#\/?/, '')
        .split('?')[0]
        .trim()
        .toLowerCase();
      syncAdminHash(rawHash);
      const nextPage = resolvePageFromHash();
      setActivePage(nextPage);
      setIsDebugVisible(checkDebugModeEnabled());
      window.setTimeout(() => {
        if (rawHash && rawHash in SECTION_TO_PAGE_MAP) {
          const targetEl = document.getElementById(rawHash);
          if (targetEl) {
            targetEl.scrollIntoView({ behavior: 'smooth' });
            return;
          }
        }
        window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
      }, 20);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isInputFocused =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable);

      if (e.key === 'Escape') {
        setIsShortcutsOpen(false);
        return;
      }

      if (isInputFocused) return;

      if (!isStaticSiteMode() && (e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        setIsAdminCmsOpen((prev) => !prev);
        return;
      }

      if (e.key === '?' && !e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault();
        setIsShortcutsOpen((prev) => !prev);
        return;
      }

      if (e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey) {
        const keyLower = e.key.toLowerCase();
        const shortcutPageMap: Record<string, PageRoute> = {
          h: 'home',
          d: 'departments',
          c: 'curriculum',
          f: 'fees',
          n: 'news',
        };
        if (keyLower in shortcutPageMap) {
          e.preventDefault();
          const targetPage = shortcutPageMap[keyLower];
          setIsShortcutsOpen(false);
          setActivePage(targetPage);
          const targetHash = `#${targetPage}`;
          if (window.location.hash !== targetHash) {
            window.location.hash = targetHash;
          }
          window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
        } else if (keyLower === 't') {
          e.preventDefault();
          window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
        }
      }
    };

    window.addEventListener('hashchange', syncFromHash);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('hashchange', syncFromHash);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [staticMode]);

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  useEffect(() => {
    if (settings.siteTitle) {
      document.title = settings.siteTitle;
    }
    if (settings.metaDescription) {
      const meta = document.querySelector('meta[name="description"]');
      if (meta) {
        meta.setAttribute('content', settings.metaDescription);
      }
    }
  }, [settings.siteTitle, settings.metaDescription]);

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleNavigate = (page: PageRoute) => {
    setActivePage(page);
    if (typeof window !== 'undefined') {
      const targetHash = `#${page}`;
      if (window.location.hash !== targetHash) {
        window.location.hash = targetHash;
      }
    }
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
  };

  return (
    <AppErrorBoundary>
      <MotionConfig reducedMotion="user">
        <div className="min-h-screen flex flex-col bg-[var(--surface-page)] text-[var(--text-primary)] font-sans selection:bg-amber-200 selection:text-[#0c1a40] overflow-x-clip transition-colors duration-200">
          <Header
            activePage={activePage}
            onNavigate={handleNavigate}
            onOpenAdmissions={() => setIsAdmissionsOpen(true)}
            onOpenPortal={() => setIsPortalOpen(true)}
            theme={theme}
            onToggleTheme={handleToggleTheme}
          />

          <main className="flex-1">
            <motion.div
              key={activePage}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            >
              {activePage === 'home' && (
                <HomePage
                  onNavigate={handleNavigate}
                  onOpenAdmissions={() => setIsAdmissionsOpen(true)}
                  onOpenProspectus={() => setIsProspectusOpen(true)}
                />
              )}

          {activePage === 'campus' && (
            <CampusPage
              onNavigate={handleNavigate}
              onOpenAdmissions={() => setIsAdmissionsOpen(true)}
            />
          )}

          {activePage === 'departments' && (
            <DepartmentsSection
              onOpenProspectus={() => setIsProspectusOpen(true)}
              onOpenAdmissions={() => setIsAdmissionsOpen(true)}
            />
          )}

          {activePage === 'curriculum' && (
            <CurriculumSection
              onOpenProspectus={() => setIsProspectusOpen(true)}
            />
          )}

          {activePage === 'fees' && <FeeCalculator />}

          {activePage === 'contact' && <FaqContactSection />}

          {activePage === 'news' && <NewsEventsPage key="news" initialTab="news" />}

          {activePage === 'events' && <NewsEventsPage key="events" initialTab="events" />}

          {activePage === 'boarding' && (
            <BoardingPage
              onOpenAdmissions={() => setIsAdmissionsOpen(true)}
            />
          )}

          {activePage === 'excursions' && (
            <ExcursionsPage
              onOpenAdmissions={() => setIsAdmissionsOpen(true)}
            />
          )}

          {activePage === 'alumni' && (
            <AlumniPage
              onOpenAdmissions={() => setIsAdmissionsOpen(true)}
            />
          )}

          {activePage === 'achievers' && (
            <AchieversPage
              onOpenAdmissions={() => setIsAdmissionsOpen(true)}
            />
          )}

          {activePage === 'sports' && (
            <SportsPage
              onOpenAdmissions={() => setIsAdmissionsOpen(true)}
              onNavigateToJaguars={() => handleNavigate('jaguars')}
              onNavigateToAthletics={() => handleNavigate('athletics')}
            />
          )}

          {activePage === 'athletics' && (
            <AthleticsPage onNavigate={handleNavigate} />
          )}

              {activePage === 'jaguars' && (
                <JaguarsPage
                  onOpenAdmissions={() => setIsAdmissionsOpen(true)}
                  onNavigateToSports={() => handleNavigate('sports')}
                />
              )}
            </motion.div>
          </main>

        <Footer
          onNavigate={handleNavigate}
          onOpenAdmissions={() => setIsAdmissionsOpen(true)}
          onOpenPortal={() => setIsPortalOpen(true)}
          onOpenProspectus={() => setIsProspectusOpen(true)}
        />

        <AdmissionsModal
          isOpen={isAdmissionsOpen}
          onClose={() => setIsAdmissionsOpen(false)}
        />

        <ProspectusModal
          isOpen={isProspectusOpen}
          onClose={() => setIsProspectusOpen(false)}
        />

        <PortalModal
          isOpen={isPortalOpen}
          onClose={() => setIsPortalOpen(false)}
          onOpenAdminCms={() => setIsAdminCmsOpen(true)}
        />

        <ImageLightboxHost />

        <ShortcutsHelpModal
          isOpen={isShortcutsOpen}
          onToggle={() => setIsShortcutsOpen((prev) => !prev)}
          onClose={() => setIsShortcutsOpen(false)}
          onNavigate={handleNavigate}
          staticMode={staticMode}
        />

        {!staticMode && AdminCmsModal && isAdminCmsOpen && (
          <Suspense fallback={null}>
            <AdminCmsModal
              isOpen={isAdminCmsOpen}
              onClose={() => setIsAdminCmsOpen(false)}
            />
          </Suspense>
        )}

        {isDebugVisible && (
          <aside
            data-testid="lkc-debug-panel"
            className="fixed bottom-4 right-4 z-50 max-w-sm w-[calc(100vw-2rem)] rounded-xl border border-amber-400/70 bg-[#081226]/95 text-white p-4 shadow-2xl text-xs font-mono space-y-2 backdrop-blur-sm"
          >
            <div className="flex items-center justify-between border-b border-white/15 pb-1.5">
              <span className="font-bold text-amber-300 uppercase tracking-wider">
                LKC Diagnostics (?debug=1)
              </span>
              <button
                type="button"
                onClick={() => setIsDebugVisible(false)}
                className="text-blue-200 hover:text-white cursor-pointer px-1.5 py-0.5 rounded bg-white/10"
              >
                Close
              </button>
            </div>
            <div className="space-y-1 text-[11px] text-blue-100">
              <div>
                <span className="text-blue-300">Active Page:</span>{' '}
                <strong className="text-white">{activePage}</strong>
              </div>
              <div>
                <span className="text-blue-300">Hash:</span>{' '}
                <span className="text-amber-200">
                  {typeof window !== 'undefined' && window.location.hash ? window.location.hash : '(empty -> home)'}
                </span>
              </div>
              <div>
                <span className="text-blue-300">Data Source:</span>{' '}
                <strong className="text-emerald-300">{diagnostics.dataSource}</strong>
              </div>
              <div>
                <span className="text-blue-300">Mode:</span>{' '}
                <span>{staticMode ? 'Static / Shared Hosting' : 'Live Server'}</span>
              </div>
              <div>
                <span className="text-blue-300">Errors:</span>{' '}
                {diagnostics.errors.length === 0 ? (
                  <span className="text-emerald-300">None (0)</span>
                ) : (
                  <ul className="mt-1 space-y-1 text-rose-300 list-disc pl-4">
                    {diagnostics.errors.map((errMsg, idx) => (
                      <li key={idx} className="break-words">
                        {errMsg}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </aside>
        )}
        </div>
      </MotionConfig>
    </AppErrorBoundary>
  );
}
