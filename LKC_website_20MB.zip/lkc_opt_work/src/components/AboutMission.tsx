import React from 'react';
import { Compass, BookCheck, Users, Globe2, Quote } from 'lucide-react';
import { useCmsSection } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { openImageViewer } from './ImageLightboxModal';

export const AboutMission: React.FC = () => {
  const about = useCmsSection('about');
  const general = useCmsSection('general');

  const visibleLeadership = (about.leadership || [])
    .filter((m) => m.status !== 'unpublished' && m.status !== 'archived')
    .sort((a, b) => (a.order ?? 99) - (b.order ?? 99));
  const managingDirector =
    visibleLeadership.find(
      (m) => m.id === 'lead-md' || m.role.toLowerCase() === 'managing director'
    ) || visibleLeadership[0];
  const principal =
    visibleLeadership.find(
      (m) => m.id === 'lead-principal' || m.role.toLowerCase() === 'principal'
    ) || visibleLeadership[1];
  const smtMembers = visibleLeadership.filter(
    (m) => m !== managingDirector && m !== principal
  );
  const visibleDirectors = (about.directors || [])
    .filter((d) => d.status !== 'unpublished' && d.status !== 'archived')
    .sort((a, b) => (a.order ?? 99) - (b.order ?? 99));

  return (
    <section id="about" className="py-20 bg-blue-50/40 border-b border-blue-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">

        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-2">
            {about.heritageBadge}
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#0c1a40] tracking-tight text-balance">
            {about.heritageHeading}
          </h2>
          <div className="w-16 h-0.5 bg-amber-500 mt-4 mb-6" />
          <div className="space-y-3 text-base text-blue-950/85 leading-relaxed font-sans">
            <p>{about.heritageParagraph1}</p>
            <p>{about.heritageParagraph2}</p>
          </div>
        </div>

        {/* 1. MANAGING DIRECTOR'S ADDRESS */}
        {managingDirector && (
          <div className="bg-white rounded-2xl border border-blue-200 shadow-sm overflow-hidden mb-12">
            <div className="p-4 sm:p-5 bg-gradient-to-r from-[#081226] via-[#0c1a40] to-[#162a6b] text-white flex flex-wrap items-center justify-between gap-3 border-b border-blue-900">
              <div className="flex items-center gap-2.5">
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400">
                  Managing Directorate · Executive Governance
                </span>
              </div>
              <div className="text-xs text-blue-200 font-mono">
                Established {general.established} · Gaborone, Botswana
              </div>
            </div>

            <div className="p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-4 flex flex-col items-center text-center">
                <div className="relative group">
                  <div className="w-48 h-56 sm:w-56 sm:h-64 rounded-2xl overflow-hidden border-2 border-amber-400 shadow-md bg-blue-50">
                    {managingDirector.image ? (
                      <img
                        src={managingDirector.image}
                        alt={managingDirector.name}
                        loading="lazy"
                        onError={handleImageFallback}
                        onClick={() =>
                          openImageViewer({
                            src: managingDirector.image!,
                            title: managingDirector.name,
                            subtitle: `${managingDirector.role || 'Executive Governance'} · ${managingDirector.title}`,
                          })
                        }
                        className="w-full h-full object-cover object-top transition duration-300 group-hover:scale-105 cursor-zoom-in"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-[#0c1a40] text-amber-400 font-serif text-4xl font-bold">
                        {managingDirector.name[0]}
                      </div>
                    )}
                  </div>
                  <div className="mt-3 inline-block bg-[#0c1a40] text-amber-400 px-3 py-1 rounded-md text-[11px] font-mono font-semibold tracking-wider border border-blue-800">
                    {managingDirector.role || 'Executive Governance'}
                  </div>
                </div>

                <div className="mt-3">
                  <h3 className="font-serif font-bold text-xl text-[#0c1a40]">
                    {managingDirector.name}
                  </h3>
                  <div className="text-xs font-semibold text-amber-700 mt-1">
                    {managingDirector.title}
                  </div>
                </div>
              </div>

              <div className="lg:col-span-8 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-amber-700 mb-3">
                    <Quote className="w-6 h-6 text-amber-500" />
                    <span className="text-xs font-mono uppercase tracking-widest font-bold">
                      Message from the Managing Director
                    </span>
                  </div>
                  <div className="max-w-none text-blue-950/90 font-sans text-sm sm:text-base leading-relaxed space-y-4">
                    <p>
                      {managingDirector.message}
                    </p>
                    <p className="text-xs sm:text-sm text-blue-900/80">
                      Our stewardship prioritizes the highest safety standards, sound fiscal administration, sustained campus development, and strong partnerships with parents and the Ministry of Basic Education.
                    </p>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-blue-100 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="font-serif font-bold text-[#0c1a40] text-sm">{managingDirector.name}</div>
                    <div className="text-xs text-blue-800/80">{managingDirector.title} · {general.name}</div>
                  </div>
                  <div className="text-xs text-amber-900 font-mono bg-amber-50 px-3 py-1 rounded-md border border-amber-300">
                    Institutional Stewardship & Strategy
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. PRINCIPAL'S ADDRESS */}
        {principal && (
          <div className="bg-white rounded-2xl border border-blue-200 shadow-sm overflow-hidden mb-16">
            <div className="p-4 sm:p-5 bg-gradient-to-r from-[#0c1a40] via-[#162a6b] to-[#0c1a40] text-white flex flex-wrap items-center justify-between gap-3 border-b border-blue-900">
              <div className="flex items-center gap-2.5">
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400">
                  Principal's Desk · Academic Standards
                </span>
              </div>
              <div className="text-xs text-blue-200 font-mono">
                {general.cambridgeCentreNo}
              </div>
            </div>

            <div className="p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-4 flex flex-col items-center text-center">
                <div className="relative group">
                  <div className="w-48 h-56 sm:w-56 sm:h-64 rounded-2xl overflow-hidden border-2 border-blue-900 shadow-md bg-blue-50">
                    {principal.image ? (
                      <img
                        src={principal.image}
                        alt={principal.name}
                        loading="lazy"
                        onError={handleImageFallback}
                        onClick={() =>
                          openImageViewer({
                            src: principal.image!,
                            title: principal.name,
                            subtitle: `${principal.role || 'Principal'} · ${principal.title}`,
                          })
                        }
                        className="w-full h-full object-cover object-top transition duration-300 group-hover:scale-105 cursor-zoom-in"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-[#0c1a40] text-amber-400 font-serif text-4xl font-bold">
                        {principal.name[0]}
                      </div>
                    )}
                  </div>
                  <div className="mt-3 inline-block bg-[#0c1a40] text-amber-400 px-3 py-1 rounded-md text-[11px] font-mono font-semibold tracking-wider border border-blue-800">
                    {principal.role || 'Senior Academician'}
                  </div>
                </div>

                <div className="mt-3">
                  <h3 className="font-serif font-bold text-xl text-[#0c1a40]">
                    {principal.name}
                  </h3>
                  <div className="text-xs font-semibold text-amber-700 mt-1">
                    {principal.title}
                  </div>
                </div>
              </div>

              <div className="lg:col-span-8 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-amber-700 mb-3">
                    <Quote className="w-6 h-6 text-amber-500" />
                    <span className="text-xs font-mono uppercase tracking-widest font-bold">
                      Address from the Principal's Desk
                    </span>
                  </div>
                  <div className="max-w-none text-blue-950/90 font-sans text-sm sm:text-base leading-relaxed space-y-4">
                    <p>{principal.message}</p>
                    <p className="text-xs sm:text-sm text-blue-900/80">
                      With eight specialized academic departments and our dedicated subject educators, Livingstone Kolobeng College guarantees supportive cohorts and direct university matriculation guidance.
                    </p>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-blue-100 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="font-serif font-bold text-[#0c1a40] text-sm">{principal.name}</div>
                    <div className="text-xs text-blue-800/80">{principal.title} · {general.name}</div>
                  </div>
                  <div className="text-xs text-blue-800 font-mono tracking-wider">
                    {general.cambridgeCentreNo} · Gaborone
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 3. SENIOR MANAGEMENT TEAM (SMT) SECTION */}
        <div className="mb-16">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1">
                Academic Administration & Governance
              </div>
              <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
                Senior Management Team (SMT)
              </h3>
              <p className="text-xs sm:text-sm text-blue-900/80 mt-1">
                Guiding curriculum standards, Cambridge A-Level excellence, student pastoral welfare, and campus operational administration.
              </p>
            </div>
            <div className="text-xs font-mono text-[#0c1a40] bg-amber-100 border border-amber-300 px-3 py-1.5 rounded-lg shrink-0 font-semibold">
              Executive Directorate · LKC SMT
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {smtMembers.map((member) => (
              <div
                key={member.id || member.name}
                className="bg-white rounded-2xl border border-blue-200 shadow-xs overflow-hidden flex flex-col justify-between hover:border-amber-400 transition-all duration-200 group"
              >
                <div>
                  <div className="h-56 bg-blue-50 relative overflow-hidden border-b border-blue-100">
                    {member.image ? (
                      <img
                        key={`${member.id || member.name}-${member.image}`}
                        src={member.image}
                        alt={member.name}
                        loading="lazy"
                        onError={handleImageFallback}
                        onClick={() =>
                          openImageViewer({
                            src: member.image!,
                            title: member.name,
                            subtitle: `${member.role || member.title} · Senior Management Team`,
                          })
                        }
                        className="w-full h-full object-cover object-top transition duration-300 group-hover:scale-105 cursor-zoom-in"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-[#0c1a40] font-serif text-3xl font-bold text-amber-400">
                        {member.name.split(' ').slice(-1)[0][0]}
                      </div>
                    )}
                    <div className="px-3 py-1 bg-[#0c1a40] text-amber-400 text-[10px] font-mono font-semibold border-t border-blue-900">
                      SMT Member · {member.department || 'Leadership'}
                    </div>
                  </div>

                  <div className="p-5">
                    <h4 className="font-serif font-bold text-base text-[#0c1a40] leading-snug">
                      {member.name}
                    </h4>
                    <div className="text-xs font-semibold text-amber-700 mt-1 mb-2">
                      {member.role || member.title}
                    </div>
                    <p className="text-xs text-blue-950/80 leading-relaxed font-sans line-clamp-4">
                      {member.bio || member.message}
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-blue-50/70 border-t border-blue-100 text-[11px] text-[#0c1a40] font-mono font-medium">
                  {member.department || member.title}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 3B. DIRECTORS SECTION (SEPARATE FROM SMT) */}
        {visibleDirectors.length > 0 && (
          <div id="campus-directors" className="mb-16 pt-12 border-t border-blue-200">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
              <div>
                <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1">
                  Academic & Infrastructure Directorate
                </div>
                <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
                  Directors
                </h3>
                <p className="text-xs sm:text-sm text-blue-900/80 mt-1">
                  Divisional directors leading Lower School, Upper School, and ICT Infrastructure.
                </p>
              </div>
              <div className="text-xs font-mono text-[#0c1a40] bg-amber-100 border border-amber-300 px-3 py-1.5 rounded-lg shrink-0 font-semibold">
                College Directorate · LKC
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {visibleDirectors.map((director, idx) => (
                <div
                  key={director.id || director.name || idx}
                  className="bg-white rounded-2xl border border-blue-200 shadow-xs overflow-hidden flex flex-col justify-between hover:border-amber-400 transition-all duration-200 group"
                >
                  <div>
                    <div className="h-64 bg-blue-50 relative overflow-hidden border-b border-blue-100">
                      {director.image ? (
                        <img
                          src={director.image}
                          alt={director.name}
                          loading="lazy"
                          onError={handleImageFallback}
                          onClick={() =>
                            openImageViewer({
                              src: director.image!,
                              title: director.name,
                              subtitle: `${director.role || director.title} · College Directorate`,
                            })
                          }
                          className="w-full h-full object-cover object-top transition duration-300 group-hover:scale-105 cursor-zoom-in"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-[#0c1a40] font-serif text-3xl font-bold text-amber-400">
                          {director.name.split(' ').slice(-1)[0]?.[0] || 'D'}
                        </div>
                      )}
                    </div>

                    <div className="px-4 py-1.5 bg-[#0c1a40] text-amber-400 text-[10px] font-mono font-semibold border-b border-blue-900">
                      Director · LKC Directorate
                    </div>

                    <div className="p-5">
                      <h4 className="font-serif font-bold text-lg text-[#0c1a40] leading-snug">
                        {director.name}
                      </h4>
                      <div className="text-xs font-semibold text-amber-700 mt-1">
                        {director.role || director.title}
                      </div>
                      {director.bio && director.bio.trim() && (
                        <p className="text-xs text-blue-950/80 leading-relaxed font-sans mt-2 line-clamp-4">
                          {director.bio}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="px-5 py-3 bg-blue-50/70 border-t border-blue-100 text-[11px] text-[#0c1a40] font-mono font-medium">
                    {director.role || director.title}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 4. STRATEGIC PILLARS, MISSION, VISION & CORE VALUES */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pt-8 border-t border-blue-200">
          <div className="lg:col-span-8 bg-[#0c1a40] text-white p-8 sm:p-10 rounded-2xl shadow-sm border border-blue-900">
            <div className="text-xs uppercase tracking-widest text-amber-400 mb-2 font-mono font-semibold">
              Core Institutional Pillars
            </div>
            <h3 className="text-2xl font-serif font-bold mb-6 text-white">
              The Four Pillars of {general.name}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs sm:text-sm">
              {about.heritagePoints.map((pt, i) => {
                const Icon = i === 0 ? BookCheck : i === 1 ? Compass : i === 2 ? Users : Globe2;
                return (
                  <div key={pt.title} className="flex gap-3">
                    <Icon className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-white text-sm">{pt.title}</h4>
                      <p className="text-blue-100 text-xs mt-1 leading-relaxed">{pt.subtitle}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-4 p-8 bg-amber-50 rounded-2xl border border-amber-300 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-wider text-amber-800 font-bold mb-2">
                {about.missionTitle} & {about.visionTitle}
              </div>
              <p className="text-xs text-[#0c1a40] leading-relaxed mb-4">{about.missionText}</p>
              <p className="text-xs text-blue-950/85 leading-relaxed mb-4 border-t border-amber-200 pt-3">
                {about.visionText}
              </p>
              <div className="text-xs text-amber-900 font-semibold">
                {about.valuesList.join(' · ')}
              </div>
            </div>
            <div className="mt-5 pt-4 border-t border-amber-200">
              <div className="text-xs text-[#0c1a40] font-bold font-sans">{general.name}</div>
              <div className="text-[11px] text-amber-800 font-mono">{`${general.address.plot}, ${general.address.area}, ${general.address.city}, ${general.address.country}`}</div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
