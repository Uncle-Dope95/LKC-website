import React from 'react';
import {
  Cpu,
  FlaskConical,
  Briefcase,
  ShieldCheck,
  Leaf,
  Award,
  HeartHandshake,
  GraduationCap,
  CheckCircle2,
  Compass,
  Target,
  Sparkles,
} from 'lucide-react';

interface AcademicVisionAndProgrammesProps {
  showCurriculumStages?: boolean;
}

const CAMBRIDGE_STAGES = [
  {
    stage: 'Form 1–3',
    name: 'Lower School',
    focus: 'Broad foundational academic curriculum building literacy, numeracy, scientific inquiry and digital competence',
  },
  {
    stage: 'Form 4–5',
    name: 'Cambridge IGCSE',
    focus: 'Internationally recognised secondary qualifications preparing students for advanced academic study',
  },
  {
    stage: 'AS Level',
    name: 'Advanced Subsidiary',
    focus: 'Specialised pre-university academic study in selected subject areas',
  },
  {
    stage: 'A2 Level',
    name: 'Advanced Level',
    focus: 'In-depth academic mastery and full A-Level qualification preparing students for university entry',
  },
];

const EDUCATIONAL_PRIORITIES = [
  'Academic rigour and critical inquiry',
  'Analytical and creative thinking',
  'Practical and investigative learning skills',
  'Digital fluency and technological readiness',
  'Leadership, teamwork and ethical character',
  'Effective communication across languages',
  'Readiness for global universities and evolving career pathways',
];

const SCHOOL_WIDE_PROGRAMMES = [
  {
    title: 'Artificial Intelligence Programme',
    description: 'Ethical use of AI, prompt literacy, AI applications across disciplines and future-ready technology skills.',
    icon: Sparkles,
  },
  {
    title: 'STEM Programme',
    description: 'Cross-curricular projects integrating Science, Technology, Engineering and Mathematics.',
    icon: FlaskConical,
  },
  {
    title: 'Entrepreneurship Programme',
    description: 'Business ideation, financial literacy, innovation challenges and enterprise projects.',
    icon: Briefcase,
  },
  {
    title: 'Digital Citizenship',
    description: 'Online safety, cybersecurity awareness, responsible technology use and academic integrity.',
    icon: ShieldCheck,
  },
  {
    title: 'Environmental Sustainability',
    description: 'Eco-initiatives, recycling, green campus projects and climate awareness.',
    icon: Leaf,
  },
  {
    title: 'Leadership Development',
    description: 'Student council, prefect leadership, peer mentoring and service leadership.',
    icon: Award,
  },
  {
    title: 'Community Engagement',
    description: 'Outreach initiatives, charitable projects and community service partnerships.',
    icon: HeartHandshake,
  },
  {
    title: 'University & Career Guidance',
    description: 'Subject selection guidance, university applications, career awareness and alumni mentorship.',
    icon: GraduationCap,
  },
];

export const AcademicVisionAndProgrammes: React.FC<AcademicVisionAndProgrammesProps> = ({
  showCurriculumStages = true,
}) => {
  return (
    <div className="space-y-12 mt-14 pt-12 border-t border-blue-200">
      {showCurriculumStages && (
        <div className="bg-white rounded-2xl border border-blue-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="max-w-3xl">
            <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1.5 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-amber-600" />
              <span>Cambridge International Curriculum Framework</span>
            </div>
            <h3 className="text-2xl font-serif font-bold text-[#0c1a40]">
              Academic Progression from Form 1 to A Level (A2)
            </h3>
            <p className="text-xs sm:text-sm text-blue-900 mt-1.5 leading-relaxed">
              Livingstone Kolobeng College delivers a balanced Cambridge International education structured to build deep subject knowledge, practical ability and character across every stage.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {CAMBRIDGE_STAGES.map((st) => (
              <div
                key={st.stage}
                className="p-4 rounded-xl bg-blue-50/70 border border-blue-200 flex flex-col justify-between"
              >
                <div>
                  <span className="inline-block px-2.5 py-0.5 rounded bg-[#0c1a40] text-amber-300 text-[10px] font-mono font-bold uppercase mb-2">
                    {st.stage}
                  </span>
                  <h4 className="font-serif font-bold text-base text-[#0c1a40] mb-1.5">
                    {st.name}
                  </h4>
                  <p className="text-xs text-blue-950/85 leading-relaxed">
                    {st.focus}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-4 border-t border-blue-100 items-start">
            <div className="lg:col-span-7">
              <h4 className="text-xs uppercase tracking-wider font-bold text-[#0c1a40] font-mono mb-3">
                Our Educational Priorities Across Every Stage
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {EDUCATIONAL_PRIORITIES.map((priority) => (
                  <div
                    key={priority}
                    className="flex items-start gap-2 text-xs text-blue-950 bg-blue-50/50 px-3 py-2 rounded-lg border border-blue-100"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <span>{priority}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-5 p-4 rounded-xl bg-amber-50/80 border border-amber-200 text-xs text-blue-950 leading-relaxed">
              <div className="font-mono text-[10px] font-bold uppercase tracking-wider text-amber-800 mb-1">
                Cambridge Registration Notice
              </div>
              Note: The exact Cambridge qualification, syllabus and examination level offered for each subject should be confirmed against the college's current Cambridge registration and subject options.
            </div>
          </div>
        </div>
      )}

      {/* Additional School-Wide Programmes */}
      <div>
        <div className="max-w-3xl mb-6">
          <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1.5">
            Holistic Student Development · Across All Year Groups
          </div>
          <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
            Additional School-Wide Programmes
          </h3>
          <p className="text-xs sm:text-sm text-blue-900 mt-1.5">
            To complement classroom learning across our eight academic departments, Livingstone Kolobeng College supports holistic initiatives equipping students for leadership, ethical technology use and university success.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {SCHOOL_WIDE_PROGRAMMES.map((prog) => {
            const Icon = prog.icon;
            return (
              <div
                key={prog.title}
                className="p-5 bg-white rounded-2xl border border-blue-200 hover:border-amber-400 transition-colors shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="w-9 h-9 rounded-xl bg-blue-50 text-[#0c1a40] border border-blue-100 flex items-center justify-center mb-3">
                    <Icon className="w-4 h-4 text-amber-600" />
                  </div>
                  <h4 className="font-serif font-bold text-sm text-[#0c1a40] mb-1.5">
                    {prog.title}
                  </h4>
                  <p className="text-xs text-blue-950/85 leading-relaxed">
                    {prog.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Our Academic Vision, Mission & Commitment */}
      <div className="bg-gradient-to-br from-[#0c1a40] to-[#162a6b] text-white rounded-2xl p-6 sm:p-10 border border-blue-900 shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="p-5 rounded-xl bg-white/10 border border-blue-400/20 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider">
              <Compass className="w-4 h-4" />
              <span>Our Academic Vision</span>
            </div>
            <p className="text-xs sm:text-sm text-blue-100 leading-relaxed">
              To deliver an internationally respected Cambridge education that nurtures confident, innovative, disciplined and compassionate learners prepared to contribute positively to Botswana and the wider world.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-white/10 border border-blue-400/20 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider">
              <Target className="w-4 h-4" />
              <span>Our Academic Mission</span>
            </div>
            <p className="text-xs sm:text-sm text-blue-100 leading-relaxed">
              To combine high academic expectations, dedicated teaching, practical learning experiences and rich co-curricular opportunities so that every student discovers their strengths and reaches their full potential.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-white/10 border border-blue-400/20 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider">
              <Award className="w-4 h-4" />
              <span>Our Commitment</span>
            </div>
            <p className="text-xs sm:text-sm text-blue-100 leading-relaxed">
              Every department at Livingstone Kolobeng College is committed to academic excellence, student support, ethical values, creativity and preparing learners for lifelong success.
            </p>
          </div>
        </div>

        <div className="pt-5 border-t border-white/15 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <span className="font-serif font-bold text-base sm:text-lg text-amber-300">
            Livingstone Kolobeng College – Inspiring Excellence, Building Futures.
          </span>
          <span className="text-[11px] font-mono text-blue-200 uppercase tracking-wider">
            Form 1 to A Level (A2) · Cambridge International School
          </span>
        </div>
      </div>
    </div>
  );
};
