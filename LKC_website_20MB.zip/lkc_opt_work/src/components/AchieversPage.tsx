import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Trophy,
  Award,
  Star,
  Globe,
  Medal,
  CheckCircle2,
  Search,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  X,
  ExternalLink,
  ArrowRight,
  Sparkles,
  BookOpen,
  GraduationCap,
  Download
} from 'lucide-react';
import { useCmsSection } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { downloadImageFile } from './ImageLightboxModal';
import { CambridgeLearnerAward } from '../types';

interface AchieversPageProps {
  onOpenAdmissions: () => void;
}

export const AchieversPage: React.FC<AchieversPageProps> = () => {
  const achievers = useCmsSection('achievers');
  const general = useCmsSection('general');

  const [selectedAwardCategory, setSelectedAwardCategory] = useState<string>('all');
  const [selectedLevelCategory, setSelectedLevelCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeModalImage, setActiveModalImage] = useState<{ url: string; title: string; subtitle?: string } | null>(null);
  const [zoomScale, setZoomScale] = useState<number>(1);
  const [honorRollSearch, setHonorRollSearch] = useState<string>('');
  const [honorRollLevel, setHonorRollLevel] = useState<string>('all');

  const availableYears =
    achievers.availableYears && achievers.availableYears.length > 0
      ? achievers.availableYears
      : ['2025'];
  const [selectedYear, setSelectedYear] = useState<string>(
    achievers.activeYear || availableYears[0]
  );

  const activeSummary =
    (achievers.yearlySummaries && achievers.yearlySummaries[selectedYear]) ||
    achievers.summary;
  const yearAwards = achievers.awards.filter((a) => !a.year || a.year === selectedYear);
  const yearHonorRoll = achievers.honorRoll.filter((h) => !h.year || h.year === selectedYear);

  const summary = activeSummary;
  const awards = yearAwards;
  const honorRoll = yearHonorRoll;

  const totalAwardsCount = awards.length;
  const worldCount = awards.filter((a) => a.awardType === 'Top in the World').length;
  const botswanaCount = awards.filter((a) => a.awardType === 'Top in Botswana').length;
  const highAchievementCount = awards.filter((a) => a.awardType === 'High Achievement').length;

  const spotlightAward = awards.find((a) => a.awardType === 'Top in the World') || awards[0];

  const filteredAwards = awards.filter((award) => {
    const matchesCategory =
      selectedAwardCategory === 'all' ||
      award.awardType.toLowerCase().includes(selectedAwardCategory.toLowerCase());

    const matchesLevel =
      selectedLevelCategory === 'all' ||
      award.level.toLowerCase().includes(selectedLevelCategory.toLowerCase());

    const matchesSearch =
      award.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      award.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      award.awardType.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesLevel && matchesSearch;
  });

  const filteredHonorRoll = honorRoll.filter((item) => {
    const matchesLevel =
      honorRollLevel === 'all' ||
      item.level.toLowerCase().includes(honorRollLevel.toLowerCase());

    const matchesSearch =
      item.studentName.toLowerCase().includes(honorRollSearch.toLowerCase()) ||
      item.grades.toLowerCase().includes(honorRollSearch.toLowerCase()) ||
      (item.featuredAward && item.featuredAward.toLowerCase().includes(honorRollSearch.toLowerCase()));

    return matchesLevel && matchesSearch;
  });

  return (
    <div className="bg-blue-50/30 min-h-screen text-[#0c1a40]">
      {/* Hero Marquee Section */}
      <section className="relative bg-gradient-to-br from-[#081226] via-[#0c1a40] to-[#162a6b] text-white py-16 sm:py-20 px-4 sm:px-6 overflow-hidden border-b border-blue-900">
        <div className="max-w-7xl mx-auto relative z-10">
          {/* Dynamic Multi-Year Switcher */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 mb-6">
            <span className="text-xs font-mono uppercase tracking-wider text-blue-200 mr-1">
              Academic Year Archive:
            </span>
            {availableYears.map((yr) => (
              <button
                key={yr}
                type="button"
                onClick={() => setSelectedYear(yr)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold transition-colors cursor-pointer ${
                  selectedYear === yr
                    ? 'bg-amber-400 text-[#081226] shadow-sm'
                    : 'bg-white/10 text-blue-100 hover:bg-white/20 border border-white/15'
                }`}
              >
                Class of {yr}
              </button>
            ))}
          </div>

          <div className="flex flex-col lg:flex-row items-center gap-10 justify-between">
            {/* Left Column: Headings & Stats */}
            <div className="max-w-2xl space-y-5 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-400/15 border border-amber-400/40 text-amber-300 text-xs font-semibold tracking-wide uppercase">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Outstanding Cambridge Learner Awards {selectedYear}</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold tracking-tight text-white leading-tight">
                {summary.headline || `Top in the World & Top in Botswana Achievers (${selectedYear})`}
              </h1>

              <p className="text-blue-100 text-sm sm:text-base leading-relaxed">
                {summary.description}
              </p>

              {/* Stat badges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                <div className="bg-white/10 p-3.5 rounded-xl border border-white/15 text-center">
                  <div className="text-2xl sm:text-3xl font-bold font-serif text-amber-400">
                    {summary.igcsePassRate}
                  </div>
                  <div className="text-[11px] text-blue-100 font-medium mt-0.5">
                    IGCSE Pass Rate (23 Subjects)
                  </div>
                </div>

                <div className="bg-white/10 p-3.5 rounded-xl border border-white/15 text-center">
                  <div className="text-2xl sm:text-3xl font-bold font-serif text-white">
                    {summary.igcseCreditPassRate}
                  </div>
                  <div className="text-[11px] text-blue-100 font-medium mt-0.5">
                    IGCSE Credit Passes
                  </div>
                </div>

                <div className="bg-white/10 p-3.5 rounded-xl border border-white/15 text-center">
                  <div className="text-2xl sm:text-3xl font-bold font-serif text-amber-300">
                    {summary.aLevelPassRate}
                  </div>
                  <div className="text-[11px] text-blue-100 font-medium mt-0.5">
                    A-Level A2 Pass Rate
                  </div>
                </div>

                <div className="bg-white/10 p-3.5 rounded-xl border border-white/15 text-center">
                  <div className="text-2xl sm:text-3xl font-bold font-serif text-amber-400">
                    {totalAwardsCount}
                  </div>
                  <div className="text-[11px] text-blue-100 font-medium mt-0.5">
                    Cambridge Awards {selectedYear}
                  </div>
                </div>
              </div>

              <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-4 text-xs text-blue-100">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-amber-400" />
                  <span>{worldCount} Top in the World Award</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-amber-300" />
                  <span>{botswanaCount} Top in Botswana Awards</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-white" />
                  <span>{highAchievementCount} High Achievement Awards</span>
                </div>
              </div>
            </div>

            {/* Right Column: World Champion Spotlight Card */}
            {spotlightAward && (
              <div className="w-full max-w-md lg:max-w-sm">
                <div className="bg-gradient-to-b from-amber-500/20 via-[#0c1a40] to-[#081226] p-5 rounded-2xl border-2 border-amber-400/50 shadow-2xl">
                  <div className="flex items-center justify-between pb-3 border-b border-amber-400/20">
                    <div className="flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-amber-400" />
                      <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
                        Global Honor
                      </span>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-400 text-[#081226] font-bold">
                      {spotlightAward.awardType}
                    </span>
                  </div>

                  <div
                    className="mt-4 relative group cursor-pointer"
                    onClick={() =>
                      setActiveModalImage({
                        url: spotlightAward.image,
                        title: `${spotlightAward.studentName} - ${spotlightAward.awardType}`,
                        subtitle: `${spotlightAward.level} ${spotlightAward.subject} (${spotlightAward.grades || ''})`
                      })
                    }
                  >
                    <div className="aspect-square rounded-xl overflow-hidden bg-[#0c1a40] border border-amber-400/40">
                      <img
                        src={spotlightAward.image}
                        alt={`${spotlightAward.studentName} - ${spotlightAward.awardType}`}
                        onError={handleImageFallback}
                        className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="absolute inset-0 bg-[#081226]/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-xl">
                      <span className="flex items-center gap-1.5 text-xs text-white bg-[#0c1a40] px-3 py-1.5 rounded-md font-medium border border-amber-400/50">
                        <ZoomIn className="w-4 h-4 text-amber-400" />
                        View Certificate
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 text-center">
                    <h3 className="font-serif font-bold text-lg text-white">
                      {spotlightAward.studentName}
                    </h3>
                    <p className="text-xs text-amber-300 font-semibold mt-0.5">
                      {spotlightAward.level} {spotlightAward.subject} {spotlightAward.grades ? `· ${spotlightAward.grades}` : ''}
                    </p>
                    <p className="text-[11px] text-blue-100 mt-2 leading-relaxed">
                      {spotlightAward.highlightNote || 'Highest mark achieved across all Cambridge Assessment International Education candidates.'}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Official Cambridge Results Banners Section */}
      <section className="py-12 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 text-[#0c1a40] text-xs font-semibold mb-2">
            <BookOpen className="w-3.5 h-3.5 text-[#162a6b]" />
            <span>Official Examination Board Releases</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
            Official Results Banners & Publications
          </h2>
          <p className="text-xs sm:text-sm text-blue-900 mt-1">
            Click on any publication banner below to inspect the high-resolution certificate and newspaper records.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Banner 1 */}
          <div
            onClick={() =>
              setActiveModalImage({
                url: summary.bannerImages.igcseHero,
                title: 'LKC Cambridge IGCSE 2025 Pass Rates Banner',
                subtitle: `${summary.igcsePassRate} Pass Rate · ${summary.igcseCreditPassRate} Credit Passes`
              })
            }
            className="group bg-white rounded-2xl border border-blue-200 overflow-hidden shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col"
          >
            <div className="relative aspect-[4/3] bg-[#081226] overflow-hidden">
              <img
                src={summary.bannerImages.igcseHero}
                alt="IGCSE Pass Rate Banner"
                loading="lazy"
                onError={handleImageFallback}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-[#0c1a40]/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="flex items-center gap-1 text-xs text-white bg-[#081226] px-3 py-1.5 rounded-md font-medium border border-amber-400/50">
                  <ZoomIn className="w-3.5 h-3.5 text-amber-400" /> Click to Enlarge
                </span>
              </div>
            </div>
            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono font-bold text-[#162a6b] uppercase tracking-wider">
                  IGCSE Examination Release
                </span>
                <h3 className="font-serif font-bold text-sm text-[#0c1a40] mt-1">
                  {summary.igcsePassRate} Pass Rate & {summary.igcseCreditPassRate} Credit Passes
                </h3>
                <p className="text-xs text-blue-900 mt-1 line-clamp-2">
                  Comprehensive performance across 23 Cambridge IGCSE subjects with top rankings in Mathematics, Sciences, and Commercials.
                </p>
              </div>
              <div className="mt-3 pt-3 border-t border-blue-100 flex items-center justify-between text-xs text-[#0c1a40] font-semibold">
                <span>View Full Banner</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform text-amber-600" />
              </div>
            </div>
          </div>

          {/* Banner 2 */}
          <div
            onClick={() =>
              setActiveModalImage({
                url: summary.bannerImages.dozenAchievers,
                title: "A Dozen of This Year's AS & A2 Achievers",
                subtitle: `${general.name} Sixth Form Distinction`
              })
            }
            className="group bg-white rounded-2xl border border-blue-200 overflow-hidden shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col"
          >
            <div className="relative aspect-[4/3] bg-[#081226] overflow-hidden">
              <img
                src={summary.bannerImages.dozenAchievers}
                alt="A Dozen of This Year's AS & A2 Achievers Poster"
                loading="lazy"
                onError={handleImageFallback}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-[#0c1a40]/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="flex items-center gap-1 text-xs text-white bg-[#081226] px-3 py-1.5 rounded-md font-medium border border-amber-400/50">
                  <ZoomIn className="w-3.5 h-3.5 text-amber-400" /> Click to Enlarge
                </span>
              </div>
            </div>
            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono font-bold text-amber-700 uppercase tracking-wider">
                  Sixth Form Honor Roll
                </span>
                <h3 className="font-serif font-bold text-sm text-[#0c1a40] mt-1">
                  A Dozen AS & A2 Top Achievers
                </h3>
                <p className="text-xs text-blue-900 mt-1 line-clamp-2">
                  Featuring LKC's elite A-Level cohort with multiple A* and A grade distinctions across Sciences, Commercials, and Humanities.
                </p>
              </div>
              <div className="mt-3 pt-3 border-t border-blue-100 flex items-center justify-between text-xs text-amber-700 font-semibold">
                <span>View Full Poster</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>

          {/* Banner 3 */}
          <div
            onClick={() =>
              setActiveModalImage({
                url: summary.bannerImages.newspaperSpread,
                title: 'LKC Does It Again! 2025 Cambridge Results Press Spread',
                subtitle: 'National Newspaper Feature · Full Results Breakdown'
              })
            }
            className="group bg-white rounded-2xl border border-blue-200 overflow-hidden shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col"
          >
            <div className="relative aspect-[4/3] bg-[#081226] overflow-hidden">
              <img
                src={summary.bannerImages.newspaperSpread}
                alt="Newspaper Feature: LKC Does It Again!"
                loading="lazy"
                onError={handleImageFallback}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-[#0c1a40]/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="flex items-center gap-1 text-xs text-white bg-[#081226] px-3 py-1.5 rounded-md font-medium border border-amber-400/50">
                  <ZoomIn className="w-3.5 h-3.5 text-amber-400" /> Click to Enlarge
                </span>
              </div>
            </div>
            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono font-bold text-[#162a6b] uppercase tracking-wider">
                  Press & Media Release
                </span>
                <h3 className="font-serif font-bold text-sm text-[#0c1a40] mt-1">
                  Full National Newspaper Spread
                </h3>
                <p className="text-xs text-blue-900 mt-1 line-clamp-2">
                  Complete published record of Cambridge IGCSE and A-Level results, student honor rolls, and institutional achievements.
                </p>
              </div>
              <div className="mt-3 pt-3 border-t border-blue-100 flex items-center justify-between text-xs text-[#0c1a40] font-semibold">
                <span>View Full Spread</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform text-amber-600" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Cambridge Learner Awards Gallery Section */}
      <section className="py-12 px-4 sm:px-6 bg-white border-y border-blue-100">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-blue-100">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 text-[#0c1a40] border border-amber-300 text-xs font-semibold uppercase tracking-wider mb-2">
                <Trophy className="w-3.5 h-3.5 text-amber-600" />
                <span>Cambridge Assessment International Education</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
                Outstanding Cambridge Learner Awards 2025
              </h2>
              <p className="text-xs sm:text-sm text-blue-900 mt-1 max-w-2xl">
                Honoring individual students who attained the highest marks in Botswana and across the globe in the 2025 examination series.
              </p>
            </div>

            <div className="relative min-w-[260px]">
              <Search className="w-4 h-4 text-blue-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search awardee or subject..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-blue-200 focus:outline-hidden focus:border-[#0c1a40] bg-blue-50/40"
              />
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-wrap items-center gap-2 pt-6 pb-8">
            <div className="text-xs font-semibold text-blue-800 mr-2">Award Category:</div>
            {[
              { id: 'all', label: `All ${totalAwardsCount} Awards` },
              { id: 'world', label: `Top in the World (${worldCount})` },
              { id: 'botswana', label: `Top in Botswana (${botswanaCount})` },
              { id: 'high achievement', label: `High Achievement (${highAchievementCount})` }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedAwardCategory(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  selectedAwardCategory === tab.id
                    ? 'bg-[#0c1a40] text-white shadow-xs'
                    : 'bg-blue-50 text-[#0c1a40] hover:bg-blue-100'
                }`}
              >
                {tab.label}
              </button>
            ))}

            <div className="h-4 w-px bg-blue-200 mx-2 hidden sm:block" />

            <div className="text-xs font-semibold text-blue-800 mr-2">Level:</div>
            {[
              { id: 'all', label: 'All Levels' },
              { id: 'igcse', label: 'IGCSE' },
              { id: 'as level', label: 'AS Level' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedLevelCategory(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  selectedLevelCategory === tab.id
                    ? 'bg-amber-400 text-[#081226] font-bold shadow-xs'
                    : 'bg-blue-50 text-[#0c1a40] hover:bg-blue-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Awards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredAwards.map((award: CambridgeLearnerAward) => {
              const isWorld = award.awardType === 'Top in the World';
              const isBotswana = award.awardType === 'Top in Botswana';

              return (
                <div
                  key={award.id}
                  className={`group bg-white rounded-2xl border transition-all hover:shadow-lg flex flex-col overflow-hidden ${
                    isWorld
                      ? 'border-amber-400 ring-2 ring-amber-400/30'
                      : isBotswana
                        ? 'border-blue-300 hover:border-[#0c1a40]'
                        : 'border-blue-200 hover:border-blue-400'
                  }`}
                >
                  <div
                    onClick={() =>
                      setActiveModalImage({
                        url: award.image,
                        title: `${award.studentName} · ${award.awardType}`,
                        subtitle: `${award.level} ${award.subject} (${award.grades || ''})`
                      })
                    }
                    className="relative aspect-square bg-[#081226] cursor-pointer overflow-hidden"
                  >
                    <img
                      src={award.image}
                      alt={`${award.studentName} - ${award.awardType} in ${award.subject}`}
                      loading="lazy"
                      onError={handleImageFallback}
                      className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                    />

                    <div className="absolute top-3 left-3">
                      <span
                        className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full shadow-md ${
                          isWorld
                            ? 'bg-amber-400 text-[#081226]'
                            : isBotswana
                              ? 'bg-[#0c1a40] text-white border border-amber-400/50'
                              : 'bg-[#162a6b] text-amber-200 border border-blue-400/40'
                        }`}
                      >
                        {isWorld ? <Globe className="w-3 h-3 text-[#081226]" /> : <Medal className="w-3 h-3 text-amber-300" />}
                        <span>{award.awardType}</span>
                      </span>
                    </div>

                    <div className="absolute bottom-3 right-3">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-[#0c1a40]/90 text-white font-semibold border border-blue-700">
                        {award.level}
                      </span>
                    </div>

                    <div className="absolute inset-0 bg-[#0c1a40]/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <span className="flex items-center gap-1.5 text-xs text-white bg-[#081226] px-3 py-1.5 rounded-md font-medium border border-amber-400/50">
                        <ZoomIn className="w-3.5 h-3.5 text-amber-400" /> Click to Zoom
                      </span>
                    </div>
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="text-[11px] font-mono font-bold text-amber-700 tracking-wide uppercase">
                        {award.subject}
                      </div>

                      <h3 className="font-serif font-bold text-base text-[#0c1a40] mt-0.5">
                        {award.studentName}
                      </h3>

                      {award.grades && (
                        <div className="mt-1 flex items-center gap-1.5">
                          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-50 text-[#0c1a40] border border-amber-300">
                            Grades: {award.grades}
                          </span>
                        </div>
                      )}

                      {award.highlightNote && (
                        <p className="text-xs text-blue-900 mt-2 line-clamp-2">
                          {award.highlightNote}
                        </p>
                      )}
                    </div>

                    <div className="mt-4 pt-3 border-t border-blue-100 flex items-center justify-between text-xs text-[#0c1a40] font-medium">
                      <span>Cambridge Series {award.year}</span>
                      <button
                        onClick={() =>
                          setActiveModalImage({
                            url: award.image,
                            title: `${award.studentName} · ${award.awardType}`,
                            subtitle: `${award.level} ${award.subject}`
                          })
                        }
                        className="text-amber-700 hover:text-amber-600 font-semibold cursor-pointer"
                      >
                        Enlarge Card →
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredAwards.length === 0 && (
            <div className="py-12 text-center text-blue-900">
              <Award className="w-10 h-10 mx-auto text-blue-300 mb-2" />
              <p className="text-sm">No awards found matching your search filter.</p>
              <button
                onClick={() => {
                  setSelectedAwardCategory('all');
                  setSelectedLevelCategory('all');
                  setSearchQuery('');
                }}
                className="mt-3 text-xs text-[#0c1a40] underline font-medium cursor-pointer"
              >
                Reset filters
              </button>
            </div>
          )}
        </div>
      </section>

      {/* 2025 Honor Roll Roster Section */}
      <section className="py-12 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="bg-white rounded-2xl border border-blue-200 p-6 sm:p-8 shadow-xs">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-blue-100">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-[#0c1a40] border border-blue-200 text-xs font-semibold uppercase tracking-wider mb-2">
                <Star className="w-3.5 h-3.5 text-amber-500" />
                <span>2025 Academic Honor Roll</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
                Distinction & Merit Honor Roll Roster
              </h2>
              <p className="text-xs sm:text-sm text-blue-900 mt-1 max-w-2xl">
                Recognizing students achieving 4 or more A* grades in Cambridge IGCSE and straight A/A* grades in Cambridge International AS & A2 Levels.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="relative min-w-[200px]">
                <Search className="w-3.5 h-3.5 text-blue-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter student or grade..."
                  value={honorRollSearch}
                  onChange={(e) => setHonorRollSearch(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-blue-200 focus:outline-hidden focus:border-[#0c1a40]"
                />
              </div>

              <select
                value={honorRollLevel}
                onChange={(e) => setHonorRollLevel(e.target.value)}
                className="py-1.5 px-3 text-xs rounded-lg border border-blue-200 bg-white text-[#0c1a40] focus:outline-hidden focus:border-[#0c1a40]"
              >
                <option value="all">All Cohorts</option>
                <option value="igcse">IGCSE (Forms 4-5)</option>
                <option value="as">AS Level</option>
                <option value="a2">A2 Level</option>
              </select>
            </div>
          </div>

          <div className="mt-6 overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-blue-200 bg-blue-50 text-[#0c1a40] font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-4">#</th>
                  <th className="py-3 px-4">Student Name</th>
                  <th className="py-3 px-4">Examination Level</th>
                  <th className="py-3 px-4">Distinction Grades Achieved</th>
                  <th className="py-3 px-4">Special Honor / Cambridge Award</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-blue-100">
                {filteredHonorRoll.map((item, index) => {
                  const isTopStar = item.starCount && item.starCount >= 5;

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-amber-50/40 transition-colors ${isTopStar ? 'bg-amber-50/20' : ''}`}
                    >
                      <td className="py-3 px-4 font-mono text-blue-700 text-[11px]">
                        {String(index + 1).padStart(2, '0')}
                      </td>
                      <td className="py-3 px-4 font-semibold text-[#0c1a40]">
                        <div className="flex items-center gap-2">
                          <span>{item.studentName}</span>
                          {isTopStar && (
                            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500 shrink-0" />
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-blue-900">
                        <span className="font-mono px-2 py-0.5 rounded bg-blue-50 text-[#0c1a40] border border-blue-100">
                          {item.level}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-[#0c1a40]">
                        <span className="px-2 py-0.5 rounded bg-blue-50 border border-blue-200">
                          {item.grades}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {item.featuredAward ? (
                          <span
                            className={`inline-flex items-center gap-1 font-medium px-2 py-0.5 rounded text-[11px] ${
                              item.featuredAward.includes('World')
                                ? 'bg-amber-100 text-[#081226] font-bold border border-amber-400'
                                : 'bg-blue-100 text-[#0c1a40] font-semibold border border-blue-200'
                            }`}
                          >
                            <Award className="w-3 h-3 shrink-0 text-amber-600" />
                            <span>{item.featuredAward}</span>
                          </span>
                        ) : (
                          <span className="text-blue-700 italic">Distinction Honor Roll</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Why LKC Students Excel - Pedagogy Pillars */}
      <section className="py-12 px-4 sm:px-6 bg-[#0c1a40] text-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white">
              The Engine of LKC Academic Excellence
            </h2>
            <p className="text-xs sm:text-sm text-blue-100 mt-2">
              Our {summary.igcsePassRate} IGCSE and {summary.aLevelPassRate} A-Level pass records stem from a deliberate pedagogical philosophy combining British Cambridge standards with caring Botho pastoral values.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white/5 border border-white/15 rounded-xl p-5">
              <div className="w-10 h-10 rounded-lg bg-amber-400/20 text-amber-400 flex items-center justify-center mb-3">
                <BookOpen className="w-5 h-5" />
              </div>
              <h3 className="font-serif font-bold text-base text-white">
                Cambridge International Centre
              </h3>
              <p className="text-xs text-blue-100 mt-2 leading-relaxed">
                Direct accreditation with Cambridge Assessment International Education ensuring international marking rigor and university-recognized credentials.
              </p>
            </div>

            <div className="bg-white/5 border border-white/15 rounded-xl p-5">
              <div className="w-10 h-10 rounded-lg bg-white/10 text-amber-300 flex items-center justify-center mb-3">
                <GraduationCap className="w-5 h-5" />
              </div>
              <h3 className="font-serif font-bold text-base text-white">
                Expert Faculty & SMT
              </h3>
              <p className="text-xs text-blue-100 mt-2 leading-relaxed">
                Led by Managing Director Mrs Nilima Bakaya, Principal Dr Jeff Ramsay, and specialized Cambridge subject heads with decades of exam training.
              </p>
            </div>

            <div className="bg-white/5 border border-white/15 rounded-xl p-5">
              <div className="w-10 h-10 rounded-lg bg-amber-400/20 text-amber-400 flex items-center justify-center mb-3">
                <Trophy className="w-5 h-5" />
              </div>
              <h3 className="font-serif font-bold text-base text-white">
                Weekly Science Labs
              </h3>
              <p className="text-xs text-blue-100 mt-2 leading-relaxed">
                Eight state-of-the-art wet chemistry, mechanics physics, and biology laboratories preparing candidates for practical assessment papers.
              </p>
            </div>

            <div className="bg-white/5 border border-white/15 rounded-xl p-5">
              <div className="w-10 h-10 rounded-lg bg-amber-400/20 text-amber-300 flex items-center justify-center mb-3">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <h3 className="font-serif font-bold text-base text-white">
                Boarding Study Culture
              </h3>
              <p className="text-xs text-blue-100 mt-2 leading-relaxed">
                Resident boarders in Masire houses benefit from structured nightly silent study blocks with rotating Cambridge tutor support.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action Banner */}
      <section className="py-14 px-4 sm:px-6 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-400 text-[#081226]">
        <div className="max-w-5xl mx-auto text-center space-y-4">
          <h2 className="text-2xl sm:text-3xl font-serif font-bold">
            Inspire Your Child’s Cambridge Journey at {general.name}
          </h2>
          <p className="text-xs sm:text-sm text-[#081226] max-w-2xl mx-auto leading-relaxed font-medium">
            Admissions are open for the 2026/27 academic year across Preschool, Lower Secondary (Forms 1–2), Pre-IGCSE (Form 3), Cambridge IGCSE, and Sixth Form A-Levels.
          </p>
          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <a
              href={general.admissionsPortalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 rounded-lg bg-[#0c1a40] text-white text-xs sm:text-sm font-semibold hover:bg-[#162a6b] transition-colors shadow-md cursor-pointer flex items-center gap-2"
            >
              <span>Apply Online for Admission</span>
              <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
            </a>
            <a
              href={general.socials.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 rounded-lg bg-white text-[#0c1a40] text-xs sm:text-sm font-semibold hover:bg-blue-50 transition-colors shadow-xs flex items-center gap-2"
            >
              <span>Chat with Admissions Office</span>
              <ExternalLink className="w-3.5 h-3.5 text-[#0c1a40]" />
            </a>
          </div>
        </div>
      </section>

      {/* Image Zoom / Lightbox Modal */}
      <AnimatePresence>
        {activeModalImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-[#081226]/95 backdrop-blur-md flex items-center justify-center p-3 sm:p-4"
            onClick={() => setActiveModalImage(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative max-w-[96vw] sm:max-w-[94vw] w-full h-[94vh] max-h-[94vh] bg-[#0c1a40] border border-blue-900 rounded-2xl overflow-hidden shadow-2xl flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="px-5 py-3.5 bg-[#081226] border-b border-blue-900 flex items-center justify-between text-white">
                <div>
                  <h3 className="font-serif font-bold text-sm sm:text-base text-white">
                    {activeModalImage.title}
                  </h3>
                  {activeModalImage.subtitle && (
                    <p className="text-xs text-amber-400 font-sans">
                      {activeModalImage.subtitle}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-blue-950 rounded-lg border border-blue-800 p-1 text-xs">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setZoomScale((s) => Math.max(s - 0.35, 0.5));
                      }}
                      className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                      title="Zoom Out"
                    >
                      <ZoomOut className="w-4 h-4" />
                    </button>
                    <span className="px-2 font-mono text-[10px] text-amber-300">
                      {Math.round(zoomScale * 100)}%
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setZoomScale((s) => Math.min(s + 0.35, 4));
                      }}
                      className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                      title="Zoom In"
                    >
                      <ZoomIn className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setZoomScale(1);
                      }}
                      className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer ml-1"
                      title="Reset Zoom"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      downloadImageFile(activeModalImage.url, activeModalImage.title);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                    title="Download Image"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Download</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveModalImage(null);
                      setZoomScale(1);
                    }}
                    className="p-1.5 rounded-lg bg-blue-900/60 hover:bg-blue-800 text-white transition-colors cursor-pointer"
                    aria-label="Close image preview"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-[#081226] min-h-[64vh]">
                <div
                  className="transition-transform duration-200 origin-center flex items-center justify-center"
                  style={{ transform: `scale(${zoomScale})` }}
                >
                  <img
                    src={activeModalImage.url}
                    alt={activeModalImage.title}
                    onError={handleImageFallback}
                    className="h-[74vh] sm:h-[78vh] w-auto max-w-[90vw] object-contain rounded-xl shadow-2xl"
                  />
                </div>
              </div>

              <div className="px-5 py-2.5 bg-[#081226] border-t border-blue-900 flex items-center justify-between text-xs text-blue-200">
                <span>{general.name} · Cambridge International Centre</span>
                <span className="text-amber-400 font-mono text-[11px]">Use +/- buttons above to inspect details</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
