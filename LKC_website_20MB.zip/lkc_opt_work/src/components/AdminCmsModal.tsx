import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  X,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  FileText,
  Image as ImageIcon,
  Building,
  ShieldCheck,
  Layers,
  Bed,
  Compass,
  GraduationCap,
  Trophy,
  Shield,
  BookOpen,
  DollarSign,
  Users,
  Calendar,
  HelpCircle,
  Home,
  Check,
  Ban,
  Edit3,
  Sparkles,
  LogOut,
  Timer,
  Sliders,
  Lock,
  LayoutDashboard,
  Newspaper,
  AlertCircle,
  Award,
  Menu,
  RotateCcw,
  Search,
  Archive,
  Upload,
} from 'lucide-react';
import {
  getAllCmsData,
  updateSectionData,
  refreshAdminBootstrap,
  fetchCurrentCmsUser,
  logoutCmsAdmin,
  uploadMediaFile,
  type CmsDatabase,
  type CmsSectionKey,
} from '../services/cmsDataService';
import type {
  AlumniProfile,
  ExcursionItem,
  TeacherProfile,
  RugbyFixture,
  CambridgeLearnerAward,
  AchieverItem,
  SubjectInfo as CurriculumSubject,
  CmsItem,
  CmsUser,
  PageKey,
  PublishStatus,
  StaffLeadershipPosition,
} from '../types';
import {
  getDepartmentHodStatus,
  getTeacherLeadershipPosition,
  LEADERSHIP_POSITION_LABELS,
  normalizePersonName,
  sortTeachersForDirectory,
} from '../utils/staffHierarchy';
import { isMissingPortrait, matchesSearchTokens } from '../utils/profileSearch';
import { openImageViewer } from './ImageLightboxModal';
import { CmsAuthGate } from './cms/CmsAuthGate';
import { CmsOverviewTab } from './cms/CmsOverviewTab';
import { CmsItemsManagerTab } from './cms/CmsItemsManagerTab';
import { CmsMediaLibraryTab } from './cms/CmsMediaLibraryTab';
import { CmsUsersAndGovernanceTab } from './cms/CmsUsersAndGovernanceTab';
import { CmsNavFooterSettingsTab } from './cms/CmsNavFooterSettingsTab';
import { CmsAthleticsTab } from './cms/CmsAthleticsTab';
import { CmsAcademicLeadershipTab } from './cms/CmsAcademicLeadershipTab';
import { PhotoUploadField } from './cms/PhotoUploadField';
import { CmsConfirmModal } from './cms/CmsConfirmModal';
import { CmsPhotoGalleryEditor, type GalleryPhotoEntry } from './cms/CmsPhotoGalleryEditor';

interface AdminCmsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type CmsTabKey =
  | 'overview'
  | 'items'
  | 'alumni'
  | 'home'
  | 'about'
  | 'boarding'
  | 'excursions'
  | 'achievers'
  | 'sports'
  | 'athletics'
  | 'jaguars'
  | 'departments'
  | 'academic_leadership'
  | 'teachers'
  | 'curriculum'
  | 'fees'
  | 'calendar'
  | 'faqs'
  | 'general'
  | 'announcements'
  | 'media'
  | 'nav_settings'
  | 'governance';

const TAB_TO_SECTION: Partial<Record<CmsTabKey, CmsSectionKey>> = {
  home: 'hero',
  about: 'about',
  boarding: 'boarding',
  excursions: 'excursions',
  alumni: 'alumni',
  achievers: 'achievers',
  sports: 'sports',
  athletics: 'athletics',
  jaguars: 'jaguars',
  departments: 'departments',
  teachers: 'teachers',
  curriculum: 'curriculum',
  fees: 'fees',
  calendar: 'calendar',
  faqs: 'faqs',
  general: 'general',
  announcements: 'announcements',
};

const TAB_REQUIRED_PAGE: Partial<Record<CmsTabKey, PageKey | 'admin_only' | 'super_only'>> = {
  alumni: 'admin_only',
  home: 'home',
  about: 'campus',
  boarding: 'boarding',
  excursions: 'excursions',
  achievers: 'achievers',
  sports: 'sports',
  athletics: 'athletics',
  jaguars: 'jaguars',
  departments: 'departments',
  academic_leadership: 'departments',
  teachers: 'departments',
  curriculum: 'curriculum',
  fees: 'admin_only',
  calendar: 'events',
  faqs: 'contact',
  general: 'admin_only',
  announcements: 'news',
  nav_settings: 'admin_only',
  governance: 'super_only',
};

function canUserAccessTab(tabKey: CmsTabKey, user: CmsUser | null): boolean {
  if (!user) return false;
  if (user.role === 'super_admin') return true;
  const req = TAB_REQUIRED_PAGE[tabKey];
  if (req === 'super_only') return false;
  if (user.role === 'admin') return true;
  if (!req) return true;
  if (req === 'admin_only') return false;
  return user.assignedPages.includes(req);
}

const TEACHERS_PER_PAGE = 10;
const HONOR_PER_PAGE = 10;

export const AdminCmsModal: React.FC<AdminCmsModalProps> = ({ isOpen, onClose }) => {
  const [db, setDb] = useState<CmsDatabase>(() => getAllCmsData());
  const [savedSnapshot, setSavedSnapshot] = useState<CmsDatabase>(() =>
    JSON.parse(JSON.stringify(getAllCmsData()))
  );
  const [cmsItems, setCmsItems] = useState<CmsItem[]>([]);
  const [currentUser, setCurrentUser] = useState<CmsUser | null>(null);
  const [authChecking, setAuthChecking] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<CmsTabKey>('overview');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const [errorNotice, setErrorNotice] = useState<string | null>(null);
  const [savingAll, setSavingAll] = useState<boolean>(false);

  const [confirmAction, setConfirmAction] = useState<{
    title: string;
    message: string;
    confirmLabel: string;
    action: () => void | Promise<void>;
  } | null>(null);

  // Filter / Search / Pagination Sub-states
  const [teacherDeptFilter, setTeacherDeptFilter] = useState<string>('all');
  const [teacherStatusFilter, setTeacherStatusFilter] = useState<'all' | 'published' | 'archived' | 'unpublished'>('all');
  const [teacherMissingOnly, setTeacherMissingOnly] = useState<boolean>(false);
  const [teacherSearch, setTeacherSearch] = useState<string>('');
  const [teacherPage, setTeacherPage] = useState<number>(1);
  const [feePdfUploading, setFeePdfUploading] = useState<boolean>(false);
  const [deptSearch, setDeptSearch] = useState<string>('');
  const [selectedCurrKey, setSelectedCurrKey] = useState<string>('igcse');
  const [alumniFilter, setAlumniFilter] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending');
  const [alumniSearch, setAlumniSearch] = useState<string>('');
  const [selectedAchieverYear, setSelectedAchieverYear] = useState<string>('2025');
  const [newYearInput, setNewYearInput] = useState<string>('2026');
  const [honorSearch, setHonorSearch] = useState<string>('');
  const [honorPage, setHonorPage] = useState<number>(1);

  // New / Edit item states
  const [newExcursion, setNewExcursion] = useState<Partial<ExcursionItem>>({
    title: '',
    category: 'International',
    year: '2026',
    destination: '',
    targetForms: '',
    duration: '',
    description: '',
    curriculumLink: '',
    image: '',
  });
  const [newExcursionHighlights, setNewExcursionHighlights] = useState('');

  const [newFixture, setNewFixture] = useState<Omit<RugbyFixture, 'id'>>({
    opponent: '',
    venue: 'The Jaguars Den (Home)',
    date: '',
    tournament: '',
    status: 'Upcoming',
  });

  const [newTeacher, setNewTeacher] = useState<Partial<TeacherProfile>>({
    name: '',
    departmentId: 'dept-maths',
    role: 'Teacher',
    title: 'Mr',
    bio: '',
    image: '',
    leadershipPosition: 'teacher',
    order: undefined,
  });
  const [newTeacherSubjects, setNewTeacherSubjects] = useState('');

  const [newAlumniForm, setNewAlumniForm] = useState<Partial<AlumniProfile>>({
    name: '',
    gradYear: 'Class of 2024',
    currentRole: '',
    organization: '',
    university: '',
    location: '',
    course: '',
    cambridgeHonors: '',
    quote: '',
    image: '',
    status: 'approved',
  });

  const [newAward, setNewAward] = useState<Partial<CambridgeLearnerAward>>({
    studentName: '',
    awardType: 'Top in Botswana',
    level: 'Cambridge IGCSE',
    subject: '',
    year: '2025',
    grades: '',
    image: './assets/aistudio/logo_33a39ff7.png',
    highlightNote: '',
  });

  const [newHonor, setNewHonor] = useState<Partial<AchieverItem>>({
    studentName: '',
    level: 'Cambridge IGCSE',
    grades: '',
    starCount: 4,
    featuredAward: '',
    year: '2025',
  });

  const [newSubject, setNewSubject] = useState<CurriculumSubject>({
    code: '',
    name: '',
    stream: 'Sciences',
    description: '',
    cambridgeCode: '',
    isCore: false,
  });

  const [newAnnouncement, setNewAnnouncement] = useState({
    title: '',
    category: 'General Notice',
    body: '',
    thumbnailUrl: '',
  });
  const [editingAnnouncementId, setEditingAnnouncementId] = useState<string | null>(null);

  const [newFaq, setNewFaq] = useState({ q: '', a: '' });

  const loadBootstrap = async () => {
    const boot = await refreshAdminBootstrap();
    setDb(boot.sections);
    setSavedSnapshot(JSON.parse(JSON.stringify(boot.sections)));
    setCmsItems(boot.items);
    setCurrentUser(boot.user);
    const defaultYear =
      boot.sections.settings?.activeAchieversYear ||
      boot.sections.achievers?.availableYears?.[0] ||
      '2025';
    setSelectedAchieverYear(defaultYear);
  };

  useEffect(() => {
    if (!isOpen) return;
    let active = true;
    setAuthChecking(true);
    setErrorNotice(null);

    (async () => {
      try {
        const me = await fetchCurrentCmsUser();
        if (!active) return;
        if (!me) {
          setCurrentUser(null);
          return;
        }
        if (me.mustChangePassword) {
          setCurrentUser(me);
          return;
        }
        const boot = await refreshAdminBootstrap();
        if (!active) return;
        setDb(boot.sections);
        setSavedSnapshot(JSON.parse(JSON.stringify(boot.sections)));
        setCmsItems(boot.items);
        setCurrentUser(boot.user);
        setSelectedAchieverYear(
          boot.sections.settings?.activeAchieversYear ||
            boot.sections.achievers?.availableYears?.[0] ||
            '2025'
        );
      } catch {
        if (active) setCurrentUser(null);
      } finally {
        if (active) setAuthChecking(false);
      }
    })();

    return () => {
      active = false;
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const syncMediaAndExternalSaves = () => {
      const latest = getAllCmsData();
      setDb((prev) => {
        if (JSON.stringify(prev.media) === JSON.stringify(latest.media)) {
          return prev;
        }
        return { ...prev, media: latest.media };
      });
    };
    window.addEventListener('lkc-cms-updated', syncMediaAndExternalSaves);
    return () => window.removeEventListener('lkc-cms-updated', syncMediaAndExternalSaves);
  }, [isOpen]);

  if (!isOpen) return null;

  if (authChecking) {
    return (
      <div data-no-global-zoom="true" className="fixed inset-0 z-50 bg-[#081226]/90 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl px-8 py-6 text-base text-[#0c1a40] font-semibold shadow-2xl border border-slate-200">
          Verifying LKC CMS session...
        </div>
      </div>
    );
  }

  if (!currentUser || currentUser.mustChangePassword) {
    return (
      <CmsAuthGate
        initialPendingPasswordUser={currentUser?.mustChangePassword ? currentUser : null}
        onAuthenticated={async (user) => {
          setCurrentUser(user);
          await loadBootstrap();
        }}
        onClose={onClose}
      />
    );
  }

  const showToast = (msg: string) => {
    setErrorNotice(null);
    setSavedNotice(msg);
    setTimeout(() => setSavedNotice(null), 4000);
  };

  const showError = (msg: string) => {
    setSavedNotice(null);
    setErrorNotice(msg);
  };

  const commitSection = async <K extends CmsSectionKey>(
    section: K,
    nextValue: CmsDatabase[K],
    label?: string
  ) => {
    try {
      const saved = await updateSectionData(section, nextValue);
      setDb((prev) => ({ ...prev, [section]: saved }));
      setSavedSnapshot((prev) => ({
        ...prev,
        [section]: JSON.parse(JSON.stringify(saved)),
      }));
      if (label) showToast(label);
    } catch (err) {
      showError(err instanceof Error ? err.message : 'Failed to save changes to CMS database.');
    }
  };

  const getTabSections = (tabKey: CmsTabKey): CmsSectionKey[] => {
    const primary = TAB_TO_SECTION[tabKey];
    if (!primary) return [];
    if (tabKey === 'home') return ['hero', 'building'];
    if (tabKey === 'sports') return ['sports', 'houses'];
    return [primary];
  };

  const activeSections = getTabSections(activeTab);
  const isCurrentTabDirty = activeSections.some(
    (sec) => JSON.stringify(db[sec]) !== JSON.stringify(savedSnapshot[sec])
  );

  const handleDiscardTabChanges = () => {
    if (activeSections.length === 0) return;
    setDb((prev) => {
      const next = { ...prev };
      activeSections.forEach((sec) => {
        (next as Record<string, unknown>)[sec] = JSON.parse(JSON.stringify(savedSnapshot[sec]));
      });
      return next;
    });
    showToast('Unsaved changes in this section were discarded.');
  };

  const handleSaveCurrentAll = async () => {
    setSavingAll(true);
    setErrorNotice(null);
    try {
      const authorizedSections: CmsSectionKey[] = [];
      (Object.keys(TAB_TO_SECTION) as CmsTabKey[]).forEach((tabKey) => {
        if (canUserAccessTab(tabKey, currentUser)) {
          getTabSections(tabKey).forEach((sec) => {
            if (!authorizedSections.includes(sec)) authorizedSections.push(sec);
          });
        }
      });

      const dirtySections = authorizedSections.filter(
        (sec) => JSON.stringify(db[sec]) !== JSON.stringify(savedSnapshot[sec])
      );

      const sectionsToSave: CmsSectionKey[] = [...dirtySections];
      if (sectionsToSave.length === 0) {
        activeSections.forEach((sec) => {
          if (authorizedSections.includes(sec) && !sectionsToSave.includes(sec)) {
            sectionsToSave.push(sec);
          }
        });
      }

      if (sectionsToSave.length === 0) {
        for (const sec of authorizedSections) {
          const saved = await updateSectionData(sec, db[sec]);
          setSavedSnapshot((prev) => ({
            ...prev,
            [sec]: JSON.parse(JSON.stringify(saved)),
          }));
        }
        showToast('All authorized CMS sections saved live to the database.');
        return;
      }

      for (const sec of sectionsToSave) {
        const saved = await updateSectionData(sec, db[sec]);
        setSavedSnapshot((prev) => ({
          ...prev,
          [sec]: JSON.parse(JSON.stringify(saved)),
        }));
      }

      showToast(
        dirtySections.length > 1
          ? `Saved ${dirtySections.length} updated sections live to the SQLite CMS database.`
          : 'Changes saved and published to the SQLite CMS database.'
      );
    } catch (err) {
      showError(err instanceof Error ? err.message : 'Failed to save changes.');
    } finally {
      setSavingAll(false);
    }
  };

  const handleSignOut = async () => {
    await logoutCmsAdmin();
    setCurrentUser(null);
  };

  const pendingAlumniCount = db.alumni.filter((a) => a.status === 'pending').length;
  const pendingItemsCount = cmsItems.filter((i) => i.status === 'pending').length;

  const sidebarGroups: {
    groupLabel: string;
    items: { key: CmsTabKey; label: string; icon: React.ReactNode; badge?: number }[];
  }[] = [
    {
      groupLabel: 'Dashboard',
      items: [
        { key: 'overview', label: 'Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
      ],
    },
    {
      groupLabel: 'Website Content',
      items: [
        { key: 'home', label: 'Home & 2027 Wing', icon: <Home className="w-4 h-4" /> },
        { key: 'about', label: 'About, Campus & SMT', icon: <Building className="w-4 h-4" /> },
        {
          key: 'items',
          label: 'News, Events & Featured',
          icon: <Newspaper className="w-4 h-4" />,
          badge: pendingItemsCount,
        },
        { key: 'announcements', label: 'Announcements', icon: <FileText className="w-4 h-4" /> },
        {
          key: 'media',
          label: `Media Library (${db.media.length})`,
          icon: <ImageIcon className="w-4 h-4" />,
        },
      ],
    },
    {
      groupLabel: 'School Management',
      items: [
        { key: 'departments', label: 'Departments (8)', icon: <Layers className="w-4 h-4" /> },
        {
          key: 'academic_leadership',
          label: 'Heads of Year & Staff',
          icon: <Award className="w-4 h-4" />,
        },
        {
          key: 'teachers',
          label: `Teachers (${db.teachers.length})`,
          icon: <Users className="w-4 h-4" />,
        },
        { key: 'curriculum', label: 'Curriculum', icon: <BookOpen className="w-4 h-4" /> },
        { key: 'boarding', label: 'Boarding & Staff', icon: <Bed className="w-4 h-4" /> },
        { key: 'fees', label: 'Fees & Banking', icon: <DollarSign className="w-4 h-4" /> },
      ],
    },
    {
      groupLabel: 'School Activities',
      items: [
        { key: 'sports', label: 'Sports & Houses', icon: <Trophy className="w-4 h-4" /> },
        { key: 'athletics', label: 'Athletics (Track & Field)', icon: <Timer className="w-4 h-4" /> },
        { key: 'jaguars', label: 'Jaguars & Fixtures', icon: <Shield className="w-4 h-4" /> },
        { key: 'excursions', label: 'Excursions', icon: <Compass className="w-4 h-4" /> },
        { key: 'achievers', label: 'Top Achievers', icon: <Sparkles className="w-4 h-4" /> },
        {
          key: 'alumni',
          label: 'Alumni Approvals',
          icon: <GraduationCap className="w-4 h-4" />,
          badge: pendingAlumniCount,
        },
        { key: 'calendar', label: 'Term Calendar', icon: <Calendar className="w-4 h-4" /> },
      ],
    },
    {
      groupLabel: 'Administration',
      items: [
        { key: 'general', label: 'Contacts & Socials', icon: <Edit3 className="w-4 h-4" /> },
        { key: 'faqs', label: 'FAQs', icon: <HelpCircle className="w-4 h-4" /> },
        { key: 'nav_settings', label: 'Nav, Footer & Settings', icon: <Sliders className="w-4 h-4" /> },
        { key: 'governance', label: 'Users, Audit & Backup', icon: <Lock className="w-4 h-4" /> },
      ],
    },
  ];

  const visibleGroups = sidebarGroups
    .map((group) => ({
      ...group,
      items: group.items.filter((tab) => canUserAccessTab(tab.key, currentUser)),
    }))
    .filter((group) => group.items.length > 0);

  // Filtered Teachers (HOD-first departmental order) + Pagination
  const missingTeacherPortraitCount = db.teachers.filter((t) =>
    isMissingPortrait(t.image)
  ).length;
  const teachersMatchingQueryCount = teacherSearch.trim()
    ? db.teachers.filter((t) =>
        matchesSearchTokens(teacherSearch, [
          t.name,
          t.title,
          t.role,
          t.departmentName,
          t.subjects,
          t.qualifications,
          t.bio,
          t.id,
        ])
      ).length
    : db.teachers.length;

  const filteredTeachers = sortTeachersForDirectory(
    db.teachers.filter((t) => {
      const status = t.status || 'published';
      if (teacherStatusFilter !== 'all' && status !== teacherStatusFilter) return false;
      if (teacherDeptFilter !== 'all' && t.departmentId !== teacherDeptFilter) return false;
      if (teacherMissingOnly && !isMissingPortrait(t.image)) return false;
      return matchesSearchTokens(teacherSearch, [
        t.name,
        t.title,
        t.role,
        t.departmentName,
        t.subjects,
        t.qualifications,
        t.bio,
        t.id,
      ]);
    }),
    db.departments
  );
  const totalTeacherPages = Math.max(1, Math.ceil(filteredTeachers.length / TEACHERS_PER_PAGE));
  const safeTeacherPage = Math.min(teacherPage, totalTeacherPages);
  const pagedTeachers = filteredTeachers.slice(
    (safeTeacherPage - 1) * TEACHERS_PER_PAGE,
    safeTeacherPage * TEACHERS_PER_PAGE
  );

  // Filtered Honor Roll for selected year + Pagination
  const yearHonorList = db.achievers.honorRoll.filter(
    (h) => (h.year || '2025') === selectedAchieverYear
  );
  const filteredHonorList = yearHonorList.filter((h) =>
    matchesSearchTokens(honorSearch, [h.studentName, h.grades, h.level, h.featuredAward])
  );
  const totalHonorPages = Math.max(1, Math.ceil(filteredHonorList.length / HONOR_PER_PAGE));
  const safeHonorPage = Math.min(honorPage, totalHonorPages);
  const pagedHonorList = filteredHonorList.slice(
    (safeHonorPage - 1) * HONOR_PER_PAGE,
    safeHonorPage * HONOR_PER_PAGE
  );

  // Filtered Alumni
  const filteredAlumni = db.alumni.filter((a) => {
    if (alumniFilter !== 'all' && a.status !== alumniFilter) return false;
    return matchesSearchTokens(alumniSearch, [
      a.name,
      a.gradYear,
      a.university,
      a.currentRole,
      a.organization,
      a.course,
    ]);
  });

  // Filtered Departments
  const filteredDepartments = db.departments.filter((dept) =>
    matchesSearchTokens(deptSearch, [
      dept.name,
      dept.headOfDepartment?.name,
      dept.headOfDepartment?.title,
      dept.curriculum,
      dept.subjects,
      dept.shortDescription,
    ])
  );

  const renderSidebarContent = () => (
    <div className="space-y-5">
      {visibleGroups.map((group) => (
        <div key={group.groupLabel} className="space-y-1">
          <div className="px-3 text-sm font-semibold text-amber-300/90 tracking-wide">
            {group.groupLabel}
          </div>
          <div className="space-y-1">
            {group.items.map((tab) => {
              const active = activeTab === tab.key;
              return (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => {
                    setActiveTab(tab.key);
                    setMobileNavOpen(false);
                  }}
                  className={`w-full px-3.5 py-2.5 rounded-xl text-[15px] flex items-center justify-between gap-2 text-left transition-colors cursor-pointer ${
                    active
                      ? 'bg-amber-400 text-[#081226] font-bold shadow-sm'
                      : 'text-blue-100 hover:bg-blue-900/70 hover:text-white font-medium'
                  }`}
                >
                  <span className="flex items-center gap-2.5 min-w-0">
                    <span className="shrink-0">{tab.icon}</span>
                    <span className="truncate">{tab.label}</span>
                  </span>
                  {typeof tab.badge === 'number' && tab.badge > 0 && (
                    <span
                      className={`text-sm font-bold tabular-nums shrink-0 ${
                        active ? 'text-[#081226]' : 'text-amber-300'
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div data-no-global-zoom="true" className="fixed inset-0 z-50 bg-[#081226]/90 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <motion.div
        initial={{ scale: 0.98, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.98, opacity: 0 }}
        className="relative w-full max-w-[1400px] h-[95vh] bg-slate-50 text-[#0c1a40] rounded-2xl border border-slate-300 shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Top Admin Header */}
        <header className="px-5 sm:px-6 py-4 bg-[#081226] text-white border-b border-blue-900 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3.5 min-w-0">
            <button
              type="button"
              onClick={() => setMobileNavOpen((o) => !o)}
              className="lg:hidden p-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white cursor-pointer"
              aria-label="Toggle CMS navigation"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="w-11 h-11 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center border border-amber-400/40 shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>

            <div className="min-w-0">
              <h2 className="font-serif font-bold text-[26px] sm:text-[28px] leading-tight text-white truncate">
                LKC School Administration CMS
              </h2>
              <p className="text-sm text-blue-200 truncate">
                Signed in as <strong className="text-white">{currentUser.fullName}</strong> ·{' '}
                <span className="capitalize text-amber-300 font-medium">
                  {currentUser.role.replace('_', ' ')}
                </span>{' '}
                · {currentUser.email}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => void handleSignOut()}
              className="px-4 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-amber-300 text-[15px] font-semibold flex items-center gap-2 border border-blue-700 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              aria-label="Close Admin CMS"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Workspace Layout */}
        <div className="flex-1 flex overflow-hidden relative">
          {/* Desktop Sidebar */}
          <aside className="hidden lg:block w-72 bg-[#0c1a40] text-white border-r border-blue-900 p-4 overflow-y-auto shrink-0">
            {renderSidebarContent()}
          </aside>

          {/* Mobile Drawer */}
          {mobileNavOpen && (
            <div
              className="lg:hidden fixed inset-0 z-40 bg-[#081226]/70 flex"
              onClick={() => setMobileNavOpen(false)}
            >
              <aside
                className="w-72 max-w-[85vw] bg-[#0c1a40] text-white h-full p-4 overflow-y-auto shadow-2xl border-r border-blue-900"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-blue-900">
                  <span className="font-serif font-bold text-lg text-white">CMS Sections</span>
                  <button
                    type="button"
                    onClick={() => setMobileNavOpen(false)}
                    className="p-1.5 rounded-lg hover:bg-white/10 text-white cursor-pointer"
                    aria-label="Close menu"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                {renderSidebarContent()}
              </aside>
            </div>
          )}

          {/* Main Light Slate Workspace */}
          <main className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-6 bg-slate-50">
            {errorNotice && (
              <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-[15px] text-red-800 flex items-center gap-2.5">
                <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
                <span>{errorNotice}</span>
              </div>
            )}

            {isCurrentTabDirty && (
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 flex flex-wrap items-center justify-between gap-3 text-[15px] text-[#0c1a40]">
                <span className="font-medium">
                  You have unsaved changes in this section. Save Changes Live to publish them, or Discard to revert.
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleDiscardTabChanges}
                    className="px-3.5 py-2 rounded-lg bg-white hover:bg-slate-100 border border-slate-300 text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Discard</span>
                  </button>
                  <button
                    type="button"
                    disabled={savingAll}
                    onClick={() => void handleSaveCurrentAll()}
                    className="px-4 py-2 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Save className="w-4 h-4 text-amber-400" />
                    <span>Save Changes</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB: OVERVIEW */}
            {activeTab === 'overview' && (
              <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6">
                <CmsOverviewTab
                  currentUser={currentUser}
                  onSelectTab={(t) => setActiveTab(t as CmsTabKey)}
                />
              </div>
            )}

            {/* TAB: NEWS, EVENTS & HOMEPAGE FEATURED ITEMS */}
            {activeTab === 'items' && (
              <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6">
                <CmsItemsManagerTab
                  items={cmsItems}
                  currentUser={currentUser}
                  onRefresh={loadBootstrap}
                  onNotify={showToast}
                />
              </div>
            )}

            {/* TAB: HOME & 2027 WING */}
            {activeTab === 'home' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                    Homepage Hero & 2027 Classroom Wing
                  </h3>
                  <p className="text-[15px] text-slate-600 mt-1">
                    Update homepage headlines, hero background photograph, statistics, and 2027 expansion wing gallery.
                  </p>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-5">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40]">
                    Homepage Hero Section
                  </h4>

                  <PhotoUploadField
                    aspect="banner"
                    value={db.hero.heroImage}
                    onChange={(url) =>
                      setDb({ ...db, hero: { ...db.hero, heroImage: url } })
                    }
                    label="Homepage Hero Background Image"
                    category="Campus & Facilities"
                    placeholderLabel="No Hero Image"
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Hero Badge Text
                      </label>
                      <input
                        type="text"
                        value={db.hero.badgeText}
                        onChange={(e) =>
                          setDb({ ...db, hero: { ...db.hero, badgeText: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Headline Top
                      </label>
                      <input
                        type="text"
                        value={db.hero.headlineTop}
                        onChange={(e) =>
                          setDb({ ...db, hero: { ...db.hero, headlineTop: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Headline Gold Accent
                      </label>
                      <input
                        type="text"
                        value={db.hero.headlineAccent}
                        onChange={(e) =>
                          setDb({ ...db, hero: { ...db.hero, headlineAccent: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Headline Bottom
                      </label>
                      <input
                        type="text"
                        value={db.hero.headlineBottom}
                        onChange={(e) =>
                          setDb({ ...db, hero: { ...db.hero, headlineBottom: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Hero Description
                      </label>
                      <textarea
                        rows={3}
                        value={db.hero.description}
                        onChange={(e) =>
                          setDb({ ...db, hero: { ...db.hero, description: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Stat 1 (Value / Label)
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={db.hero.stat1Value}
                          onChange={(e) =>
                            setDb({ ...db, hero: { ...db.hero, stat1Value: e.target.value } })
                          }
                          className="w-28 px-3 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                        />
                        <input
                          type="text"
                          value={db.hero.stat1Label}
                          onChange={(e) =>
                            setDb({ ...db, hero: { ...db.hero, stat1Label: e.target.value } })
                          }
                          className="flex-1 px-3 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Stat 2 (Value / Label)
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={db.hero.stat2Value}
                          onChange={(e) =>
                            setDb({ ...db, hero: { ...db.hero, stat2Value: e.target.value } })
                          }
                          className="w-28 px-3 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                        />
                        <input
                          type="text"
                          value={db.hero.stat2Label}
                          onChange={(e) =>
                            setDb({ ...db, hero: { ...db.hero, stat2Label: e.target.value } })
                          }
                          className="flex-1 px-3 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2027 Wing Text */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40]">
                    2027 Forms 1 & 2 Classroom Wing Project
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">Project Title</label>
                      <input
                        type="text"
                        value={db.building.title}
                        onChange={(e) =>
                          setDb({ ...db, building: { ...db.building, title: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">Status Tag</label>
                      <input
                        type="text"
                        value={db.building.status}
                        onChange={(e) =>
                          setDb({ ...db, building: { ...db.building, status: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block font-semibold text-[15px] mb-1.5">Subtitle</label>
                      <input
                        type="text"
                        value={db.building.subtitle}
                        onChange={(e) =>
                          setDb({ ...db, building: { ...db.building, subtitle: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Foundation Milestone
                      </label>
                      <input
                        type="text"
                        value={db.building.timeline.start}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            building: {
                              ...db.building,
                              timeline: { ...db.building.timeline, start: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Grand Opening Target
                      </label>
                      <input
                        type="text"
                        value={db.building.timeline.completion}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            building: {
                              ...db.building,
                              timeline: { ...db.building.timeline, completion: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Architectural Narrative
                      </label>
                      <textarea
                        rows={4}
                        value={db.building.story}
                        onChange={(e) =>
                          setDb({ ...db, building: { ...db.building, story: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                  </div>
                </div>

                <CmsPhotoGalleryEditor
                  title={`2027 Wing Architectural Photos (${db.building.images.length})`}
                  description="Upload, replace, caption, or remove architectural preview photos for the 2027 Classroom Wing showcase."
                  category="Campus & Facilities"
                  mode="building"
                  items={db.building.images}
                  onChange={(next) =>
                    setDb({
                      ...db,
                      building: {
                        ...db.building,
                        images: next.map((item) => ({
                          url: item.url,
                          tag: item.tag || 'Campus Facility',
                          caption: item.caption || '',
                        })),
                      },
                    })
                  }
                />
              </div>
            )}

            {/* TAB: ABOUT, CAMPUS & SMT */}
            {activeTab === 'about' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                      About, Mission & Executive Leadership / SMT
                    </h3>
                    <p className="text-[15px] text-slate-600 mt-1">
                      Manage institutional heritage, mission & vision statements, Directors, and Senior Management Team portraits.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      void commitSection(
                        'about',
                        db.about,
                        'About, SMT & Directors saved live to the SQLite CMS!'
                      )
                    }
                    className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-bold flex items-center gap-2 cursor-pointer"
                  >
                    <Save className="w-4 h-4 text-amber-400" />
                    <span>Save SMT & About</span>
                  </button>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Heritage Heading
                      </label>
                      <input
                        type="text"
                        value={db.about.heritageHeading}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            about: { ...db.about, heritageHeading: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Mission Statement
                      </label>
                      <textarea
                        rows={3}
                        value={db.about.missionText}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            about: { ...db.about, missionText: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Vision Statement
                      </label>
                      <textarea
                        rows={3}
                        value={db.about.visionText}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            about: { ...db.about, visionText: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
                    <h4 className="font-serif font-bold text-lg text-[#0c1a40] tabular-nums">
                      School Leadership & SMT Profiles ({db.about.leadership.length})
                    </h4>
                    <button
                      type="button"
                      onClick={() => {
                        const created = {
                          id: `smt-${Date.now()}`,
                          name: 'New Leader',
                          role: 'Senior Management Team',
                          title: 'Senior Management Team',
                          bio: '',
                          message: '',
                          image: '',
                          isSMT: true,
                          order: db.about.leadership.length + 1,
                          status: 'published' as PublishStatus,
                        };
                        setDb({
                          ...db,
                          about: { ...db.about, leadership: [...db.about.leadership, created] },
                        });
                      }}
                      className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-semibold flex items-center gap-2 cursor-pointer"
                    >
                      <Plus className="w-4 h-4 text-amber-400" />
                      <span>Add Leader</span>
                    </button>
                  </div>

                  <div className="space-y-4">
                    {db.about.leadership.map((leader, idx) => (
                      <div
                        key={leader.id || idx}
                        className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-serif font-bold text-lg text-[#0c1a40] tabular-nums">
                            #{leader.order ?? idx + 1} · {leader.name}
                          </span>
                          <div className="flex items-center gap-2">
                            <select
                              value={leader.status || 'published'}
                              onChange={(e) => {
                                const updated = [...db.about.leadership];
                                updated[idx] = {
                                  ...leader,
                                  status: e.target.value as PublishStatus,
                                };
                                setDb({ ...db, about: { ...db.about, leadership: updated } });
                              }}
                              className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-sm font-semibold"
                            >
                              <option value="published">Published</option>
                              <option value="unpublished">Unpublished (Hidden)</option>
                            </select>
                            <button
                              type="button"
                              onClick={() =>
                                setConfirmAction({
                                  title: 'Delete Leadership Profile',
                                  message: `Remove "${leader.name}" from Senior Management Team? Save Changes afterwards to update the live site.`,
                                  confirmLabel: 'Remove Profile',
                                  action: () => {
                                    const updated = db.about.leadership.filter((_, i) => i !== idx);
                                    setDb((prev) => ({
                                      ...prev,
                                      about: { ...prev.about, leadership: updated },
                                    }));
                                  },
                                })
                              }
                              className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                              title="Delete leader profile"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <input
                            type="text"
                            value={leader.name}
                            onChange={(e) => {
                              const updated = [...db.about.leadership];
                              updated[idx] = { ...leader, name: e.target.value };
                              setDb({ ...db, about: { ...db.about, leadership: updated } });
                            }}
                            placeholder="Full Name"
                            className="px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-[15px] font-semibold"
                          />
                          <input
                            type="text"
                            value={leader.role}
                            onChange={(e) => {
                              const updated = [...db.about.leadership];
                              updated[idx] = {
                                ...leader,
                                role: e.target.value,
                                title: e.target.value,
                              };
                              setDb({ ...db, about: { ...db.about, leadership: updated } });
                            }}
                            placeholder="Designation / Role"
                            className="px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-[15px]"
                          />
                          <input
                            type="number"
                            value={leader.order ?? idx + 1}
                            onChange={(e) => {
                              const updated = [...db.about.leadership];
                              updated[idx] = {
                                ...leader,
                                order: Number(e.target.value) || idx + 1,
                              };
                              setDb({ ...db, about: { ...db.about, leadership: updated } });
                            }}
                            placeholder="Display Order"
                            className="px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-[15px] tabular-nums"
                          />
                        </div>

                        <PhotoUploadField
                          value={leader.image || ''}
                          onChange={(url) => {
                            const updated = [...db.about.leadership];
                            updated[idx] = { ...leader, image: url || undefined };
                            setDb({ ...db, about: { ...db.about, leadership: updated } });
                          }}
                          label="Leader Portrait"
                          category="Boarding & Staff"
                          placeholderLabel="No Photo"
                        />

                        <textarea
                          rows={2}
                          value={leader.message || leader.bio}
                          onChange={(e) => {
                            const updated = [...db.about.leadership];
                            if (leader.message !== undefined) {
                              updated[idx] = { ...leader, message: e.target.value };
                            } else {
                              updated[idx] = { ...leader, bio: e.target.value };
                            }
                            setDb({ ...db, about: { ...db.about, leadership: updated } });
                          }}
                          placeholder="Campus & About bio/message (homepage displays portrait, name & designation only)"
                          className="w-full px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-[15px]"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Separate Directors Section (Below SMT) */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
                    <div>
                      <h4 className="font-serif font-bold text-lg text-[#0c1a40] tabular-nums">
                        College Directors ({(db.about.directors || []).length})
                      </h4>
                      <p className="text-sm text-slate-600 mt-0.5">
                        Displayed in a dedicated Directors section immediately below Senior Management Team (SMT) on Homepage & Campus page.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const currentDirectors = db.about.directors || [];
                        const created = {
                          id: `dir-${Date.now()}`,
                          name: 'New Director',
                          role: 'Director',
                          title: 'Director',
                          bio: '',
                          image: '',
                          order: currentDirectors.length + 1,
                          status: 'published' as PublishStatus,
                        };
                        setDb({
                          ...db,
                          about: { ...db.about, directors: [...currentDirectors, created] },
                        });
                      }}
                      className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-semibold flex items-center gap-2 cursor-pointer"
                    >
                      <Plus className="w-4 h-4 text-amber-400" />
                      <span>Add Director</span>
                    </button>
                  </div>

                  <div className="space-y-4">
                    {(db.about.directors || []).map((director, idx) => (
                      <div
                        key={director.id || idx}
                        className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-serif font-bold text-lg text-[#0c1a40] tabular-nums">
                            #{director.order ?? idx + 1} · {director.name}
                          </span>
                          <div className="flex items-center gap-2">
                            <select
                              value={director.status || 'published'}
                              onChange={(e) => {
                                const updated = [...(db.about.directors || [])];
                                updated[idx] = {
                                  ...director,
                                  status: e.target.value as PublishStatus,
                                };
                                setDb({ ...db, about: { ...db.about, directors: updated } });
                              }}
                              className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-sm font-semibold"
                            >
                              <option value="published">Published</option>
                              <option value="unpublished">Unpublished (Hidden)</option>
                            </select>
                            <button
                              type="button"
                              onClick={() =>
                                setConfirmAction({
                                  title: 'Delete Director Profile',
                                  message: `Remove "${director.name}" from Directors? Save Changes afterwards to update the live site.`,
                                  confirmLabel: 'Remove Profile',
                                  action: () => {
                                    const updated = (db.about.directors || []).filter(
                                      (_, i) => i !== idx
                                    );
                                    setDb((prev) => ({
                                      ...prev,
                                      about: { ...prev.about, directors: updated },
                                    }));
                                  },
                                })
                              }
                              className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                              title="Delete director profile"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <input
                            type="text"
                            value={director.name}
                            onChange={(e) => {
                              const updated = [...(db.about.directors || [])];
                              updated[idx] = { ...director, name: e.target.value };
                              setDb({ ...db, about: { ...db.about, directors: updated } });
                            }}
                            placeholder="Director Full Name"
                            className="px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-[15px] font-semibold"
                          />
                          <input
                            type="text"
                            value={director.role}
                            onChange={(e) => {
                              const updated = [...(db.about.directors || [])];
                              updated[idx] = {
                                ...director,
                                role: e.target.value,
                                title: e.target.value,
                              };
                              setDb({ ...db, about: { ...db.about, directors: updated } });
                            }}
                            placeholder="Official Designation (e.g. Director of Lower School)"
                            className="px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-[15px]"
                          />
                          <input
                            type="number"
                            value={director.order ?? idx + 1}
                            onChange={(e) => {
                              const updated = [...(db.about.directors || [])];
                              updated[idx] = {
                                ...director,
                                order: Number(e.target.value) || idx + 1,
                              };
                              setDb({ ...db, about: { ...db.about, directors: updated } });
                            }}
                            placeholder="Display Order"
                            className="px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-[15px] tabular-nums"
                          />
                        </div>

                        <PhotoUploadField
                          value={director.image || ''}
                          onChange={(url) => {
                            const updated = [...(db.about.directors || [])];
                            updated[idx] = { ...director, image: url || undefined };
                            setDb({ ...db, about: { ...db.about, directors: updated } });
                          }}
                          label="Director Portrait Photograph"
                          category="Boarding & Staff"
                          placeholderLabel="No Photo"
                        />

                        <textarea
                          rows={2}
                          value={director.bio || ''}
                          onChange={(e) => {
                            const updated = [...(db.about.directors || [])];
                            updated[idx] = { ...director, bio: e.target.value };
                            setDb({ ...db, about: { ...db.about, directors: updated } });
                          }}
                          placeholder="Optional Director biography / notes (leave blank if none)"
                          className="w-full px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-[15px]"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB: BOARDING HOUSES & STAFF PROFILES */}
            {activeTab === 'boarding' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                      Boarding Houses (100 Beds) & Boarding Master / Mistress Profiles
                    </h3>
                    <p className="text-[15px] text-slate-600 mt-1">
                      Manage boarding residence hero photograph, capacity metrics, and Mr Dube & Ms Tumotumo pastoral profiles.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      void commitSection(
                        'boarding',
                        db.boarding,
                        'Boarding residences & staff profiles saved live!'
                      )
                    }
                    className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-bold flex items-center gap-2 cursor-pointer"
                  >
                    <Save className="w-4 h-4 text-amber-400" />
                    <span>Save Boarding</span>
                  </button>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-5">
                  <PhotoUploadField
                    aspect="banner"
                    value={db.boarding.bannerImage || './assets/aistudio/image_06ec6396.png'}
                    onChange={(url) =>
                      setDb({
                        ...db,
                        boarding: { ...db.boarding, bannerImage: url },
                      })
                    }
                    label="Boarding Complex Showcase Banner (Masire Residences)"
                    category="Boarding & Staff"
                    placeholderLabel="No Banner"
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Total Capacity (Beds)
                      </label>
                      <input
                        type="number"
                        value={db.boarding.capacity}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            boarding: { ...db.boarding, capacity: Number(e.target.value) || 0 },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Current Residents
                      </label>
                      <input
                        type="number"
                        value={db.boarding.currentResidents}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            boarding: {
                              ...db.boarding,
                              currentResidents: Number(e.target.value) || 0,
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">Spaces Open</label>
                      <input
                        type="number"
                        value={db.boarding.spacesOpen}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            boarding: {
                              ...db.boarding,
                              spacesOpen: Number(e.target.value) || 0,
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                      />
                    </div>
                    <div className="sm:col-span-3">
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Lead Introduction
                      </label>
                      <textarea
                        rows={3}
                        value={db.boarding.leadParagraph}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            boarding: { ...db.boarding, leadParagraph: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                  </div>
                </div>

                {/* Hostels + Boarding Staff Portraits */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  {db.boarding.hostels.map((hostel, idx) => {
                    const isGirls = hostel.id === 'girls-house';
                    return (
                      <div
                        key={hostel.id}
                        className={`p-5 sm:p-6 rounded-xl bg-white border space-y-4 ${
                          isGirls ? 'border-pink-200' : 'border-blue-200'
                        }`}
                      >
                        <div className="flex items-center gap-3.5 pb-3 border-b border-slate-200">
                          <img
                            src={hostel.leaderImage || './assets/aistudio/logo_33a39ff7.png'}
                            alt={hostel.leaderName}
                            className={`w-16 h-16 rounded-full object-cover object-top border-2 ${
                              isGirls ? 'border-pink-500' : 'border-[#0c1a40]'
                            }`}
                          />
                          <div>
                            <div className="font-serif font-bold text-lg text-[#0c1a40]">
                              {hostel.name}
                            </div>
                            <div
                              className={`text-sm font-semibold ${
                                isGirls ? 'text-pink-700' : 'text-blue-800'
                              }`}
                            >
                              {hostel.leaderRole}: {hostel.leaderName}
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block font-semibold text-sm text-[#0c1a40] mb-1">
                              Staff Member Name
                            </label>
                            <input
                              type="text"
                              value={hostel.leaderName}
                              onChange={(e) => {
                                const next = [...db.boarding.hostels];
                                next[idx] = { ...hostel, leaderName: e.target.value };
                                setDb({ ...db, boarding: { ...db.boarding, hostels: next } });
                              }}
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                          <div>
                            <label className="block font-semibold text-sm text-[#0c1a40] mb-1">
                              Role
                            </label>
                            <input
                              type="text"
                              value={hostel.leaderRole}
                              onChange={(e) => {
                                const next = [...db.boarding.hostels];
                                next[idx] = { ...hostel, leaderRole: e.target.value };
                                setDb({ ...db, boarding: { ...db.boarding, hostels: next } });
                              }}
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <label className="block font-semibold text-sm text-[#0c1a40] mb-1">
                              Title & Residence
                            </label>
                            <input
                              type="text"
                              value={hostel.leaderTitle}
                              onChange={(e) => {
                                const next = [...db.boarding.hostels];
                                next[idx] = { ...hostel, leaderTitle: e.target.value };
                                setDb({ ...db, boarding: { ...db.boarding, hostels: next } });
                              }}
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <PhotoUploadField
                              value={hostel.leaderImage || ''}
                              onChange={(url) => {
                                const next = [...db.boarding.hostels];
                                next[idx] = { ...hostel, leaderImage: url || undefined };
                                setDb({ ...db, boarding: { ...db.boarding, hostels: next } });
                              }}
                              label="Boarding Staff Portrait"
                              category="Boarding & Staff"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <label className="block font-semibold text-sm text-[#0c1a40] mb-1">
                              Residence Description
                            </label>
                            <textarea
                              rows={2}
                              value={hostel.description}
                              onChange={(e) => {
                                const next = [...db.boarding.hostels];
                                next[idx] = { ...hostel, description: e.target.value };
                                setDb({ ...db, boarding: { ...db.boarding, hostels: next } });
                              }}
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <label className="block font-semibold text-sm text-[#0c1a40] mb-1">
                              Staff Statement / Pastoral Message
                            </label>
                            <textarea
                              rows={3}
                              value={hostel.quote}
                              onChange={(e) => {
                                const next = [...db.boarding.hostels];
                                next[idx] = { ...hostel, quote: e.target.value };
                                setDb({ ...db, boarding: { ...db.boarding, hostels: next } });
                              }}
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB: EXCURSIONS */}
            {activeTab === 'excursions' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <h3 className="font-serif font-bold text-2xl text-[#0c1a40] tabular-nums">
                    Educational Excursions ({db.excursions.length} Trips)
                  </h3>
                  <p className="text-[15px] text-slate-600 mt-1">
                    Add, edit, upload showcase photos, or remove national, regional, and international excursions.
                  </p>
                </div>

                {/* Add New Excursion */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40] flex items-center gap-2">
                    <Plus className="w-5 h-5 text-amber-600" />
                    <span>Add Educational Excursion</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <input
                      type="text"
                      placeholder="Trip Title *"
                      value={newExcursion.title}
                      onChange={(e) => setNewExcursion({ ...newExcursion, title: e.target.value })}
                      className="sm:col-span-2 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <select
                      value={newExcursion.category}
                      onChange={(e) =>
                        setNewExcursion({
                          ...newExcursion,
                          category: e.target.value as ExcursionItem['category'],
                        })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    >
                      <option value="International">International</option>
                      <option value="Regional">Regional</option>
                      <option value="National">National</option>
                    </select>
                    <input
                      type="text"
                      placeholder="Destination"
                      value={newExcursion.destination}
                      onChange={(e) =>
                        setNewExcursion({ ...newExcursion, destination: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Target Forms"
                      value={newExcursion.targetForms}
                      onChange={(e) =>
                        setNewExcursion({ ...newExcursion, targetForms: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Year / Duration"
                      value={newExcursion.duration}
                      onChange={(e) =>
                        setNewExcursion({ ...newExcursion, duration: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <div className="sm:col-span-3">
                      <PhotoUploadField
                        aspect="banner"
                        value={newExcursion.image || ''}
                        onChange={(url) => setNewExcursion({ ...newExcursion, image: url })}
                        label="Excursion Banner Photograph (Optional)"
                        category="Excursions"
                        placeholderLabel="No Photo"
                      />
                    </div>
                    <textarea
                      rows={2}
                      placeholder="Description"
                      value={newExcursion.description}
                      onChange={(e) =>
                        setNewExcursion({ ...newExcursion, description: e.target.value })
                      }
                      className="sm:col-span-3 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Highlights (comma separated)"
                      value={newExcursionHighlights}
                      onChange={(e) => setNewExcursionHighlights(e.target.value)}
                      className="sm:col-span-3 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (!newExcursion.title?.trim()) return;
                      const created: ExcursionItem = {
                        id: `exc-${Date.now()}`,
                        title: newExcursion.title.trim(),
                        category:
                          (newExcursion.category as ExcursionItem['category']) || 'National',
                        year: newExcursion.year || '2026',
                        destination: newExcursion.destination || 'Botswana',
                        targetForms: newExcursion.targetForms || 'All Forms',
                        duration: newExcursion.duration || 'Study Tour',
                        description: newExcursion.description || '',
                        curriculumLink: newExcursion.curriculumLink || 'Cambridge Enrichment',
                        highlights: newExcursionHighlights
                          .split(',')
                          .map((h) => h.trim())
                          .filter(Boolean),
                        image: newExcursion.image || undefined,
                      };
                      void commitSection(
                        'excursions',
                        [created, ...db.excursions],
                        'New excursion added!'
                      );
                      setNewExcursion({
                        title: '',
                        category: 'International',
                        year: '2026',
                        destination: '',
                        targetForms: '',
                        duration: '',
                        description: '',
                        curriculumLink: '',
                        image: '',
                      });
                      setNewExcursionHighlights('');
                    }}
                    className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
                  >
                    + Add Excursion
                  </button>
                </div>

                <div className="space-y-4">
                  {db.excursions.map((exc, idx) => (
                    <div
                      key={exc.id}
                      className="p-5 sm:p-6 rounded-xl bg-white border border-slate-200 space-y-4"
                    >
                      <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-3">
                        <span className="font-serif font-bold text-lg text-[#0c1a40]">
                          {exc.title}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setConfirmAction({
                              title: 'Delete Excursion',
                              message: `Delete excursion "${exc.title}" from the website?`,
                              confirmLabel: 'Delete Excursion',
                              action: () =>
                                commitSection(
                                  'excursions',
                                  db.excursions.filter((x) => x.id !== exc.id),
                                  'Excursion removed.'
                                ),
                            })
                          }
                          className="px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>Delete</span>
                        </button>
                      </div>

                      <PhotoUploadField
                        aspect="banner"
                        value={exc.image || ''}
                        onChange={(url) => {
                          const next = [...db.excursions];
                          next[idx] = { ...exc, image: url || undefined };
                          setDb({ ...db, excursions: next });
                        }}
                        label="Excursion Banner Photograph"
                        category="Excursions"
                        placeholderLabel="No Photo"
                      />

                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                        <input
                          type="text"
                          value={exc.title}
                          onChange={(e) => {
                            const next = [...db.excursions];
                            next[idx] = { ...exc, title: e.target.value };
                            setDb({ ...db, excursions: next });
                          }}
                          placeholder="Trip Title"
                          className="sm:col-span-2 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                        <select
                          value={exc.category}
                          onChange={(e) => {
                            const next = [...db.excursions];
                            next[idx] = {
                              ...exc,
                              category: e.target.value as ExcursionItem['category'],
                            };
                            setDb({ ...db, excursions: next });
                          }}
                          className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        >
                          <option value="International">International</option>
                          <option value="Regional">Regional</option>
                          <option value="National">National</option>
                        </select>
                        <input
                          type="text"
                          value={exc.year || ''}
                          placeholder="Year"
                          onChange={(e) => {
                            const next = [...db.excursions];
                            next[idx] = { ...exc, year: e.target.value };
                            setDb({ ...db, excursions: next });
                          }}
                          className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                        />
                        <input
                          type="text"
                          value={exc.destination}
                          onChange={(e) => {
                            const next = [...db.excursions];
                            next[idx] = { ...exc, destination: e.target.value };
                            setDb({ ...db, excursions: next });
                          }}
                          placeholder="Destination"
                          className="sm:col-span-2 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                        <input
                          type="text"
                          value={exc.targetForms}
                          onChange={(e) => {
                            const next = [...db.excursions];
                            next[idx] = { ...exc, targetForms: e.target.value };
                            setDb({ ...db, excursions: next });
                          }}
                          placeholder="Target Forms"
                          className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                        <input
                          type="text"
                          value={exc.duration}
                          onChange={(e) => {
                            const next = [...db.excursions];
                            next[idx] = { ...exc, duration: e.target.value };
                            setDb({ ...db, excursions: next });
                          }}
                          placeholder="Duration"
                          className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                        <textarea
                          rows={2}
                          value={exc.description}
                          onChange={(e) => {
                            const next = [...db.excursions];
                            next[idx] = { ...exc, description: e.target.value };
                            setDb({ ...db, excursions: next });
                          }}
                          placeholder="Description"
                          className="sm:col-span-4 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: ALUMNI APPROVALS & PROFILES */}
            {activeTab === 'alumni' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
                  <div>
                    <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                      Alumni Registration Queue & Profiles
                    </h3>
                    <p className="text-[15px] text-slate-600 mt-1">
                      Public alumni registrations arrive as Pending. Only Approved alumni appear on the live directory.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {(['pending', 'approved', 'rejected', 'all'] as const).map((status) => (
                      <button
                        key={status}
                        type="button"
                        onClick={() => setAlumniFilter(status)}
                        className={`px-3.5 py-2 rounded-xl text-sm font-semibold capitalize cursor-pointer tabular-nums ${
                          alumniFilter === status
                            ? 'bg-[#0c1a40] text-white font-bold'
                            : 'bg-white text-[#0c1a40] border border-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        {status} (
                        {status === 'all'
                          ? db.alumni.length
                          : db.alumni.filter((a) => a.status === status).length}
                        )
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() =>
                        void commitSection(
                          'alumni',
                          db.alumni,
                          'Alumni profiles saved and synced!'
                        )
                      }
                      className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-sm font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save Alumni Changes</span>
                    </button>
                  </div>
                </div>

                <div className="relative max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={alumniSearch}
                    onChange={(e) => setAlumniSearch(e.target.value)}
                    placeholder="Search alumni by name, class year, role or university..."
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px]"
                  />
                </div>

                {/* Alumni List */}
                <div className="space-y-4">
                  {filteredAlumni.length === 0 ? (
                    <div className="p-8 rounded-xl bg-white border border-slate-200 text-center text-[15px] text-slate-600">
                      No alumni records in <strong className="uppercase">{alumniFilter}</strong>{' '}
                      status.
                    </div>
                  ) : (
                    filteredAlumni.map((alum) => (
                      <div
                        key={alum.id}
                        className="p-5 rounded-xl bg-white border border-slate-200 space-y-4"
                      >
                        <div className="flex flex-wrap items-start justify-between gap-4">
                          <div className="flex items-start gap-3.5">
                            {alum.image ? (
                              <img
                                src={alum.image}
                                alt={alum.name}
                                className="w-14 h-14 rounded-full object-cover object-top border border-amber-400 shrink-0"
                              />
                            ) : (
                              <div className="w-14 h-14 rounded-full bg-[#0c1a40] text-amber-400 flex items-center justify-center font-serif font-bold text-lg shrink-0">
                                {alum.name.slice(0, 1).toUpperCase()}
                              </div>
                            )}
                            <div>
                              <div className="font-serif font-bold text-lg text-[#0c1a40]">
                                {alum.name}
                              </div>
                              <div className="text-sm text-slate-600 mt-0.5">
                                {alum.gradYear} ·{' '}
                                <span
                                  className={`font-semibold capitalize ${
                                    alum.status === 'approved'
                                      ? 'text-emerald-700'
                                      : alum.status === 'pending'
                                      ? 'text-amber-700'
                                      : 'text-red-700'
                                  }`}
                                >
                                  {alum.status}
                                </span>
                                {alum.currentRole ? ` · ${alum.currentRole}` : ''}
                                {alum.university ? ` · ${alum.university}` : ''}
                              </div>
                              {alum.email && (
                                <div className="text-sm text-slate-600 mt-0.5">
                                  {alum.email} {alum.phone ? `· ${alum.phone}` : ''}
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            {alum.status !== 'approved' && (
                              <button
                                type="button"
                                onClick={() =>
                                  void commitSection(
                                    'alumni',
                                    db.alumni.map((x) =>
                                      x.id === alum.id ? { ...x, status: 'approved' } : x
                                    ),
                                    `${alum.name} approved and published!`
                                  )
                                }
                                className="px-3.5 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-sm flex items-center gap-1.5 cursor-pointer"
                              >
                                <Check className="w-4 h-4" />
                                <span>Approve</span>
                              </button>
                            )}
                            {alum.status !== 'rejected' && (
                              <button
                                type="button"
                                onClick={() =>
                                  void commitSection(
                                    'alumni',
                                    db.alumni.map((x) =>
                                      x.id === alum.id ? { ...x, status: 'rejected' } : x
                                    ),
                                    `${alum.name} moved to rejected.`
                                  )
                                }
                                className="px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                              >
                                <Ban className="w-4 h-4" />
                                <span>Reject</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() =>
                                setConfirmAction({
                                  title: 'Delete Alumni Record',
                                  message: `Permanently delete alumni profile for "${alum.name}"?`,
                                  confirmLabel: 'Delete Record',
                                  action: () =>
                                    commitSection(
                                      'alumni',
                                      db.alumni.filter((x) => x.id !== alum.id),
                                      'Alumni profile deleted.'
                                    ),
                                })
                              }
                              className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                              title="Delete alumni record"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        <PhotoUploadField
                          value={alum.image || ''}
                          onChange={(url) =>
                            setDb({
                              ...db,
                              alumni: db.alumni.map((x) =>
                                x.id === alum.id ? { ...x, image: url || undefined } : x
                              ),
                            })
                          }
                          label="Alumni Portrait"
                          category="Alumni"
                          placeholderLabel="No Portrait"
                        />

                        {/* Inline Quick Edit Fields */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-200">
                          <input
                            type="text"
                            value={alum.name}
                            onChange={(e) =>
                              setDb({
                                ...db,
                                alumni: db.alumni.map((x) =>
                                  x.id === alum.id ? { ...x, name: e.target.value } : x
                                ),
                              })
                            }
                            placeholder="Name"
                            className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                          />
                          <input
                            type="text"
                            value={alum.currentRole}
                            onChange={(e) =>
                              setDb({
                                ...db,
                                alumni: db.alumni.map((x) =>
                                  x.id === alum.id ? { ...x, currentRole: e.target.value } : x
                                ),
                              })
                            }
                            placeholder="Current Role / Occupation"
                            className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                          />
                          <input
                            type="text"
                            value={alum.university}
                            onChange={(e) =>
                              setDb({
                                ...db,
                                alumni: db.alumni.map((x) =>
                                  x.id === alum.id ? { ...x, university: e.target.value } : x
                                ),
                              })
                            }
                            placeholder="University / Institution"
                            className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                          />
                          <input
                            type="text"
                            value={alum.location}
                            onChange={(e) =>
                              setDb({
                                ...db,
                                alumni: db.alumni.map((x) =>
                                  x.id === alum.id ? { ...x, location: e.target.value } : x
                                ),
                              })
                            }
                            placeholder="City, Country"
                            className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                          />
                          <input
                            type="text"
                            value={alum.course}
                            onChange={(e) =>
                              setDb({
                                ...db,
                                alumni: db.alumni.map((x) =>
                                  x.id === alum.id ? { ...x, course: e.target.value } : x
                                ),
                              })
                            }
                            placeholder="Degree / Field"
                            className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                          />
                          <input
                            type="text"
                            value={alum.cambridgeHonors}
                            onChange={(e) =>
                              setDb({
                                ...db,
                                alumni: db.alumni.map((x) =>
                                  x.id === alum.id ? { ...x, cambridgeHonors: e.target.value } : x
                                ),
                              })
                            }
                            placeholder="Cambridge Honors"
                            className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                          />
                          <textarea
                            rows={2}
                            value={alum.quote}
                            onChange={(e) =>
                              setDb({
                                ...db,
                                alumni: db.alumni.map((x) =>
                                  x.id === alum.id ? { ...x, quote: e.target.value } : x
                                ),
                              })
                            }
                            placeholder="Alumni reflection quote..."
                            className="sm:col-span-3 px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                          />
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Add Verified Alumni Directly in CMS */}
                <div className="p-5 sm:p-6 rounded-xl bg-white border border-slate-200 space-y-4">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40] flex items-center gap-2">
                    <Plus className="w-5 h-5 text-amber-600" />
                    <span>Add Alumni Profile Directly (Approved)</span>
                  </h4>
                  <PhotoUploadField
                    value={newAlumniForm.image || ''}
                    onChange={(url) => setNewAlumniForm({ ...newAlumniForm, image: url })}
                    label="Alumni Portrait (Optional)"
                    category="Alumni"
                    placeholderLabel="No Portrait"
                  />
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <input
                      type="text"
                      placeholder="Full Name *"
                      value={newAlumniForm.name}
                      onChange={(e) =>
                        setNewAlumniForm({ ...newAlumniForm, name: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Graduation Class (e.g. Class of 2024)"
                      value={newAlumniForm.gradYear}
                      onChange={(e) =>
                        setNewAlumniForm({ ...newAlumniForm, gradYear: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Current Role"
                      value={newAlumniForm.currentRole}
                      onChange={(e) =>
                        setNewAlumniForm({ ...newAlumniForm, currentRole: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="University"
                      value={newAlumniForm.university}
                      onChange={(e) =>
                        setNewAlumniForm({ ...newAlumniForm, university: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Course / Degree"
                      value={newAlumniForm.course}
                      onChange={(e) =>
                        setNewAlumniForm({ ...newAlumniForm, course: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="City, Country"
                      value={newAlumniForm.location}
                      onChange={(e) =>
                        setNewAlumniForm({ ...newAlumniForm, location: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <textarea
                      rows={2}
                      placeholder="Testimonial / Advice Quote"
                      value={newAlumniForm.quote}
                      onChange={(e) =>
                        setNewAlumniForm({ ...newAlumniForm, quote: e.target.value })
                      }
                      className="sm:col-span-3 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (!newAlumniForm.name?.trim()) return;
                      const created: AlumniProfile = {
                        id: `alum-${Date.now()}`,
                        name: newAlumniForm.name.trim(),
                        gradYear: newAlumniForm.gradYear || 'Class of 2024',
                        currentRole: newAlumniForm.currentRole || 'LKC Alumnus',
                        organization: newAlumniForm.organization || '',
                        university: newAlumniForm.university || '',
                        location: newAlumniForm.location || 'Botswana',
                        course: newAlumniForm.course || '',
                        cambridgeHonors: newAlumniForm.cambridgeHonors || '',
                        quote: newAlumniForm.quote || '',
                        image: newAlumniForm.image || undefined,
                        status: 'approved',
                        submittedAt: new Date().toISOString().split('T')[0],
                      };
                      void commitSection(
                        'alumni',
                        [created, ...db.alumni],
                        'Verified alumni profile added!'
                      );
                      setNewAlumniForm({
                        name: '',
                        gradYear: 'Class of 2024',
                        currentRole: '',
                        organization: '',
                        university: '',
                        location: '',
                        course: '',
                        cambridgeHonors: '',
                        quote: '',
                        image: '',
                        status: 'approved',
                      });
                    }}
                    className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
                  >
                    + Add & Approve Alumni
                  </button>
                </div>
              </div>
            )}

            {/* TAB: TOP ACHIEVERS (MULTI-YEAR ACADEMIC ARCHIVE) */}
            {activeTab === 'achievers' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
                  <div>
                    <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                      Top Achievers · Multi-Year Cambridge Archives & Honor Roll
                    </h3>
                    <p className="text-[15px] text-slate-600 mt-1">
                      Manage annual Cambridge results, showcase banner photography, learner awards, and the full Honor Roll.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {(db.achievers.availableYears || ['2025']).map((yr) => (
                      <button
                        key={yr}
                        type="button"
                        onClick={() => {
                          setSelectedAchieverYear(yr);
                          setHonorPage(1);
                          setNewAward((prev) => ({ ...prev, year: yr }));
                          setNewHonor((prev) => ({ ...prev, year: yr }));
                        }}
                        className={`px-3.5 py-2 rounded-xl text-[15px] font-bold tabular-nums cursor-pointer ${
                          selectedAchieverYear === yr
                            ? 'bg-[#0c1a40] text-amber-400'
                            : 'bg-white text-[#0c1a40] border border-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        {yr}
                      </button>
                    ))}
                    <div className="flex items-center gap-1.5 ml-1">
                      <input
                        type="text"
                        value={newYearInput}
                        onChange={(e) => setNewYearInput(e.target.value)}
                        placeholder="e.g. 2026"
                        className="w-24 px-3 py-2 rounded-xl border border-slate-300 bg-white text-[15px] tabular-nums"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const yr = newYearInput.trim();
                          if (!yr) return;
                          const years = Array.from(
                            new Set([yr, ...(db.achievers.availableYears || ['2025'])])
                          )
                            .sort()
                            .reverse();
                          const nextSummaries = {
                            ...(db.achievers.yearlySummaries || {}),
                            [yr]:
                              (db.achievers.yearlySummaries &&
                                db.achievers.yearlySummaries[yr]) || {
                                ...db.achievers.summary,
                                headline: `${yr} Cambridge International Excellence & Learner Awards`,
                              },
                          };
                          void commitSection(
                            'achievers',
                            {
                              ...db.achievers,
                              availableYears: years,
                              yearlySummaries: nextSummaries,
                            },
                            `Academic year ${yr} added to Achievers archive.`
                          );
                          setSelectedAchieverYear(yr);
                        }}
                        className="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
                      >
                        + Year
                      </button>
                    </div>
                  </div>
                </div>

                {/* Selected Year Summary + Banner Images */}
                {(() => {
                  const yearSummary =
                    (db.achievers.yearlySummaries &&
                      db.achievers.yearlySummaries[selectedAchieverYear]) ||
                    db.achievers.summary;
                  const updateYearSummary = (patch: Partial<typeof db.achievers.summary>) => {
                    const updated = { ...yearSummary, ...patch };
                    const nextYearlySummaries = {
                      ...(db.achievers.yearlySummaries || {}),
                      [selectedAchieverYear]: updated,
                    };
                    setDb({
                      ...db,
                      achievers: {
                        ...db.achievers,
                        yearlySummaries: nextYearlySummaries,
                        summary:
                          selectedAchieverYear === (db.settings?.activeAchieversYear || '2025')
                            ? updated
                            : db.achievers.summary,
                      },
                    });
                  };
                  const banners = yearSummary.bannerImages || {
                    igcseHero: '',
                    dozenAchievers: '',
                    newspaperSpread: '',
                  };
                  const updateBanner = (key: keyof typeof banners, url: string) => {
                    updateYearSummary({
                      bannerImages: {
                        ...banners,
                        [key]: url,
                      },
                    });
                  };

                  return (
                    <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-5">
                      <h4 className="font-serif font-bold text-lg text-[#0c1a40] tabular-nums">
                        Cohort Summary & Showcase Images for {selectedAchieverYear}
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="sm:col-span-2">
                          <label className="block font-semibold text-[15px] mb-1.5">
                            Year Headline
                          </label>
                          <input
                            type="text"
                            value={yearSummary.headline}
                            onChange={(e) => updateYearSummary({ headline: e.target.value })}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold text-[15px] mb-1.5">
                            IGCSE Pass Rate
                          </label>
                          <input
                            type="text"
                            value={yearSummary.igcsePassRate}
                            onChange={(e) => updateYearSummary({ igcsePassRate: e.target.value })}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <label className="block font-semibold text-[15px] mb-1.5">
                            Subheadline / Anniversary Summary
                          </label>
                          <input
                            type="text"
                            value={yearSummary.subheadline || ''}
                            onChange={(e) => updateYearSummary({ subheadline: e.target.value })}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <label className="block font-semibold text-[15px] mb-1.5">
                            Cohort Overview Description
                          </label>
                          <textarea
                            rows={2}
                            value={yearSummary.description}
                            onChange={(e) => updateYearSummary({ description: e.target.value })}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-slate-200">
                        <PhotoUploadField
                          aspect="banner"
                          value={banners.igcseHero}
                          onChange={(url) => updateBanner('igcseHero', url)}
                          label="IGCSE Hero Banner"
                          category="Achievers"
                        />
                        <PhotoUploadField
                          aspect="banner"
                          value={banners.dozenAchievers}
                          onChange={(url) => updateBanner('dozenAchievers', url)}
                          label="Top Achievers Collage"
                          category="Achievers"
                        />
                        <PhotoUploadField
                          aspect="banner"
                          value={banners.newspaperSpread}
                          onChange={(url) => updateBanner('newspaperSpread', url)}
                          label="Results Publication Spread"
                          category="Achievers"
                        />
                      </div>
                    </div>
                  );
                })()}

                {/* Add Award */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40] flex items-center gap-2">
                    <Plus className="w-5 h-5 text-amber-600" />
                    <span>Add Cambridge Learner Award ({selectedAchieverYear})</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <input
                      type="text"
                      placeholder="Student Name *"
                      value={newAward.studentName}
                      onChange={(e) => setNewAward({ ...newAward, studentName: e.target.value })}
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <select
                      value={newAward.awardType}
                      onChange={(e) =>
                        setNewAward({
                          ...newAward,
                          awardType: e.target.value as CambridgeLearnerAward['awardType'],
                        })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    >
                      <option value="Top in the World">Top in the World</option>
                      <option value="Top in Botswana">Top in Botswana</option>
                      <option value="High Achievement">High Achievement</option>
                    </select>
                    <input
                      type="text"
                      placeholder="Subject *"
                      value={newAward.subject}
                      onChange={(e) => setNewAward({ ...newAward, subject: e.target.value })}
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Grades (e.g. 6A*, 2A)"
                      value={newAward.grades}
                      onChange={(e) => setNewAward({ ...newAward, grades: e.target.value })}
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                  </div>
                  <PhotoUploadField
                    value={newAward.image || ''}
                    onChange={(url) =>
                      setNewAward({
                        ...newAward,
                        image: url || './assets/aistudio/logo_33a39ff7.png',
                      })
                    }
                    label="Award Recipient / Certificate Image"
                    category="Achievers"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!newAward.studentName?.trim()) return;
                      const created: CambridgeLearnerAward = {
                        id: `award-${Date.now()}`,
                        studentName: newAward.studentName.trim(),
                        awardType:
                          (newAward.awardType as CambridgeLearnerAward['awardType']) ||
                          'Top in Botswana',
                        level: (newAward.level as CambridgeLearnerAward['level']) || 'Cambridge IGCSE',
                        subject: newAward.subject || 'Academic Distinction',
                        image: newAward.image || './assets/aistudio/logo_33a39ff7.png',
                        year: selectedAchieverYear,
                        grades: newAward.grades,
                        highlightNote:
                          newAward.highlightNote || `${newAward.awardType} in ${newAward.subject}`,
                      };
                      void commitSection(
                        'achievers',
                        { ...db.achievers, awards: [created, ...db.achievers.awards] },
                        `Cambridge Award added for ${selectedAchieverYear}!`
                      );
                      setNewAward({
                        studentName: '',
                        awardType: 'Top in Botswana',
                        level: 'Cambridge IGCSE',
                        subject: '',
                        year: selectedAchieverYear,
                        grades: '',
                        image: './assets/aistudio/logo_33a39ff7.png',
                        highlightNote: '',
                      });
                    }}
                    className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
                  >
                    + Add Award ({selectedAchieverYear})
                  </button>
                </div>

                {/* Existing Editable Awards */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40] tabular-nums">
                    Cambridge Learner Awards in {selectedAchieverYear} (
                    {
                      db.achievers.awards.filter(
                        (aw) => (aw.year || '2025') === selectedAchieverYear
                      ).length
                    }
                    )
                  </h4>
                  <div className="space-y-4">
                    {db.achievers.awards
                      .filter((aw) => (aw.year || '2025') === selectedAchieverYear)
                      .map((aw) => (
                        <div
                          key={aw.id}
                          className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-3">
                            <div className="font-serif font-bold text-lg text-[#0c1a40]">
                              {aw.studentName} ·{' '}
                              <span className="text-amber-700 font-sans text-base">
                                {aw.awardType} ({aw.subject})
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() =>
                                setConfirmAction({
                                  title: 'Delete Cambridge Award',
                                  message: `Remove "${aw.studentName} (${aw.awardType})" from ${selectedAchieverYear} awards?`,
                                  confirmLabel: 'Remove Award',
                                  action: () =>
                                    commitSection(
                                      'achievers',
                                      {
                                        ...db.achievers,
                                        awards: db.achievers.awards.filter((x) => x.id !== aw.id),
                                      },
                                      'Award removed.'
                                    ),
                                })
                              }
                              className="px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                              <span>Delete</span>
                            </button>
                          </div>

                          <PhotoUploadField
                            value={aw.image}
                            onChange={(url) =>
                              setDb({
                                ...db,
                                achievers: {
                                  ...db.achievers,
                                  awards: db.achievers.awards.map((x) =>
                                    x.id === aw.id ? { ...x, image: url } : x
                                  ),
                                },
                              })
                            }
                            label="Recipient / Certificate Photograph"
                            category="Achievers"
                          />

                          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                            <input
                              type="text"
                              value={aw.studentName}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  achievers: {
                                    ...db.achievers,
                                    awards: db.achievers.awards.map((x) =>
                                      x.id === aw.id ? { ...x, studentName: e.target.value } : x
                                    ),
                                  },
                                })
                              }
                              placeholder="Student Name"
                              className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                            />
                            <select
                              value={aw.awardType}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  achievers: {
                                    ...db.achievers,
                                    awards: db.achievers.awards.map((x) =>
                                      x.id === aw.id
                                        ? {
                                            ...x,
                                            awardType: e.target
                                              .value as CambridgeLearnerAward['awardType'],
                                          }
                                        : x
                                    ),
                                  },
                                })
                              }
                              className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                            >
                              <option value="Top in the World">Top in the World</option>
                              <option value="Top in Botswana">Top in Botswana</option>
                              <option value="High Achievement">High Achievement</option>
                            </select>
                            <select
                              value={aw.level}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  achievers: {
                                    ...db.achievers,
                                    awards: db.achievers.awards.map((x) =>
                                      x.id === aw.id
                                        ? {
                                            ...x,
                                            level: e.target.value as CambridgeLearnerAward['level'],
                                          }
                                        : x
                                    ),
                                  },
                                })
                              }
                              className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                            >
                              <option value="Cambridge IGCSE">Cambridge IGCSE</option>
                              <option value="Cambridge AS Level">Cambridge AS Level</option>
                              <option value="Cambridge A2 Level">Cambridge A2 Level</option>
                            </select>
                            <input
                              type="text"
                              value={aw.subject}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  achievers: {
                                    ...db.achievers,
                                    awards: db.achievers.awards.map((x) =>
                                      x.id === aw.id ? { ...x, subject: e.target.value } : x
                                    ),
                                  },
                                })
                              }
                              placeholder="Subject"
                              className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                            />
                            <input
                              type="text"
                              value={aw.grades || ''}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  achievers: {
                                    ...db.achievers,
                                    awards: db.achievers.awards.map((x) =>
                                      x.id === aw.id ? { ...x, grades: e.target.value } : x
                                    ),
                                  },
                                })
                              }
                              placeholder="Grades (e.g. 6A*, 2A)"
                              className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                            />
                            <input
                              type="text"
                              value={aw.highlightNote || ''}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  achievers: {
                                    ...db.achievers,
                                    awards: db.achievers.awards.map((x) =>
                                      x.id === aw.id ? { ...x, highlightNote: e.target.value } : x
                                    ),
                                  },
                                })
                              }
                              placeholder="Citation / Highlight Note"
                              className="sm:col-span-3 px-3 py-2 rounded-lg bg-white border border-slate-300 text-[15px]"
                            />
                          </div>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Honor Roll Quick Add + Editable Paginated List */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <h4 className="font-serif font-bold text-lg text-[#0c1a40] tabular-nums">
                      Honor Roll Scholars in {selectedAchieverYear} ({yearHonorList.length})
                    </h4>
                    <div className="relative w-full sm:w-72">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={honorSearch}
                        onChange={(e) => {
                          setHonorSearch(e.target.value);
                          setHonorPage(1);
                        }}
                        placeholder="Search Honor Roll scholars..."
                        className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2.5 p-4 rounded-xl bg-slate-50 border border-slate-200">
                    <input
                      type="text"
                      placeholder="Student Name *"
                      value={newHonor.studentName}
                      onChange={(e) => setNewHonor({ ...newHonor, studentName: e.target.value })}
                      className="flex-1 min-w-[180px] px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Grades (e.g. 5A*, 3A)"
                      value={newHonor.grades}
                      onChange={(e) => setNewHonor({ ...newHonor, grades: e.target.value })}
                      className="w-44 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <select
                      value={newHonor.level}
                      onChange={(e) =>
                        setNewHonor({
                          ...newHonor,
                          level: e.target.value as AchieverItem['level'],
                        })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    >
                      <option value="Cambridge IGCSE">Cambridge IGCSE</option>
                      <option value="Cambridge AS Level">Cambridge AS Level</option>
                      <option value="Cambridge A2 Level">Cambridge A2 Level</option>
                    </select>
                    <button
                      type="button"
                      onClick={() => {
                        if (!newHonor.studentName?.trim()) return;
                        const item: AchieverItem = {
                          id: `hr-${Date.now()}`,
                          studentName: newHonor.studentName.trim(),
                          level: (newHonor.level as AchieverItem['level']) || 'Cambridge IGCSE',
                          grades: newHonor.grades || '4A*',
                          starCount: newHonor.starCount,
                          featuredAward: newHonor.featuredAward,
                          year: selectedAchieverYear,
                        };
                        void commitSection(
                          'achievers',
                          { ...db.achievers, honorRoll: [item, ...db.achievers.honorRoll] },
                          `Honor Roll scholar added for ${selectedAchieverYear}!`
                        );
                        setNewHonor({
                          studentName: '',
                          level: 'Cambridge IGCSE',
                          grades: '',
                          starCount: 4,
                          featuredAward: '',
                          year: selectedAchieverYear,
                        });
                      }}
                      className="px-4 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
                    >
                      + Add Scholar
                    </button>
                  </div>

                  <div className="space-y-2.5">
                    {pagedHonorList.map((hr) => (
                      <div
                        key={hr.id}
                        className="p-3 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 md:grid-cols-12 gap-2.5 items-center"
                      >
                        <input
                          type="text"
                          value={hr.studentName}
                          onChange={(e) =>
                            setDb({
                              ...db,
                              achievers: {
                                ...db.achievers,
                                honorRoll: db.achievers.honorRoll.map((x) =>
                                  x.id === hr.id ? { ...x, studentName: e.target.value } : x
                                ),
                              },
                            })
                          }
                          className="md:col-span-4 px-3 py-2 rounded-lg border border-slate-300 bg-white text-[15px] font-semibold"
                        />
                        <input
                          type="text"
                          value={hr.grades}
                          onChange={(e) =>
                            setDb({
                              ...db,
                              achievers: {
                                ...db.achievers,
                                honorRoll: db.achievers.honorRoll.map((x) =>
                                  x.id === hr.id ? { ...x, grades: e.target.value } : x
                                ),
                              },
                            })
                          }
                          className="md:col-span-3 px-3 py-2 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                        <select
                          value={hr.level}
                          onChange={(e) =>
                            setDb({
                              ...db,
                              achievers: {
                                ...db.achievers,
                                honorRoll: db.achievers.honorRoll.map((x) =>
                                  x.id === hr.id
                                    ? { ...x, level: e.target.value as AchieverItem['level'] }
                                    : x
                                ),
                              },
                            })
                          }
                          className="md:col-span-4 px-3 py-2 rounded-lg border border-slate-300 bg-white text-[15px]"
                        >
                          <option value="Cambridge IGCSE">Cambridge IGCSE</option>
                          <option value="Cambridge AS Level">Cambridge AS Level</option>
                          <option value="Cambridge A2 Level">Cambridge A2 Level</option>
                        </select>
                        <div className="md:col-span-1 flex justify-end">
                          <button
                            type="button"
                            onClick={() =>
                              setConfirmAction({
                                title: 'Remove Honor Roll Scholar',
                                message: `Remove "${hr.studentName}" from the ${selectedAchieverYear} Honor Roll?`,
                                confirmLabel: 'Remove',
                                action: () =>
                                  commitSection(
                                    'achievers',
                                    {
                                      ...db.achievers,
                                      honorRoll: db.achievers.honorRoll.filter(
                                        (x) => x.id !== hr.id
                                      ),
                                    },
                                    'Honor Roll scholar removed.'
                                  ),
                              })
                            }
                            className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                            title="Remove scholar"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {totalHonorPages > 1 && (
                    <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-sm">
                      <span className="text-slate-600 tabular-nums">
                        Page {safeHonorPage} of {totalHonorPages} · {filteredHonorList.length} scholars
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          disabled={safeHonorPage <= 1}
                          onClick={() => setHonorPage((p) => Math.max(1, p - 1))}
                          className="px-3.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer font-semibold"
                        >
                          Previous
                        </button>
                        <button
                          type="button"
                          disabled={safeHonorPage >= totalHonorPages}
                          onClick={() => setHonorPage((p) => Math.min(totalHonorPages, p + 1))}
                          className="px-3.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer font-semibold"
                        >
                          Next
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB: SPORTS & HOUSES */}
            {activeTab === 'sports' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                    Sports Directorate & College Houses
                  </h3>
                  <p className="text-[15px] text-slate-600 mt-1">
                    Manage Sports Directorate overview, photo gallery, and official Bathoen, Khama, Sechele & Moremi Houses.
                  </p>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Sports Motto
                      </label>
                      <input
                        type="text"
                        value={db.sports.motto}
                        onChange={(e) =>
                          setDb({ ...db, sports: { ...db.sports, motto: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Sporting Calendar Year
                      </label>
                      <input
                        type="text"
                        value={db.sports.houseTrophyRace.year}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            sports: {
                              ...db.sports,
                              houseTrophyRace: {
                                ...db.sports.houseTrophyRace,
                                year: e.target.value,
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Sports Directorate Overview
                      </label>
                      <textarea
                        rows={3}
                        value={db.sports.intro}
                        onChange={(e) =>
                          setDb({ ...db, sports: { ...db.sports, intro: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                  </div>
                </div>

                <CmsPhotoGalleryEditor
                  title="Sports Directorate Photo Gallery"
                  description="Upload, replace, caption, or remove photographs shown on the Sports page."
                  category="Sports"
                  mode="gallery"
                  enableLocationAndStatus
                  items={(db.sports.photos || []) as GalleryPhotoEntry[]}
                  defaultItems={[]}
                  hasUnsavedChanges={isCurrentTabDirty}
                  saving={savingAll}
                  onSaveSection={() =>
                    void commitSection('sports', db.sports, 'Sports gallery photos published live!')
                  }
                  onChange={(next) =>
                    setDb({
                      ...db,
                      sports: {
                        ...db.sports,
                        photos: next.map((item) => ({
                          url: item.url,
                          title: item.title || '',
                          category: item.category || 'Sports',
                          location: item.location || '',
                          status: item.status || 'published',
                          caption: item.caption || '',
                        })),
                      },
                    })
                  }
                />

                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <div>
                    <h4 className="font-serif font-bold text-lg text-[#0c1a40]">
                      College Houses (4 Official Houses — Equal Standing, No Rankings)
                    </h4>
                    <p className="text-sm text-slate-600 mt-1">
                      Official LKC Houses: Bathoen (Red), Khama (Green), Sechele (Blue), and Moremi (Yellow). House points, ranks, and trophy standings remain institutionally disabled.
                    </p>
                  </div>

                  <div className="space-y-4">
                    {db.houses.map((house, idx) => (
                      <div
                        key={house.id || house.name}
                        className="p-4 sm:p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-4"
                      >
                        <div className="flex items-center gap-3">
                          <span
                            className="w-5 h-5 rounded-full border border-slate-300 shrink-0"
                            style={{ backgroundColor: house.colorHex || '#1d4ed8' }}
                          />
                          <span className="font-serif font-bold text-lg text-[#0c1a40]">
                            {house.name}
                          </span>
                          <span className="text-sm font-medium text-amber-700">
                            · {house.colorName || 'Official Colour'}
                          </span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <input
                            type="text"
                            value={house.patron}
                            onChange={(e) => {
                              const next = [...db.houses];
                              next[idx] = { ...house, patron: e.target.value };
                              setDb({ ...db, houses: next });
                            }}
                            placeholder="House Heritage / Patron"
                            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                          <input
                            type="text"
                            value={house.description}
                            onChange={(e) => {
                              const next = [...db.houses];
                              next[idx] = { ...house, description: e.target.value };
                              setDb({ ...db, houses: next });
                            }}
                            placeholder="House Description"
                            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                          <PhotoUploadField
                            value={house.badgeUrl || ''}
                            onChange={(url) => {
                              const next = [...db.houses];
                              next[idx] = { ...house, badgeUrl: url || undefined };
                              setDb({ ...db, houses: next });
                            }}
                            label="House Badge / Crest"
                            category="Sports"
                            placeholderLabel="Crest"
                          />
                          <PhotoUploadField
                            value={house.photoUrl || ''}
                            onChange={(url) => {
                              const next = [...db.houses];
                              next[idx] = { ...house, photoUrl: url || undefined };
                              setDb({ ...db, houses: next });
                            }}
                            label="House Feature Photo"
                            category="Sports"
                            placeholderLabel="Photo"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB: JAGUARS RUGBY & FIXTURES */}
            {activeTab === 'jaguars' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                    The Jaguars Rugby & Fixtures Management
                  </h3>
                  <p className="text-[15px] text-slate-600 mt-1">
                    Manage Jaguars coaching details, matchday gallery photography, and 2026 official fixtures.
                  </p>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">Head Coach</label>
                      <input
                        type="text"
                        value={db.jaguars.headCoach}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            jaguars: { ...db.jaguars, headCoach: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">Home Ground</label>
                      <input
                        type="text"
                        value={db.jaguars.homeGround}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            jaguars: { ...db.jaguars, homeGround: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">Club Tagline</label>
                      <input
                        type="text"
                        value={db.jaguars.tagline}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            jaguars: { ...db.jaguars, tagline: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div className="sm:col-span-3">
                      <label className="block font-semibold text-[15px] mb-1.5">Overview</label>
                      <textarea
                        rows={3}
                        value={db.jaguars.overview}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            jaguars: { ...db.jaguars, overview: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                  </div>
                </div>

                <CmsPhotoGalleryEditor
                  title="Jaguars Rugby Photo Gallery"
                  description="Upload, replace, caption, or remove rugby pitch and matchday photographs."
                  category="Sports"
                  mode="gallery"
                  enableLocationAndStatus
                  items={(db.jaguars.photos || []) as GalleryPhotoEntry[]}
                  defaultItems={[]}
                  hasUnsavedChanges={isCurrentTabDirty}
                  saving={savingAll}
                  onSaveSection={() =>
                    void commitSection('jaguars', db.jaguars, 'Jaguars rugby gallery published live!')
                  }
                  onChange={(next) =>
                    setDb({
                      ...db,
                      jaguars: {
                        ...db.jaguars,
                        photos: next.map((item) => ({
                          url: item.url,
                          title: item.title || '',
                          category: item.category || 'Jaguars Rugby',
                          location: item.location || '',
                          status: item.status || 'published',
                          caption: item.caption || '',
                        })),
                      },
                    })
                  }
                />

                {/* Add Official Rugby Fixture */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40] flex items-center gap-2">
                    <Plus className="w-5 h-5 text-amber-600" />
                    <span>Add Official Rugby Fixture</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
                    <input
                      type="text"
                      placeholder="Opponent *"
                      value={newFixture.opponent}
                      onChange={(e) =>
                        setNewFixture({ ...newFixture, opponent: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Date *"
                      value={newFixture.date}
                      onChange={(e) => setNewFixture({ ...newFixture, date: e.target.value })}
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Venue"
                      value={newFixture.venue}
                      onChange={(e) => setNewFixture({ ...newFixture, venue: e.target.value })}
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Tournament"
                      value={newFixture.tournament}
                      onChange={(e) =>
                        setNewFixture({ ...newFixture, tournament: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <input
                      type="text"
                      placeholder="Status (e.g. Upcoming)"
                      value={newFixture.status}
                      onChange={(e) => setNewFixture({ ...newFixture, status: e.target.value })}
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (!newFixture.opponent.trim()) return;
                      const created: RugbyFixture = {
                        id: `fix-${Date.now()}`,
                        ...newFixture,
                      };
                      void commitSection(
                        'jaguars',
                        { ...db.jaguars, fixtures2026: [...db.jaguars.fixtures2026, created] },
                        'Rugby fixture published to Jaguars page!'
                      );
                      setNewFixture({
                        opponent: '',
                        venue: 'The Jaguars Den (Home)',
                        date: '',
                        tournament: '',
                        status: 'Upcoming',
                      });
                    }}
                    className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
                  >
                    + Add Fixture
                  </button>
                </div>

                {/* Current Fixtures */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-3">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40] tabular-nums">
                    Published Fixtures ({db.jaguars.fixtures2026.length})
                  </h4>
                  {db.jaguars.fixtures2026.length === 0 ? (
                    <div className="p-6 rounded-xl bg-slate-50 border border-slate-200 text-center text-[15px] text-slate-600">
                      No rugby fixtures scheduled yet. Use the form above to add official matches.
                    </div>
                  ) : (
                    db.jaguars.fixtures2026.map((fix) => (
                      <div
                        key={fix.id}
                        className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
                      >
                        <div>
                          <div className="font-bold text-base text-[#0c1a40]">
                            vs. {fix.opponent}
                          </div>
                          <div className="text-sm text-slate-600 mt-0.5">
                            {fix.date} · {fix.venue} · {fix.tournament} ({fix.status})
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            setConfirmAction({
                              title: 'Remove Rugby Fixture',
                              message: `Remove fixture vs. ${fix.opponent} (${fix.date})?`,
                              confirmLabel: 'Remove Fixture',
                              action: () =>
                                commitSection(
                                  'jaguars',
                                  {
                                    ...db.jaguars,
                                    fixtures2026: db.jaguars.fixtures2026.filter(
                                      (f) => f.id !== fix.id
                                    ),
                                  },
                                  'Fixture removed.'
                                ),
                            })
                          }
                          className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* TAB: DEPARTMENTS */}
            {activeTab === 'departments' && (
              <div className="space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
                  <div>
                    <h3 className="font-serif font-bold text-2xl text-[#0c1a40] tabular-nums">
                      Academic Departments ({db.departments.length} Fixed Institutional Departments)
                    </h3>
                    <p className="text-[15px] text-slate-600 mt-1">
                      Edit department overviews, curriculum notes, and Head of Department portraits & profiles.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
                    <div className="relative w-full sm:w-72">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={deptSearch}
                        onChange={(e) => setDeptSearch(e.target.value)}
                        placeholder="Filter departments, subjects or HOD..."
                        className="w-full pl-10 pr-8 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px]"
                      />
                      {deptSearch && (
                        <button
                          type="button"
                          onClick={() => setDeptSearch('')}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0c1a40] cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        void commitSection(
                          'departments',
                          db.departments,
                          'All academic departments saved live!'
                        )
                      }
                      className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-bold flex items-center gap-2 cursor-pointer"
                    >
                      <Save className="w-4 h-4 text-amber-400" />
                      <span>Save Departments</span>
                    </button>
                  </div>
                </div>

                {filteredDepartments.length === 0 ? (
                  <div className="p-10 text-center rounded-xl bg-white border border-slate-200 space-y-2">
                    <p className="font-semibold text-[#0c1a40]">
                      No departments match "{deptSearch}".
                    </p>
                    <button
                      type="button"
                      onClick={() => setDeptSearch('')}
                      className="px-4 py-2 rounded-lg bg-[#0c1a40] text-white text-sm font-semibold cursor-pointer"
                    >
                      Show All Departments ({db.departments.length})
                    </button>
                  </div>
                ) : (
                  filteredDepartments.map((dept) => {
                  const idx = db.departments.findIndex((d) => d.id === dept.id);
                  const hodStatus = getDepartmentHodStatus(dept, db.teachers);
                  return (
                    <div
                      key={dept.id}
                      className="p-5 sm:p-6 rounded-xl bg-white border border-slate-200 space-y-4"
                    >
                      {hodStatus.needsAttention && (
                        <div className="p-3.5 rounded-lg bg-amber-50 border border-amber-300 text-sm text-[#0c1a40] flex items-center gap-2.5">
                          <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                          <span>
                            <strong>HOD Assignment Notice:</strong> {hodStatus.reason} Update the Head of Department below or assign a teacher's Leadership Position to HOD in the Teachers tab.
                          </span>
                        </div>
                      )}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                        <div>
                          <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                            Department Name
                          </label>
                          <input
                            type="text"
                            value={dept.name}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = { ...dept, name: e.target.value };
                              setDb({ ...db, departments: next });
                            }}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-bold"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                            Curriculum Framework
                          </label>
                          <input
                            type="text"
                            value={dept.curriculum}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = { ...dept, curriculum: e.target.value };
                              setDb({ ...db, departments: next });
                            }}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                            Department Overview
                          </label>
                          <textarea
                            rows={2}
                            value={dept.shortDescription}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = { ...dept, shortDescription: e.target.value };
                              setDb({ ...db, departments: next });
                            }}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                            Subjects Offered (comma separated)
                          </label>
                          <input
                            type="text"
                            value={(dept.subjects || []).join(', ')}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = {
                                ...dept,
                                subjects: e.target.value
                                  .split(',')
                                  .map((s) => s.trim())
                                  .filter(Boolean),
                              };
                              setDb({ ...db, departments: next });
                            }}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                            Clubs & Co-Curricular Activities (one per line)
                          </label>
                          <textarea
                            rows={3}
                            value={(dept.activities || dept.features || []).join('\n')}
                            onChange={(e) => {
                              const next = [...db.departments];
                              const lines = e.target.value
                                .split('\n')
                                .map((s) => s.trim())
                                .filter(Boolean);
                              next[idx] = {
                                ...dept,
                                activities: lines,
                                features: lines,
                              };
                              setDb({ ...db, departments: next });
                            }}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                            Key Areas of Learning (one per line)
                          </label>
                          <textarea
                            rows={3}
                            value={(dept.keyAreas || []).join('\n')}
                            onChange={(e) => {
                              const next = [...db.departments];
                              const lines = e.target.value
                                .split('\n')
                                .map((s) => s.trim())
                                .filter(Boolean);
                              next[idx] = {
                                ...dept,
                                keyAreas: lines,
                              };
                              setDb({ ...db, departments: next });
                            }}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                            Facilities & Learning Resources (one per line)
                          </label>
                          <textarea
                            rows={3}
                            value={(dept.facilities || []).join('\n')}
                            onChange={(e) => {
                              const next = [...db.departments];
                              const lines = e.target.value
                                .split('\n')
                                .map((s) => s.trim())
                                .filter(Boolean);
                              next[idx] = {
                                ...dept,
                                facilities: lines,
                              };
                              setDb({ ...db, departments: next });
                            }}
                            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                      </div>

                      <div className="pt-4 border-t border-slate-200 space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <h4 className="font-serif font-bold text-lg text-[#0c1a40]">
                            Head of Department Profile
                          </h4>
                          <select
                            value={dept.headOfDepartment?.status || 'published'}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = {
                                ...dept,
                                headOfDepartment: {
                                  ...dept.headOfDepartment,
                                  status: e.target.value as PublishStatus,
                                },
                              };
                              setDb({ ...db, departments: next });
                            }}
                            className="px-3.5 py-2 rounded-lg bg-white border border-slate-300 text-sm font-semibold"
                          >
                            <option value="published">HOD Visible (Published)</option>
                            <option value="unpublished">HOD Hidden (Unpublished)</option>
                          </select>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <input
                            type="text"
                            value={dept.headOfDepartment?.name || ''}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = {
                                ...dept,
                                headOfDepartment: {
                                  ...dept.headOfDepartment,
                                  name: e.target.value,
                                },
                              };
                              setDb({ ...db, departments: next });
                            }}
                            placeholder="HOD Name"
                            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-semibold"
                          />
                          <input
                            type="text"
                            value={dept.headOfDepartment?.title || ''}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = {
                                ...dept,
                                headOfDepartment: {
                                  ...dept.headOfDepartment,
                                  title: e.target.value,
                                },
                              };
                              setDb({ ...db, departments: next });
                            }}
                            placeholder="HOD Designation"
                            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                          <input
                            type="text"
                            value={dept.headOfDepartment?.qualifications || ''}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = {
                                ...dept,
                                headOfDepartment: {
                                  ...dept.headOfDepartment,
                                  qualifications: e.target.value,
                                },
                              };
                              setDb({ ...db, departments: next });
                            }}
                            placeholder="Qualifications (if verified)"
                            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>

                        <PhotoUploadField
                          value={dept.headOfDepartment?.image || ''}
                          onChange={(url) => {
                            const next = [...db.departments];
                            next[idx] = {
                              ...dept,
                              headOfDepartment: {
                                ...dept.headOfDepartment,
                                image: url || undefined,
                              },
                            };
                            setDb({ ...db, departments: next });
                          }}
                          label="HOD Portrait"
                          category="Academics"
                          placeholderLabel="No Photo"
                        />

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <textarea
                            rows={2}
                            value={dept.headOfDepartment?.welcomeMessage || ''}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = {
                                ...dept,
                                headOfDepartment: {
                                  ...dept.headOfDepartment,
                                  welcomeMessage: e.target.value,
                                },
                              };
                              setDb({ ...db, departments: next });
                            }}
                            placeholder="HOD Welcome Message (optional)"
                            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                          <textarea
                            rows={2}
                            value={dept.headOfDepartment?.vision || ''}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = {
                                ...dept,
                                headOfDepartment: {
                                  ...dept.headOfDepartment,
                                  vision: e.target.value,
                                },
                              };
                              setDb({ ...db, departments: next });
                            }}
                            placeholder="Department Vision / Academic Goals (optional)"
                            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                          <textarea
                            rows={2}
                            value={dept.headOfDepartment?.bio || ''}
                            onChange={(e) => {
                              const next = [...db.departments];
                              next[idx] = {
                                ...dept,
                                headOfDepartment: {
                                  ...dept.headOfDepartment,
                                  bio: e.target.value,
                                },
                              };
                              setDb({ ...db, departments: next });
                            }}
                            placeholder="HOD Biography / Notes (optional)"
                            className="sm:col-span-2 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-200 flex justify-end">
                        <button
                          type="button"
                          onClick={() =>
                            void commitSection(
                              'departments',
                              db.departments,
                              `${dept.name} & HOD profile saved live!`
                            )
                          }
                          className="px-4 py-2 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-bold flex items-center gap-2 cursor-pointer"
                        >
                          <Save className="w-4 h-4 text-amber-400" />
                          <span>Save {dept.name}</span>
                        </button>
                      </div>
                    </div>
                  );
                }))}
              </div>
            )}

            {/* TAB: HEADS OF YEAR, A-LEVEL COORDINATOR, PASTORAL CARE & STAFF */}
            {activeTab === 'academic_leadership' && (
              <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6">
                <CmsAcademicLeadershipTab
                  currentUser={currentUser}
                  onNotify={showToast}
                  onRefreshSections={loadBootstrap}
                />
              </div>
            )}

            {/* TAB: TEACHERS DIRECTORY & PROFILES */}
            {activeTab === 'teachers' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
                  <div>
                    <h3 className="font-serif font-bold text-2xl text-[#0c1a40] tabular-nums">
                      Teacher Profiles ({db.teachers.length})
                    </h3>
                    <p className="text-[15px] text-slate-600 mt-1">
                      Add, search, edit, assign portrait photos, or remove any faculty profile.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2.5">
                    <div className="relative">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={teacherSearch}
                        onChange={(e) => {
                          setTeacherSearch(e.target.value);
                          setTeacherPage(1);
                        }}
                        placeholder="Search teachers by name, subject, role..."
                        className="pl-9 pr-8 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px]"
                      />
                      {teacherSearch && (
                        <button
                          type="button"
                          onClick={() => {
                            setTeacherSearch('');
                            setTeacherPage(1);
                          }}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0c1a40] cursor-pointer"
                          aria-label="Clear search"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    <select
                      value={teacherDeptFilter}
                      onChange={(e) => {
                        setTeacherDeptFilter(e.target.value);
                        setTeacherPage(1);
                      }}
                      className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px]"
                    >
                      <option value="all">All Departments ({db.teachers.length})</option>
                      {db.departments.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name} ({db.teachers.filter((t) => t.departmentId === d.id).length})
                        </option>
                      ))}
                    </select>
                    <select
                      value={teacherStatusFilter}
                      onChange={(e) => {
                        setTeacherStatusFilter(
                          e.target.value as 'all' | 'published' | 'archived' | 'unpublished'
                        );
                        setTeacherPage(1);
                      }}
                      className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px]"
                    >
                      <option value="all">All Statuses</option>
                      <option value="published">Published (Live)</option>
                      <option value="unpublished">Unpublished (Hidden)</option>
                      <option value="archived">Archived</option>
                    </select>
                    <label className="flex items-center gap-2 font-semibold text-sm cursor-pointer px-3.5 py-2.5 rounded-xl bg-amber-50 border border-amber-200">
                      <input
                        type="checkbox"
                        checked={teacherMissingOnly}
                        onChange={(e) => {
                          setTeacherMissingOnly(e.target.checked);
                          setTeacherPage(1);
                        }}
                        className="w-4 h-4 accent-[#0c1a40]"
                      />
                      <span className="tabular-nums">
                        Missing Portrait ({missingTeacherPortraitCount})
                      </span>
                    </label>
                  </div>
                </div>

                {/* Missing HOD Attention Notice */}
                {(() => {
                  const missingHodDepts = db.departments
                    .map((d) => ({ dept: d, status: getDepartmentHodStatus(d, db.teachers) }))
                    .filter((entry) => entry.status.needsAttention);
                  if (missingHodDepts.length === 0) return null;
                  return (
                    <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 text-sm text-[#0c1a40] space-y-1">
                      <div className="font-semibold flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                        <span>Department Head Verification Required ({missingHodDepts.length})</span>
                      </div>
                      <ul className="list-disc pl-6 text-xs text-slate-700 space-y-0.5">
                        {missingHodDepts.map(({ dept, status }) => (
                          <li key={dept.id}>
                            <strong>{dept.name}:</strong> {status.reason}
                          </li>
                        ))}
                      </ul>
                    </div>
                  );
                })()}

                {/* Add Teacher */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40] flex items-center gap-2">
                    <Plus className="w-5 h-5 text-amber-600" />
                    <span>Add New Teacher Profile</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    <input
                      type="text"
                      placeholder="Full Name (e.g. Mr K. Phiri) *"
                      value={newTeacher.name}
                      onChange={(e) => setNewTeacher({ ...newTeacher, name: e.target.value })}
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <select
                      value={newTeacher.departmentId}
                      onChange={(e) =>
                        setNewTeacher({ ...newTeacher, departmentId: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    >
                      {db.departments.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      placeholder="Role / Title (e.g. Subject Teacher)"
                      value={newTeacher.role}
                      onChange={(e) => setNewTeacher({ ...newTeacher, role: e.target.value })}
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <select
                      value={newTeacher.leadershipPosition || 'teacher'}
                      onChange={(e) =>
                        setNewTeacher({
                          ...newTeacher,
                          leadershipPosition: e.target.value as StaffLeadershipPosition,
                        })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    >
                      {(Object.keys(LEADERSHIP_POSITION_LABELS) as StaffLeadershipPosition[]).map(
                        (posKey) => (
                          <option key={posKey} value={posKey}>
                            {LEADERSHIP_POSITION_LABELS[posKey]}
                          </option>
                        )
                      )}
                    </select>
                    <input
                      type="number"
                      min={1}
                      placeholder="Display Order (optional, e.g. 1)"
                      value={newTeacher.order ?? ''}
                      onChange={(e) =>
                        setNewTeacher({
                          ...newTeacher,
                          order: e.target.value ? Number(e.target.value) : undefined,
                        })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                    />
                    <input
                      type="text"
                      placeholder="Subjects (comma separated)"
                      value={newTeacherSubjects}
                      onChange={(e) => setNewTeacherSubjects(e.target.value)}
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <div className="sm:col-span-2 lg:col-span-3">
                      <PhotoUploadField
                        value={newTeacher.image || ''}
                        onChange={(url) => setNewTeacher({ ...newTeacher, image: url })}
                        label="Teacher Portrait"
                        category="Academics"
                        placeholderLabel="No Photo"
                      />
                    </div>
                    <textarea
                      rows={2}
                      placeholder="Short Bio (optional)"
                      value={newTeacher.bio}
                      onChange={(e) => setNewTeacher({ ...newTeacher, bio: e.target.value })}
                      className="sm:col-span-2 lg:col-span-3 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (!newTeacher.name?.trim()) return;
                      const dept = db.departments.find((d) => d.id === newTeacher.departmentId);
                      const created: TeacherProfile = {
                        id: `t-${Date.now()}`,
                        name: newTeacher.name.trim(),
                        departmentId: newTeacher.departmentId || 'dept-maths',
                        departmentName: dept?.name || 'Academic Department',
                        role: newTeacher.role?.trim() || 'Teacher',
                        title: newTeacher.title || 'Mr/Ms',
                        subjects: newTeacherSubjects
                          .split(',')
                          .map((s) => s.trim())
                          .filter(Boolean),
                        image: newTeacher.image || undefined,
                        bio: newTeacher.bio || '',
                        leadershipPosition: newTeacher.leadershipPosition || 'teacher',
                        order: newTeacher.order,
                        status: 'published',
                      };
                      void commitSection(
                        'teachers',
                        sortTeachersForDirectory([created, ...db.teachers], db.departments),
                        'Teacher profile added!'
                      );
                      setNewTeacher({
                        name: '',
                        departmentId: 'dept-maths',
                        role: 'Teacher',
                        title: 'Mr',
                        bio: '',
                        image: '',
                        leadershipPosition: 'teacher',
                        order: undefined,
                      });
                      setNewTeacherSubjects('');
                    }}
                    className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
                  >
                    + Add Teacher
                  </button>
                </div>

                {/* Teachers List */}
                <div className="space-y-4">
                  {pagedTeachers.length === 0 ? (
                    <div className="p-10 rounded-xl bg-white border border-slate-200 text-center space-y-3">
                      <div className="font-serif font-bold text-lg text-[#0c1a40]">
                        No teachers match {teacherSearch ? `"${teacherSearch}"` : 'the active filters'}.
                      </div>
                      {teacherSearch.trim() && teachersMatchingQueryCount > 0 && (
                        <p className="text-sm text-amber-800 font-medium">
                          {teachersMatchingQueryCount} teacher(s) match "{teacherSearch}" across all departments/statuses.
                        </p>
                      )}
                      <div className="flex flex-wrap justify-center gap-2">
                        {teacherSearch.trim() && teachersMatchingQueryCount > 0 && (
                          <button
                            type="button"
                            onClick={() => {
                              setTeacherDeptFilter('all');
                              setTeacherStatusFilter('all');
                              setTeacherMissingOnly(false);
                              setTeacherPage(1);
                            }}
                            className="px-4 py-2 rounded-lg bg-[#0c1a40] text-white text-sm font-semibold cursor-pointer"
                          >
                            Search All Departments ({teachersMatchingQueryCount})
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            setTeacherSearch('');
                            setTeacherDeptFilter('all');
                            setTeacherStatusFilter('all');
                            setTeacherMissingOnly(false);
                            setTeacherPage(1);
                          }}
                          className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-sm font-semibold cursor-pointer"
                        >
                          Reset All Filters
                        </button>
                      </div>
                    </div>
                  ) : (
                    pagedTeachers.map((t) => {
                      const teacherStatus = t.status || 'published';
                      const teacherDept = db.departments.find((d) => d.id === t.departmentId);
                      const effectivePos = getTeacherLeadershipPosition(t, teacherDept);
                      return (
                      <div
                        key={t.id}
                        className={`p-5 rounded-xl border space-y-4 ${
                          teacherStatus === 'archived'
                            ? 'bg-slate-50 border-slate-300 opacity-85'
                            : 'bg-white border-slate-200'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div className="flex items-center gap-3.5">
                            {t.image ? (
                              <img
                                src={t.image}
                                alt={t.name}
                                onClick={() =>
                                  openImageViewer({
                                    src: t.image!,
                                    title: t.name,
                                    subtitle: `${t.departmentName} · ${t.role || 'Teacher'}`,
                                  })
                                }
                                className="w-14 h-16 rounded-xl object-cover object-top border border-amber-400 cursor-zoom-in shrink-0"
                              />
                            ) : (
                              <div className="w-14 h-16 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center font-serif font-bold text-lg text-[#0c1a40] shrink-0">
                                {t.name.split(' ').slice(-1)[0]?.[0] || 'L'}
                              </div>
                            )}
                            <div>
                              <div className="font-serif font-bold text-lg text-[#0c1a40] flex flex-wrap items-center gap-2">
                                <span>{t.name}</span>
                                {effectivePos === 'hod' && (
                                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-[#0c1a40] text-amber-300 uppercase">
                                    HOD · 1st
                                  </span>
                                )}
                                {effectivePos === 'deputy_hod' && (
                                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-blue-100 text-[#0c1a40] uppercase">
                                    Deputy HOD
                                  </span>
                                )}
                                {effectivePos === 'support' && (
                                  <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 uppercase">
                                    Support
                                  </span>
                                )}
                                {teacherStatus !== 'published' && (
                                  <span className="text-xs font-sans font-semibold px-2 py-0.5 rounded bg-slate-200 text-slate-700 capitalize">
                                    {teacherStatus}
                                  </span>
                                )}
                              </div>
                              <div className="text-sm font-medium text-amber-700">
                                {t.departmentName} · {t.role || 'Teacher'}
                              </div>
                            </div>
                          </div>
                          <div className="flex flex-wrap items-center gap-2">
                            <button
                              type="button"
                              onClick={async () => {
                                await commitSection(
                                  'teachers',
                                  db.teachers,
                                  `Saved profile for ${t.name}!`
                                );
                                // Also cross-sync HOD portrait if this teacher is HOD of their department
                                const matchingDept = db.departments.find(
                                  (d) =>
                                    d.id === t.departmentId &&
                                    normalizePersonName(d.headOfDepartment?.name) ===
                                      normalizePersonName(t.name)
                                );
                                if (matchingDept) {
                                  const nextDepts = db.departments.map((d) =>
                                    d.id === matchingDept.id
                                      ? {
                                          ...d,
                                          headOfDepartment: {
                                            ...d.headOfDepartment,
                                            image: t.image || undefined,
                                          },
                                        }
                                      : d
                                  );
                                  await commitSection(
                                    'departments',
                                    nextDepts,
                                    `Saved & synced ${t.name} profile + HOD card!`
                                  );
                                }
                              }}
                              className="px-3.5 py-2 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-bold flex items-center gap-1.5 cursor-pointer"
                            >
                              <Save className="w-4 h-4 text-amber-400" />
                              <span>Save Profile</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                const nextStatus: PublishStatus =
                                  teacherStatus === 'archived' ? 'published' : 'archived';
                                const nextTeachers = db.teachers.map((x) =>
                                  x.id === t.id ? { ...x, status: nextStatus } : x
                                );
                                void commitSection(
                                  'teachers',
                                  nextTeachers,
                                  `${t.name} ${nextStatus === 'archived' ? 'archived' : 'restored to live directory'}.`
                                );
                              }}
                              className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                              title={teacherStatus === 'archived' ? 'Restore teacher' : 'Archive teacher'}
                            >
                              {teacherStatus === 'archived' ? (
                                <>
                                  <RotateCcw className="w-4 h-4" />
                                  <span>Restore</span>
                                </>
                              ) : (
                                <>
                                  <Archive className="w-4 h-4" />
                                  <span>Archive</span>
                                </>
                              )}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setConfirmAction({
                                  title: 'Delete Teacher Profile',
                                  message: `Permanently delete teacher profile for "${t.name}"?`,
                                  confirmLabel: 'Delete Profile',
                                  action: () =>
                                    commitSection(
                                      'teachers',
                                      db.teachers.filter((x) => x.id !== t.id),
                                      `${t.name} removed.`
                                    ),
                                })
                              }
                              className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                              title="Delete teacher"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                          <div>
                            <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                              Full Name
                            </label>
                            <input
                              type="text"
                              value={t.name}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id ? { ...x, name: e.target.value } : x
                                  ),
                                })
                              }
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                              Honorific / Title (Mr / Mrs / Ms / Dr)
                            </label>
                            <input
                              type="text"
                              value={t.title || ''}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id ? { ...x, title: e.target.value } : x
                                  ),
                                })
                              }
                              placeholder="e.g. Mrs, Mr, Ms, Dr"
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                              Department Assignment
                            </label>
                            <select
                              value={t.departmentId}
                              onChange={(e) => {
                                const nextDeptId = e.target.value;
                                const targetDept = db.departments.find((d) => d.id === nextDeptId);
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id
                                      ? {
                                          ...x,
                                          departmentId: nextDeptId,
                                          departmentName: targetDept?.name || x.departmentName,
                                        }
                                      : x
                                  ),
                                });
                              }}
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            >
                              {db.departments.map((d) => (
                                <option key={d.id} value={d.id}>
                                  {d.name}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                              Visibility Status
                            </label>
                            <select
                              value={teacherStatus}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id
                                      ? { ...x, status: e.target.value as PublishStatus }
                                      : x
                                  ),
                                })
                              }
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            >
                              <option value="published">Published (Live)</option>
                              <option value="unpublished">Unpublished (Hidden)</option>
                              <option value="archived">Archived</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                              Leadership Position (Hierarchy)
                            </label>
                            <select
                              value={effectivePos}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id
                                      ? {
                                          ...x,
                                          leadershipPosition: e.target.value as StaffLeadershipPosition,
                                        }
                                      : x
                                  ),
                                })
                              }
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            >
                              {(Object.keys(LEADERSHIP_POSITION_LABELS) as StaffLeadershipPosition[]).map(
                                (posKey) => (
                                  <option key={posKey} value={posKey}>
                                    {LEADERSHIP_POSITION_LABELS[posKey]}
                                  </option>
                                )
                              )}
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                              Display Priority (Order)
                            </label>
                            <input
                              type="number"
                              min={1}
                              value={t.order ?? ''}
                              placeholder="Auto (within role)"
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id
                                      ? {
                                          ...x,
                                          order: e.target.value ? Number(e.target.value) : undefined,
                                        }
                                      : x
                                  ),
                                })
                              }
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                              Designation / Role
                            </label>
                            <input
                              type="text"
                              value={t.role || ''}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id ? { ...x, role: e.target.value } : x
                                  ),
                                })
                              }
                              placeholder="Designation (e.g. Senior Mathematics Teacher)"
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                              Qualifications (optional)
                            </label>
                            <input
                              type="text"
                              value={t.qualifications || ''}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id ? { ...x, qualifications: e.target.value } : x
                                  ),
                                })
                              }
                              placeholder="Academic qualifications (optional)"
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                          <div className="sm:col-span-2 lg:col-span-3">
                            <PhotoUploadField
                              value={t.image || ''}
                              onChange={(url) =>
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id ? { ...x, image: url || undefined } : x
                                  ),
                                })
                              }
                              label="Teacher Portrait"
                              category="Academics"
                              placeholderLabel="No Photo"
                            />
                          </div>
                          <div className="sm:col-span-2 lg:col-span-3">
                            <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                              Subjects Taught (comma separated)
                            </label>
                            <input
                              type="text"
                              value={(t.subjects || []).join(', ')}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id
                                      ? {
                                          ...x,
                                          subjects: e.target.value
                                            .split(',')
                                            .map((s) => s.trim())
                                            .filter(Boolean),
                                        }
                                      : x
                                  ),
                                })
                              }
                              placeholder="Subjects (comma separated)"
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                          <div className="sm:col-span-2 lg:col-span-3">
                            <label className="block text-sm font-semibold text-[#0c1a40] mb-1">
                              Profile Biography
                            </label>
                            <textarea
                              rows={2}
                              value={t.bio || ''}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  teachers: db.teachers.map((x) =>
                                    x.id === t.id ? { ...x, bio: e.target.value } : x
                                  ),
                                })
                              }
                              placeholder="Short teacher biography..."
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                        </div>
                      </div>
                    );
                    })
                  )}
                </div>

                {totalTeacherPages > 1 && (
                  <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-sm">
                    <span className="text-slate-600 tabular-nums">
                      Page {safeTeacherPage} of {totalTeacherPages} · {filteredTeachers.length}{' '}
                      teachers
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={safeTeacherPage <= 1}
                        onClick={() => setTeacherPage((p) => Math.max(1, p - 1))}
                        className="px-3.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer font-semibold"
                      >
                        Previous
                      </button>
                      <button
                        type="button"
                        disabled={safeTeacherPage >= totalTeacherPages}
                        onClick={() => setTeacherPage((p) => Math.min(totalTeacherPages, p + 1))}
                        className="px-3.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer font-semibold"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB: CURRICULUM */}
            {activeTab === 'curriculum' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                    Cambridge Curriculum Explorer
                  </h3>
                  <p className="text-[15px] text-slate-600 mt-1">
                    Manage academic stage descriptions and subject codes across Key Stage 3, IGCSE, AS, and A2 levels.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2">
                  {Object.keys(db.curriculum).map((k) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => setSelectedCurrKey(k)}
                      className={`px-4 py-2.5 rounded-xl text-[15px] font-semibold capitalize cursor-pointer ${
                        selectedCurrKey === k
                          ? 'bg-[#0c1a40] text-amber-400 font-bold'
                          : 'bg-white text-[#0c1a40] border border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      {k.replace('-', ' ')}
                    </button>
                  ))}
                </div>

                {db.curriculum[selectedCurrKey] && (
                  <div className="space-y-5">
                    <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-semibold text-[15px] mb-1.5">
                          Stage Title
                        </label>
                        <input
                          type="text"
                          value={db.curriculum[selectedCurrKey].title}
                          onChange={(e) =>
                            setDb({
                              ...db,
                              curriculum: {
                                ...db.curriculum,
                                [selectedCurrKey]: {
                                  ...db.curriculum[selectedCurrKey],
                                  title: e.target.value,
                                },
                              },
                            })
                          }
                          className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-bold"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-[15px] mb-1.5">Subtitle</label>
                        <input
                          type="text"
                          value={db.curriculum[selectedCurrKey].subtitle}
                          onChange={(e) =>
                            setDb({
                              ...db,
                              curriculum: {
                                ...db.curriculum,
                                [selectedCurrKey]: {
                                  ...db.curriculum[selectedCurrKey],
                                  subtitle: e.target.value,
                                },
                              },
                            })
                          }
                          className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block font-semibold text-[15px] mb-1.5">
                          Description
                        </label>
                        <textarea
                          rows={2}
                          value={db.curriculum[selectedCurrKey].description}
                          onChange={(e) =>
                            setDb({
                              ...db,
                              curriculum: {
                                ...db.curriculum,
                                [selectedCurrKey]: {
                                  ...db.curriculum[selectedCurrKey],
                                  description: e.target.value,
                                },
                              },
                            })
                          }
                          className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                      </div>
                    </div>

                    <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                      <h4 className="font-serif font-bold text-lg text-[#0c1a40] flex items-center gap-2">
                        <Plus className="w-5 h-5 text-amber-600" />
                        <span>Add Subject to {selectedCurrKey}</span>
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                        <input
                          type="text"
                          placeholder="Code (e.g. IG-0500)"
                          value={newSubject.code}
                          onChange={(e) => setNewSubject({ ...newSubject, code: e.target.value })}
                          className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                        <input
                          type="text"
                          placeholder="Subject Name *"
                          value={newSubject.name}
                          onChange={(e) => setNewSubject({ ...newSubject, name: e.target.value })}
                          className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        />
                        <select
                          value={newSubject.stream}
                          onChange={(e) =>
                            setNewSubject({
                              ...newSubject,
                              stream: e.target.value as CurriculumSubject['stream'],
                            })
                          }
                          className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                        >
                          <option value="Sciences">Sciences</option>
                          <option value="Commercial">Commercial</option>
                          <option value="Humanities">Humanities</option>
                          <option value="Languages">Languages</option>
                          <option value="Creative & Tech">Creative & Tech</option>
                          <option value="Early Years">Early Years</option>
                        </select>
                        <button
                          type="button"
                          onClick={() => {
                            if (!newSubject.name.trim()) return;
                            const levelObj = db.curriculum[selectedCurrKey];
                            const nextCurr = {
                              ...db.curriculum,
                              [selectedCurrKey]: {
                                ...levelObj,
                                subjects: [
                                  ...levelObj.subjects,
                                  {
                                    ...newSubject,
                                    code:
                                      newSubject.code || `SUB-${Date.now().toString().slice(-3)}`,
                                  },
                                ],
                              },
                            };
                            void commitSection(
                              'curriculum',
                              nextCurr,
                              'Subject added to curriculum!'
                            );
                            setNewSubject({
                              code: '',
                              name: '',
                              stream: 'Sciences',
                              description: '',
                              cambridgeCode: '',
                              isCore: false,
                            });
                          }}
                          className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
                        >
                          + Add Subject
                        </button>
                      </div>

                      <div className="space-y-2.5 pt-2">
                        {db.curriculum[selectedCurrKey].subjects.map((sub, idx) => (
                          <div
                            key={sub.code + idx}
                            className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
                          >
                            <div>
                              <div className="font-bold text-base text-[#0c1a40]">{sub.name}</div>
                              <div className="text-sm text-amber-700 font-mono">
                                {sub.code} · {sub.stream}
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() =>
                                setConfirmAction({
                                  title: 'Remove Subject',
                                  message: `Remove "${sub.name}" (${sub.code}) from ${selectedCurrKey}?`,
                                  confirmLabel: 'Remove Subject',
                                  action: () => {
                                    const levelObj = db.curriculum[selectedCurrKey];
                                    return commitSection(
                                      'curriculum',
                                      {
                                        ...db.curriculum,
                                        [selectedCurrKey]: {
                                          ...levelObj,
                                          subjects: levelObj.subjects.filter((_, i) => i !== idx),
                                        },
                                      },
                                      'Subject removed.'
                                    );
                                  },
                                })
                              }
                              className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB: FEES & BANKING */}
            {activeTab === 'fees' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                    Tuition Structure, Fee Policy PDF & Bank Accounts
                  </h3>
                  <p className="text-[15px] text-slate-600 mt-1">
                    Update academic fee bands, boarding tariffs, one-off levies, official Fee Policy PDF document, and college bank accounts.
                  </p>
                </div>

                {/* Official Fee Policy Document & General Rates */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Academic Year
                      </label>
                      <input
                        type="text"
                        value={db.fees.structure.academicYear}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: { ...db.fees.structure, academicYear: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Boarding Annual (P)
                      </label>
                      <input
                        type="number"
                        value={db.fees.structure.boardingSchedule.annual}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                boardingSchedule: {
                                  ...db.fees.structure.boardingSchedule,
                                  annual: Number(e.target.value) || 0,
                                },
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Annual Discount (%)
                      </label>
                      <input
                        type="number"
                        step="0.5"
                        value={db.fees.structure.annualDiscountPercentage}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                annualDiscountPercentage: Number(e.target.value) || 0,
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Sibling Discount (%)
                      </label>
                      <input
                        type="number"
                        step="0.5"
                        value={db.fees.structure.siblingDiscountPercentage}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                siblingDiscountPercentage: Number(e.target.value) || 0,
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
                      />
                    </div>
                  </div>

                  {/* Fee Policy PDF Upload / Replacement */}
                  <div className="pt-4 border-t border-slate-200 space-y-2.5">
                    <label className="block font-semibold text-[15px] text-[#0c1a40]">
                      Official School Fees Policy PDF Document
                    </label>
                    <div className="flex flex-wrap items-center gap-3">
                      <input
                        type="text"
                        value={db.fees.structure.pdfDocumentUrl}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: { ...db.fees.structure, pdfDocumentUrl: e.target.value },
                            },
                          })
                        }
                        placeholder="/uploads/... or ./assets/...pdf"
                        className="flex-1 min-w-[240px] px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-sm font-mono"
                      />
                      <label className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-semibold flex items-center gap-2 cursor-pointer">
                        <Upload className="w-4 h-4 text-amber-400" />
                        <span>{feePdfUploading ? 'Uploading PDF...' : 'Upload / Replace PDF'}</span>
                        <input
                          type="file"
                          accept=".pdf,application/pdf"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            setFeePdfUploading(true);
                            try {
                              const uploaded = await uploadMediaFile(file, {
                                name: file.name.replace(/\.[^.]+$/, ''),
                                category: 'Fee Policies & Documents',
                              });
                              setDb((prev) => ({
                                ...prev,
                                fees: {
                                  ...prev.fees,
                                  structure: { ...prev.fees.structure, pdfDocumentUrl: uploaded.url },
                                },
                              }));
                              showToast('Fee Policy PDF uploaded! Click Save Changes Live to publish.');
                            } catch (err) {
                              setErrorNotice(
                                err instanceof Error ? err.message : 'PDF upload failed.'
                              );
                            } finally {
                              setFeePdfUploading(false);
                              e.target.value = '';
                            }
                          }}
                        />
                      </label>
                      {db.fees.structure.pdfDocumentUrl && (
                        <a
                          href={db.fees.structure.pdfDocumentUrl}
                          download="LKC_School_Fees_Policy.pdf"
                          className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-[15px] font-semibold flex items-center gap-1.5"
                        >
                          <FileText className="w-4 h-4" />
                          <span>Download Current PDF</span>
                        </a>
                      )}
                    </div>
                  </div>
                </div>

                {/* Boarding Term Schedule & One-Off Fees */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-5">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40]">
                    One-Off Admissions Levies & Boarding Term Breakdown (BWP)
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                    <div>
                      <label className="block text-sm font-semibold mb-1">Entrance Assessment (P)</label>
                      <input
                        type="number"
                        value={db.fees.structure.oneOffFees.entranceAssessment}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                oneOffFees: {
                                  ...db.fees.structure.oneOffFees,
                                  entranceAssessment: Number(e.target.value) || 0,
                                },
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-mono tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-1">Registration Fee (P)</label>
                      <input
                        type="number"
                        value={db.fees.structure.oneOffFees.registrationEnrollment}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                oneOffFees: {
                                  ...db.fees.structure.oneOffFees,
                                  registrationEnrollment: Number(e.target.value) || 0,
                                },
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-mono tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-1">Dev. Levy Forms 1–5 (P)</label>
                      <input
                        type="number"
                        value={db.fees.structure.oneOffFees.developmentLevyForms1to5}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                oneOffFees: {
                                  ...db.fees.structure.oneOffFees,
                                  developmentLevyForms1to5: Number(e.target.value) || 0,
                                },
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-mono tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-1">Dev. Levy A-Level (P)</label>
                      <input
                        type="number"
                        value={db.fees.structure.oneOffFees.developmentLevyALevel}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                oneOffFees: {
                                  ...db.fees.structure.oneOffFees,
                                  developmentLevyALevel: Number(e.target.value) || 0,
                                },
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-mono tabular-nums"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-3 border-t border-slate-200">
                    <div>
                      <label className="block text-sm font-semibold mb-1">Boarding Term 1 (P)</label>
                      <input
                        type="number"
                        value={db.fees.structure.boardingSchedule.term1}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                boardingSchedule: {
                                  ...db.fees.structure.boardingSchedule,
                                  term1: Number(e.target.value) || 0,
                                },
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-mono tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-1">Boarding Term 2 (P)</label>
                      <input
                        type="number"
                        value={db.fees.structure.boardingSchedule.term2}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                boardingSchedule: {
                                  ...db.fees.structure.boardingSchedule,
                                  term2: Number(e.target.value) || 0,
                                },
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-mono tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-1">Boarding Term 3 (P)</label>
                      <input
                        type="number"
                        value={db.fees.structure.boardingSchedule.term3}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                boardingSchedule: {
                                  ...db.fees.structure.boardingSchedule,
                                  term3: Number(e.target.value) || 0,
                                },
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-mono tabular-nums"
                      />
                    </div>
                  </div>
                </div>

                {/* Tuition Bands */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-3">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40]">
                    Tuition Bands (Label · Per Term BWP · Annual BWP)
                  </h4>
                  {Object.entries(db.fees.structure.tuitionPerTerm).map(([key, band]) => (
                    <div
                      key={key}
                      className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3"
                    >
                      <input
                        type="text"
                        value={band.label}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                tuitionPerTerm: {
                                  ...db.fees.structure.tuitionPerTerm,
                                  [key]: { ...band, label: e.target.value },
                                },
                              },
                            },
                          })
                        }
                        className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-semibold"
                      />
                      <input
                        type="number"
                        value={band.term}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                tuitionPerTerm: {
                                  ...db.fees.structure.tuitionPerTerm,
                                  [key]: { ...band, term: Number(e.target.value) || 0 },
                                },
                              },
                            },
                          })
                        }
                        className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-mono tabular-nums"
                      />
                      <input
                        type="number"
                        value={band.annual}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            fees: {
                              ...db.fees,
                              structure: {
                                ...db.fees.structure,
                                tuitionPerTerm: {
                                  ...db.fees.structure.tuitionPerTerm,
                                  [key]: { ...band, annual: Number(e.target.value) || 0 },
                                },
                              },
                            },
                          })
                        }
                        className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-mono tabular-nums"
                      />
                    </div>
                  ))}
                </div>

                {/* Official Bank Accounts Editor */}
                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <h4 className="font-serif font-bold text-lg text-[#0c1a40]">
                      Official College Bank Accounts ({(db.fees.bankAccounts || []).length})
                    </h4>
                    <button
                      type="button"
                      onClick={() =>
                        setDb({
                          ...db,
                          fees: {
                            ...db.fees,
                            bankAccounts: [
                              ...(db.fees.bankAccounts || []),
                              {
                                bankName: 'New Bank Account',
                                accountName: 'Lavender Projects (Pty) Ltd',
                                accountNumber: '',
                                branch: 'Gaborone',
                                branchCode: '',
                                swiftCode: '',
                              },
                            ],
                          },
                        })
                      }
                      className="px-3.5 py-2 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-4 h-4 text-amber-400" />
                      <span>Add Bank Account</span>
                    </button>
                  </div>
                  <div className="space-y-3">
                    {(db.fees.bankAccounts || []).map((acc, idx) => (
                      <div
                        key={idx}
                        className="p-4 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3 items-end"
                      >
                        <div>
                          <label className="block text-sm font-semibold mb-1">Bank Name</label>
                          <input
                            type="text"
                            value={acc.bankName}
                            onChange={(e) => {
                              const next = [...db.fees.bankAccounts];
                              next[idx] = { ...acc, bankName: e.target.value };
                              setDb({ ...db, fees: { ...db.fees, bankAccounts: next } });
                            }}
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold mb-1">Account Name</label>
                          <input
                            type="text"
                            value={acc.accountName}
                            onChange={(e) => {
                              const next = [...db.fees.bankAccounts];
                              next[idx] = { ...acc, accountName: e.target.value };
                              setDb({ ...db, fees: { ...db.fees, bankAccounts: next } });
                            }}
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold mb-1">Account Number</label>
                          <input
                            type="text"
                            value={acc.accountNumber}
                            onChange={(e) => {
                              const next = [...db.fees.bankAccounts];
                              next[idx] = { ...acc, accountNumber: e.target.value };
                              setDb({ ...db, fees: { ...db.fees, bankAccounts: next } });
                            }}
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-[15px] font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold mb-1">Branch</label>
                          <input
                            type="text"
                            value={acc.branch}
                            onChange={(e) => {
                              const next = [...db.fees.bankAccounts];
                              next[idx] = { ...acc, branch: e.target.value };
                              setDb({ ...db, fees: { ...db.fees, bankAccounts: next } });
                            }}
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-[15px]"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold mb-1">Branch Code / SWIFT</label>
                          <input
                            type="text"
                            value={acc.swiftCode || acc.branchCode || ''}
                            onChange={(e) => {
                              const next = [...db.fees.bankAccounts];
                              next[idx] = { ...acc, swiftCode: e.target.value };
                              setDb({ ...db, fees: { ...db.fees, bankAccounts: next } });
                            }}
                            className="w-full px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-[15px] font-mono"
                          />
                        </div>
                        <div className="flex justify-end">
                          <button
                            type="button"
                            onClick={() => {
                              const next = db.fees.bankAccounts.filter((_, i) => i !== idx);
                              setDb({ ...db, fees: { ...db.fees, bankAccounts: next } });
                            }}
                            className="px-3 py-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                            <span>Remove</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB: CALENDAR */}
            {activeTab === 'calendar' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                    2026 Academic Term Calendar
                  </h3>
                  <p className="text-[15px] text-slate-600 mt-1">
                    Update term titles, opening dates, closing dates, and mid-term breaks.
                  </p>
                </div>

                <div className="space-y-4">
                  {db.calendar.map((term, idx) => (
                    <div
                      key={term.term + idx}
                      className="p-5 rounded-xl bg-white border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-3.5"
                    >
                      <input
                        type="text"
                        value={term.term}
                        onChange={(e) => {
                          const next = [...db.calendar];
                          next[idx] = { ...term, term: e.target.value };
                          setDb({ ...db, calendar: next });
                        }}
                        className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-bold"
                      />
                      <input
                        type="text"
                        value={term.title}
                        onChange={(e) => {
                          const next = [...db.calendar];
                          next[idx] = { ...term, title: e.target.value };
                          setDb({ ...db, calendar: next });
                        }}
                        className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                      <input
                        type="text"
                        value={term.start}
                        onChange={(e) => {
                          const next = [...db.calendar];
                          next[idx] = { ...term, start: e.target.value };
                          setDb({ ...db, calendar: next });
                        }}
                        className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                      <input
                        type="text"
                        value={term.end}
                        onChange={(e) => {
                          const next = [...db.calendar];
                          next[idx] = { ...term, end: e.target.value };
                          setDb({ ...db, calendar: next });
                        }}
                        className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                      <input
                        type="text"
                        value={term.midTermBreak}
                        onChange={(e) => {
                          const next = [...db.calendar];
                          next[idx] = { ...term, midTermBreak: e.target.value };
                          setDb({ ...db, calendar: next });
                        }}
                        placeholder="Mid-Term Break"
                        className="sm:col-span-2 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: FAQS */}
            {activeTab === 'faqs' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <h3 className="font-serif font-bold text-2xl text-[#0c1a40] tabular-nums">
                    Frequently Asked Questions ({db.faqs.length})
                  </h3>
                  <p className="text-[15px] text-slate-600 mt-1">
                    Add, edit, or delete admissions and school policy FAQ entries.
                  </p>
                </div>

                <div className="p-5 sm:p-6 rounded-xl bg-white border border-slate-200 space-y-3">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40]">Add New FAQ</h4>
                  <input
                    type="text"
                    placeholder="New FAQ Question *"
                    value={newFaq.q}
                    onChange={(e) => setNewFaq({ ...newFaq, q: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                  />
                  <textarea
                    rows={2}
                    placeholder="Answer *"
                    value={newFaq.a}
                    onChange={(e) => setNewFaq({ ...newFaq, a: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!newFaq.q.trim()) return;
                      void commitSection('faqs', [...db.faqs, { ...newFaq }], 'FAQ item added!');
                      setNewFaq({ q: '', a: '' });
                    }}
                    className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
                  >
                    + Add FAQ
                  </button>
                </div>

                <div className="space-y-4">
                  {db.faqs.map((faq, idx) => (
                    <div
                      key={idx}
                      className="p-5 rounded-xl bg-white border border-slate-200 space-y-3"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <input
                          type="text"
                          value={faq.q}
                          onChange={(e) => {
                            const next = [...db.faqs];
                            next[idx] = { ...faq, q: e.target.value };
                            setDb({ ...db, faqs: next });
                          }}
                          className="flex-1 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] font-semibold"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setConfirmAction({
                              title: 'Delete FAQ Item',
                              message: `Remove question "${faq.q}"?`,
                              confirmLabel: 'Delete FAQ',
                              action: () =>
                                commitSection(
                                  'faqs',
                                  db.faqs.filter((_, i) => i !== idx),
                                  'FAQ deleted.'
                                ),
                            })
                          }
                          className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <textarea
                        rows={2}
                        value={faq.a}
                        onChange={(e) => {
                          const next = [...db.faqs];
                          next[idx] = { ...faq, a: e.target.value };
                          setDb({ ...db, faqs: next });
                        }}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: GENERAL & CONTACTS */}
            {activeTab === 'general' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
                    General Institutional Info, Contacts & Social Channels
                  </h3>
                  <p className="text-[15px] text-slate-600 mt-1">
                    Manage official college phone lines, email addresses, Cambridge centre designation, and social URLs.
                  </p>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-5">
                  <PhotoUploadField
                    value={db.general.logoUrl || ''}
                    onChange={(url) =>
                      setDb({
                        ...db,
                        general: { ...db.general, logoUrl: url || './assets/aistudio/logo_33a39ff7.png' },
                      })
                    }
                    label="Official College Crest / Logo"
                    category="Branding & Logos"
                    placeholderLabel="LKC Crest"
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Institution Name
                      </label>
                      <input
                        type="text"
                        value={db.general.name}
                        onChange={(e) =>
                          setDb({ ...db, general: { ...db.general, name: e.target.value } })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Centre Designation
                      </label>
                      <input
                        type="text"
                        value={db.general.cambridgeCentreNo}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: { ...db.general, cambridgeCentreNo: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Primary Switchboard Phone
                      </label>
                      <input
                        type="text"
                        value={db.general.contacts.phone}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: {
                              ...db.general,
                              contacts: { ...db.general.contacts, phone: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Official WhatsApp
                      </label>
                      <input
                        type="text"
                        value={db.general.contacts.whatsapp}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: {
                              ...db.general,
                              contacts: { ...db.general.contacts, whatsapp: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Principal Email
                      </label>
                      <input
                        type="email"
                        value={db.general.contacts.principalEmail}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: {
                              ...db.general,
                              contacts: { ...db.general.contacts, principalEmail: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Admissions Email
                      </label>
                      <input
                        type="email"
                        value={db.general.contacts.admissionsEmail}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: {
                              ...db.general,
                              contacts: {
                                ...db.general.contacts,
                                admissionsEmail: e.target.value,
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Accounts Email
                      </label>
                      <input
                        type="email"
                        value={db.general.contacts.accountsEmail}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: {
                              ...db.general,
                              contacts: {
                                ...db.general.contacts,
                                accountsEmail: e.target.value,
                              },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Office Hours
                      </label>
                      <input
                        type="text"
                        value={db.general.contacts.officeHours}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: {
                              ...db.general,
                              contacts: { ...db.general.contacts, officeHours: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Campus Plot & Street
                      </label>
                      <input
                        type="text"
                        value={db.general.address.plot}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: {
                              ...db.general,
                              address: { ...db.general.address, plot: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Postal Box & City
                      </label>
                      <input
                        type="text"
                        value={db.general.address.postalBox}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: {
                              ...db.general,
                              address: { ...db.general.address, postalBox: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Admissions Portal URL
                      </label>
                      <input
                        type="text"
                        value={db.general.admissionsPortalUrl}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: { ...db.general, admissionsPortalUrl: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">
                        Google Maps Directions URL
                      </label>
                      <input
                        type="text"
                        value={db.general.googleMapsDirectionsUrl}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: { ...db.general, googleMapsDirectionsUrl: e.target.value },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">Instagram URL</label>
                      <input
                        type="text"
                        value={db.general.socials.instagram}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: {
                              ...db.general,
                              socials: { ...db.general.socials, instagram: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[15px] mb-1.5">TikTok URL</label>
                      <input
                        type="text"
                        value={db.general.socials.tiktok}
                        onChange={(e) =>
                          setDb({
                            ...db,
                            general: {
                              ...db.general,
                              socials: { ...db.general.socials, tiktok: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: ANNOUNCEMENTS */}
            {activeTab === 'announcements' && (
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <h3 className="font-serif font-bold text-2xl text-[#0c1a40] tabular-nums">
                    Campus Announcements ({db.announcements.length})
                  </h3>
                  <p className="text-[15px] text-slate-600 mt-1">
                    Publish official school notices with optional photography, toggle visibility, or edit active announcements.
                  </p>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40]">
                    Publish New Announcement
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <input
                      type="text"
                      placeholder="Announcement Headline *"
                      value={newAnnouncement.title}
                      onChange={(e) =>
                        setNewAnnouncement({ ...newAnnouncement, title: e.target.value })
                      }
                      className="sm:col-span-2 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    />
                    <select
                      value={newAnnouncement.category}
                      onChange={(e) =>
                        setNewAnnouncement({ ...newAnnouncement, category: e.target.value })
                      }
                      className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                    >
                      <option value="General Notice">General Notice</option>
                      <option value="Admissions">Admissions</option>
                      <option value="Academic Honors">Academic Honors</option>
                      <option value="Excursions">Excursions</option>
                      <option value="Jaguars Rugby">Jaguars Rugby</option>
                    </select>
                  </div>
                  <PhotoUploadField
                    aspect="banner"
                    value={newAnnouncement.thumbnailUrl}
                    onChange={(url) =>
                      setNewAnnouncement({ ...newAnnouncement, thumbnailUrl: url })
                    }
                    label="Announcement Thumbnail (Optional)"
                    category="Campus & Facilities"
                    placeholderLabel="No Image"
                  />
                  <textarea
                    rows={3}
                    placeholder="Details..."
                    value={newAnnouncement.body}
                    onChange={(e) =>
                      setNewAnnouncement({ ...newAnnouncement, body: e.target.value })
                    }
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!newAnnouncement.title.trim()) return;
                      void commitSection(
                        'announcements',
                        [
                          {
                            id: `ann-${Date.now()}`,
                            title: newAnnouncement.title.trim(),
                            category: newAnnouncement.category,
                            body: newAnnouncement.body.trim(),
                            thumbnailUrl: newAnnouncement.thumbnailUrl || undefined,
                            date: new Date().toLocaleDateString('en-GB', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric',
                            }),
                            active: true,
                          },
                          ...db.announcements,
                        ],
                        'Announcement published!'
                      );
                      setNewAnnouncement({
                        title: '',
                        category: 'General Notice',
                        body: '',
                        thumbnailUrl: '',
                      });
                    }}
                    className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
                  >
                    + Publish Notice
                  </button>
                </div>

                <div className="space-y-4">
                  {db.announcements.map((ann) => {
                    const isEditing = editingAnnouncementId === ann.id;
                    return (
                      <div
                        key={ann.id}
                        className="p-5 rounded-xl bg-white border border-slate-200 space-y-4"
                      >
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div className="flex items-start gap-4 min-w-0">
                            {ann.thumbnailUrl && (
                              <img
                                src={ann.thumbnailUrl}
                                alt={ann.title}
                                className="w-20 h-16 rounded-lg object-cover border border-slate-200 shrink-0"
                              />
                            )}
                            <div>
                              <div className="text-sm font-semibold text-amber-700">
                                {ann.category} · {ann.date} ·{' '}
                                <span
                                  className={ann.active ? 'text-emerald-700' : 'text-slate-500'}
                                >
                                  {ann.active ? 'Active' : 'Hidden'}
                                </span>
                              </div>
                              <div className="font-serif font-bold text-lg text-[#0c1a40] mt-0.5">
                                {ann.title}
                              </div>
                              <div className="text-[15px] text-slate-700 mt-1">{ann.body}</div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={() =>
                                setEditingAnnouncementId(isEditing ? null : ann.id)
                              }
                              className="px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                            >
                              <Edit3 className="w-4 h-4" />
                              <span>{isEditing ? 'Done Editing' : 'Edit'}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                void commitSection(
                                  'announcements',
                                  db.announcements.map((a) =>
                                    a.id === ann.id ? { ...a, active: !a.active } : a
                                  ),
                                  `Announcement ${ann.active ? 'hidden' : 'activated'}.`
                                )
                              }
                              className="px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-sm font-semibold cursor-pointer"
                            >
                              {ann.active ? 'Hide' : 'Activate'}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setConfirmAction({
                                  title: 'Delete Announcement',
                                  message: `Permanently delete announcement "${ann.title}"?`,
                                  confirmLabel: 'Delete Notice',
                                  action: () =>
                                    commitSection(
                                      'announcements',
                                      db.announcements.filter((a) => a.id !== ann.id),
                                      'Announcement deleted.'
                                    ),
                                })
                              }
                              className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {isEditing && (
                          <div className="pt-4 border-t border-slate-200 space-y-3">
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                              <input
                                type="text"
                                value={ann.title}
                                onChange={(e) =>
                                  setDb({
                                    ...db,
                                    announcements: db.announcements.map((a) =>
                                      a.id === ann.id ? { ...a, title: e.target.value } : a
                                    ),
                                  })
                                }
                                className="sm:col-span-2 px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                              />
                              <select
                                value={ann.category}
                                onChange={(e) =>
                                  setDb({
                                    ...db,
                                    announcements: db.announcements.map((a) =>
                                      a.id === ann.id ? { ...a, category: e.target.value } : a
                                    ),
                                  })
                                }
                                className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                              >
                                <option value="General Notice">General Notice</option>
                                <option value="Admissions">Admissions</option>
                                <option value="Academic Honors">Academic Honors</option>
                                <option value="Excursions">Excursions</option>
                                <option value="Jaguars Rugby">Jaguars Rugby</option>
                              </select>
                            </div>
                            <PhotoUploadField
                              aspect="banner"
                              value={ann.thumbnailUrl || ''}
                              onChange={(url) =>
                                setDb({
                                  ...db,
                                  announcements: db.announcements.map((a) =>
                                    a.id === ann.id
                                      ? { ...a, thumbnailUrl: url || undefined }
                                      : a
                                  ),
                                })
                              }
                              label="Announcement Image"
                              category="Campus & Facilities"
                              placeholderLabel="No Image"
                            />
                            <textarea
                              rows={3}
                              value={ann.body}
                              onChange={(e) =>
                                setDb({
                                  ...db,
                                  announcements: db.announcements.map((a) =>
                                    a.id === ann.id ? { ...a, body: e.target.value } : a
                                  ),
                                })
                              }
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                            />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB: ATHLETICS (TRACK & FIELD) */}
            {activeTab === 'athletics' && (
              <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6">
                <CmsAthleticsTab
                  athletics={db.athletics}
                  onSave={async (next) => {
                    await commitSection('athletics', next, 'Athletics page & school records saved live!');
                  }}
                />
              </div>
            )}

            {/* TAB: MEDIA ASSETS */}
            {activeTab === 'media' && (
              <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6">
                <CmsMediaLibraryTab
                  media={db.media}
                  currentUser={currentUser}
                  onRefresh={loadBootstrap}
                  onNotify={showToast}
                />
              </div>
            )}

            {/* TAB: NAVIGATION, FOOTER & SETTINGS */}
            {activeTab === 'nav_settings' && (
              <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6">
                <CmsNavFooterSettingsTab
                  navigation={db.navigation}
                  footer={db.footer}
                  settings={db.settings}
                  onSaveSection={async (sec, data, label) => {
                    await commitSection(sec, data, `${label} updated in live SQLite CMS.`);
                  }}
                />
              </div>
            )}

            {/* TAB: USERS, ROLES, AUDIT LOGS & BACKUP */}
            {activeTab === 'governance' && currentUser.role === 'super_admin' && (
              <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6">
                <CmsUsersAndGovernanceTab
                  currentUser={currentUser}
                  onRefreshAll={loadBootstrap}
                  onNotify={showToast}
                />
              </div>
            )}
          </main>
        </div>

        {/* Sticky Bottom Save Footer */}
        <footer className="px-5 sm:px-6 py-4 bg-[#081226] border-t border-blue-900 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div>
            {savedNotice && (
              <span className="text-[15px] text-amber-300 font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0" />
                <span>{savedNotice}</span>
              </span>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-3">
            {isCurrentTabDirty && (
              <button
                type="button"
                onClick={handleDiscardTabChanges}
                className="px-4 py-2.5 text-[15px] font-semibold text-amber-200 hover:text-white rounded-xl hover:bg-blue-900/60 border border-blue-800 flex items-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Discard Changes</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-[15px] font-medium text-blue-200 hover:text-white rounded-xl hover:bg-blue-900/50 cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              disabled={savingAll}
              onClick={() => void handleSaveCurrentAll()}
              className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-[15px] rounded-xl shadow-md flex items-center gap-2 cursor-pointer disabled:opacity-60"
            >
              <Save className="w-4 h-4" />
              <span>{savingAll ? 'Saving...' : 'Save Changes Live'}</span>
            </button>
          </div>
        </footer>

        <CmsConfirmModal
          open={Boolean(confirmAction)}
          title={confirmAction?.title || ''}
          message={confirmAction?.message || ''}
          confirmLabel={confirmAction?.confirmLabel || 'Confirm'}
          onConfirm={() => {
            if (!confirmAction) return;
            const fn = confirmAction.action;
            setConfirmAction(null);
            void fn();
          }}
          onCancel={() => setConfirmAction(null)}
        />
      </motion.div>
    </div>
  );
};
