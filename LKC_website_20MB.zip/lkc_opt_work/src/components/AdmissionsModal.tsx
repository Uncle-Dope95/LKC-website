import React, { useState } from 'react';
import { X, CheckCircle, ArrowRight, ArrowLeft, Check, AlertTriangle, Phone, MessageCircle } from 'lucide-react';
import { useCmsSection, submitPublicEnquiry } from '../services/cmsDataService';

interface AdmissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdmissionsModal: React.FC<AdmissionsModalProps> = ({ isOpen, onClose }) => {
  const general = useCmsSection('general');
  const fees = useCmsSection('fees');

  const [step, setStep] = useState<number>(1);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [referenceCode, setReferenceCode] = useState<string>('');

  const [formData, setFormData] = useState({
    studentFirstName: '',
    studentLastName: '',
    dob: '',
    gender: 'Female',
    currentSchool: '',
    gradeApplying: 'Form 1',
    boardingStatus: 'Day',
    academicStream: 'General',
    parentName: '',
    parentEmail: '',
    parentPhone: '',
    parentAddress: 'Gaborone, Botswana',
    assessmentDate: 'Saturday, 14 November 2026 (09:00 AM)',
    notes: '',
  });

  if (!isOpen) return null;

  const currency = fees.structure.currency || 'P';
  const entranceFee = fees.structure.oneOffFees.entranceAssessment;

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const randomCode = `LKC-${fees.structure.academicYear || '2026'}-${Math.floor(1000 + Math.random() * 9000)}`;
    setIsSubmitting(true);
    setSubmitError(null);
    try {
      await submitPublicEnquiry({ type: 'admission', referenceCode: randomCode, ...formData });
      setReferenceCode(randomCode);
      setIsSubmitted(true);
    } catch (err) {
      setSubmitError(
        err instanceof Error
          ? err.message
          : 'Unable to submit your application automatically. Please call +267 316 1140 / +267 316 2208 or message WhatsApp +267 78 465 196.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setSubmitError(null);
    setStep(1);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#081226]/85 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-blue-200 relative my-6 text-[#0c1a40]">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-md text-blue-900/60 hover:text-[#0c1a40] hover:bg-blue-50 transition-colors cursor-pointer"
          aria-label="Close application modal"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSubmitted ? (
          <div>
            <div className="mb-6 pb-4 border-b border-blue-100">
              <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1">
                Admissions Portal · Cambridge International Centre
              </div>
              <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#0c1a40]">
                Application for Admission 2026/2027
              </h2>
              <p className="text-xs text-blue-900/70 font-sans mt-1">
                {general.name}, {general.address.plot}, {general.address.area}, {general.address.city}
              </p>
            </div>

            <div className="flex items-center justify-between mb-8 text-xs font-sans">
              <div
                className={`flex items-center gap-2 ${
                  step >= 1 ? 'text-[#0c1a40] font-semibold' : 'text-blue-900/40'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                    step >= 1 ? 'bg-[#0c1a40] text-amber-400' : 'bg-blue-50 text-blue-900/50'
                  }`}
                >
                  1
                </span>
                <span>Applicant Info</span>
              </div>
              <div className="h-0.5 flex-1 mx-3 bg-blue-100" />
              <div
                className={`flex items-center gap-2 ${
                  step >= 2 ? 'text-[#0c1a40] font-semibold' : 'text-blue-900/40'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                    step >= 2 ? 'bg-[#0c1a40] text-amber-400' : 'bg-blue-50 text-blue-900/50'
                  }`}
                >
                  2
                </span>
                <span>Parent/Guardian</span>
              </div>
              <div className="h-0.5 flex-1 mx-3 bg-blue-100" />
              <div
                className={`flex items-center gap-2 ${
                  step >= 3 ? 'text-[#0c1a40] font-semibold' : 'text-blue-900/40'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                    step >= 3 ? 'bg-[#0c1a40] text-amber-400' : 'bg-blue-50 text-blue-900/50'
                  }`}
                >
                  3
                </span>
                <span>Assessment Slot</span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs font-sans">
              {step === 1 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[#0c1a40] font-medium mb-1">Student First Name *</label>
                      <input
                        type="text"
                        name="studentFirstName"
                        required
                        value={formData.studentFirstName}
                        onChange={handleChange}
                        placeholder="First name"
                        className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                      />
                    </div>
                    <div>
                      <label className="block text-[#0c1a40] font-medium mb-1">Student Surname *</label>
                      <input
                        type="text"
                        name="studentLastName"
                        required
                        value={formData.studentLastName}
                        onChange={handleChange}
                        placeholder="Surname"
                        className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[#0c1a40] font-medium mb-1">Date of Birth *</label>
                      <input
                        type="date"
                        name="dob"
                        required
                        value={formData.dob}
                        onChange={handleChange}
                        className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                      />
                    </div>
                    <div>
                      <label className="block text-[#0c1a40] font-medium mb-1">Gender</label>
                      <select
                        name="gender"
                        value={formData.gender}
                        onChange={handleChange}
                        className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                      >
                        <option value="Female">Female</option>
                        <option value="Male">Male</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[#0c1a40] font-medium mb-1">Grade Level Applying For *</label>
                      <select
                        name="gradeApplying"
                        value={formData.gradeApplying}
                        onChange={handleChange}
                        className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                      >
                        <option value="Preschool (Early Years)">Preschool (Early Years)</option>
                        <option value="Form 1">Form 1 (Lower Secondary)</option>
                        <option value="Form 2">Form 2 (Lower Secondary)</option>
                        <option value="Form 3">Form 3 (Lower Secondary)</option>
                        <option value="Form 4 (IGCSE)">Form 4 (Cambridge IGCSE)</option>
                        <option value="Form 5 (IGCSE)">Form 5 (Cambridge IGCSE Transfer)</option>
                        <option value="Cambridge AS Level (Form 6.1)">Cambridge AS Level (Form 6.1)</option>
                        <option value="Cambridge A2 Level (Form 6.2)">Cambridge A2 Level (Form 6.2)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[#0c1a40] font-medium mb-1">Boarding Preference *</label>
                      <select
                        name="boardingStatus"
                        value={formData.boardingStatus}
                        onChange={handleChange}
                        className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                      >
                        <option value="Day">Day Scholar (Gaborone)</option>
                        <option value="Boarding">Full On-Campus Boarding Hostels</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[#0c1a40] font-medium mb-1">Current / Previous School *</label>
                    <input
                      type="text"
                      name="currentSchool"
                      required
                      value={formData.currentSchool}
                      onChange={handleChange}
                      placeholder="Current or previous primary/secondary school name"
                      className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                    />
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-[#0c1a40] font-medium mb-1">Parent / Guardian Full Name *</label>
                    <input
                      type="text"
                      name="parentName"
                      required
                      value={formData.parentName}
                      onChange={handleChange}
                      placeholder="Parent or guardian full name"
                      className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[#0c1a40] font-medium mb-1">Email Address *</label>
                      <input
                        type="email"
                        name="parentEmail"
                        required
                        value={formData.parentEmail}
                        onChange={handleChange}
                        placeholder="parent@example.com"
                        className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                      />
                    </div>
                    <div>
                      <label className="block text-[#0c1a40] font-medium mb-1">Telephone / WhatsApp *</label>
                      <input
                        type="tel"
                        name="parentPhone"
                        required
                        value={formData.parentPhone}
                        onChange={handleChange}
                        placeholder="+267 78 465 196"
                        className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[#0c1a40] font-medium mb-1">Physical Residential Address</label>
                    <input
                      type="text"
                      name="parentAddress"
                      value={formData.parentAddress}
                      onChange={handleChange}
                      placeholder="Plot / Suburb / City, Country"
                      className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                    />
                  </div>

                  <div>
                    <label className="block text-[#0c1a40] font-medium mb-1">
                      Any Special Medical or Educational Needs
                    </label>
                    <textarea
                      name="notes"
                      rows={2}
                      value={formData.notes}
                      onChange={handleChange}
                      placeholder="Optional notes regarding allergies, dietary needs, or past academic awards..."
                      className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                    />
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-4">
                  <div className="p-4 bg-amber-50 rounded-lg border border-amber-300 text-[#0c1a40] text-xs">
                    <div className="font-semibold text-amber-800 mb-1">Entrance Assessment Procedure</div>
                    <p className="leading-relaxed">
                      All prospective candidates sit for an entrance diagnostic evaluation in English Comprehension and Mathematics. The {currency} {entranceFee} assessment fee is settled at the reception on the morning of testing.
                    </p>
                  </div>

                  <div>
                    <label className="block text-[#0c1a40] font-medium mb-1">
                      Select Preferred Assessment Date *
                    </label>
                    <select
                      name="assessmentDate"
                      value={formData.assessmentDate}
                      onChange={handleChange}
                      className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                    >
                      <option value="Saturday, 14 November 2026 (09:00 AM)">Saturday, 14 November 2026 (09:00 AM)</option>
                      <option value="Saturday, 28 November 2026 (09:00 AM)">Saturday, 28 November 2026 (09:00 AM)</option>
                      <option value="Saturday, 12 December 2026 (09:00 AM)">Saturday, 12 December 2026 (09:00 AM)</option>
                      <option value="Mid-week Private Assessment by Appointment">Mid-week Private Assessment by Appointment</option>
                    </select>
                  </div>

                  <div className="pt-2">
                    <div className="font-semibold text-[#0c1a40] mb-2">Checklist of Documents to Bring:</div>
                    <div className="space-y-1.5 text-blue-900/80 text-[11px]">
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-amber-600" />
                        <span>Certified copy of Birth Certificate or Passport</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-amber-600" />
                        <span>Latest 2 consecutive term academic reports from previous school</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-amber-600" />
                        <span>2 recent passport-sized photographs of applicant</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-amber-600" />
                        <span>{currency} {entranceFee} Entrance Examination fee receipt / cash / card</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {submitError && (
                <div className="p-3.5 rounded-lg bg-red-50 border border-red-200 text-red-900 text-xs space-y-1.5">
                  <div className="flex items-start gap-2 font-semibold">
                    <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <span>{submitError}</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-[11px] pl-6">
                    <a href="tel:+2673161140" className="inline-flex items-center gap-1 underline font-semibold text-[#0c1a40]">
                      <Phone className="w-3 h-3" /> +267 316 1140
                    </a>
                    <a href="tel:+2673162208" className="inline-flex items-center gap-1 underline font-semibold text-[#0c1a40]">
                      <Phone className="w-3 h-3" /> +267 316 2208
                    </a>
                    <a
                      href={general.socials.whatsapp || 'https://wa.me/26778465196'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 underline font-semibold text-amber-800"
                    >
                      <MessageCircle className="w-3 h-3" /> WhatsApp +267 78 465 196
                    </a>
                  </div>
                </div>
              )}

              <div className="pt-6 border-t border-blue-100 flex items-center justify-between">
                {step > 1 ? (
                  <button
                    type="button"
                    onClick={() => setStep(step - 1)}
                    className="px-4 py-2 border border-blue-200 rounded-lg text-[#0c1a40] hover:bg-blue-50 flex items-center gap-1.5 cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Previous</span>
                  </button>
                ) : (
                  <div />
                )}

                {step < 3 ? (
                  <button
                    key="next-step-btn"
                    type="button"
                    onClick={() => setStep(step + 1)}
                    className="px-5 py-2.5 bg-[#0c1a40] text-white rounded-lg hover:bg-[#162a6b] flex items-center gap-1.5 cursor-pointer font-medium"
                  >
                    <span>Next Step</span>
                    <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
                  </button>
                ) : (
                  <button
                    key="submit-application-btn"
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6 py-2.5 bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-[#081226] font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <span>{isSubmitting ? 'Submitting Application...' : 'Submit Application'}</span>
                    <CheckCircle className="w-4 h-4" />
                  </button>
                )}
              </div>
            </form>
          </div>
        ) : (
          <div className="py-6 text-center space-y-4">
            <div className="w-14 h-14 bg-blue-50 text-amber-500 rounded-full flex items-center justify-center mx-auto border border-blue-200">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div className="text-xs uppercase tracking-widest text-amber-700 font-semibold">
              Application Successfully Lodged
            </div>
            <h3 className="text-2xl font-serif font-bold text-[#0c1a40]">Welcome to {general.name}</h3>

            <p className="text-xs sm:text-sm text-blue-900/80 max-w-md mx-auto leading-relaxed">
              We have received the preliminary enrollment application for{' '}
              <strong className="text-[#0c1a40]">
                {formData.studentFirstName} {formData.studentLastName}
              </strong>{' '}
              for <strong className="text-[#0c1a40]">{formData.gradeApplying}</strong>.
            </p>

            <div className="p-4 bg-blue-50/50 rounded-lg border border-blue-200 max-w-sm mx-auto text-left text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-blue-900/70">Application Reference:</span>
                <span className="font-mono font-bold text-[#0c1a40]">{referenceCode}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-blue-900/70">Assessment Scheduled:</span>
                <span className="font-medium text-[#0c1a40]">{formData.assessmentDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-blue-900/70">Venue:</span>
                <span className="text-[#0c1a40]">
                  {general.address.plot}, {general.address.city}
                </span>
              </div>
            </div>

            <p className="text-xs text-blue-900/70">
              A formal confirmation notice has been queued to <strong>{formData.parentEmail || 'your email'}</strong>. Queries: {general.contacts.admissionsEmail}.
            </p>

            <div className="pt-4 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={handleReset}
                className="px-5 py-2.5 bg-[#0c1a40] text-white rounded-lg text-xs font-medium hover:bg-[#162a6b] cursor-pointer"
              >
                Close & Return to College Site
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

