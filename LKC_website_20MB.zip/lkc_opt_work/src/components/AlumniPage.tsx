import React, { useState, useMemo } from 'react';
import {
  GraduationCap,
  Building2,
  Quote,
  CheckCircle2,
  ChevronRight,
  Send
} from 'lucide-react';
import { useCmsSection, submitPendingAlumni } from '../services/cmsDataService';
import { AlumniTestimonials } from './AlumniTestimonials';
import { handleImageFallback } from '../utils/imageFallback';

interface AlumniPageProps {
  onOpenAdmissions: () => void;
}

export const AlumniPage: React.FC<AlumniPageProps> = () => {
  const alumniList = useCmsSection('alumni');
  const general = useCmsSection('general');

  const approvedAlumni = useMemo(
    () => alumniList.filter((a) => a.status === 'approved'),
    [alumniList]
  );

  const [registered, setRegistered] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    fullName: '',
    gradYear: '2023',
    email: '',
    phone: '',
    currentUniversityOrEmployer: '',
    cityCountry: '',
    degreeOrRole: '',
    cambridgeHonors: '',
    willingToMentor: true,
    message: ''
  });

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setSubmitError(null);
    try {
      await submitPendingAlumni({
        name: formData.fullName.trim(),
        gradYear: formData.gradYear.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        university: formData.currentUniversityOrEmployer.trim(),
        organization: formData.currentUniversityOrEmployer.trim(),
        location: formData.cityCountry.trim() || 'Gaborone, Botswana',
        currentRole: formData.degreeOrRole.trim() || 'LKC Graduate',
        course: formData.degreeOrRole.trim() || 'Alumni Registry Member',
        cambridgeHonors: formData.cambridgeHonors.trim() || 'LKC Graduate',
        willingToMentor: formData.willingToMentor,
        quote: formData.message.trim() || 'Proud alumnus of Livingstone Kolobeng College.'
      });
      setRegistered(true);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Unable to submit alumni profile right now.');
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      fullName: '',
      gradYear: '2023',
      email: '',
      phone: '',
      currentUniversityOrEmployer: '',
      cityCountry: '',
      degreeOrRole: '',
      cambridgeHonors: '',
      willingToMentor: true,
      message: ''
    });
    setRegistered(false);
  };

  return (
    <div className="bg-white min-h-screen text-[#0c1a40] pb-20">

      {/* 1. Hero Section */}
      <div className="relative bg-gradient-to-br from-[#081226] via-[#0c1a40] to-[#162a6b] text-white pt-16 pb-20 px-4 sm:px-6 overflow-hidden border-b border-blue-900">
        <div className="absolute right-[-60px] top-[-40px] opacity-10 pointer-events-none" aria-hidden="true">
          <img
            src={general.logoUrl}
            alt={`${general.name} Crest`}
            onError={handleImageFallback}
            className="w-96 h-96 object-contain"
          />
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-amber-300 uppercase tracking-widest mb-4">
            <span>{general.name}</span>
            <span>·</span>
            <span>Global Alumni Network</span>
            <span>·</span>
            <span className="text-amber-400 font-bold">Est. {general.established}</span>
          </div>

          <div className="max-w-3xl">
            <h1 className="text-3xl sm:text-5xl font-serif font-bold tracking-tight text-white mb-4">
              LKC Alumni Network
            </h1>
            <p className="text-xl sm:text-2xl text-amber-300 font-serif italic mb-6">
              From Kolobeng to the World: Global Leaders, Scholars & Changemakers
            </p>
            <p className="text-base sm:text-lg text-blue-100 leading-relaxed font-sans mb-8">
              Since our founding in {general.established} as an accredited Cambridge International Centre, {general.name} has nurtured graduates pursuing excellence at universities and institutions across the globe. Register below to join the verified official LKC Alumni Registry.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <a
                href="#profiles"
                className="px-6 py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-sm shadow-md transition-all cursor-pointer flex items-center gap-2"
              >
                <span>View Alumni Directory</span>
                <ChevronRight className="w-4 h-4" />
              </a>
              <a
                href="#register"
                className="px-5 py-3 rounded-lg bg-white/15 hover:bg-white/25 text-white font-medium text-sm border border-white/25 transition-all"
              >
                Register with Alumni Association
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Featured Verified Alumni Profiles */}
      <section id="profiles" className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="max-w-3xl mb-10">
          <div className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold mb-2">
            Official Verified Registry
          </div>
          <h2 className="text-3xl font-serif font-bold text-[#0c1a40] mb-3">
            Livingstone Kolobeng Alumni Profiles
          </h2>
          <p className="text-blue-950 text-sm leading-relaxed font-sans">
            All alumni profiles displayed here have formally registered and been verified by College Administration.
          </p>
        </div>

        {approvedAlumni.length === 0 ? (
          <div className="p-10 sm:p-14 rounded-2xl bg-blue-50/50 border border-blue-200 text-center max-w-3xl mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-[#0c1a40] text-amber-400 flex items-center justify-center mx-auto mb-4">
              <GraduationCap className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-serif font-bold text-[#0c1a40] mb-2">
              Official LKC Alumni Directory Open for Registration
            </h3>
            <p className="text-xs sm:text-sm text-blue-950 max-w-lg mx-auto leading-relaxed mb-6">
              Our alumni registry only publishes real, verified LKC graduates. Former students are invited to submit their details below; verified submissions appear in this directory once approved by College Administration.
            </p>
            <a
              href="#register"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-xs font-bold transition-colors"
            >
              <span>Submit Your Alumni Profile</span>
              <ChevronRight className="w-4 h-4 text-amber-400" />
            </a>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {approvedAlumni.map((alumnus) => (
              <div
                key={alumnus.id}
                className="bg-white rounded-2xl border border-blue-200 shadow-sm overflow-hidden flex flex-col justify-between hover:border-amber-400 hover:shadow-md transition-all duration-200 group"
              >
                <div>
                  {/* Header */}
                  <div className="p-4 bg-gradient-to-r from-[#081226] to-[#162a6b] text-white flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <GraduationCap className="w-4 h-4 text-amber-400" />
                      <span className="text-xs font-mono font-semibold text-amber-300">
                        Class of {alumnus.gradYear}
                      </span>
                    </div>
                    <span className="text-[11px] font-mono text-blue-100">
                      {alumnus.location}
                    </span>
                  </div>

                  {/* Profile Info */}
                  <div className="p-6">
                    <div className="flex items-start gap-3.5">
                      {alumnus.image && (
                        <img
                          src={alumnus.image}
                          alt={alumnus.name}
                          loading="lazy"
                          onError={handleImageFallback}
                          className="w-16 h-16 rounded-xl object-cover object-top border border-amber-400 shrink-0"
                        />
                      )}
                      <div className="min-w-0">
                        <h3 className="font-serif font-bold text-xl text-[#0c1a40] group-hover:text-[#162a6b] transition-colors">
                          {alumnus.name}
                        </h3>
                        <div className="text-xs font-semibold text-amber-700 mt-1">
                          {alumnus.currentRole}
                        </div>
                        <div className="text-xs text-blue-800 font-mono mt-0.5">
                          {alumnus.organization}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 p-3 rounded-xl bg-blue-50/70 border border-blue-200 text-xs">
                      <div className="font-semibold text-[#0c1a40] flex items-center gap-1.5 mb-0.5">
                        <Building2 className="w-3.5 h-3.5 text-[#162a6b] shrink-0" />
                        <span>{alumnus.university}</span>
                      </div>
                      <div className="text-blue-950 font-mono text-[11px]">
                        {alumnus.course}
                      </div>
                      {alumnus.cambridgeHonors && (
                        <div className="text-amber-700 font-mono text-[11px] mt-1 font-semibold">
                          {alumnus.cambridgeHonors}
                        </div>
                      )}
                    </div>

                    {alumnus.quote && (
                      <div className="mt-4 pt-4 border-t border-blue-100 text-xs sm:text-sm text-blue-950 italic font-sans leading-relaxed">
                        <Quote className="w-4 h-4 text-amber-600 inline mr-1 opacity-70" />
                        “{alumnus.quote}”
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Tag */}
                <div className="p-3.5 bg-blue-50/60 border-t border-blue-100 text-right">
                  <span className="text-[11px] font-mono text-[#0c1a40] font-semibold">
                    Verified LKC Alumnus
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 2B. Scrolling Alumni Testimonials */}
      <AlumniTestimonials variant="alumni-page" />

      {/* 3. Mentorship Program & Live Registration */}
      <section id="register" className="bg-blue-50/50 py-16 border-t border-blue-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

            {/* Info / Mentorship description */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-white rounded-2xl p-6 sm:p-8 border border-blue-200 shadow-sm">
                <div className="text-xs font-mono uppercase tracking-wider text-amber-700 font-bold mb-2">
                  Giving Back to Botho
                </div>
                <h3 className="text-2xl font-serif font-bold text-[#0c1a40] mb-3">
                  The LKC Alumni Mentorship Initiative
                </h3>
                <p className="text-xs sm:text-sm text-blue-950 leading-relaxed mb-6">
                  Are you an LKC alumnus? Reconnect with your alma mater and help guide current Form 4–5 IGCSE and Cambridge A-Level candidates through university applications and career pathways.
                </p>

                <div className="space-y-3">
                  <div className="flex items-start gap-2.5 text-xs text-blue-950">
                    <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>Deliver guest talks during Cambridge Sixth Form University Week</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-blue-950">
                    <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>Offer one-on-one virtual mentorship for international university admissions</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-blue-950">
                    <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>Attend the Annual LKC Valedictory Banquet as an honored alumnus</span>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-blue-100">
                  <div className="text-xs font-mono text-blue-800 mb-1">Direct Alumni Inquiries:</div>
                  <div className="text-sm font-serif font-bold text-[#0c1a40]">{general.contacts.principalEmail}</div>
                  <div className="text-xs text-blue-900">{general.name} · {general.address.city}</div>
                </div>
              </div>
            </div>

            {/* Registration Form */}
            <div className="lg:col-span-7">
              <div className="bg-white rounded-2xl p-6 sm:p-8 border border-blue-200 shadow-sm">
                <div className="text-xs font-mono uppercase tracking-wider text-amber-700 font-bold mb-2">
                  Alumni Directory Registry
                </div>
                <h3 className="text-2xl font-serif font-bold text-[#0c1a40] mb-2">
                  Register with the Alumni Association
                </h3>
                <p className="text-xs sm:text-sm text-blue-950 mb-6">
                  Submit your alumni profile below. Registrations are reviewed and approved in the College Administration portal before appearing in the public directory.
                </p>

                {registered ? (
                  <div className="p-8 rounded-xl bg-blue-50 border border-blue-200 text-center">
                    <div className="w-12 h-12 rounded-full bg-[#0c1a40] text-amber-400 flex items-center justify-center mx-auto mb-3">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <h4 className="text-lg font-serif font-bold text-[#0c1a40] mb-1">
                      Registration Submitted for Verification
                    </h4>
                    <p className="text-xs sm:text-sm text-blue-950 max-w-md mx-auto mb-4">
                      Thank you. Your LKC Alumni profile has been submitted and is pending administrator review. Once approved in the College backend, it will appear on the public Alumni Directory.
                    </p>
                    <button
                      onClick={resetForm}
                      className="px-4 py-2 rounded-lg bg-[#0c1a40] text-white text-xs font-semibold hover:bg-[#162a6b] cursor-pointer"
                    >
                      Submit Another Alumni Record
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleRegister} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          placeholder="Your full name"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                          Graduating Year (Class of) *
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.gradYear}
                          onChange={(e) => setFormData({ ...formData, gradYear: e.target.value })}
                          placeholder="e.g. 2022"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="alumnus@example.com"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                          Phone / WhatsApp
                        </label>
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          placeholder="+267 7X XXX XXX"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                          Current University or Employer *
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.currentUniversityOrEmployer}
                          onChange={(e) => setFormData({ ...formData, currentUniversityOrEmployer: e.target.value })}
                          placeholder="University or organization name"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                          Degree Programme or Job Title
                        </label>
                        <input
                          type="text"
                          value={formData.degreeOrRole}
                          onChange={(e) => setFormData({ ...formData, degreeOrRole: e.target.value })}
                          placeholder="Degree or current role"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                          Current City & Country
                        </label>
                        <input
                          type="text"
                          value={formData.cityCountry}
                          onChange={(e) => setFormData({ ...formData, cityCountry: e.target.value })}
                          placeholder="e.g. Gaborone, Botswana"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                          Cambridge Distinction / Message
                        </label>
                        <input
                          type="text"
                          value={formData.message}
                          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                          placeholder="Short reflection on your time at LKC"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2">
                      <input
                        type="checkbox"
                        id="willingToMentor"
                        checked={formData.willingToMentor}
                        onChange={(e) => setFormData({ ...formData, willingToMentor: e.target.checked })}
                        className="rounded border-blue-300 text-[#0c1a40] focus:ring-[#0c1a40]"
                      />
                      <label htmlFor="willingToMentor" className="text-xs text-blue-950 cursor-pointer">
                        I am interested in mentoring current LKC students and Sixth Formers
                      </label>
                    </div>

                    {submitError && (
                      <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800 font-medium space-y-1">
                        <div>{submitError}</div>
                        <div className="flex flex-wrap gap-3 text-[11px]">
                          <a href="tel:+2673161140" className="underline font-semibold text-[#0c1a40]">+267 316 1140</a>
                          <a href="tel:+2673162208" className="underline font-semibold text-[#0c1a40]">+267 316 2208</a>
                          <a href="https://wa.me/26778465196" target="_blank" rel="noopener noreferrer" className="underline font-semibold text-amber-800">WhatsApp +267 78 465 196</a>
                        </div>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full py-3 px-6 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white font-bold text-sm shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60"
                    >
                      <Send className="w-4 h-4 text-amber-400" />
                      <span>{submitting ? 'Submitting Registration...' : 'Submit Alumni Registration for Approval'}</span>
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
