import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  GraduationCap,
  Pause,
  Play,
  Quote,
} from 'lucide-react';
import { useCmsSection, usePublishedCmsItems } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { openImageViewer } from './ImageLightboxModal';
import type { AlumniProfile, CmsItem, PageKey } from '../types';

interface AlumniTestimonialsProps {
  onNavigate?: (page: PageKey) => void;
  variant?: 'homepage' | 'alumni-page';
}

interface ResolvedTestimonial {
  id: string;
  name: string;
  gradYear: string;
  subtitle: string;
  location: string;
  quote: string;
  honors?: string;
  image?: string;
}

function mapProfileToTestimonial(profile: AlumniProfile): ResolvedTestimonial {
  const subtitleParts = [
    profile.currentRole?.trim(),
    profile.university?.trim() || profile.organization?.trim(),
  ].filter(Boolean);
  return {
    id: `prof-${profile.id}`,
    name: profile.name,
    gradYear: profile.gradYear || 'Alumni',
    subtitle: subtitleParts.join(' · ') || profile.course || 'Livingstone Kolobeng Alumnus',
    location: profile.location || 'Botswana',
    quote: profile.quote.trim(),
    honors: profile.cambridgeHonors?.trim() || undefined,
    image: profile.image || undefined,
  };
}

function mapCmsItemToTestimonial(item: CmsItem): ResolvedTestimonial | null {
  const rawQuote =
    (typeof item.content?.quote === 'string' && item.content.quote.trim()) ||
    item.excerpt?.trim() ||
    (typeof item.content?.body === 'string' && item.content.body.trim()) ||
    '';
  if (!rawQuote) return null;

  const gradYear =
    (typeof item.content?.gradYear === 'string' && item.content.gradYear.trim()) ||
    item.academicYear ||
    item.category ||
    'Alumni';
  const roleOrUni =
    (typeof item.content?.subtitle === 'string' && item.content.subtitle.trim()) ||
    (typeof item.content?.university === 'string' && item.content.university.trim()) ||
    item.category ||
    'LKC Graduate';
  const location =
    (typeof item.content?.location === 'string' && item.content.location.trim()) ||
    'Global Network';

  return {
    id: `item-${item.id}`,
    name: item.title,
    gradYear,
    subtitle: roleOrUni,
    location,
    quote: rawQuote,
    image: item.thumbnailUrl || item.mediaUrl || undefined,
  };
}

export const AlumniTestimonials: React.FC<AlumniTestimonialsProps> = ({
  onNavigate,
  variant = 'homepage',
}) => {
  const alumniProfiles = useCmsSection('alumni');
  const alumniCmsItems = usePublishedCmsItems('alumni');
  const general = useCmsSection('general');

  const [isPaused, setIsPaused] = useState(false);
  const [stepOffset, setStepOffset] = useState(0);

  const testimonials = useMemo<ResolvedTestimonial[]>(() => {
    const profileQuotes = (Array.isArray(alumniProfiles) ? alumniProfiles : [])
      .filter((a) => a && a.status === 'approved' && typeof a.quote === 'string' && a.quote.trim().length > 0)
      .map(mapProfileToTestimonial);

    const itemQuotes = (Array.isArray(alumniCmsItems) ? alumniCmsItems : [])
      .map(mapCmsItemToTestimonial)
      .filter((entry): entry is ResolvedTestimonial => entry !== null);

    const seenNames = new Set<string>();
    const combined: ResolvedTestimonial[] = [];
    for (const entry of [...profileQuotes, ...itemQuotes]) {
      const key = `${entry.name.toLowerCase()}::${entry.quote.slice(0, 48).toLowerCase()}`;
      if (!seenNames.has(key)) {
        seenNames.add(key);
        combined.push(entry);
      }
    }
    return combined;
  }, [alumniProfiles, alumniCmsItems]);

  const rotatedTestimonials = useMemo(() => {
    if (testimonials.length <= 1) return testimonials;
    const len = testimonials.length;
    const norm = ((stepOffset % len) + len) % len;
    return [...testimonials.slice(norm), ...testimonials.slice(0, norm)];
  }, [testimonials, stepOffset]);

  // Repeat cards inside a single half until there are at least 4 cards so the -50% CSS marquee fills widescreen viewports smoothly.
  const marqueeHalf = useMemo(() => {
    if (rotatedTestimonials.length === 0) return [];
    const filled: ResolvedTestimonial[] = [];
    while (filled.length < Math.max(4, rotatedTestimonials.length)) {
      filled.push(...rotatedTestimonials);
    }
    return filled;
  }, [rotatedTestimonials]);

  const handleStep = (delta: number) => {
    if (testimonials.length === 0) return;
    setStepOffset((prev) => prev + delta);
  };

  const renderCard = (item: ResolvedTestimonial, uniqueKey: string) => (
    <article
      key={uniqueKey}
      className="w-[320px] sm:w-[370px] shrink-0 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/15 hover:border-amber-400/70 transition-colors p-6 flex flex-col justify-between shadow-lg"
    >
      <div>
        <div className="flex items-center justify-between gap-2 mb-4">
          <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
            <Quote className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-md bg-[#081226]/80 text-amber-300 border border-amber-400/30">
            {item.gradYear}
          </span>
        </div>

        <blockquote className="text-sm text-blue-50 leading-relaxed font-sans italic line-clamp-5">
          “{item.quote}”
        </blockquote>
      </div>

      <div className="mt-5 pt-4 border-t border-white/15 flex items-center gap-3">
        {item.image ? (
          <button
            type="button"
            onClick={() =>
              openImageViewer({
                src: item.image!,
                title: item.name,
                subtitle: `${item.gradYear} · ${item.subtitle}`,
              })
            }
            className="w-12 h-12 rounded-xl overflow-hidden border-2 border-amber-400/80 shrink-0 bg-[#081226] cursor-zoom-in"
            aria-label={`View portrait of ${item.name}`}
          >
            <img
              src={item.image}
              alt={item.name}
              loading="lazy"
              onError={handleImageFallback}
              className="w-full h-full object-cover object-top"
            />
          </button>
        ) : (
          <div className="w-12 h-12 rounded-xl bg-amber-400 text-[#081226] flex items-center justify-center font-serif font-bold text-lg shrink-0">
            {item.name.slice(0, 1).toUpperCase()}
          </div>
        )}

        <div className="min-w-0">
          <div className="font-serif font-bold text-base text-white truncate">
            {item.name}
          </div>
          <div className="text-xs text-amber-300 font-medium truncate">
            {item.subtitle}
          </div>
          <div className="text-[11px] font-mono text-blue-200/80 truncate">
            {item.honors ? `${item.honors} · ${item.location}` : item.location}
          </div>
        </div>
      </div>
    </article>
  );

  return (
    <section
      data-testid="alumni-testimonials"
      aria-label="Alumni Testimonials"
      className="py-16 bg-gradient-to-br from-[#081226] via-[#0c1a40] to-[#162a6b] text-white border-y border-blue-900 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 mb-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono uppercase tracking-widest text-amber-300 font-bold mb-1.5 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-amber-400" />
              <span>Voices of Kolobeng · Live CMS Alumni Feed</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
              Alumni Testimonials
            </h2>
            <p className="text-xs sm:text-sm text-blue-100/85 mt-1 max-w-2xl">
              Reflections and university pathways shared by verified {general?.name || 'Livingstone Kolobeng College'} graduates.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {testimonials.length > 0 && (
              <>
                <button
                  type="button"
                  onClick={() => handleStep(-1)}
                  className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white border border-white/15 cursor-pointer transition-colors"
                  aria-label="Previous testimonial"
                  title="Previous quote"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setIsPaused((prev) => !prev)}
                  className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-amber-300 border border-white/15 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                  aria-label={isPaused ? 'Resume scrolling quotes' : 'Pause scrolling quotes'}
                >
                  {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                  <span>{isPaused ? 'Resume' : 'Pause'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleStep(1)}
                  className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white border border-white/15 cursor-pointer transition-colors"
                  aria-label="Next testimonial"
                  title="Next quote"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </>
            )}

            {variant === 'homepage' && onNavigate ? (
              <a
                href="#alumni"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('alumni');
                }}
                className="px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <span>Alumni Directory & Submit Quote</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            ) : (
              <a
                href="#register"
                className="px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <span>Submit Your Testimonial</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>
      </div>

      {testimonials.length === 0 ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="rounded-2xl bg-white/5 border border-white/15 p-8 sm:p-10 text-center max-w-3xl mx-auto">
            <Quote className="w-8 h-8 text-amber-400 mx-auto mb-3 opacity-90" />
            <h3 className="font-serif font-bold text-xl text-white mb-2">
              Approved Graduate Quotes Appear Here Live
            </h3>
            <p className="text-xs sm:text-sm text-blue-100/85 max-w-xl mx-auto leading-relaxed mb-5">
              This marquee streams real quotes directly from the LKC Alumni Registry and CMS Alumni highlights once approved by College Administration.
            </p>
            {variant === 'homepage' && onNavigate ? (
              <a
                href="#register"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('alumni');
                }}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] text-xs font-bold transition-colors"
              >
                <span>Are You an Old Kolobengan? Share Your Story</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            ) : (
              <a
                href="#register"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] text-xs font-bold transition-colors"
              >
                <span>Register & Share Your Reflection Below</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>
      ) : (
        <div className="lkc-marquee-viewport relative w-full overflow-hidden">
          <div className="pointer-events-none absolute inset-y-0 left-0 w-10 sm:w-20 bg-gradient-to-r from-[#081226] to-transparent z-10" />
          <div className="pointer-events-none absolute inset-y-0 right-0 w-10 sm:w-20 bg-gradient-to-l from-[#162a6b] to-transparent z-10" />
          <div
            className="lkc-marquee-track gap-5 px-4"
            data-paused={isPaused ? 'true' : 'false'}
          >
            {marqueeHalf.map((item, idx) => renderCard(item, `a-${item.id}-${idx}`))}
            {marqueeHalf.map((item, idx) => renderCard(item, `b-${item.id}-${idx}`))}
          </div>
        </div>
      )}
    </section>
  );
};
