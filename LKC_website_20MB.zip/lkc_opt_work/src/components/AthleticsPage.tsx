import React, { useState } from 'react';
import { Timer, Trophy, Medal, Calendar, ArrowRight, ZoomIn, ZoomOut, RotateCcw, Download, X, MapPin } from 'lucide-react';
import { useCmsSection, usePublishedCmsItems } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { downloadImageFile } from './ImageLightboxModal';
import type { PageKey } from '../types';

interface AthleticsPageProps {
  onNavigate?: (page: PageKey) => void;
}

export const AthleticsPage: React.FC<AthleticsPageProps> = ({ onNavigate }) => {
  const athletics = useCmsSection('athletics');
  const general = useCmsSection('general');
  const athleticsItems = usePublishedCmsItems('athletics');

  const [selectedCategory, setSelectedCategory] = useState<'all' | 'Track' | 'Field' | 'Relay'>('all');
  const [zoomScale, setZoomScale] = useState<number>(1);
  const [lightbox, setLightbox] = useState<{
    url: string;
    title: string;
    caption: string;
    location?: string;
    category?: string;
  } | null>(null);

  const visiblePhotos = (athletics.photos || []).filter(
    (p) =>
      Boolean(p.url && p.url.trim()) &&
      p.status !== 'unpublished' &&
      p.status !== 'archived'
  );

  const isImageUrl = (url?: string) =>
    Boolean(url && (/\.(png|jpe?g|webp|gif|svg)(\?|$)/i.test(url) || url.startsWith('/uploads/') || url.startsWith('./uploads/')));

  const filteredEvents =
    selectedCategory === 'all'
      ? athletics.events
      : athletics.events.filter((e) => e.category === selectedCategory);

  return (
    <div className="bg-white min-h-screen text-[#0c1a40]">
      {/* Hero Banner */}
      <section className="bg-gradient-to-br from-[#081226] via-[#0c1a40] to-[#162a6b] text-white py-16 sm:py-20 px-4 sm:px-6 border-b border-blue-900">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-widest mb-3">
            <Timer className="w-4 h-4" />
            <span>{general.name} · Athletics Directorate</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-serif font-bold tracking-tight text-white max-w-3xl">
            {athletics.headline}
          </h1>
          <p className="text-base sm:text-lg text-amber-300 font-serif italic mt-2">
            {athletics.subheadline}
          </p>
          <p className="text-sm sm:text-base text-blue-100 mt-4 max-w-3xl leading-relaxed">
            {athletics.description}
          </p>

          <div className="mt-6 flex flex-wrap gap-3">
            {onNavigate && (
              <a
                href="#sports"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('sports');
                }}
                className="px-5 py-2.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold border border-white/20 cursor-pointer flex items-center gap-2"
              >
                <span>Back to Sports & House Trophy</span>
                <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
              </a>
            )}
          </div>
        </div>
      </section>

      {/* Track & Field Events Filter */}
      <section className="py-14 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold">
              Competitive Track & Field Programme
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40] mt-1">
              Official Disciplines & House Divisions
            </h2>
          </div>

          <div className="flex flex-wrap gap-2">
            {(['all', 'Track', 'Field', 'Relay'] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  selectedCategory === cat
                    ? 'bg-[#0c1a40] text-white'
                    : 'bg-blue-50 text-[#0c1a40] hover:bg-blue-100'
                }`}
              >
                {cat === 'all' ? 'All Disciplines' : `${cat} Events`}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map((ev, idx) => (
            <div
              key={`${ev.name}-${idx}`}
              className="p-6 rounded-2xl bg-blue-50/40 border border-blue-200 flex flex-col justify-between"
            >
              <div>
                <span className="inline-block px-2.5 py-0.5 rounded bg-[#0c1a40] text-amber-300 text-[10px] font-mono font-bold uppercase mb-3">
                  {ev.category}
                </span>
                <h3 className="font-serif font-bold text-lg text-[#0c1a40] mb-2">
                  {ev.name}
                </h3>
                <p className="text-xs text-blue-900/80 mb-3">{ev.records}</p>
              </div>
              <div className="pt-3 border-t border-blue-200/70 text-[11px] font-mono text-amber-800 font-semibold">
                Divisions: {ev.ageGroups}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Competitions & Meets */}
      <section className="py-14 px-4 sm:px-6 bg-blue-50/40 border-y border-blue-100">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mb-8">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-700 font-bold mb-1">
              <Trophy className="w-4 h-4" />
              <span>Championship Pathway</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
              Inter-House & Invitational Athletics Meets
            </h2>
            <p className="text-xs sm:text-sm text-blue-900/80 mt-2 leading-relaxed">
              {athletics.seasonSummary}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {athletics.competitions.map((comp, idx) => (
              <div
                key={`${comp.name}-${idx}`}
                className="bg-white p-6 rounded-2xl border border-blue-200 shadow-xs space-y-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="inline-flex items-center gap-1.5 text-xs font-mono text-amber-700 font-bold">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{comp.date}</span>
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-[#0c1a40] text-[10px] font-mono font-bold border border-amber-300">
                    {comp.status}
                  </span>
                </div>
                <h3 className="font-serif font-bold text-xl text-[#0c1a40]">
                  {comp.name}
                </h3>
                <div className="text-xs font-medium text-blue-800">
                  Venue: {comp.venue}
                </div>
                <p className="text-xs text-blue-950/80 leading-relaxed">
                  {comp.highlights}
                </p>
              </div>
            ))}
          </div>

          {athletics.records.length > 0 && (
            <div className="mt-12 bg-white rounded-2xl border border-blue-200 p-6 shadow-xs">
              <div className="flex items-center gap-2 text-xs font-mono uppercase text-amber-700 font-bold mb-4">
                <Medal className="w-4 h-4" />
                <span>Verified College Athletics Records</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-blue-200 bg-blue-50 text-[#0c1a40] font-semibold">
                      <th className="py-2.5 px-3">Event</th>
                      <th className="py-2.5 px-3">Athlete</th>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-3">Record Mark</th>
                      <th className="py-2.5 px-3">Year</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-blue-100">
                    {athletics.records.map((rec, idx) => (
                      <tr key={idx}>
                        <td className="py-2.5 px-3 font-semibold">{rec.event}</td>
                        <td className="py-2.5 px-3">{rec.athlete}</td>
                        <td className="py-2.5 px-3">{rec.category}</td>
                        <td className="py-2.5 px-3 font-mono font-bold text-amber-700">{rec.mark}</td>
                        <td className="py-2.5 px-3 font-mono">{rec.year}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Gallery & CMS Updates */}
      <section className="py-14 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
          <h2 className="text-2xl font-serif font-bold text-[#0c1a40]">
            Athletics Track & Training Gallery
          </h2>
          {(visiblePhotos.length > 0 || athleticsItems.length > 0) && (
            <span className="text-xs text-blue-800">Click any photograph to view full screen</span>
          )}
        </div>

        {visiblePhotos.length === 0 && athleticsItems.length === 0 ? (
          <div className="p-10 rounded-2xl bg-blue-50/50 border border-blue-200 text-center space-y-2">
            <Timer className="w-8 h-8 text-amber-600 mx-auto" />
            <h3 className="font-serif font-bold text-lg text-[#0c1a40]">
              Athletics Photography Gallery
            </h3>
            <p className="text-xs sm:text-sm text-blue-900/80 max-w-xl mx-auto leading-relaxed">
              Official LKC track, sprint, relay, and inter-house championship photographs uploaded via the College CMS appear here automatically once published.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {visiblePhotos.map((photo, idx) => (
              <div
                key={`${idx}-${photo.url}`}
                onClick={() => setLightbox(photo)}
                className="bg-white rounded-2xl border border-blue-200 overflow-hidden shadow-xs cursor-pointer group"
              >
                <div className="relative aspect-[16/10] bg-[#081226] overflow-hidden">
                  <img
                    src={photo.url}
                    alt={photo.title}
                    loading="lazy"
                    onError={handleImageFallback}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-[#0c1a40]/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="px-3 py-1.5 rounded-lg bg-[#081226] text-white text-xs font-medium flex items-center gap-1.5 border border-amber-400/50">
                      <ZoomIn className="w-3.5 h-3.5 text-amber-400" /> View Image
                    </span>
                  </div>
                </div>
                <div className="p-4">
                  <span className="text-[10px] font-mono uppercase text-amber-700 font-bold">
                    {photo.category}
                  </span>
                  <h3 className="font-serif font-bold text-sm text-[#0c1a40] mt-0.5">
                    {photo.title}
                  </h3>
                  <p className="text-xs text-blue-900/80 mt-1">{photo.caption}</p>
                  {photo.location && (
                    <div className="mt-2 pt-2 border-t border-blue-100 flex items-center gap-1.5 text-[11px] font-mono text-blue-800">
                      <MapPin className="w-3 h-3 text-amber-600 shrink-0" />
                      <span>{photo.location}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {athleticsItems.map((item) => {
              const imgUrl =
                item.thumbnailUrl || (isImageUrl(item.mediaUrl) ? item.mediaUrl : undefined);
              return (
                <div
                  key={item.id}
                  onClick={() =>
                    imgUrl &&
                    setLightbox({
                      url: imgUrl,
                      title: item.title,
                      caption: item.excerpt,
                      category: item.category,
                    })
                  }
                  className={`bg-white rounded-2xl border border-blue-200 overflow-hidden shadow-xs flex flex-col ${
                    imgUrl ? 'cursor-pointer group' : ''
                  }`}
                >
                  {imgUrl && (
                    <div className="relative aspect-[16/10] bg-[#081226] overflow-hidden">
                      <img
                        src={imgUrl}
                        alt={item.title}
                        loading="lazy"
                        onError={handleImageFallback}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-[#0c1a40]/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="px-3 py-1.5 rounded-lg bg-[#081226] text-white text-xs font-medium flex items-center gap-1.5 border border-amber-400/50">
                          <ZoomIn className="w-3.5 h-3.5 text-amber-400" /> View Image
                        </span>
                      </div>
                    </div>
                  )}
                  <div className="p-4">
                    <span className="text-[10px] font-mono uppercase text-amber-700 font-bold">
                      {item.category}
                    </span>
                    <h3 className="font-serif font-bold text-sm text-[#0c1a40] mt-0.5">
                      {item.title}
                    </h3>
                    <p className="text-xs text-blue-900/80 mt-1">{item.excerpt}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-[#081226]/92 flex items-center justify-center p-4"
          onClick={() => {
            setLightbox(null);
            setZoomScale(1);
          }}
        >
          <div
            className="bg-[#0c1a40] border border-blue-800 rounded-2xl max-w-[96vw] sm:max-w-[94vw] w-full h-[94vh] max-h-[94vh] overflow-hidden shadow-2xl flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 py-3 bg-[#081226] border-b border-blue-900 flex flex-wrap items-center justify-between gap-2 text-white">
              <div className="font-serif font-bold text-sm sm:text-base">{lightbox.title}</div>
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-blue-950 rounded-lg border border-blue-800 px-1 py-0.5 text-xs text-blue-100">
                  <button
                    type="button"
                    onClick={() => setZoomScale((z) => Math.max(0.5, Number((z - 0.25).toFixed(2))))}
                    className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>
                  <span className="px-2 font-mono text-[11px] text-amber-400">
                    {Math.round(zoomScale * 100)}%
                  </span>
                  <button
                    type="button"
                    onClick={() => setZoomScale((z) => Math.min(4, Number((z + 0.25).toFixed(2))))}
                    className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setZoomScale(1)}
                    className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer ml-1"
                    title="Reset Zoom"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => downloadImageFile(lightbox.url, lightbox.title)}
                  className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                  title="Download Image"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Download</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setLightbox(null);
                    setZoomScale(1);
                  }}
                  className="p-1.5 rounded-lg bg-blue-900/60 hover:bg-blue-800 text-white cursor-pointer"
                  aria-label="Close image preview"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-4 bg-[#081226] flex items-center justify-center min-h-[64vh]">
              <div
                className="transition-transform duration-150 origin-center flex items-center justify-center"
                style={{ transform: `scale(${zoomScale})` }}
              >
                <img
                  src={lightbox.url}
                  alt={lightbox.title}
                  onError={handleImageFallback}
                  data-no-global-zoom="true"
                  className="h-[74vh] sm:h-[78vh] w-auto max-w-[90vw] object-contain rounded-xl shadow-2xl"
                />
              </div>
            </div>
            <div className="px-5 py-3 text-xs text-blue-100 border-t border-blue-900 space-y-1">
              <div>{lightbox.caption}</div>
              {lightbox.location && (
                <div className="flex items-center gap-1.5 text-[11px] font-mono text-amber-300">
                  <MapPin className="w-3 h-3 shrink-0" />
                  <span>{lightbox.location}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
