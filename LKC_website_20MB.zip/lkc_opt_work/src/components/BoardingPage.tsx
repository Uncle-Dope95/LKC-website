import React, { useState } from 'react';
import {
  ShieldCheck,
  Utensils,
  Bed,
  CheckCircle2,
  Phone,
  MessageCircle,
  Mail,
  Download,
  ChevronRight,
  Send,
  Moon,
  Sun,
  Coffee,
  Quote
} from 'lucide-react';
import { submitPublicEnquiry, useCmsSection } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';

interface BoardingPageProps {
  onOpenAdmissions: () => void;
}

export const BoardingPage: React.FC<BoardingPageProps> = () => {
  const boarding = useCmsSection('boarding');
  const general = useCmsSection('general');
  const fees = useCmsSection('fees');

  const [inquirySubmitted, setInquirySubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    parentName: '',
    parentEmail: '',
    parentPhone: '',
    studentName: '',
    gender: 'Female',
    gradeApplying: 'Form 1 (Cambridge Lower Secondary)',
    entryTerm: 'Term 1 2026',
    specialNotes: ''
  });

  const handleSubmitInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setSubmitError(null);
    try {
      await submitPublicEnquiry({
        type: 'boarding',
        name: formData.parentName,
        email: formData.parentEmail,
        phone: formData.parentPhone,
        studentName: formData.studentName,
        gender: formData.gender,
        gradeApplying: formData.gradeApplying,
        entryTerm: formData.entryTerm,
        notes: formData.specialNotes,
      });
      setInquirySubmitted(true);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Unable to submit inquiry. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-white min-h-screen text-[#0c1a40] pb-20">

      {/* 1. Hero / Residential Banner */}
      <div className="relative bg-gradient-to-br from-[#081226] via-[#0c1a40] to-[#162a6b] text-white pt-16 pb-20 px-4 sm:px-6 overflow-hidden border-b border-blue-900">
        <div className="absolute right-[-60px] top-[-40px] opacity-10 pointer-events-none" aria-hidden="true">
          <img
            src={general.logoUrl}
            alt={`${general.name} Crest`}
            onError={handleImageFallback}
            className="w-96 h-96 object-contain"
          />
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-amber-300 uppercase tracking-widest mb-4">
            <span>{general.name}</span>
            <span>·</span>
            <span>Residential Life</span>
            <span>·</span>
            <span className="text-amber-400 font-bold">{boarding.capacity} Beds Capacity</span>
          </div>

          <div className="max-w-3xl">
            <h1 className="text-3xl sm:text-5xl font-serif font-bold tracking-tight text-white mb-4">
              {boarding.headline}
            </h1>
            <p className="text-xl sm:text-2xl text-amber-300 font-serif italic mb-6">
              {boarding.subheadline}
            </p>
            <p className="text-base sm:text-lg text-blue-100 leading-relaxed font-sans mb-8">
              {boarding.leadParagraph}
            </p>

            <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20 text-sm text-amber-200 leading-relaxed mb-8">
              {boarding.capacityNotice}
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <a
                href={general.admissionsPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-sm shadow-md transition-all cursor-pointer flex items-center gap-2"
              >
                <span>Apply for Admission</span>
                <ChevronRight className="w-4 h-4" />
              </a>
              <a
                href="#residences"
                className="px-5 py-3 rounded-lg bg-white/15 hover:bg-white/25 text-white font-medium text-sm border border-white/25 transition-all"
              >
                Explore Residences
              </a>
              <a
                href="#routine"
                className="px-5 py-3 rounded-lg bg-white/15 hover:bg-white/25 text-white font-medium text-sm border border-white/25 transition-all"
              >
                Daily Routine
              </a>
              <a
                href="#cafeteria"
                className="px-5 py-3 rounded-lg bg-white/15 hover:bg-white/25 text-white font-medium text-sm border border-white/25 transition-all"
              >
                Our Cafeteria
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Statistical Ribbon · Real-time Admission Capacity */}
      <div className="bg-[#081226] text-white border-b border-blue-900 py-6 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-4 gap-5 text-center">
          <div className="p-4 rounded-xl bg-[#0c1a40] border border-blue-800">
            <div className="text-xs font-mono uppercase tracking-wider text-blue-200 mb-1">
              Total Capacity
            </div>
            <div className="text-2xl sm:text-3xl font-serif font-bold text-white">
              {boarding.capacity} Beds
            </div>
            <div className="text-xs text-blue-200 mt-1">Separate Girls & Boys Houses</div>
          </div>

          <div className="p-4 rounded-xl bg-[#0c1a40] border border-blue-800">
            <div className="text-xs font-mono uppercase tracking-wider text-amber-300 mb-1">
              Current Enrollment
            </div>
            <div className="text-2xl sm:text-3xl font-serif font-bold text-white">
              {boarding.currentResidents} Enrolled
            </div>
            <div className="text-xs text-blue-200 mt-1">Active resident scholars</div>
          </div>

          <div className="p-4 rounded-xl bg-[#162a6b] border border-amber-400/60">
            <div className="text-xs font-mono uppercase tracking-wider text-amber-300 mb-1">
              Spaces Available
            </div>
            <div className="text-2xl sm:text-3xl font-serif font-bold text-amber-300">
              {boarding.spacesOpen} Open
            </div>
            <div className="text-xs text-blue-100 mt-1">2026 / 2027 Intake</div>
          </div>

          <div className="p-4 rounded-xl bg-[#0c1a40] border border-amber-400/50">
            <div className="text-xs font-mono uppercase tracking-wider text-amber-300 mb-1">
              Annual Boarding Fee
            </div>
            <div className="text-2xl sm:text-3xl font-serif font-bold text-amber-400">
              P {fees.structure.boardingSchedule.annual.toLocaleString()}
            </div>
            <div className="text-xs text-blue-100 mt-1">
              T1 P{fees.structure.boardingSchedule.term1.toLocaleString()} · T2 P{fees.structure.boardingSchedule.term2.toLocaleString()} · T3 P{fees.structure.boardingSchedule.term3.toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {/* 3. The Two Dedicated Residences (Girls = PINK, Boys = BLUE) */}
      <section id="residences" className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-[#0c1a40] text-xs font-mono font-semibold border border-blue-200 mb-3">
            <span>{boarding.entranceBanner}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#0c1a40] mb-3">
            {boarding.officialTitle}
          </h2>
          <p className="text-lg text-amber-700 font-serif italic mb-2">
            {boarding.housesSubhead}
          </p>
          <p className="text-sm sm:text-base text-blue-950 font-sans leading-relaxed">
            {boarding.housesLead}
          </p>
        </div>

        <div className="mb-10 rounded-2xl overflow-hidden border-2 border-blue-200 shadow-sm bg-[#0c1a40]">
          <img
            src={boarding.bannerImage || './assets/aistudio/image_06ec6396.png'}
            alt="Sir Ketumile Masire & Lady Olebile Masire Boarding Houses (100 Beds)"
            loading="lazy"
            onError={handleImageFallback}
            className="w-full h-auto max-h-[420px] object-cover object-center"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {boarding.hostels.map((hostel) => {
            const isGirls =
              hostel.id === 'girls-house' ||
              hostel.name.toLowerCase().includes('olebile') ||
              hostel.wing.toLowerCase().includes('girls');

            return (
              <div
                key={hostel.id}
                className={`bg-white rounded-2xl border-2 ${
                  isGirls
                    ? 'border-pink-300 hover:border-pink-400'
                    : 'border-blue-300 hover:border-blue-500'
                } shadow-sm overflow-hidden flex flex-col justify-between transition-all duration-200`}
              >
                {/* Header Strip: Pink for Girls, Blue for Boys */}
                <div
                  className={`p-4 flex items-center justify-between text-white ${
                    isGirls
                      ? 'bg-gradient-to-r from-pink-700 via-pink-600 to-pink-700'
                      : 'bg-gradient-to-r from-[#081226] via-[#0c1a40] to-[#162a6b]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Bed className="w-4 h-4 text-amber-300" />
                    <span className="text-xs font-mono font-semibold uppercase tracking-wider text-white">
                      {hostel.capacityBadge}
                    </span>
                  </div>
                  <span className="text-xs font-mono font-bold text-amber-200">
                    {hostel.capacity} Beds
                  </span>
                </div>

                {/* Content */}
                <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className={`text-2xl font-serif font-bold mb-2 ${isGirls ? 'text-pink-900' : 'text-[#0c1a40]'}`}>
                      {hostel.name}
                    </h3>
                    <p className="text-blue-950 text-sm leading-relaxed mb-6 font-sans">
                      {hostel.description}
                    </p>

                    {/* House Leader Profile & Pastoral Quote Box */}
                    <div
                      className={`p-5 rounded-xl mb-6 border ${
                        isGirls
                          ? 'bg-pink-50 border-pink-200'
                          : 'bg-blue-50 border-blue-200'
                      }`}
                    >
                      <div className="flex items-center gap-4 mb-4">
                        {hostel.leaderImage ? (
                          <img
                            src={hostel.leaderImage}
                            alt={hostel.leaderName}
                            loading="lazy"
                            onError={handleImageFallback}
                            className={`w-16 h-16 rounded-2xl object-cover object-top shrink-0 border-2 shadow-sm ${
                              isGirls ? 'border-pink-500' : 'border-blue-600'
                            }`}
                          />
                        ) : (
                          <div
                            className={`w-16 h-16 rounded-2xl ${
                              isGirls ? 'bg-pink-600' : 'bg-[#0c1a40]'
                            } text-white font-serif font-bold text-xl flex items-center justify-center shadow-xs shrink-0`}
                          >
                            {hostel.leaderName[0]}
                          </div>
                        )}

                        <div>
                          <div className={`font-serif font-bold text-base leading-tight ${isGirls ? 'text-pink-950' : 'text-[#0c1a40]'}`}>
                            {hostel.leaderName}
                          </div>
                          <div className={`text-xs font-bold mt-0.5 ${isGirls ? 'text-pink-700' : 'text-amber-700'}`}>
                            {hostel.leaderRole}
                          </div>
                          <div className={`text-[11px] font-mono ${isGirls ? 'text-pink-800/80' : 'text-blue-800'}`}>
                            {hostel.leaderTitle}
                          </div>
                        </div>
                      </div>

                      <div
                        className={`relative pl-4 border-l-2 text-xs sm:text-sm italic leading-relaxed font-sans ${
                          isGirls
                            ? 'border-pink-400 text-pink-950'
                            : 'border-amber-500 text-blue-950'
                        }`}
                      >
                        <Quote className={`w-4 h-4 inline mr-1 opacity-70 ${isGirls ? 'text-pink-600' : 'text-amber-600'}`} />
                        {hostel.quote}
                      </div>
                    </div>

                    {/* Key House Features */}
                    <div>
                      <div className="text-xs font-mono uppercase tracking-wider text-blue-800 font-semibold mb-3">
                        Residence Key Features
                      </div>
                      <ul className="space-y-2.5">
                        {hostel.features.map((feature, i) => (
                          <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-blue-950">
                            <CheckCircle2
                              className={`w-4 h-4 shrink-0 mt-0.5 ${
                                isGirls ? 'text-pink-600' : 'text-[#162a6b]'
                              }`}
                            />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* CTA Button */}
                  <div className={`mt-8 pt-5 border-t ${isGirls ? 'border-pink-100' : 'border-blue-100'}`}>
                    <a
                      href={general.admissionsPortalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`w-full py-3 px-4 rounded-xl font-semibold text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 ${
                        isGirls
                          ? 'bg-pink-600 hover:bg-pink-700 text-white shadow-xs'
                          : 'bg-[#0c1a40] hover:bg-[#162a6b] text-white shadow-xs'
                      }`}
                    >
                      <span>{hostel.applyCta}</span>
                      <ChevronRight className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. Daily Boarding Routine & Lights-Out Tables */}
      <section id="routine" className="bg-blue-50/50 py-16 border-y border-blue-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="max-w-3xl mb-12">
            <div className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold mb-2">
              Structured Daily Discipline · Botho & Academic Focus
            </div>
            <h2 className="text-3xl font-serif font-bold text-[#0c1a40] mb-3">
              Daily Boarding Routine
            </h2>
            <p className="text-blue-950 text-sm leading-relaxed">
              {general.name} enforces a disciplined, nurturing timetable designed to instill healthy sleep rhythms, time stewardship, daily reflection, and structured evening prep.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            {/* Morning Table */}
            <div className="bg-white rounded-2xl border border-blue-200 shadow-xs overflow-hidden">
              <div className="p-4 bg-gradient-to-r from-amber-500 to-amber-600 text-[#081226] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sun className="w-5 h-5 text-[#081226]" />
                  <h3 className="font-serif font-bold text-base">Morning Schedule (05:30 – 16:30)</h3>
                </div>
                <span className="text-xs font-mono font-bold">Day Break to Classes</span>
              </div>
              <div className="divide-y divide-blue-100">
                <div className="grid grid-cols-12 bg-blue-50 text-[11px] font-mono text-blue-900 uppercase tracking-wider p-3 font-semibold">
                  <div className="col-span-4">Time</div>
                  <div className="col-span-5">Activity</div>
                  <div className="col-span-3">Notes</div>
                </div>
                {boarding.morningRoutine.map((item, idx) => (
                  <div key={idx} className="grid grid-cols-12 p-3.5 text-xs sm:text-sm items-center hover:bg-blue-50/40 transition-colors">
                    <div className="col-span-4 font-mono font-semibold text-[#0c1a40] text-xs">
                      {item.time}
                    </div>
                    <div className="col-span-5 text-blue-950 font-medium pr-2">
                      {item.activity}
                    </div>
                    <div className="col-span-3 text-[11px] text-blue-800 italic">
                      {item.notes}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Afternoon & Evening Table */}
            <div className="bg-white rounded-2xl border border-blue-200 shadow-xs overflow-hidden">
              <div className="p-4 bg-gradient-to-r from-[#0c1a40] to-[#162a6b] text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Moon className="w-5 h-5 text-amber-400" />
                  <h3 className="font-serif font-bold text-base">Evening Schedule (16:30 Onwards)</h3>
                </div>
                <span className="text-xs font-mono text-amber-300">Study, Dinner & Lights-Out</span>
              </div>
              <div className="divide-y divide-blue-100">
                <div className="grid grid-cols-12 bg-blue-50 text-[11px] font-mono text-blue-900 uppercase tracking-wider p-3 font-semibold">
                  <div className="col-span-4">Time</div>
                  <div className="col-span-5">Activity</div>
                  <div className="col-span-3">Notes</div>
                </div>
                {boarding.eveningRoutine.map((item, idx) => (
                  <div key={idx} className="grid grid-cols-12 p-3.5 text-xs sm:text-sm items-center hover:bg-blue-50/40 transition-colors">
                    <div className="col-span-4 font-mono font-semibold text-[#0c1a40] text-xs">
                      {item.time}
                    </div>
                    <div className="col-span-5 text-blue-950 font-medium pr-2">
                      {item.activity}
                    </div>
                    <div className="col-span-3 text-[11px] text-blue-800 italic">
                      {item.notes}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Staggered Lights-Out Schedule */}
          <div className="bg-[#081226] text-white rounded-2xl p-6 sm:p-8 border border-blue-900">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <div>
                <div className="text-xs font-mono uppercase tracking-widest text-amber-400 mb-1">
                  Staggered Curfew Guidelines
                </div>
                <h3 className="text-2xl font-serif font-bold text-white">
                  Lights-Out Schedule by Year Group
                </h3>
              </div>
              <div className="text-xs text-amber-200 font-mono bg-[#0c1a40] px-3 py-1.5 rounded-lg border border-blue-800">
                Supervised by Resident Staff & Prefects
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {boarding.lightsOutSchedule.map((sched, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-[#0c1a40] border border-blue-800 flex flex-col justify-between">
                  <div>
                    <div className="text-xs font-mono text-amber-300 uppercase tracking-wider font-semibold">
                      {sched.group}
                    </div>
                    <div className="text-sm font-sans text-blue-100 mt-0.5">
                      {sched.grades}
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-blue-800 flex items-baseline justify-between">
                    <span className="text-2xl font-serif font-bold text-amber-400">
                      {sched.time}
                    </span>
                    <span className="text-[11px] text-blue-200">
                      {sched.rationale}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 5. Cafeteria & Dining Pavilion */}
      <section id="cafeteria" className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="bg-white rounded-3xl border border-blue-200 shadow-sm p-6 sm:p-12 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-5">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 text-[#0c1a40] text-xs font-mono font-semibold border border-amber-300 mb-3">
                <Utensils className="w-3.5 h-3.5 text-amber-600" />
                <span>{boarding.cafeteria.headline}</span>
              </div>
              <h2 className="text-3xl font-serif font-bold text-[#0c1a40] mb-3">
                {boarding.cafeteria.title}
              </h2>
              <p className="text-base text-amber-700 font-serif italic mb-4">
                {boarding.cafeteria.subheadline}
              </p>
              <p className="text-blue-950 text-sm leading-relaxed mb-6 font-sans">
                {boarding.cafeteria.description}
              </p>

              <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-950 space-y-2">
                <div className="flex items-center gap-2 font-semibold text-[#0c1a40]">
                  <ShieldCheck className="w-4 h-4 text-amber-600" />
                  <span>Hygienic & Certified Nutrition Standards</span>
                </div>
                <p>
                  Vegetarian, halal, and allergen-sensitive meal options are carefully coordinated with campus catering staff and medical attendants.
                </p>
              </div>
            </div>

            <div className="lg:col-span-7 space-y-4">
              {boarding.cafeteria.meals.map((meal, idx) => (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-blue-50/50 border border-blue-200 hover:border-amber-400 hover:bg-amber-50/20 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-amber-100 text-[#0c1a40] flex items-center justify-center shrink-0 mt-0.5 border border-amber-300">
                      {idx === 0 ? <Coffee className="w-5 h-5" /> : idx === 1 ? <Utensils className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="font-serif font-bold text-base text-[#0c1a40]">
                        {meal.meal}
                      </div>
                      <div className="text-xs text-blue-950 mt-1">
                        {meal.details}
                      </div>
                    </div>
                  </div>
                  <div className="sm:text-right shrink-0">
                    <span className="inline-block px-3 py-1 rounded-full bg-white border border-blue-200 text-xs font-mono font-semibold text-[#0c1a40]">
                      {meal.time}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 6. Community & Character Development Section */}
      <section className="bg-[#0c1a40] text-white py-16 px-4 sm:px-6 border-y border-blue-900">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mb-12">
            <div className="text-xs font-mono uppercase tracking-widest text-amber-400 mb-2">
              Holistic Residential Life
            </div>
            <h2 className="text-3xl font-serif font-bold text-white mb-3">
              Community & Character Development
            </h2>
            <p className="text-blue-100 text-sm leading-relaxed">
              {general.name} boarding extends beyond beds and study desks. We cultivate lifelong friendships, leadership competencies, and dignified self-reliance.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {boarding.communityPillars.map((pillar, i) => (
              <div
                key={i}
                className="p-6 rounded-2xl bg-[#081226] border border-blue-800 flex flex-col justify-between hover:border-amber-400 transition-colors"
              >
                <div>
                  <div className="w-10 h-10 rounded-lg bg-[#162a6b] text-amber-400 flex items-center justify-center mb-4 font-mono font-bold text-sm border border-blue-700">
                    0{i + 1}
                  </div>
                  <h3 className="font-serif font-bold text-lg text-white mb-2">
                    {pillar.title}
                  </h3>
                  <p className="text-xs text-blue-100 leading-relaxed">
                    {pillar.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Boarding Inquiries & Admissions Section */}
      <section id="inquiry" className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

          {/* Contact Directory & Downloads */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-2xl p-6 sm:p-8 border border-blue-200 shadow-sm">
              <div className="text-xs font-mono uppercase tracking-wider text-amber-700 font-bold mb-2">
                Admissions & Hostels Desk
              </div>
              <h2 className="text-2xl font-serif font-bold text-[#0c1a40] mb-3">
                Boarding Inquiries
              </h2>
              <p className="text-xs sm:text-sm text-blue-950 mb-6 leading-relaxed">
                Connect directly with the Vice Principal Administration and our residential admissions wardens to discuss boarding availability for your child.
              </p>

              <div className="space-y-4 text-xs sm:text-sm">
                <a
                  href={`tel:${general.contacts.phone.replace(/\s+/g, '')}`}
                  className="flex items-center gap-3 p-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#0c1a40] transition-colors border border-blue-200"
                >
                  <Phone className="w-4 h-4 text-amber-600 shrink-0" />
                  <div>
                    <div className="font-semibold text-[#0c1a40]">{general.contacts.phone} / {general.contacts.phoneSecondary}</div>
                    <div className="text-[11px] text-blue-800">Boarding Administration Direct Lines</div>
                  </div>
                </a>

                <a
                  href={general.socials.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#0c1a40] transition-colors border border-blue-200"
                >
                  <MessageCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <div>
                    <div className="font-semibold text-[#0c1a40]">{general.socials.whatsappNumber}</div>
                    <div className="text-[11px] text-blue-800">Official Admissions WhatsApp</div>
                  </div>
                </a>

                <a
                  href={`mailto:${general.contacts.admissionsEmail}`}
                  className="flex items-center gap-3 p-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#0c1a40] transition-colors border border-blue-200"
                >
                  <Mail className="w-4 h-4 text-amber-600 shrink-0" />
                  <div>
                    <div className="font-semibold text-[#0c1a40]">{general.contacts.admissionsEmail}</div>
                    <div className="text-[11px] text-blue-800">{general.contacts.admissionsAltEmail}</div>
                  </div>
                </a>
              </div>

              <div className="mt-6 pt-6 border-t border-blue-100">
                <a
                  href={general.contacts.feePolicyPdfUrl}
                  download="Livingstone-Kolobeng-College-2026-Fees-Policy.pdf"
                  className="w-full py-3 px-4 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition-colors"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>Download 2026 Boarding Fee Policy (PDF)</span>
                </a>
              </div>
            </div>
          </div>

          {/* Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-2xl p-6 sm:p-8 border border-blue-200 shadow-sm">
              <div className="text-xs font-mono uppercase tracking-wider text-amber-700 font-bold mb-2">
                Priority Application
              </div>
              <h3 className="text-2xl font-serif font-bold text-[#0c1a40] mb-2">
                Submit a Residential Boarding Inquiry
              </h3>
              <p className="text-xs sm:text-sm text-blue-950 mb-6">
                Reserve one of our {boarding.spacesOpen} open boarding spaces across the Lady Olebile Masire (Girls) and Sir Ketumile Masire (Boys) residences.
              </p>

              {inquirySubmitted ? (
                <div className="p-8 rounded-xl bg-blue-50 border border-blue-200 text-center">
                  <div className="w-12 h-12 rounded-full bg-[#0c1a40] text-amber-400 flex items-center justify-center mx-auto mb-3">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-serif font-bold text-[#0c1a40] mb-1">
                    Boarding Inquiry Received
                  </h4>
                  <p className="text-xs sm:text-sm text-blue-950 max-w-md mx-auto mb-4">
                    Thank you, {formData.parentName || 'Parent'}. Our residential admissions warden will contact you via {formData.parentPhone || 'phone'} within 24 operational hours with the hostel prospectus and tour schedule.
                  </p>
                  <button
                    onClick={() => setInquirySubmitted(false)}
                    className="px-4 py-2 rounded-lg bg-[#0c1a40] text-white text-xs font-semibold hover:bg-[#162a6b] cursor-pointer"
                  >
                    Submit Another Inquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmitInquiry} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                        Parent / Guardian Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.parentName}
                        onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                        placeholder="Parent or guardian name"
                        className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                        Parent Mobile / WhatsApp *
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.parentPhone}
                        onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                        placeholder="+267 7X XXX XXX"
                        className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                        Parent Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.parentEmail}
                        onChange={(e) => setFormData({ ...formData, parentEmail: e.target.value })}
                        placeholder="parent@example.com"
                        className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                        Student Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.studentName}
                        onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                        placeholder="Student full name"
                        className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                        Residence Wing *
                      </label>
                      <select
                        value={formData.gender}
                        onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none bg-white"
                      >
                        <option value="Female">Lady Olebile Masire (Girls)</option>
                        <option value="Male">Sir Ketumile Masire (Boys)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                        Grade Applying For *
                      </label>
                      <select
                        value={formData.gradeApplying}
                        onChange={(e) => setFormData({ ...formData, gradeApplying: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none bg-white"
                      >
                        <option>Form 1 (Cambridge Lower Secondary)</option>
                        <option>Form 2 (Cambridge Lower Secondary)</option>
                        <option>Form 3 (Pre-IGCSE)</option>
                        <option>Form 4 (Cambridge IGCSE)</option>
                        <option>Form 5 (Cambridge IGCSE)</option>
                        <option>Form 6 (Cambridge AS & A-Levels)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                        Entry Term *
                      </label>
                      <select
                        value={formData.entryTerm}
                        onChange={(e) => setFormData({ ...formData, entryTerm: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none bg-white"
                      >
                        <option>Term 1 (January 2026)</option>
                        <option>Term 2 (May 2026)</option>
                        <option>Term 3 (September 2026)</option>
                        <option>Term 1 (January 2027)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#0c1a40] mb-1">
                      Dietary Requirements or Pastoral Questions
                    </label>
                    <textarea
                      rows={3}
                      value={formData.specialNotes}
                      onChange={(e) => setFormData({ ...formData, specialNotes: e.target.value })}
                      placeholder="Please note any medical conditions, dietary preferences, or specific boarding queries..."
                      className="w-full px-3.5 py-2.5 rounded-lg border border-blue-200 text-xs sm:text-sm focus:border-[#0c1a40] focus:outline-none"
                    />
                  </div>

                  {submitError && (
                    <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-800 text-xs font-medium space-y-1">
                      <div>{submitError}</div>
                      <div className="flex flex-wrap gap-3 text-[11px]">
                        <a href="tel:+2673161140" className="underline font-semibold text-[#0c1a40]">+267 316 1140</a>
                        <a href="tel:+2673162208" className="underline font-semibold text-[#0c1a40]">+267 316 2208</a>
                        <a href="https://wa.me/26778465196" target="_blank" rel="noopener noreferrer" className="underline font-semibold text-amber-800">WhatsApp +267 78 465 196</a>
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-3 px-6 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] disabled:opacity-60 text-white font-bold text-sm shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4 text-amber-400" />
                    <span>{submitting ? 'Submitting Inquiry...' : 'Submit Boarding Admission Inquiry'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
