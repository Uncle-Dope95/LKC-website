import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Building2,
  Sparkles,
  Cpu,
  MonitorPlay,
  Calendar,
  CheckCircle2,
  ArrowRight,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  X,
  ExternalLink,
  Download
} from 'lucide-react';
import { useCmsSection } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { downloadImageFile } from './ImageLightboxModal';

interface BuildingSectionProps {
  onOpenAdmissions?: () => void;
}

export const BuildingSection: React.FC<BuildingSectionProps> = () => {
  const building = useCmsSection('building');
  const general = useCmsSection('general');

  const [selectedImage, setSelectedImage] = useState<{ url: string; caption: string; tag: string } | null>(null);
  const [zoomScale, setZoomScale] = useState<number>(1);

  const handleOpenZoom = (img: { url: string; caption: string; tag: string }) => {
    setSelectedImage(img);
    setZoomScale(1);
  };

  const handleZoomIn = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoomScale((prev) => Math.min(prev + 0.35, 4));
  };

  const handleZoomOut = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoomScale((prev) => Math.max(prev - 0.35, 0.5));
  };

  const handleResetZoom = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoomScale(1);
  };

  return (
    <section id="new-building-2027" className="py-20 bg-gradient-to-b from-[#081226] via-[#0c1a40] to-[#162a6b] text-white relative overflow-hidden border-y border-blue-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">

        {/* Header Tag & Title */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="text-xs font-mono uppercase tracking-widest text-amber-400 font-bold flex items-center justify-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{building.status}</span>
          </div>

          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.05 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-white tracking-tight text-balance"
          >
            {building.title}
          </motion.h2>

          <p className="text-blue-200 text-sm sm:text-base font-medium max-w-2xl mx-auto">
            {building.subtitle}
          </p>
        </div>

        {/* Milestone Timeline Bar */}
        <div className="mt-8 max-w-2xl mx-auto bg-white/10 rounded-2xl p-4 border border-blue-400/25 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 flex items-center justify-center text-amber-300 border border-amber-400/30">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <div className="font-mono uppercase text-blue-200 text-[10px]">Foundation Milestone</div>
              <div className="font-semibold text-white">{building.timeline.start}</div>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-1 text-amber-400">
            <span className="w-8 h-px bg-amber-400/50" />
            <ArrowRight className="w-4 h-4" />
            <span className="w-8 h-px bg-amber-400/50" />
          </div>

          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 flex items-center justify-center text-amber-300 border border-amber-400/30">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <div className="font-mono uppercase text-blue-200 text-[10px]">Grand Opening</div>
              <div className="font-semibold text-white">{building.timeline.completion}</div>
            </div>
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
          {building.keyMetrics.map((metric, i) => (
            <div
              key={i}
              className="bg-white/10 border border-blue-400/25 rounded-2xl p-5 text-center hover:border-amber-400 transition-colors"
            >
              <div className="text-3xl sm:text-4xl font-serif font-bold text-amber-400 tabular-nums">
                {metric.value}
              </div>
              <div className="text-xs sm:text-sm font-semibold text-white mt-1">
                {metric.label}
              </div>
              <div className="text-[11px] text-blue-100 mt-1">
                {metric.detail}
              </div>
            </div>
          ))}
        </div>

        {/* Construction & Architectural Renders Gallery */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          {building.images.map((img, index) => (
            <motion.div
              key={index}
              whileHover={{ y: -4 }}
              onClick={() => handleOpenZoom(img)}
              className="group bg-[#081226] rounded-2xl overflow-hidden border border-blue-700/60 shadow-xl cursor-pointer flex flex-col hover:border-amber-400 transition-colors"
            >
              <div className="relative aspect-[16/10] overflow-hidden bg-[#0c1a40]">
                <img
                  src={img.url}
                  alt={img.tag}
                  loading="lazy"
                  onError={handleImageFallback}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="px-3 py-1 bg-[#0c1a40] border-t border-blue-800 text-[11px] font-mono font-bold text-amber-400 flex items-center justify-between">
                  <span>{img.tag}</span>
                  <ZoomIn className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between">
                <p className="text-xs text-blue-100 leading-relaxed">{img.caption}</p>
                <div className="mt-3 pt-3 border-t border-blue-900 flex items-center justify-between text-xs text-amber-400 font-medium">
                  <span>2027 Architectural Render</span>
                  <span className="group-hover:translate-x-1 transition-transform">Inspect →</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Narrative & Architectural Features Split */}
        <div className="mt-14 bg-white/10 border border-blue-400/25 rounded-3xl p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-400 font-bold">
              <MonitorPlay className="w-4 h-4" />
              <span>Future-Ready Lower Secondary Hub</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-serif font-bold text-white leading-snug">
              Smart LED Classrooms, Advanced Computing Labs & High-Engagement Learning
            </h3>
            <div className="text-blue-100 text-xs sm:text-sm leading-relaxed space-y-3">
              {building.story.split('\n\n').map((para, idx) => (
                <p key={idx}>{para}</p>
              ))}
            </div>

            <div className="pt-4 border-t border-blue-800/70">
              <blockquote className="italic text-xs sm:text-sm text-amber-300 font-serif">
                "{building.tagline}"
              </blockquote>
              <div className="text-[11px] text-blue-200 font-sans mt-1">
                — {building.signature}
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#081226] rounded-2xl p-6 border border-blue-800 space-y-3">
            <h4 className="font-serif font-bold text-base text-amber-400 flex items-center gap-2">
              <Cpu className="w-4 h-4" />
              <span>Project Key Highlights</span>
            </h4>
            <div className="space-y-2.5 text-xs text-blue-100">
              {building.features.map((feat, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-blue-900 flex flex-col gap-2.5">
              <a
                href={general.admissionsPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 text-center rounded-lg bg-amber-400 hover:bg-amber-300 text-[#0c1a40] font-bold text-xs transition-colors shadow-md flex items-center justify-center gap-2"
              >
                <span>Reserve Lower Secondary Place (2026/27)</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>

      </div>

      {/* Interactive Lightbox Modal with Zoom Controls */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-[#081226]/95 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative max-w-[96vw] sm:max-w-[94vw] w-full h-[94vh] max-h-[94vh] bg-[#0c1a40] border border-blue-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="px-5 py-3.5 bg-[#081226] border-b border-blue-900 flex items-center justify-between text-white">
                <div>
                  <h3 className="font-serif font-bold text-sm sm:text-base text-amber-400">
                    {selectedImage.tag}
                  </h3>
                  <p className="text-[11px] text-blue-100 line-clamp-1">
                    {selectedImage.caption}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-blue-950 rounded-lg border border-blue-800 p-1 text-xs">
                    <button
                      onClick={handleZoomOut}
                      className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                      title="Zoom Out"
                    >
                      <ZoomOut className="w-4 h-4" />
                    </button>
                    <span className="px-2 font-mono text-[10px] text-amber-300 tabular-nums">
                      {Math.round(zoomScale * 100)}%
                    </span>
                    <button
                      onClick={handleZoomIn}
                      className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                      title="Zoom In"
                    >
                      <ZoomIn className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleResetZoom}
                      className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer ml-1"
                      title="Reset Zoom"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => downloadImageFile(selectedImage.url, selectedImage.tag)}
                    className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                    title="Download Image"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Download</span>
                  </button>

                  <button
                    onClick={() => setSelectedImage(null)}
                    className="p-1.5 rounded-lg bg-blue-900 hover:bg-blue-800 text-white transition-colors cursor-pointer"
                    aria-label="Close image preview"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-[#081226] min-h-[64vh]">
                <div
                  className="transition-transform duration-200 origin-center flex items-center justify-center"
                  style={{ transform: `scale(${zoomScale})` }}
                >
                  <img
                    src={selectedImage.url}
                    alt={selectedImage.tag}
                    onError={handleImageFallback}
                    className="h-[74vh] sm:h-[78vh] w-auto max-w-[90vw] object-contain rounded-xl shadow-2xl"
                  />
                </div>
              </div>

              <div className="px-5 py-2.5 bg-[#081226] border-t border-blue-900 flex items-center justify-between text-xs text-blue-200">
                <span>{general.name} · 2027 Lower School Expansion</span>
                <span className="text-amber-400 font-mono text-[11px]">Use +/- controls to inspect architectural details</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
