import React, { useState } from 'react';
import { useCmsSection } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { Trophy, Cpu, Home, Shield } from 'lucide-react';

interface CampusLifeProps {
  onNavigateToBoarding?: () => void;
  onNavigateToSports?: () => void;
  onNavigateToJaguars?: () => void;
}

export const CampusLifeSection: React.FC<CampusLifeProps> = ({
  onNavigateToBoarding,
  onNavigateToSports,
  onNavigateToJaguars
}) => {
  const houses = useCmsSection('houses');
  const boarding = useCmsSection('boarding');
  const [selectedHouse, setSelectedHouse] = useState<number>(0);

  return (
    <section id="campus-life" className="py-20 bg-blue-50/40 border-b border-blue-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">

        {/* The Four Official College Houses System */}
        <div className="bg-white p-8 sm:p-10 rounded-2xl border border-blue-100 shadow-xs mb-16">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 pb-6 border-b border-blue-100">
            <div>
              <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1">
                Collegial Heritage & House Spirit
              </div>
              <h3 className="text-2xl font-serif font-bold text-[#0c1a40]">
                The Four College Houses
              </h3>
              <p className="text-sm text-blue-950/80 mt-1">
                Every student at LKC belongs to one of four official houses—Bathoen (Red), Khama (Green), Sechele (Blue), and Moremi (Yellow)—fostering camaraderie, leadership, and friendly inter-house competition.
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Trophy className="w-5 h-5 text-amber-500" />
              <span className="text-xs font-semibold text-[#0c1a40] uppercase tracking-wider">
                Inter-House Cultural & Sporting Tradition
              </span>
            </div>
          </div>

          {/* Interactive Equal-Prominence House Selector */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
            {houses.map((house, idx) => {
              const hex = house.colorHex || house.color || '#0c1a40';
              const isSelected = selectedHouse === idx;
              return (
                <button
                  key={house.id || house.name}
                  type="button"
                  onClick={() => setSelectedHouse(idx)}
                  className={`p-4 rounded-xl border text-left transition-all cursor-pointer overflow-hidden relative ${
                    isSelected
                      ? 'bg-[#0c1a40] text-white border-amber-400 border-2 shadow-sm'
                      : 'bg-blue-50/50 border-blue-200 hover:bg-blue-50 text-[#0c1a40]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span
                      className="w-4 h-4 rounded-full border border-white/60 shadow-xs"
                      style={{ backgroundColor: hex }}
                    />
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md ${
                        isSelected ? 'bg-white/15 text-amber-300' : 'bg-white border border-blue-200 text-[#0c1a40]'
                      }`}
                    >
                      {house.colorName || 'House'}
                    </span>
                  </div>
                  <div className={`font-serif font-bold text-sm ${isSelected ? 'text-white' : 'text-[#0c1a40]'}`}>
                    {house.name}
                  </div>
                  <div className={`text-[11px] truncate mt-0.5 ${isSelected ? 'text-blue-200' : 'text-blue-800'}`}>
                    Patron: {house.patron}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected House Detail */}
          {houses[selectedHouse] && (
            <div className="p-6 bg-blue-50/60 rounded-xl border border-blue-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-3">
                <div className="flex items-center gap-3">
                  <span
                    className="w-5 h-5 rounded-full shrink-0 border border-white shadow-xs"
                    style={{ backgroundColor: houses[selectedHouse].colorHex || houses[selectedHouse].color || '#0c1a40' }}
                  />
                  <div>
                    <h4 className="text-xl font-serif font-bold text-[#0c1a40]">
                      {houses[selectedHouse].name}
                    </h4>
                    <div className="text-xs font-mono text-amber-700 font-semibold">
                      Official Colour: {houses[selectedHouse].colorName || 'Official'}
                    </div>
                  </div>
                </div>
                <div className="text-xs font-sans text-blue-900">
                  <span className="text-blue-700">House Patron:</span>{' '}
                  <span className="font-semibold text-[#0c1a40]">{houses[selectedHouse].patron}</span>
                </div>
              </div>
              <p className="text-sm text-blue-950 leading-relaxed font-sans">
                {houses[selectedHouse].description}
              </p>
            </div>
          )}
        </div>

        {/* Boarding Hostels & Pastoral Care Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

          <div className="p-8 bg-white rounded-2xl border border-blue-100 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-[#0c1a40]">
                  <Home className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40]">Campus Residential Community</h4>
                  <div className="text-xs text-[#162a6b] font-semibold font-sans">
                    Capacity: {boarding.capacity} Students · {boarding.currentResidents} Enrolled ({boarding.spacesOpen} Spaces Open)
                  </div>
                </div>
              </div>
              <p className="text-sm text-blue-950/90 leading-relaxed font-sans mb-4">
                {boarding.leadParagraph}
              </p>

              <div className="space-y-3 mb-4">
                {boarding.hostels.map((hostel) => {
                  const isGirls = hostel.id === 'girls-house' || hostel.name.toLowerCase().includes('olebile') || hostel.wing.toLowerCase().includes('girls');
                  return (
                    <div
                      key={hostel.id}
                      className={`p-3.5 rounded-xl border text-xs flex items-center gap-3 ${
                        isGirls
                          ? 'bg-pink-50 border-pink-300 text-pink-950'
                          : 'bg-blue-50 border-blue-300 text-blue-950'
                      }`}
                    >
                      {hostel.leaderImage ? (
                        <img
                          src={hostel.leaderImage}
                          alt={hostel.leaderName}
                          loading="lazy"
                          onError={handleImageFallback}
                          className={`w-12 h-12 rounded-xl object-cover object-top shrink-0 border-2 ${
                            isGirls ? 'border-pink-400' : 'border-blue-500'
                          }`}
                        />
                      ) : (
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-serif font-bold text-white shrink-0 ${
                          isGirls ? 'bg-pink-600' : 'bg-blue-700'
                        }`}>
                          {hostel.leaderName[0]}
                        </div>
                      )}
                      <div>
                        <span className={`font-bold text-sm block ${isGirls ? 'text-pink-900' : 'text-[#0c1a40]'}`}>
                          {hostel.name}
                        </span>
                        <span className={`block mt-0.5 ${isGirls ? 'text-pink-800' : 'text-blue-900'}`}>
                          {hostel.capacityBadge} · Led by <strong>{hostel.leaderName}</strong> ({hostel.leaderRole})
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-blue-100 space-y-3">
              <ul className="space-y-2 text-xs text-blue-950 font-sans">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  <span>Structured daily timetable with supervised evening study (18:30–20:30)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  <span>3 hot daily cafeteria meals (Breakfast, Lunch & Dinner)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  <span>Biometric-monitored dormitories, resident house staff & on-site nurse</span>
                </li>
              </ul>

              {onNavigateToBoarding && (
                <a
                  href="#boarding"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigateToBoarding();
                  }}
                  className="w-full py-2.5 px-3 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white font-semibold text-xs transition-colors cursor-pointer text-center block"
                >
                  Explore Boarding Houses, Cafeteria & Daily Routines →
                </a>
              )}
            </div>
          </div>

          <div className="p-8 bg-white rounded-2xl border border-blue-100 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-[#0c1a40]">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-lg text-[#0c1a40]">Kolobeng Jaguars & Student Societies</h4>
                  <div className="text-xs text-amber-700 font-semibold font-sans">Over 24 Active Extracurricular Clubs</div>
                </div>
              </div>
              <p className="text-sm text-blue-950/90 leading-relaxed font-sans mb-4">
                Students engage in enriching extracurriculars that cultivate intellect and social responsibility. From high-level diplomacy in Model UN to cultural vibrancy in the traditional marimba band.
              </p>
              <div className="grid grid-cols-2 gap-2.5 text-xs text-[#0c1a40] font-sans">
                <div className="p-3 bg-blue-50/70 rounded-lg border border-blue-100">
                  <span className="font-semibold block text-[#0c1a40]">Debate & Public Speaking</span>
                  <span className="text-blue-800 text-[11px]">SADC Pan-African Champions</span>
                </div>
                <div className="p-3 bg-blue-50/70 rounded-lg border border-blue-100">
                  <span className="font-semibold block text-[#0c1a40]">Robotics & Coding</span>
                  <span className="text-blue-800 text-[11px]">VEX Robotics Academy</span>
                </div>
                <div className="p-3 bg-blue-50/70 rounded-lg border border-blue-100">
                  <span className="font-semibold block text-[#0c1a40]">Marimba & Choir</span>
                  <span className="text-blue-800 text-[11px]">Botswana Cultural Arts</span>
                </div>
                <div className="p-3 bg-blue-50/70 rounded-lg border border-blue-100">
                  <span className="font-semibold block text-[#0c1a40]">President's Award</span>
                  <span className="text-blue-800 text-[11px]">Duke of Edinburgh Int.</span>
                </div>
                <div className="p-3 bg-blue-50/70 rounded-lg border border-blue-100">
                  <span className="font-semibold block text-[#0c1a40]">Jaguars Rugby</span>
                  <span className="text-blue-800 text-[11px]">LKC 1st XV & U16 Squads</span>
                </div>
                <div className="p-3 bg-blue-50/70 rounded-lg border border-blue-100">
                  <span className="font-semibold block text-[#0c1a40]">Model United Nations</span>
                  <span className="text-blue-800 text-[11px]">Regional Diplomacy</span>
                </div>
              </div>
            </div>

            <div className="pt-4 mt-6 border-t border-blue-100 flex flex-wrap items-center justify-between gap-2 text-xs font-sans">
              <div className="flex items-center gap-2">
                {onNavigateToSports && (
                  <a
                    href="#sports"
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigateToSports();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#0c1a40] font-semibold border border-blue-200 cursor-pointer"
                  >
                    LKC Sports →
                  </a>
                )}
                {onNavigateToJaguars && (
                  <a
                    href="#jaguars"
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigateToJaguars();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-amber-100 hover:bg-amber-200 text-[#0c1a40] font-semibold border border-amber-300 cursor-pointer flex items-center gap-1"
                  >
                    <Shield className="w-3 h-3 text-amber-700" />
                    <span>The Jaguars →</span>
                  </a>
                )}
              </div>
              <span className="font-semibold text-[#0c1a40]">12 Varsity Disciplines</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
