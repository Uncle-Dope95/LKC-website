import React from 'react';
import { Building2, Image as ImageIcon, PlayCircle } from 'lucide-react';
import { AboutMission } from './AboutMission';
import { BuildingSection } from './BuildingSection';
import { CampusLifeSection } from './CampusLifeSection';
import { useCmsSection, usePublishedCmsItems } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import type { PageKey } from '../types';

interface CampusPageProps {
  onNavigate: (page: PageKey) => void;
  onOpenAdmissions: () => void;
}

export const CampusPage: React.FC<CampusPageProps> = ({
  onNavigate,
  onOpenAdmissions,
}) => {
  const general = useCmsSection('general');
  const hero = useCmsSection('hero');
  const media = useCmsSection('media');
  const campusItems = usePublishedCmsItems('campus');

  const campusVideoAsset =
    media.find((m) => m.id === 'm-18') ||
    media.find((m) => m.mediaType === 'video' && m.category === 'Campus') ||
    media.find((m) => m.mediaType === 'video');
  const campusVideoUrl = campusVideoAsset?.url || './assets/aistudio/school_video_5ac9eb5b.mp4';
  const campusVideoPoster = hero.heroImage || './assets/aistudio/image_efcc4027.png';

  return (
    <div className="bg-white min-h-screen text-[#0c1a40]">
      <div className="bg-gradient-to-br from-[#081226] via-[#0c1a40] to-[#162a6b] text-white py-14 px-4 sm:px-6 border-b border-blue-900">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-widest mb-2">
            <Building2 className="w-4 h-4" />
            <span>{general.name} · Gaborone Block 8 Campus</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-serif font-bold tracking-tight">
            Campus, Heritage, Executive Leadership & Facilities
          </h1>
          <p className="text-sm sm:text-base text-blue-100 mt-3 max-w-2xl leading-relaxed">
            Explore our 1847 Kolobeng heritage, Executive Governance & Senior Management Team, 2027 Forms 1 & 2 Wing expansion, and Block 8 learning environment.
          </p>
        </div>
      </div>

      <AboutMission />

      <BuildingSection onOpenAdmissions={onOpenAdmissions} />

      <CampusLifeSection
        onNavigateToBoarding={() => onNavigate('boarding')}
        onNavigateToSports={() => onNavigate('sports')}
        onNavigateToJaguars={() => onNavigate('jaguars')}
      />

      {/* Campus & School Video Showcase */}
      <section id="campus-video" className="py-16 px-4 sm:px-6 bg-white border-t border-blue-100">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-700 font-bold mb-2">
                <PlayCircle className="w-4 h-4" />
                <span>Campus Film · Block 8 Gaborone</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
                Inside Livingstone Kolobeng College
              </h2>
              <p className="text-xs sm:text-sm text-blue-900/80 mt-1.5 max-w-2xl">
                Walk through our shaded courtyard pathways, Sechele Hall, classroom blocks, and Jaguars rugby & sporting fields.
              </p>
            </div>
          </div>

          <div className="rounded-2xl overflow-hidden border-2 border-blue-200 bg-[#081226] shadow-lg">
            <video
              controls
              playsInline
              preload="metadata"
              poster={campusVideoPoster}
              aria-label="Livingstone Kolobeng College Campus Tour Video"
              className="w-full max-h-[540px] object-contain bg-[#081226] block mx-auto"
            >
              <source src={campusVideoUrl} type="video/mp4" />
              Your browser does not support embedded video playback.
            </video>
          </div>
        </div>
      </section>

      {campusItems.length > 0 && (
        <section className="py-16 px-4 sm:px-6 bg-blue-50/40 border-t border-blue-100">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-700 font-bold mb-2">
              <ImageIcon className="w-4 h-4" />
              <span>Campus Updates & Projects</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40] mb-8">
              Published Campus Notices & Expansions
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {campusItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl border border-blue-200 overflow-hidden shadow-xs flex flex-col justify-between"
                >
                  <div>
                    {item.thumbnailUrl && (
                      <div className="aspect-[16/9] bg-[#081226] overflow-hidden">
                        <img
                          src={item.thumbnailUrl}
                          alt={item.title}
                          loading="lazy"
                          onError={handleImageFallback}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    <div className="p-5">
                      <span className="text-[10px] font-mono uppercase text-amber-700 font-bold">
                        {item.category}
                      </span>
                      <h3 className="font-serif font-bold text-lg text-[#0c1a40] mt-1 mb-2">
                        {item.title}
                      </h3>
                      <p className="text-xs text-blue-950/80 leading-relaxed">
                        {item.excerpt}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
