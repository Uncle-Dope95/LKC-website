import React, { useState } from 'react';
import { FileText } from 'lucide-react';
import { useCmsSection } from '../services/cmsDataService';
import { AcademicVisionAndProgrammes } from './AcademicVisionAndProgrammes';

interface CurriculumSectionProps {
  onOpenProspectus: () => void;
}

export const CurriculumSection: React.FC<CurriculumSectionProps> = ({ onOpenProspectus }) => {
  const curriculumData = useCmsSection('curriculum');
  const [activeLevel, setActiveLevel] = useState<'preschool' | 'lower-secondary' | 'pre-igcse' | 'igcse' | 'a-levels'>('igcse');
  const [streamFilter, setStreamFilter] = useState<string>('all');

  const currentLevelData = curriculumData[activeLevel] || curriculumData['igcse'] || Object.values(curriculumData)[0];

  const filteredSubjects = (currentLevelData?.subjects || []).filter((subj) => {
    if (streamFilter === 'all') return true;
    return subj.stream.toLowerCase() === streamFilter.toLowerCase();
  });

  const levelTabs = [
    { id: 'preschool', label: 'Preschool (Ages 3–5)' },
    { id: 'lower-secondary', label: 'Lower Secondary (Forms 1–2)' },
    { id: 'pre-igcse', label: 'Pre-IGCSE (Form 3)' },
    { id: 'igcse', label: 'Cambridge IGCSE (Forms 4–5)' },
    { id: 'a-levels', label: 'Cambridge AS & A Levels' },
  ].filter((t) => Boolean(curriculumData[t.id]));

  return (
    <section id="academics" className="py-20 bg-white border-b border-blue-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">

        {/* Section Title */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-2">
            Academic Programs · Cambridge Assessment International Education
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#0c1a40] tracking-tight text-balance">
            World-Recognized Cambridge Academic Pathways
          </h2>
          <div className="w-16 h-0.5 bg-amber-500 mt-4 mb-6" />
          <p className="text-base text-blue-950/85 leading-relaxed font-sans">
            Our instructional framework follows the internationally acclaimed University of Cambridge Local Examinations Syndicate (UCLES) syllabus. From foundational inquiry in Preschool through Form 1 to rigorous A-Level (A2) research, students develop deep domain mastery and critical synthesis.
          </p>
        </div>

        {/* Level Switcher */}
        <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-blue-50 rounded-xl mb-8 border border-blue-200">
          {levelTabs.map((level) => (
            <button
              key={level.id}
              onClick={() => { setActiveLevel(level.id as typeof activeLevel); setStreamFilter('all'); }}
              className={`flex-1 min-w-[140px] py-2.5 px-3 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap text-center ${
                activeLevel === level.id
                  ? 'bg-[#0c1a40] text-white shadow-xs font-semibold border border-blue-900'
                  : 'text-[#0c1a40] hover:bg-white'
              }`}
            >
              {level.label}
            </button>
          ))}
        </div>

        {/* Level Overview Banner */}
        {currentLevelData && (
          <div className="p-6 sm:p-8 bg-blue-50/60 rounded-xl border border-blue-200 mb-10">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="max-w-2xl">
                <div className="text-xs font-mono uppercase tracking-wider text-amber-700 font-semibold mb-1">
                  {currentLevelData.subtitle}
                </div>
                <h3 className="text-xl sm:text-2xl font-serif font-bold text-[#0c1a40] mb-2">
                  {currentLevelData.title}
                </h3>
                <p className="text-sm text-blue-950/85 leading-relaxed font-sans">
                  {currentLevelData.description}
                </p>
              </div>
              <div className="shrink-0 flex items-center gap-3">
                <button
                  onClick={onOpenProspectus}
                  className="px-4 py-2 text-xs font-semibold text-[#0c1a40] bg-white border border-blue-300 rounded-lg hover:bg-amber-50 hover:border-amber-400 transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <FileText className="w-3.5 h-3.5 text-amber-600" />
                  <span>Syllabus Guide</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Stream Filter */}
        <div className="flex items-center justify-between flex-wrap gap-4 mb-6 pb-4 border-b border-blue-100">
          <div className="text-xs uppercase tracking-wider text-blue-800 font-sans font-semibold">
            Filter by Academic Discipline:
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            {['all', 'sciences', 'commercial', 'humanities', 'languages', 'creative & tech'].map((stream) => (
              <button
                key={stream}
                onClick={() => setStreamFilter(stream)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer capitalize whitespace-nowrap ${
                  streamFilter === stream
                    ? 'bg-[#0c1a40] text-amber-300 font-semibold'
                    : 'bg-blue-50 text-[#0c1a40] hover:bg-blue-100'
                }`}
              >
                {stream === 'all' ? 'All Subjects' : stream}
              </button>
            ))}
          </div>
        </div>

        {/* Subjects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {filteredSubjects.map((subj) => (
            <div
              key={subj.code + subj.name}
              className="p-6 bg-white rounded-xl border border-blue-200 hover:border-amber-400 transition-all flex flex-col justify-between group shadow-xs"
            >
              <div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-blue-800 font-sans mb-2.5">
                  <span className="font-mono font-semibold">{subj.code}</span>
                  <span aria-hidden="true">·</span>
                  <span>{subj.stream}</span>
                  {subj.cambridgeCode && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-[#0c1a40] font-medium">CIE {subj.cambridgeCode}</span>
                    </>
                  )}
                  {subj.isCore && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-amber-700 font-semibold">Compulsory</span>
                    </>
                  )}
                </div>

                <h4 className="text-base font-serif font-bold text-[#0c1a40] group-hover:text-blue-700 transition-colors mb-2">
                  {subj.name}
                </h4>

                <p className="text-xs sm:text-sm text-blue-950/80 leading-relaxed font-sans">
                  {subj.description}
                </p>
              </div>

              <div className="mt-5 pt-4 border-t border-blue-100 flex items-center justify-between text-xs text-blue-800 font-sans">
                <span>External Cambridge Assessment</span>
                <span className="font-mono text-amber-700 font-semibold">Standard / Ext</span>
              </div>
            </div>
          ))}
        </div>

        {/* University Career Pathway Packages */}
        <div className="bg-[#0c1a40] text-white p-8 rounded-xl border border-blue-900">
          <div className="max-w-2xl mb-8">
            <div className="text-xs uppercase tracking-widest text-amber-400 font-mono mb-1">
              Curricular Guidance · Higher Education Readiness
            </div>
            <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-2">
              Structured University Preparation Streams
            </h3>
            <p className="text-xs sm:text-sm text-blue-100 font-sans">
              Our academic advisors guide students in structuring Cambridge subject choices tailored to specific global faculty entrance requirements.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-5 bg-white/10 border border-blue-400/25 rounded-lg">
              <div className="text-amber-400 text-xs font-semibold uppercase tracking-wider mb-2">Health Sciences & Medicine</div>
              <p className="text-xs text-white mb-3">Biology · Chemistry · Mathematics · Physics</p>
              <div className="text-[11px] text-blue-100">Preparation for Medicine, Biomedical Science, Dentistry, and Pharmacy faculties globally.</div>
            </div>

            <div className="p-5 bg-white/10 border border-blue-400/25 rounded-lg">
              <div className="text-amber-400 text-xs font-semibold uppercase tracking-wider mb-2">Engineering & Technology</div>
              <p className="text-xs text-white mb-3">Mathematics · Physics · Computer Science · Chemistry</p>
              <div className="text-[11px] text-blue-100">Preparation for Aeronautical, Electrical, Civil, and Mechanical Engineering degrees.</div>
            </div>

            <div className="p-5 bg-white/10 border border-blue-400/25 rounded-lg">
              <div className="text-amber-400 text-xs font-semibold uppercase tracking-wider mb-2">Actuarial & Business</div>
              <p className="text-xs text-white mb-3">Mathematics · Economics · Accounting · Business</p>
              <div className="text-[11px] text-blue-100">Preparation for Actuarial Science, Finance, Quantitative Economics, and Management.</div>
            </div>

            <div className="p-5 bg-white/10 border border-blue-400/25 rounded-lg">
              <div className="text-amber-400 text-xs font-semibold uppercase tracking-wider mb-2">Law & Humanities</div>
              <p className="text-xs text-white mb-3">English Lang/Lit · History · Geography · French</p>
              <div className="text-[11px] text-blue-100">Preparation for LLB Law, International Diplomacy, Political Science, and Public Policy.</div>
            </div>
          </div>
        </div>

        <AcademicVisionAndProgrammes showCurriculumStages={true} />

      </div>
    </section>
  );
};
