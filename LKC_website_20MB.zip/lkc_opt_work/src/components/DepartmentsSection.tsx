import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAcademicLeadership, useCmsSection, usePublishedCmsItems } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { DepartmentInfo, TeacherProfile, YearGroupKey } from '../types';
import {
  getTeacherLeadershipPosition,
  sortTeachersForDepartment,
  sortTeachersForDirectory,
} from '../utils/staffHierarchy';
import { matchesSearchTokens } from '../utils/profileSearch';
import { AcademicVisionAndProgrammes } from './AcademicVisionAndProgrammes';
import {
  Calculator,
  FlaskConical,
  Palette,
  Trophy,
  Globe,
  Languages,
  Briefcase,
  Cpu,
  Search,
  X,
  CheckCircle2,
  BookOpen,
  Users,
  ChevronRight,
  Download,
  GraduationCap,
  HeartHandshake,
  ShieldCheck,
  UserCheck,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Building2,
  Sparkles,
  Newspaper
} from 'lucide-react';
import { downloadImageFile, openImageViewer } from './ImageLightboxModal';

interface DepartmentsSectionProps {
  onOpenProspectus: () => void;
  onOpenAdmissions: () => void;
}

const YEAR_GROUP_ORDER: YearGroupKey[] = [
  'Form 1',
  'Form 2',
  'Form 3',
  'Form 4',
  'Form 5',
  'A Level',
];

function formatDepartmentProfileLabel(departmentId?: string, departmentName?: string): string {
  switch (departmentId) {
    case 'dept-maths':
      return 'Mathematics';
    case 'dept-science':
      return 'Science';
    case 'dept-creatives':
      return 'Creatives';
    case 'dept-pe':
      return 'Physical Education';
    case 'dept-humanities':
      return 'Humanities';
    case 'dept-languages':
      return 'Languages';
    case 'dept-commercials':
      return 'Commercials';
    case 'dept-ict':
      return 'ICT';
    default:
      return (
        (departmentName || 'Academic')
          .replace(/\s*Department$/i, '')
          .replace(/\s*&\s*Logistics$/i, '')
          .trim() || 'Academic'
      );
  }
}

function formatDepartmentTeacherTitle(departmentId?: string, departmentName?: string): string {
  return `${formatDepartmentProfileLabel(departmentId, departmentName)} Teacher`;
}

export const DepartmentsSection: React.FC<DepartmentsSectionProps> = ({ onOpenProspectus }) => {
  const departments = useCmsSection('departments');
  const teachers = useCmsSection('teachers');
  const general = useCmsSection('general');
  const academicLeadership = useAcademicLeadership();
  const publishedDeptCmsItems = usePublishedCmsItems('departments');

  const [selectedDeptId, setSelectedDeptId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewMode, setViewMode] = useState<'curriculum' | 'faculty'>('curriculum');
  const [activeTeacherModal, setActiveTeacherModal] = useState<TeacherProfile | null>(null);
  const [teacherPhotoZoom, setTeacherPhotoZoom] = useState<number>(1);

  const openTeacherProfileModal = (teacher: TeacherProfile) => {
    setActiveTeacherModal(teacher);
    setTeacherPhotoZoom(1);
  };

  const publishedAssignments = useMemo(
    () =>
      (academicLeadership.assignments || []).filter(
        (a) => a.status === 'published' && a.staff && a.staff.status === 'published'
      ),
    [academicLeadership]
  );

  const headsOfYearByForm = useMemo(() => {
    const hoys = publishedAssignments.filter((a) => a.assignmentType === 'head_of_year');
    return YEAR_GROUP_ORDER.map((yg) => ({
      yearGroup: yg,
      assignments: hoys
        .filter((a) => a.yearGroup === yg)
        .sort((a, b) => a.sortOrder - b.sortOrder),
    })).filter((group) => group.assignments.length > 0);
  }, [publishedAssignments]);

  const aLevelCoordinators = useMemo(
    () =>
      publishedAssignments
        .filter((a) => a.assignmentType === 'a_level_coordinator')
        .sort((a, b) => a.sortOrder - b.sortOrder),
    [publishedAssignments]
  );

  const pastoralProfiles = useMemo(
    () =>
      publishedAssignments
        .filter((a) => a.assignmentType === 'pastoral_care')
        .sort((a, b) => a.sortOrder - b.sortOrder),
    [publishedAssignments]
  );

  const getDepartmentIcon = (iconName: string) => {
    switch (iconName) {
      case 'Calculator': return <Calculator className="w-5 h-5" />;
      case 'FlaskConical': return <FlaskConical className="w-5 h-5" />;
      case 'Palette': return <Palette className="w-5 h-5" />;
      case 'Trophy': return <Trophy className="w-5 h-5" />;
      case 'Globe': return <Globe className="w-5 h-5" />;
      case 'Languages': return <Languages className="w-5 h-5" />;
      case 'Briefcase': return <Briefcase className="w-5 h-5" />;
      case 'Cpu': return <Cpu className="w-5 h-5" />;
      default: return <BookOpen className="w-5 h-5" />;
    }
  };

  const deptById = useMemo(
    () => new Map(departments.map((d) => [d.id, d])),
    [departments]
  );

  const visibleTeachers = useMemo(
    () =>
      sortTeachersForDirectory(
        teachers.filter((t) => t.status !== 'unpublished' && t.status !== 'archived'),
        departments
      ),
    [teachers, departments]
  );

  // Department teacher counts
  const deptCounts: Record<string, number> = useMemo(() => {
    const counts: Record<string, number> = {};
    visibleTeachers.forEach(t => {
      counts[t.departmentId] = (counts[t.departmentId] || 0) + 1;
    });
    return counts;
  }, [visibleTeachers]);

  // Filtered departments
  const filteredDepartments = useMemo(() => {
    return departments.filter(dept => {
      const matchesTab = selectedDeptId === 'all' || dept.id === selectedDeptId;
      if (!matchesTab) return false;

      if (!searchQuery.trim()) return true;

      const deptTeachers = visibleTeachers.filter(t => t.departmentId === dept.id);
      return matchesSearchTokens(searchQuery, [
        dept.name,
        dept.shortDescription,
        dept.curriculum,
        dept.subjects,
        dept.keyAreas || [],
        dept.activities || [],
        dept.facilities || [],
        dept.headOfDepartment?.name,
        dept.headOfDepartment?.title,
        ...deptTeachers.flatMap((t) => [t.name, formatDepartmentTeacherTitle(t.departmentId, t.departmentName), ...(t.subjects || [])]),
      ]);
    });
  }, [departments, visibleTeachers, selectedDeptId, searchQuery]);

  // Filtered teachers (retains HOD-first departmental hierarchy from visibleTeachers)
  const filteredTeachers = useMemo(() => {
    return visibleTeachers.filter(teacher => {
      const matchesTab = selectedDeptId === 'all' || teacher.departmentId === selectedDeptId;
      if (!matchesTab) return false;

      return matchesSearchTokens(searchQuery, [
        teacher.name,
        teacher.departmentName,
        formatDepartmentTeacherTitle(teacher.departmentId, teacher.departmentName),
        teacher.subjects,
        teacher.role,
        teacher.qualifications,
        teacher.bio,
      ]);
    });
  }, [visibleTeachers, selectedDeptId, searchQuery]);

  const activeDetailDept: DepartmentInfo | undefined =
    departments.find(d => d.id === selectedDeptId) || filteredDepartments[0] || departments[0];

  const activeDeptTeachers = useMemo(
    () =>
      activeDetailDept
        ? sortTeachersForDepartment(
            visibleTeachers.filter((t) => t.departmentId === activeDetailDept.id),
            activeDetailDept
          )
        : [],
    [visibleTeachers, activeDetailDept]
  );

  const activeDeptNews = useMemo(() => {
    if (!activeDetailDept) return [];
    const deptTokens = [
      activeDetailDept.slug.toLowerCase(),
      formatDepartmentProfileLabel(activeDetailDept.id, activeDetailDept.name).toLowerCase(),
    ];
    return publishedDeptCmsItems.filter((item) => {
      const haystack = `${item.category} ${item.title} ${item.excerpt}`.toLowerCase();
      return deptTokens.some((tok) => haystack.includes(tok));
    });
  }, [activeDetailDept, publishedDeptCmsItems]);

  const handleDownloadDeptSyllabus = (dept: DepartmentInfo) => {
    const deptTeachers = sortTeachersForDepartment(
      visibleTeachers.filter((t) => t.departmentId === dept.id),
      dept
    );
    const keyAreas = dept.keyAreas && dept.keyAreas.length > 0 ? dept.keyAreas : dept.features;
    const clubs = dept.activities && dept.activities.length > 0 ? dept.activities : dept.features;
    const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>${dept.name} — Curriculum & Syllabus | ${general.name}</title>
<style>
  body { font-family: Georgia, serif; color: #0c1a40; max-width: 820px; margin: 40px auto; padding: 24px; line-height: 1.6; }
  h1, h2, h3 { color: #0c1a40; }
  .header { border-bottom: 3px solid #f59e0b; padding-bottom: 16px; margin-bottom: 24px; }
  .badge { display: inline-block; background: #0c1a40; color: #fbbf24; padding: 4px 12px; font-size: 12px; font-family: monospace; text-transform: uppercase; border-radius: 4px; }
  .card { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 10px; padding: 16px; margin: 16px 0; }
  ul { padding-left: 20px; }
  .footer { margin-top: 32px; border-top: 1px solid #bfdbfe; padding-top: 14px; font-size: 12px; color: #1e3a8a; }
</style>
</head>
<body>
  <div class="header">
    <span class="badge">${general.name} · Academic Programme Overview</span>
    <h1>${dept.name}</h1>
    <p><strong>${dept.headOfDepartment.name} (${dept.headOfDepartment.title})</strong> · ${dept.curriculum}</p>
  </div>
  <p>${dept.shortDescription}</p>
  <div class="card">
    <h3>Academic Subjects</h3>
    <ul>${dept.subjects.map(s => `<li>${s}</li>`).join('')}</ul>
  </div>
  <div class="card">
    <h3>Key Areas of Learning</h3>
    <ul>${keyAreas.map(f => `<li>${f}</li>`).join('')}</ul>
  </div>
  <div class="card">
    <h3>${dept.id === 'dept-pe' ? 'Sporting Activities & Development Programmes' : 'Clubs and Co-Curricular Activities'}</h3>
    <ul>${clubs.map(a => `<li>${a}</li>`).join('')}</ul>
  </div>
  <div class="card">
    <h3>Department Faculty (${deptTeachers.length} Educators)</h3>
    <ul>${deptTeachers.map(t => `<li><strong>${t.name}</strong> — ${formatDepartmentTeacherTitle(t.departmentId, t.departmentName)}</li>`).join('')}</ul>
  </div>
  <div class="footer">
    ${general.name} · ${general.address.plot}, ${general.address.area}, ${general.address.city} · Tel: ${general.contacts.phone} · Email: ${general.contacts.admissionsEmail}
  </div>
</body>
</html>`;

    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LKC-${dept.slug || dept.id}-Syllabus.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <section id="departments" className="py-20 bg-blue-50/40 border-b border-blue-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">

        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div className="max-w-3xl">
            <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span>Academic Departments & Teaching Staff · {departments.length} Disciplines · {visibleTeachers.length} Teachers</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#0c1a40] tracking-tight text-balance">
              LKC Academic Departments & Teachers
            </h2>
            <div className="w-16 h-0.5 bg-amber-500 mt-4 mb-3" />
            <p className="text-sm sm:text-base text-blue-950 leading-relaxed font-sans">
              Under the academic leadership of Principal Dr. Jeff Ramsay and Vice Principal Dr. Fedious Mutenheri, our {visibleTeachers.length} certified subject teachers guide students through rigorous Cambridge syllabi across {departments.length} specialized departments.
            </p>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center bg-blue-100/80 p-1 rounded-xl self-start md:self-auto shrink-0 border border-blue-200">
            <button
              onClick={() => setViewMode('curriculum')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'curriculum'
                  ? 'bg-[#0c1a40] text-white shadow-xs'
                  : 'text-[#0c1a40] hover:text-[#162a6b]'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-400" />
              <span>Curriculum & Syllabi</span>
            </button>
            <button
              onClick={() => setViewMode('faculty')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'faculty'
                  ? 'bg-[#0c1a40] text-white shadow-xs'
                  : 'text-[#0c1a40] hover:text-[#162a6b]'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-amber-400" />
              <span>Teachers Directory ({visibleTeachers.length})</span>
            </button>
          </div>
        </div>

        {/* Search Bar & Instant Filter Tabs */}
        <div className="bg-white p-4 rounded-2xl border border-blue-100 shadow-xs mb-8">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-blue-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search departments, subjects (e.g. Physics, Economics), or teachers (e.g. Chivorese, Barot)..."
                className="w-full pl-10 pr-10 py-2.5 bg-blue-50/50 border border-blue-200 rounded-xl text-xs sm:text-sm text-[#0c1a40] placeholder:text-blue-400 focus:outline-hidden focus:border-[#0c1a40] focus:ring-1 focus:ring-[#0c1a40] transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-blue-400 hover:text-[#0c1a40] p-1 cursor-pointer"
                  aria-label="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {searchQuery && (
              <span className="text-xs text-blue-900 whitespace-nowrap self-center font-mono">
                Found {viewMode === 'faculty' ? `${filteredTeachers.length} teachers` : `${filteredDepartments.length} departments`}
              </span>
            )}
          </div>

          {/* Department Tab Buttons */}
          <div className="mt-4 pt-3 border-t border-blue-100 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
            <button
              onClick={() => setSelectedDeptId('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedDeptId === 'all'
                  ? 'bg-[#0c1a40] text-white shadow-xs'
                  : 'bg-blue-50 text-[#0c1a40] hover:bg-blue-100'
              }`}
            >
              <span>All Departments</span>
              <span className={`text-[10px] font-mono px-1.5 rounded-full ${selectedDeptId === 'all' ? 'bg-amber-400 text-[#081226] font-bold' : 'bg-white text-[#0c1a40] border border-blue-200'}`}>
                {departments.length}
              </span>
            </button>

            {departments.map((dept) => {
              const isSelected = dept.id === selectedDeptId;
              const count = deptCounts[dept.id] || 0;
              return (
                <button
                  key={dept.id}
                  onClick={() => setSelectedDeptId(dept.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-[#0c1a40] text-white font-semibold shadow-xs'
                      : 'bg-blue-50 text-[#0c1a40] hover:bg-blue-100'
                  }`}
                >
                  <span>{dept.name.replace(' Department', '')}</span>
                  <span className={`text-[10px] font-mono px-1.5 rounded-full ${isSelected ? 'bg-amber-400 text-[#081226] font-bold' : 'bg-white text-[#0c1a40] border border-blue-200'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* VIEW MODE 1: CURRICULUM & SYLLABI */}
        {viewMode === 'curriculum' && (
          <div className="space-y-8">
            {filteredDepartments.length === 0 ? (
              <div className="p-12 text-center bg-white rounded-2xl border border-blue-100">
                <BookOpen className="w-10 h-10 text-blue-300 mx-auto mb-3" />
                <h4 className="text-base font-semibold text-[#0c1a40]">No departments match "{searchQuery}"</h4>
                <p className="text-xs text-blue-900 mt-1">Try resetting the search term or switching to the All Departments tab.</p>
                <button
                  onClick={() => { setSearchQuery(''); setSelectedDeptId('all'); }}
                  className="mt-4 px-4 py-2 bg-[#0c1a40] text-white text-xs font-semibold rounded-lg hover:bg-[#162a6b] cursor-pointer"
                >
                  Reset Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {filteredDepartments.map((dept) => {
                  const isSelected = activeDetailDept?.id === dept.id;
                  const teachersInDept = visibleTeachers.filter(t => t.departmentId === dept.id);
                  const count = teachersInDept.length;

                  return (
                    <motion.div
                      key={dept.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2 }}
                      onClick={() => setSelectedDeptId(dept.id)}
                      className={`p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'bg-gradient-to-br from-[#0c1a40] to-[#162a6b] text-white border-[#0c1a40] shadow-md'
                          : 'bg-white text-[#0c1a40] border-blue-100 hover:border-amber-400 hover:shadow-sm'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <div className={`p-2.5 rounded-xl ${isSelected ? 'bg-amber-400 text-[#081226]' : 'bg-blue-50 text-[#0c1a40]'}`}>
                            {getDepartmentIcon(dept.icon)}
                          </div>
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                            isSelected ? 'bg-white/20 text-amber-300' : 'bg-blue-50 text-[#0c1a40] border border-blue-100'
                          }`}>
                            {count} Teachers
                          </span>
                        </div>

                        <h3 className={`text-base font-serif font-bold ${isSelected ? 'text-white' : 'text-[#0c1a40]'} leading-snug mb-1`}>
                          {dept.name}
                        </h3>
                        <p className={`text-xs line-clamp-2 leading-relaxed mb-3 ${isSelected ? 'text-blue-100' : 'text-blue-950/80'}`}>
                          {dept.shortDescription}
                        </p>
                      </div>

                      <div>
                        <div className="flex flex-wrap gap-1 mb-3">
                          {dept.subjects.slice(0, 3).map((s, idx) => (
                            <span
                              key={idx}
                              className={`text-[10px] px-2 py-0.5 rounded-md ${
                                isSelected ? 'bg-white/10 text-blue-100' : 'bg-blue-50 text-[#0c1a40]'
                              }`}
                            >
                              {s}
                            </span>
                          ))}
                          {dept.subjects.length > 3 && (
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-mono ${isSelected ? 'text-amber-300' : 'text-blue-700'}`}>
                              +{dept.subjects.length - 3} more
                            </span>
                          )}
                        </div>

                        <div className={`pt-3 border-t text-xs flex items-center justify-between ${isSelected ? 'border-white/15 text-amber-300' : 'border-blue-100 text-[#0c1a40]'}`}>
                          <span className="font-semibold truncate">{dept.headOfDepartment.name}</span>
                          <ChevronRight className="w-3.5 h-3.5 shrink-0" />
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}

            {/* Detailed Selected Department Showcase (8-Part Academic Structure) */}
            {activeDetailDept && (
              <div className="bg-white rounded-2xl border border-blue-100 p-6 sm:p-10 shadow-xs space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

                  {/* Left 7 cols: Overview, HOD & Staff, Subjects, Cambridge Info, Key Areas & Facilities */}
                  <div className="lg:col-span-7 space-y-6">
                    {/* 1. Department Overview & Introduction */}
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-amber-100 text-[#0c1a40] rounded-xl border border-amber-300">
                        {getDepartmentIcon(activeDetailDept.icon)}
                      </div>
                      <div>
                        <span className="text-xs font-mono uppercase tracking-wider text-amber-700 font-bold">
                          Cambridge International School · Form 1 to A Level (A2)
                        </span>
                        <h3 className="text-2xl font-serif font-bold text-[#0c1a40]">
                          {activeDetailDept.name}
                        </h3>
                      </div>
                    </div>

                    <p className="text-sm sm:text-base text-blue-950 leading-relaxed font-sans">
                      {activeDetailDept.shortDescription}
                    </p>

                    {/* 2. Head of Department & Teaching Staff */}
                    {activeDetailDept.headOfDepartment.status !== 'unpublished' && (
                      <div className="p-5 rounded-2xl bg-blue-50/70 border border-blue-200 flex flex-col sm:flex-row gap-4 items-start">
                        <div className="w-20 h-24 rounded-xl overflow-hidden bg-[#0c1a40] border-2 border-amber-400 shrink-0">
                          {activeDetailDept.headOfDepartment.image ? (
                            <img
                              key={`${activeDetailDept.id}-${activeDetailDept.headOfDepartment.image}`}
                              src={activeDetailDept.headOfDepartment.image}
                              alt={activeDetailDept.headOfDepartment.name}
                              onError={handleImageFallback}
                              onClick={() =>
                                openImageViewer({
                                  src: activeDetailDept.headOfDepartment.image!,
                                  title: activeDetailDept.headOfDepartment.name,
                                  subtitle: `Head of Department · ${formatDepartmentProfileLabel(activeDetailDept.id, activeDetailDept.name)}`,
                                })
                              }
                              data-zoomable-image="true"
                              className="w-full h-full object-cover object-top cursor-zoom-in hover:scale-105 transition-transform duration-200"
                            />
                          ) : (
                            <div className="w-full h-full flex flex-col items-center justify-center text-amber-300 font-serif font-bold text-lg p-1 text-center">
                              <span>
                                {activeDetailDept.headOfDepartment.name
                                  .split(' ')
                                  .slice(-1)[0]?.[0] || 'H'}
                              </span>
                              <span className="text-[8px] font-mono text-blue-200 uppercase">
                                HOD
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="space-y-1.5 min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="px-2 py-0.5 rounded bg-[#0c1a40] text-amber-300 text-[10px] font-mono font-bold uppercase">
                              Head of Department (HOD)
                            </span>
                            <span className="text-xs font-mono text-blue-800">
                              {activeDetailDept.name}
                            </span>
                          </div>
                          <h4 className="font-serif font-bold text-lg text-[#0c1a40]">
                            {activeDetailDept.headOfDepartment.name}
                          </h4>
                          <div className="text-xs text-amber-700 font-semibold">
                            {activeDetailDept.headOfDepartment.title}
                            {activeDetailDept.headOfDepartment.qualifications
                              ? ` · ${activeDetailDept.headOfDepartment.qualifications}`
                              : ''}
                          </div>
                          {activeDetailDept.headOfDepartment.welcomeMessage && (
                            <p className="text-xs text-blue-950/90 leading-relaxed pt-1">
                              "{activeDetailDept.headOfDepartment.welcomeMessage}"
                            </p>
                          )}
                          {activeDetailDept.headOfDepartment.vision && (
                            <p className="text-xs text-blue-900 leading-relaxed">
                              <strong className="text-[#0c1a40]">Academic Focus:</strong>{' '}
                              {activeDetailDept.headOfDepartment.vision}
                            </p>
                          )}
                          {activeDetailDept.headOfDepartment.bio && (
                            <p className="text-[11px] text-blue-800 leading-relaxed">
                              {activeDetailDept.headOfDepartment.bio}
                            </p>
                          )}
                        </div>
                      </div>
                    )}

                    {/* 3. Subjects Offered by Academic Level */}
                    <div>
                      <h4 className="text-xs uppercase tracking-wider font-semibold text-blue-800 mb-3 font-sans">
                        {activeDetailDept.id === 'dept-pe' ? 'Academic Subject & Sporting Activities:' : 'Academic Subjects Offered:'}
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {activeDetailDept.subjects.map((subj, idx) => (
                          <span
                            key={idx}
                            className="px-3 py-1.5 bg-blue-50 text-[#0c1a40] text-xs rounded-lg font-medium border border-blue-200"
                          >
                            {subj}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* 4. Cambridge Syllabus & Qualification Information */}
                    <div className="p-4 bg-blue-50/70 rounded-xl border border-blue-200 text-xs space-y-1.5">
                      <span className="font-semibold text-[#0c1a40] block">
                        Cambridge Syllabus & Qualification Pathway:
                      </span>
                      <span className="text-blue-900 block leading-relaxed">
                        {activeDetailDept.curriculum}
                      </span>
                      <span className="text-[11px] text-blue-800/85 block italic pt-1 border-t border-blue-200/70">
                        {activeDetailDept.cambridgeNote ||
                          "Exact Cambridge qualification, syllabus and examination level offered for each subject should be confirmed against the college's current Cambridge registration and subject options."}
                      </span>
                    </div>

                    {/* 5. Key Areas of Learning & Department Facilities */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {((activeDetailDept.keyAreas && activeDetailDept.keyAreas.length > 0) ||
                        (activeDetailDept.features && activeDetailDept.features.length > 0)) && (
                        <div className="p-4 rounded-xl bg-blue-50/40 border border-blue-100 space-y-2.5">
                          <h4 className="text-xs uppercase tracking-wider font-bold text-[#0c1a40] font-sans flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                            <span>
                              {activeDetailDept.id === 'dept-pe'
                                ? 'Sports & Development Programmes'
                                : 'Key Areas of Learning'}
                            </span>
                          </h4>
                          <ul className="space-y-1.5 text-xs text-blue-950">
                            {(activeDetailDept.keyAreas && activeDetailDept.keyAreas.length > 0
                              ? activeDetailDept.keyAreas
                              : activeDetailDept.features
                            ).map((area, idx) => (
                              <li key={idx} className="flex items-start gap-2">
                                <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                                <span>{area}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {activeDetailDept.facilities && activeDetailDept.facilities.length > 0 && (
                        <div className="p-4 rounded-xl bg-blue-50/40 border border-blue-100 space-y-2.5">
                          <h4 className="text-xs uppercase tracking-wider font-bold text-[#0c1a40] font-sans flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5 text-amber-600" />
                            <span>Facilities & Learning Resources</span>
                          </h4>
                          <ul className="space-y-1.5 text-xs text-blue-950">
                            {activeDetailDept.facilities.map((fac, idx) => (
                              <li key={idx} className="flex items-start gap-2">
                                <CheckCircle2 className="w-3.5 h-3.5 text-blue-700 shrink-0 mt-0.5" />
                                <span>{fac}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>

                    {/* Teaching Staff preview */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-xs uppercase tracking-wider font-semibold text-blue-800 font-sans">
                          Department Teaching Staff ({activeDeptTeachers.length}):
                        </h4>
                        <button
                          onClick={() => setViewMode('faculty')}
                          className="text-xs font-semibold text-[#0c1a40] hover:text-amber-600 flex items-center gap-1 cursor-pointer"
                        >
                          <span>View all profiles</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                        {activeDeptTeachers.slice(0, 6).map((teacher) => {
                          const pos = getTeacherLeadershipPosition(teacher, activeDetailDept);
                          return (
                            <button
                              key={teacher.id}
                              onClick={() => openTeacherProfileModal(teacher)}
                              className="p-2 rounded-xl bg-blue-50/60 hover:bg-blue-100/70 border border-blue-200 text-left flex items-center gap-2.5 cursor-pointer transition-colors"
                            >
                              {teacher.image ? (
                                <img
                                  key={`${teacher.id}-${teacher.image}`}
                                  src={teacher.image}
                                  alt={teacher.name}
                                  loading="lazy"
                                  onError={handleImageFallback}
                                  className="w-8 h-8 rounded-full object-cover object-top shrink-0 border border-amber-400"
                                />
                              ) : (
                                <div className="w-8 h-8 rounded-full bg-[#0c1a40] text-amber-300 font-bold text-xs flex items-center justify-center shrink-0">
                                  {teacher.name.split(' ').slice(-1)[0][0]}
                                </div>
                              )}
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-1">
                                  <span className="text-xs font-semibold text-[#0c1a40] block truncate">
                                    {teacher.name}
                                  </span>
                                  {pos === 'hod' && (
                                    <span className="px-1.5 py-0.2 rounded bg-[#0c1a40] text-amber-300 text-[9px] font-mono font-bold uppercase shrink-0">
                                      HOD
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-blue-800 block truncate">
                                  {formatDepartmentTeacherTitle(teacher.departmentId, teacher.departmentName)}
                                </span>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Right 5 cols: Clubs & Co-Curriculars, Student Pathways, Department Announcements & Actions */}
                  <div className="lg:col-span-5 bg-[#0c1a40] text-white p-7 rounded-2xl flex flex-col justify-between border border-blue-900 shadow-md space-y-6">
                    <div className="space-y-6">
                      {/* 6. Clubs & Co-Curricular Activities */}
                      <div>
                        <div className="text-xs uppercase tracking-widest text-amber-400 font-mono mb-1.5">
                          {activeDetailDept.id === 'dept-pe'
                            ? 'Sporting Activities & Athletics'
                            : 'Clubs & Co-Curricular Activities'}
                        </div>
                        <h4 className="text-lg font-serif font-bold text-white mb-3.5">
                          {activeDetailDept.headOfDepartment.title}
                        </h4>

                        <div className="space-y-2.5 text-xs text-blue-100 font-sans">
                          {(activeDetailDept.activities && activeDetailDept.activities.length > 0
                            ? activeDetailDept.activities
                            : activeDetailDept.features
                          ).map((item, i) => (
                            <div key={i} className="flex items-start gap-2.5">
                              <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                              <span>{item}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* 7. Academic Achievements & Student Projects */}
                      <div className="p-4 rounded-xl bg-white/10 border border-blue-400/20 space-y-1.5 text-xs">
                        <div className="text-amber-300 font-mono text-[10px] font-bold uppercase tracking-wider">
                          Academic Achievements & Student Projects
                        </div>
                        {activeDetailDept.achievements && activeDetailDept.achievements.length > 0 ? (
                          <ul className="space-y-1 text-blue-100">
                            {activeDetailDept.achievements.map((ach, idx) => (
                              <li key={idx}>• {ach}</li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-blue-100/90 leading-relaxed">
                            Students regularly participate in annual exhibitions, practical investigations, national competitions and Cambridge learner showcase initiatives leading to university entry.
                          </p>
                        )}
                      </div>

                      {/* 8. Department News, Events & Announcements */}
                      <div className="p-4 rounded-xl bg-white/5 border border-white/15 space-y-2 text-xs">
                        <div className="flex items-center gap-1.5 text-amber-300 font-mono text-[10px] font-bold uppercase tracking-wider">
                          <Newspaper className="w-3.5 h-3.5" />
                          <span>Department News & Announcements</span>
                        </div>
                        {activeDeptNews.length > 0 ? (
                          <ul className="space-y-2 text-blue-100">
                            {activeDeptNews.slice(0, 3).map((item) => (
                              <li key={item.id} className="border-b border-white/10 pb-1.5 last:border-b-0 last:pb-0">
                                <span className="font-semibold text-white block">{item.title}</span>
                                <span className="text-[11px] text-blue-200 line-clamp-2">{item.excerpt}</span>
                              </li>
                            ))}
                          </ul>
                        ) : activeDetailDept.news && activeDetailDept.news.length > 0 ? (
                          <ul className="space-y-1 text-blue-100">
                            {activeDetailDept.news.map((n, idx) => (
                              <li key={idx}>• {n}</li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-blue-200/90 text-[11px] leading-relaxed">
                            Check the College News & Events calendar for upcoming {formatDepartmentProfileLabel(activeDetailDept.id, activeDetailDept.name)} competitions, workshops and showcase dates.
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="pt-5 border-t border-blue-900 space-y-3">
                      <a
                        href={general.admissionsPortalUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full block text-center py-2.5 px-4 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-[#081226] text-xs font-bold rounded-lg transition-all shadow-xs cursor-pointer"
                      >
                        Apply for this Department Pathway
                      </a>
                      <button
                        onClick={() => handleDownloadDeptSyllabus(activeDetailDept)}
                        className="w-full py-2.5 px-4 bg-white/10 hover:bg-white/20 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer border border-white/15 flex items-center justify-center gap-2"
                      >
                        <Download className="w-3.5 h-3.5 text-amber-400" />
                        <span>Download Department Syllabus Overview</span>
                      </button>
                      <button
                        onClick={onOpenProspectus}
                        className="w-full py-2 px-4 text-amber-300 hover:text-amber-200 text-[11px] font-semibold transition-colors cursor-pointer text-center"
                      >
                        View Full College Prospectus & 2026 Fee Policy →
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            )}
          </div>
        )}

        {/* VIEW MODE 2: TEACHERS DIRECTORY */}
        {viewMode === 'faculty' && (
          <div>
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
              <div>
                <h3 className="text-xl font-serif font-bold text-[#0c1a40]">
                  LKC Academic Departments & Teachers Directory
                </h3>
                <p className="text-xs text-blue-900 mt-0.5">
                  Showing {filteredTeachers.length} educators across {selectedDeptId === 'all' ? `all ${departments.length} departments` : activeDetailDept?.name || 'selected department'}.
                </p>
              </div>

              <span className="text-xs font-mono px-3 py-1 bg-amber-100 text-[#0c1a40] rounded-full font-bold border border-amber-300">
                Cambridge Certified Teachers
              </span>
            </div>

            {filteredTeachers.length === 0 ? (
              <div className="p-12 text-center bg-white rounded-2xl border border-blue-100">
                <Users className="w-10 h-10 text-blue-200 mx-auto mb-3" />
                <h4 className="text-base font-semibold text-[#0c1a40]">No teachers found</h4>
                <p className="text-xs text-blue-900 mt-1 max-w-sm mx-auto">
                  Try adjusting your search query or selecting a different department tab.
                </p>
                <button
                  onClick={() => { setSearchQuery(''); setSelectedDeptId('all'); }}
                  className="mt-4 px-4 py-2 bg-[#0c1a40] text-white text-xs font-semibold rounded-lg hover:bg-[#162a6b] cursor-pointer"
                >
                  Reset Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredTeachers.map((teacher) => {
                  const pos = getTeacherLeadershipPosition(teacher, deptById.get(teacher.departmentId));
                  return (
                  <motion.div
                    key={teacher.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.2 }}
                    data-lkc-card-clickable="true"
                    onClick={() => openTeacherProfileModal(teacher)}
                    className="bg-white rounded-2xl border border-blue-100 p-4 hover:border-amber-400 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
                  >
                    <div>
                      <div className="aspect-square rounded-xl overflow-hidden bg-blue-50 mb-3.5 relative border border-blue-100 shadow-inner">
                        {teacher.image ? (
                          <>
                            <motion.img
                              key={`${teacher.id}-${teacher.image}`}
                              src={teacher.image}
                              alt={teacher.name}
                              onError={handleImageFallback}
                              className="w-full h-full object-cover object-top"
                              whileHover={{ scale: 1.06 }}
                              transition={{ duration: 0.3 }}
                              loading="lazy"
                            />
                            <div className="absolute bottom-2 right-2 flex items-center gap-1 opacity-90 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                                <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openImageViewer({
                                    src: teacher.image!,
                                    title: teacher.name,
                                    subtitle: formatDepartmentTeacherTitle(teacher.departmentId, teacher.departmentName),
                                  });
                                }}
                                className="p-1.5 rounded-lg bg-[#081226]/85 hover:bg-[#081226] text-amber-300 border border-amber-400/40 cursor-pointer shadow-xs"
                                title="Zoom portrait"
                                aria-label={`Zoom ${teacher.name} portrait`}
                              >
                                <ZoomIn className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  downloadImageFile(teacher.image!, teacher.name);
                                }}
                                className="p-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] cursor-pointer shadow-xs"
                                title="Download portrait"
                                aria-label={`Download ${teacher.name} portrait`}
                              >
                                <Download className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </>
                        ) : (
                          <div className="w-full h-full bg-gradient-to-br from-[#0c1a40] to-[#162a6b] flex flex-col items-center justify-center text-center p-4">
                            <div className="w-14 h-14 rounded-full bg-amber-400 text-[#081226] font-serif font-bold text-xl flex items-center justify-center shadow-md mb-2">
                              {teacher.name.split(' ').filter(n => !n.startsWith('M') && !n.startsWith('D')).slice(0, 2).map(n => n[0]).join('') || 'LK'}
                            </div>
                            <span className="text-[11px] text-amber-200 font-mono">Faculty Profile</span>
                          </div>
                        )}

                        <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-[#0c1a40]/90 text-amber-300 text-[10px] font-mono font-semibold">
                          {formatDepartmentProfileLabel(teacher.departmentId, teacher.departmentName)}
                        </div>
                        {pos === 'hod' && (
                          <div className="absolute top-2 right-2 px-2 py-0.5 rounded-md bg-amber-400 text-[#081226] text-[10px] font-mono font-bold uppercase shadow-xs">
                            HOD
                          </div>
                        )}
                      </div>

                      <h4 className="font-serif font-bold text-[#0c1a40] text-sm group-hover:text-[#162a6b] transition-colors line-clamp-1">
                        {teacher.name}
                      </h4>

                      <div className="text-xs font-medium text-amber-700 mt-0.5">
                        {formatDepartmentTeacherTitle(teacher.departmentId, teacher.departmentName)}
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-blue-100 flex items-center justify-between text-xs gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-blue-50 text-[#0c1a40] font-semibold border border-blue-100 truncate">
                        {formatDepartmentProfileLabel(teacher.departmentId, teacher.departmentName)}
                      </span>

                      <span className="text-[#0c1a40] group-hover:text-amber-600 font-semibold text-[11px] flex items-center gap-0.5 shrink-0">
                        Profile →
                      </span>
                    </div>
                  </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* DEDICATED SECTION: HEADS OF YEAR (FORM 1 – FORM 5 & A LEVEL) */}
        {headsOfYearByForm.length > 0 && (
          <div id="heads-of-year" className="mt-16 pt-12 border-t border-blue-200">
            <div className="max-w-3xl mb-8">
              <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1 flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-amber-600" />
                <span>Year-Group Pastoral & Academic Oversight</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
                Heads of Year (Form 1 – Form 5 & A Level)
              </h3>
              <p className="text-xs sm:text-sm text-blue-900/85 mt-1.5">
                Dedicated Heads of Year monitor student academic progress, attendance, discipline, parent liaison, and holistic welfare across every cohort.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {headsOfYearByForm.map((group) => (
                <div
                  key={group.yearGroup}
                  className="bg-white rounded-2xl border border-blue-200 shadow-xs overflow-hidden flex flex-col justify-between"
                >
                  <div className="px-5 py-3 bg-[#0c1a40] text-white flex items-center justify-between border-b border-blue-900">
                    <span className="font-serif font-bold text-base text-white">
                      {group.yearGroup}
                    </span>
                    <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-amber-400 text-[#081226] font-bold">
                      {group.assignments.length > 1
                        ? `${group.assignments.length} Heads of Year`
                        : 'Head of Year'}
                    </span>
                  </div>

                  <div className="p-5 space-y-5 flex-1">
                    {group.assignments.map((assign) => {
                      const staff = assign.staff!;
                      const respLines = (assign.responsibilities || '')
                        .split('\n')
                        .map((l) => l.trim())
                        .filter(Boolean);
                      return (
                        <div key={assign.id} className="space-y-3 border-b last:border-b-0 border-blue-100 pb-4 last:pb-0">
                          <div className="flex items-center gap-4">
                            <div className="w-20 aspect-[4/5] rounded-xl overflow-hidden bg-[#0c1a40] border-2 border-amber-400 shrink-0">
                              {staff.image ? (
                                <img
                                  key={`${staff.id}-${staff.image}`}
                                  src={staff.image}
                                  alt={staff.fullName}
                                  loading="lazy"
                                  onError={handleImageFallback}
                                  onClick={() =>
                                    openImageViewer({
                                      src: staff.image!,
                                      title: staff.fullName,
                                      subtitle: `${assign.roleTitle} · ${group.yearGroup}`,
                                    })
                                  }
                                  data-zoomable-image="true"
                                  className="w-full h-full object-cover object-top cursor-zoom-in hover:scale-105 transition-transform duration-200"
                                />
                              ) : (
                                <div className="w-full h-full flex flex-col items-center justify-center text-center p-1.5 text-amber-300">
                                  <span className="font-serif font-bold text-lg leading-none">
                                    {staff.surname[0] || 'L'}
                                  </span>
                                  <span className="text-[8px] font-mono text-blue-200 mt-1 leading-tight">
                                    Photo Pending
                                  </span>
                                </div>
                              )}
                            </div>

                            <div className="min-w-0">
                              <div className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-700">
                                {assign.roleTitle}
                              </div>
                              <h4 className="font-serif font-bold text-lg text-[#0c1a40] leading-snug">
                                {staff.fullName}
                              </h4>
                            </div>
                          </div>

                          {assign.welcomeMessage && (
                            <p className="text-xs text-blue-950 italic bg-blue-50/60 p-2.5 rounded-lg border border-blue-100">
                              "{assign.welcomeMessage}"
                            </p>
                          )}

                          {respLines.length > 0 && (
                            <ul className="space-y-1 text-[11px] text-blue-900">
                              {respLines.slice(0, 5).map((line, i) => (
                                <li key={i} className="flex items-start gap-1.5">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                                  <span>{line}</span>
                                </li>
                              ))}
                            </ul>
                          )}

                          {staff.bio && (
                            <p className="text-[11px] text-blue-800 leading-relaxed">{staff.bio}</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* DEDICATED SECTION: A-LEVEL COORDINATOR & PASTORAL CARE (INDEPENDENT ROLES) */}
        {(aLevelCoordinators.length > 0 || pastoralProfiles.length > 0) && (
          <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* A-Level Coordinator */}
            {aLevelCoordinators.map((assign) => {
              const staff = assign.staff!;
              const respLines = (assign.responsibilities || '')
                .split('\n')
                .map((l) => l.trim())
                .filter(Boolean);
              return (
                <div
                  key={assign.id}
                  id="a-level-coordinator"
                  className="bg-white rounded-2xl border-2 border-blue-200 shadow-xs overflow-hidden flex flex-col justify-between"
                >
                  <div className="px-6 py-4 bg-gradient-to-r from-[#0c1a40] to-[#162a6b] text-white flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <GraduationCap className="w-5 h-5 text-amber-400" />
                      <span className="font-serif font-bold text-lg">{assign.roleTitle}</span>
                    </div>
                    <span className="text-[10px] font-mono uppercase bg-amber-400 text-[#081226] px-2.5 py-0.5 rounded font-bold">
                      Academic Coordination
                    </span>
                  </div>

                  <div className="p-6 space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="w-24 aspect-[4/5] rounded-xl overflow-hidden bg-[#0c1a40] border-2 border-amber-400 shrink-0">
                        {staff.image ? (
                          <img
                            key={`${staff.id}-${staff.image}`}
                            src={staff.image}
                            alt={staff.fullName}
                            loading="lazy"
                            onError={handleImageFallback}
                            onClick={() =>
                              openImageViewer({
                                src: staff.image!,
                                title: staff.fullName,
                                subtitle: assign.roleTitle,
                              })
                            }
                            data-zoomable-image="true"
                            className="w-full h-full object-cover object-top cursor-zoom-in hover:scale-105 transition-transform duration-200"
                          />
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center text-center p-2 text-amber-300">
                            <span className="font-serif font-bold text-2xl">
                              {staff.surname[0] || 'C'}
                            </span>
                            <span className="text-[9px] font-mono text-blue-200 mt-1">
                              Portrait Pending
                            </span>
                          </div>
                        )}
                      </div>
                      <div>
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-700 block">
                          {assign.roleTitle}
                        </span>
                        <h4 className="font-serif font-bold text-xl text-[#0c1a40]">
                          {staff.fullName}
                        </h4>
                        <p className="text-xs text-blue-800 mt-0.5">
                          {staff.department || 'Sixth Form Academic Programmes'}
                        </p>
                      </div>
                    </div>

                    {assign.welcomeMessage && (
                      <p className="text-xs text-blue-950 italic bg-blue-50 p-3 rounded-xl border border-blue-200">
                        "{assign.welcomeMessage}"
                      </p>
                    )}

                    {respLines.length > 0 && (
                      <div>
                        <div className="text-[11px] font-mono uppercase tracking-wider text-blue-800 font-bold mb-2">
                          Core Academic Coordination Responsibilities
                        </div>
                        <ul className="space-y-1.5 text-xs text-blue-950">
                          {respLines.map((line, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                              <span>{line}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {staff.bio && (
                      <p className="text-xs text-blue-800 leading-relaxed pt-2 border-t border-blue-100">
                        {staff.bio}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Pastoral Care, Guidance and Counselling – A Level */}
            {pastoralProfiles.map((assign) => {
              const staff = assign.staff!;
              const respLines = (assign.responsibilities || '')
                .split('\n')
                .map((l) => l.trim())
                .filter(Boolean);
              return (
                <div
                  key={assign.id}
                  id="pastoral-care-a-level"
                  className="bg-white rounded-2xl border-2 border-amber-300 shadow-xs overflow-hidden flex flex-col justify-between"
                >
                  <div className="px-6 py-4 bg-gradient-to-r from-[#081226] to-[#0c1a40] text-white flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <HeartHandshake className="w-5 h-5 text-amber-400" />
                      <span className="font-serif font-bold text-lg">{assign.roleTitle}</span>
                    </div>
                    <span className="text-[10px] font-mono uppercase bg-white/15 text-amber-300 px-2.5 py-0.5 rounded border border-amber-400/30 font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      <span>Pastoral Support</span>
                    </span>
                  </div>

                  <div className="p-6 space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="w-24 aspect-[4/5] rounded-xl overflow-hidden bg-[#0c1a40] border-2 border-amber-400 shrink-0">
                        {staff.image ? (
                          <img
                            key={`${staff.id}-${staff.image}`}
                            src={staff.image}
                            alt={staff.fullName}
                            loading="lazy"
                            onError={handleImageFallback}
                            onClick={() =>
                              openImageViewer({
                                src: staff.image!,
                                title: staff.fullName,
                                subtitle: assign.roleTitle,
                              })
                            }
                            data-zoomable-image="true"
                            className="w-full h-full object-cover object-top cursor-zoom-in hover:scale-105 transition-transform duration-200"
                          />
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center text-center p-2 text-amber-300">
                            <span className="font-serif font-bold text-2xl">
                              {staff.surname[0] || 'M'}
                            </span>
                            <span className="text-[9px] font-mono text-blue-200 mt-1">
                              Portrait Pending
                            </span>
                          </div>
                        )}
                      </div>
                      <div>
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-700 block">
                          {assign.roleTitle}
                        </span>
                        <h4 className="font-serif font-bold text-xl text-[#0c1a40]">
                          {staff.fullName}
                        </h4>
                        <p className="text-xs text-blue-800 mt-0.5">
                          Sixth Form Student Welfare & Guidance
                        </p>
                      </div>
                    </div>

                    {assign.welcomeMessage && (
                      <p className="text-xs text-blue-950 italic bg-amber-50/60 p-3 rounded-xl border border-amber-200">
                        "{assign.welcomeMessage}"
                      </p>
                    )}

                    {respLines.length > 0 && (
                      <div>
                        <div className="text-[11px] font-mono uppercase tracking-wider text-blue-800 font-bold mb-2">
                          Pastoral Care & Guidance Scope
                        </div>
                        <ul className="space-y-1.5 text-xs text-blue-950">
                          {respLines.map((line, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                              <span>{line}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {staff.bio && (
                      <p className="text-xs text-blue-800 leading-relaxed pt-2 border-t border-blue-100">
                        {staff.bio}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <AcademicVisionAndProgrammes showCurriculumStages={true} />

      </div>

      {/* Teacher Profile Bio Modal */}
      <AnimatePresence>
        {activeTeacherModal && (
          <div
            className="fixed inset-0 z-50 bg-[#081226]/85 backdrop-blur-xs flex items-center justify-center p-4"
            onClick={() => setActiveTeacherModal(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto p-6 sm:p-8 shadow-2xl border border-blue-200 relative text-[#0c1a40]"
            >
              <button
                onClick={() => setActiveTeacherModal(null)}
                className="absolute top-4 right-4 p-1.5 rounded-lg text-blue-500 hover:text-[#0c1a40] hover:bg-blue-50 transition-colors cursor-pointer"
                aria-label="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 mb-5 pb-5 border-b border-blue-100">
                <div className="flex flex-col items-center shrink-0 gap-2.5">
                  <div className="w-48 h-60 sm:w-56 sm:h-72 rounded-2xl overflow-auto bg-blue-50 border-2 border-amber-400 shadow-lg flex items-center justify-center">
                    {activeTeacherModal.image ? (
                      <div
                        className="w-full h-full transition-transform duration-150 origin-center"
                        style={{ transform: `scale(${teacherPhotoZoom})` }}
                      >
                        <img
                          key={`${activeTeacherModal.id}-${activeTeacherModal.image}`}
                          src={activeTeacherModal.image}
                          alt={activeTeacherModal.name}
                          onError={handleImageFallback}
                          onClick={() =>
                            openImageViewer({
                              src: activeTeacherModal.image!,
                              title: activeTeacherModal.name,
                              subtitle: formatDepartmentTeacherTitle(activeTeacherModal.departmentId, activeTeacherModal.departmentName),
                            })
                          }
                          data-zoomable-image="true"
                          className="w-full h-full object-cover object-top cursor-zoom-in"
                        />
                      </div>
                    ) : (
                      <div className="w-full h-full bg-[#0c1a40] text-amber-300 font-bold font-serif text-3xl flex items-center justify-center">
                        {activeTeacherModal.name.split(' ').slice(-1)[0][0]}
                      </div>
                    )}
                  </div>

                  {activeTeacherModal.image && (
                    <div className="flex flex-wrap items-center justify-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setTeacherPhotoZoom((z) => Math.max(0.5, Number((z - 0.25).toFixed(2))))}
                        className="p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#0c1a40] border border-blue-200 cursor-pointer"
                        title="Zoom Out Portrait"
                        aria-label="Zoom out portrait"
                      >
                        <ZoomOut className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-[11px] font-mono font-bold text-[#0c1a40] px-1.5 min-w-[2.8rem] text-center">
                        {Math.round(teacherPhotoZoom * 100)}%
                      </span>
                      <button
                        type="button"
                        onClick={() => setTeacherPhotoZoom((z) => Math.min(4, Number((z + 0.25).toFixed(2))))}
                        className="p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#0c1a40] border border-blue-200 cursor-pointer"
                        title="Zoom In Portrait"
                        aria-label="Zoom in portrait"
                      >
                        <ZoomIn className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setTeacherPhotoZoom(1)}
                        className="p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#0c1a40] border border-blue-200 cursor-pointer"
                        title="Reset Zoom"
                        aria-label="Reset portrait zoom"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          openImageViewer({
                            src: activeTeacherModal.image!,
                            title: activeTeacherModal.name,
                            subtitle: formatDepartmentTeacherTitle(activeTeacherModal.departmentId, activeTeacherModal.departmentName),
                          })
                        }
                        className="px-2.5 py-1.5 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[11px] font-semibold cursor-pointer"
                        title="Open Fullscreen Image"
                      >
                        Full View
                      </button>
                      <button
                        type="button"
                        onClick={() => downloadImageFile(activeTeacherModal.image!, activeTeacherModal.name)}
                        className="px-2.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                        title="Download Portrait"
                      >
                        <Download className="w-3 h-3" />
                        <span>Download</span>
                      </button>
                    </div>
                  )}
                </div>

                <div className="text-center sm:text-left pt-1">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-amber-700 font-bold px-2.5 py-0.5 bg-amber-50 rounded-md border border-amber-200">
                    {formatDepartmentProfileLabel(activeTeacherModal.departmentId, activeTeacherModal.departmentName)}
                  </span>
                  <h3 className="text-xl font-serif font-bold text-[#0c1a40] mt-2">
                    {activeTeacherModal.name}
                  </h3>
                  <div className="text-xs text-[#162a6b] font-semibold mt-1">
                    {formatDepartmentTeacherTitle(activeTeacherModal.departmentId, activeTeacherModal.departmentName)}
                  </div>
                  {activeTeacherModal.image && (
                    <button
                      type="button"
                      onClick={() =>
                        openImageViewer({
                          src: activeTeacherModal.image!,
                          title: activeTeacherModal.name,
                          subtitle: formatDepartmentTeacherTitle(activeTeacherModal.departmentId, activeTeacherModal.departmentName),
                        })
                      }
                      className="mt-3 inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#0c1a40] hover:text-amber-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-2.5 py-1 rounded-lg cursor-pointer transition-colors"
                    >
                      <ZoomIn className="w-3.5 h-3.5 text-amber-600" />
                      <span>Open Fullscreen Image Viewer</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-4 text-xs sm:text-sm text-blue-950 font-sans leading-relaxed">
                <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200 text-xs flex items-center justify-between gap-2">
                  <div>
                    <span className="font-semibold text-[#0c1a40] block">
                      {formatDepartmentProfileLabel(activeTeacherModal.departmentId, activeTeacherModal.departmentName)} Department · {formatDepartmentTeacherTitle(activeTeacherModal.departmentId, activeTeacherModal.departmentName)}
                    </span>
                    <span className="text-blue-800">{general.name}, {general.address.area}, {general.address.city}</span>
                  </div>
                  <a
                    href={`mailto:${general.contacts.principalEmail}`}
                    className="px-3 py-1.5 bg-[#0c1a40] text-white rounded-lg text-xs font-semibold hover:bg-[#162a6b] transition-colors shrink-0"
                  >
                    Contact Faculty
                  </a>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-blue-100 flex items-center justify-end">
                <button
                  onClick={() => setActiveTeacherModal(null)}
                  className="px-4 py-2 bg-blue-100 hover:bg-blue-200 text-[#0c1a40] rounded-lg text-xs font-semibold cursor-pointer transition-colors"
                >
                  Close Profile
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};
