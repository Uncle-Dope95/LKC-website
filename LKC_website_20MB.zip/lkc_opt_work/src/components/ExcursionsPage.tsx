import React, { useState } from 'react';
import {
  MapPin,
  CheckCircle2,
  ChevronRight,
  Clock,
  BookOpen,
  Compass
} from 'lucide-react';
import { useCmsSection } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';

interface ExcursionsPageProps {
  onOpenAdmissions: () => void;
}

export const ExcursionsPage: React.FC<ExcursionsPageProps> = () => {
  const excursions = useCmsSection('excursions');
  const general = useCmsSection('general');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'International', 'Regional', 'National'];

  const filteredExcursions =
    selectedCategory === 'All'
      ? excursions
      : excursions.filter((item) => item.category === selectedCategory);

  return (
    <div className="bg-white min-h-screen text-[#0c1a40] pb-20">

      {/* 1. Hero Section */}
      <div className="relative bg-gradient-to-br from-[#081226] via-[#0c1a40] to-[#162a6b] text-white pt-16 pb-20 px-4 sm:px-6 overflow-hidden border-b border-blue-900">
        <div className="absolute right-[-60px] top-[-40px] opacity-10 pointer-events-none">
          <img
            src={general.logoUrl}
            alt={`${general.name} Crest`}
            onError={handleImageFallback}
            className="w-96 h-96 object-contain"
          />
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-amber-300 uppercase tracking-widest mb-4">
            <span>{general.name}</span>
            <span>·</span>
            <span>Experiential Learning</span>
            <span>·</span>
            <span className="text-amber-400 font-bold">International, Regional & National</span>
          </div>

          <div className="max-w-3xl">
            <h1 className="text-3xl sm:text-5xl font-serif font-bold tracking-tight text-white mb-4">
              Educational Excursions
            </h1>
            <p className="text-xl sm:text-2xl text-amber-300 font-serif italic mb-6">
              Translating Classroom Mastery into Global, Regional & Botswana Horizons
            </p>
            <p className="text-base sm:text-lg text-blue-100 leading-relaxed font-sans mb-8">
              At {general.name}, educational travel enriches language immersion, STEM innovation, geography fieldwork, and regional ecological stewardship. Below are our flagship official LKC excursions.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <a
                href="#excursions-list"
                className="px-6 py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-sm shadow-md transition-all cursor-pointer flex items-center gap-2"
              >
                <span>Explore Expeditions</span>
                <ChevronRight className="w-4 h-4" />
              </a>
              <a
                href={general.admissionsPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-3 rounded-lg bg-white/15 hover:bg-white/25 text-white font-medium text-sm border border-white/25 transition-all cursor-pointer"
              >
                Apply for 2026/27 Intake
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Key Pillars Ribbon */}
      <div className="bg-[#081226] text-white border-b border-blue-900 py-6 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
          <div className="p-3">
            <div className="text-2xl font-serif font-bold text-amber-400">{excursions.length} Flagship Trips</div>
            <div className="text-xs text-blue-200 font-mono mt-1">Official LKC Educational Tours</div>
          </div>
          <div className="p-3">
            <div className="text-2xl font-serif font-bold text-white">International & SADC</div>
            <div className="text-xs text-blue-200 font-mono mt-1">France, Singapore, South Africa & Regional</div>
          </div>
          <div className="p-3">
            <div className="text-2xl font-serif font-bold text-amber-300">Cambridge Aligned</div>
            <div className="text-xs text-blue-200 font-mono mt-1">French, STEM, Geography & Cultural Enrichment</div>
          </div>
        </div>
      </div>

      {/* 3. Category Filter & Excursions Grid */}
      <section id="excursions-list" className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold mb-2">
              Official LKC Itineraries
            </div>
            <h2 className="text-3xl font-serif font-bold text-[#0c1a40]">
              Signature Educational Excursions
            </h2>
            <p className="text-blue-950 text-sm mt-1">
              Academic immersions across Europe, Asia, Southern Africa, and northern Botswana.
            </p>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#0c1a40] text-white shadow-xs font-semibold'
                    : 'bg-blue-50 text-[#0c1a40] hover:bg-blue-100 border border-blue-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Grid of Excursion Cards */}
        {filteredExcursions.length === 0 ? (
          <div className="p-12 text-center bg-blue-50/40 rounded-2xl border border-blue-200">
            <Compass className="w-10 h-10 text-blue-400 mx-auto mb-3" />
            <h3 className="text-lg font-serif font-bold text-[#0c1a40]">No Excursions in this Category</h3>
            <p className="text-xs text-blue-900 mt-1">Select All or another category tab above.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredExcursions.map((excursion) => (
              <div
                key={excursion.id}
                className="bg-white rounded-2xl border border-blue-200 shadow-sm overflow-hidden flex flex-col justify-between hover:border-amber-400 hover:shadow-md transition-all duration-200 group"
              >
                <div>
                  {/* Category Top Banner */}
                  <div className="p-4 bg-gradient-to-r from-[#081226] to-[#162a6b] text-white flex items-center justify-between">
                    <span className="text-[11px] font-mono font-semibold uppercase tracking-wider text-amber-300">
                      {excursion.category}
                    </span>
                    <span className="text-xs text-white font-mono flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-400" />
                      <span>{excursion.year || excursion.duration}</span>
                    </span>
                  </div>

                  {excursion.image && (
                    <div className="aspect-[16/9] bg-[#081226] overflow-hidden border-b border-blue-100">
                      <img
                        src={excursion.image}
                        alt={excursion.title}
                        loading="lazy"
                        onError={handleImageFallback}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}

                  {/* Details */}
                  <div className="p-6">
                    <h3 className="font-serif font-bold text-xl text-[#0c1a40] mb-2 group-hover:text-[#162a6b] transition-colors">
                      {excursion.title}
                    </h3>

                    <div className="flex items-center gap-1.5 text-xs text-blue-900 mb-3 font-sans">
                      <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span className="line-clamp-1">{excursion.destination}</span>
                    </div>

                    <p className="text-xs sm:text-sm text-blue-950 leading-relaxed mb-4 font-sans">
                      {excursion.description}
                    </p>

                    <div className="p-3 rounded-xl bg-blue-50 border border-blue-100 mb-4 text-xs">
                      <div className="font-semibold text-[#0c1a40] flex items-center gap-1.5 mb-1">
                        <BookOpen className="w-3.5 h-3.5 text-[#162a6b] shrink-0" />
                        <span>Cambridge Curriculum Link</span>
                      </div>
                      <div className="text-blue-950 font-mono text-[11px]">
                        {excursion.curriculumLink}
                      </div>
                    </div>

                    {/* Highlights List */}
                    {excursion.highlights && excursion.highlights.length > 0 && (
                      <div>
                        <div className="text-[11px] font-mono uppercase tracking-wider text-blue-800 font-semibold mb-2">
                          Expedition Highlights
                        </div>
                        <ul className="space-y-1.5">
                          {excursion.highlights.map((h, i) => (
                            <li key={i} className="flex items-start gap-2 text-xs text-blue-950">
                              <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                              <span>{h}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Footer Meta */}
                <div className="p-4 bg-blue-50/70 border-t border-blue-100 flex items-center justify-between text-xs text-blue-900 font-mono">
                  <span className="truncate pr-2">{excursion.targetForms}</span>
                  <span className="text-[#0c1a40] font-semibold shrink-0">{excursion.duration}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Coordinator Contact Banner */}
        <div className="mt-14 p-6 sm:p-8 rounded-2xl bg-[#0c1a40] text-white border border-blue-900 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="text-xs font-mono uppercase tracking-widest text-amber-400 font-bold mb-1">
              Parent & Guardian Information
            </div>
            <h3 className="font-serif font-bold text-lg text-white">
              Planning for an upcoming LKC Educational Excursion?
            </h3>
            <p className="text-xs text-blue-100 mt-1">
              Contact College Administration for permission forms, travel itineraries, and fee schedules.
            </p>
          </div>
          <a
            href={`mailto:${general.contacts.principalEmail}`}
            className="px-5 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs transition-colors shrink-0"
          >
            Contact Excursions Office ({general.contacts.principalEmail})
          </a>
        </div>
      </section>

    </div>
  );
};
