import React, { useState } from 'react';
import { useCmsSection, submitPublicEnquiry } from '../services/cmsDataService';
import {
  ChevronDown,
  MapPin,
  Phone,
  Mail,
  Clock,
  Send,
  CheckCircle,
  MessageCircle,
  ExternalLink,
  Navigation,
  Instagram,
  Compass,
  AlertTriangle,
} from 'lucide-react';

export const FaqContactSection: React.FC = () => {
  const faqs = useCmsSection('faqs');
  const general = useCmsSection('general');

  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [enquirySent, setEnquirySent] = useState<boolean>(false);
  const [enquirySubmitting, setEnquirySubmitting] = useState<boolean>(false);
  const [enquiryError, setEnquiryError] = useState<string | null>(null);
  const [enquiryForm, setEnquiryForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'General Admissions Query',
    message: '',
  });

  const toggleFaq = (idx: number) => {
    setOpenFaq(openFaq === idx ? null : idx);
  };

  const handleSendEnquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    setEnquirySubmitting(true);
    setEnquiryError(null);
    try {
      await submitPublicEnquiry({ type: 'contact', ...enquiryForm });
      setEnquirySent(true);
    } catch (err) {
      setEnquiryError(
        err instanceof Error
          ? err.message
          : 'Unable to send your enquiry automatically. Please call +267 316 1140 / +267 316 2208 or message WhatsApp +267 78 465 196.'
      );
    } finally {
      setEnquirySubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-20 bg-blue-50/40 border-b border-blue-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-2">
            Admissions Enquiries & Campus Directory
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#0c1a40] tracking-tight text-balance">
            Frequently Asked Questions & College Contacts
          </h2>
          <div className="w-16 h-0.5 bg-amber-500 mt-4 mb-6" />
          <p className="text-base text-blue-900/80 leading-relaxed font-sans">
            Our admissions registry and academic leadership welcome prospective families to contact us or visit our {general.address.area}, {general.address.city} campus.
          </p>
        </div>

        {/* 2 Columns: FAQs on Left, Contact & Enquiry Form on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-16">
          {/* FAQs (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <h3 className="font-serif font-bold text-xl text-[#0c1a40] mb-6">
              Frequently Asked Questions
            </h3>

            <div className="space-y-3">
              {faqs.map((faq, idx) => {
                const isOpen = openFaq === idx;
                return (
                  <div
                    key={`${faq.q}-${idx}`}
                    className="border border-blue-200 rounded-xl overflow-hidden bg-white shadow-xs transition-colors"
                  >
                    <button
                      type="button"
                      onClick={() => toggleFaq(idx)}
                      className="w-full p-4 sm:p-5 text-left bg-white hover:bg-blue-50/50 flex items-center justify-between gap-4 transition-colors cursor-pointer"
                    >
                      <span className="font-serif font-bold text-sm sm:text-base text-[#0c1a40]">
                        {faq.q}
                      </span>
                      <ChevronDown
                        className={`w-4 h-4 text-blue-900/70 shrink-0 transition-transform duration-200 ${
                          isOpen ? 'rotate-180 text-amber-600' : ''
                        }`}
                      />
                    </button>
                    {isOpen && (
                      <div className="p-4 sm:p-5 bg-blue-50/40 text-xs sm:text-sm text-blue-900/85 leading-relaxed font-sans border-t border-blue-100">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Contact & Enquiry Form (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            {/* Direct Contact Card */}
            <div className="bg-gradient-to-b from-[#0c1a40] to-[#081226] text-white p-6 sm:p-7 rounded-2xl shadow-lg border border-blue-900/60">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-serif font-bold text-lg text-white">Contact & Location</h3>
                <span className="text-[10px] font-mono px-2.5 py-0.5 rounded bg-amber-400/20 text-amber-300 font-bold border border-amber-400/30">
                  Block 8 Campus
                </span>
              </div>

              <div className="space-y-4 text-xs font-sans text-blue-100">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-white">Physical Address</div>
                    <div className="text-blue-100">
                      {general.address.plot}, {general.address.area}
                    </div>
                    <div className="text-blue-300">
                      {general.address.city}, {general.address.country}
                    </div>
                    <div className="text-[11px] text-amber-300 font-mono mt-1 flex items-center gap-1">
                      <Compass className="w-3 h-3 text-amber-400" />
                      <span>GPS: {general.address.gps}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-white">Postal Address</div>
                    <div className="text-blue-200">
                      {general.address.postalBox}, {general.address.city}, {general.address.country}
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-white">Office Hours</div>
                    <div className="text-blue-100">{general.contacts.officeHours}</div>
                    <div className="text-blue-300 text-[11px]">Closed on weekends & national public holidays</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-white">Direct Telephone</div>
                    <div>
                      Switchboard:{' '}
                      <a
                        href={`tel:${general.contacts.phone.replace(/\s+/g, '')}`}
                        className="hover:text-amber-400 underline font-mono text-white font-semibold"
                      >
                        {general.contacts.phone}
                      </a>
                    </div>
                    <div>
                      Principal:{' '}
                      <a
                        href={`mailto:${general.contacts.principalEmail}`}
                        className="hover:text-amber-400 text-blue-100 underline"
                      >
                        {general.contacts.principalEmail}
                      </a>
                    </div>
                  </div>
                </div>

                {/* WhatsApp & Socials */}
                <div className="pt-2 border-t border-blue-900/60 flex flex-col gap-2">
                  <div className="flex items-center gap-3">
                    <MessageCircle className="w-4 h-4 text-amber-400 shrink-0" />
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white">WhatsApp:</span>
                      <a
                        href={general.socials.whatsapp}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-amber-300 hover:text-amber-200 font-mono underline font-medium inline-flex items-center gap-1"
                      >
                        <span>{general.socials.whatsappNumber}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Instagram className="w-4 h-4 text-amber-400 shrink-0" />
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white">Instagram:</span>
                      <a
                        href={general.socials.instagram}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-200 hover:text-amber-300 font-mono underline font-medium inline-flex items-center gap-1"
                      >
                        <span>{general.socials.instagramHandle}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>

                {/* Primary Action Button */}
                <div className="pt-3">
                  <a
                    href={general.googleMapsDirectionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 text-[#081226] font-bold text-xs transition-colors flex items-center justify-center gap-2 shadow-md"
                  >
                    <Navigation className="w-4 h-4" />
                    <span>Open Google Maps Directions</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Quick Enquiry Message Form */}
            <div className="bg-white p-6 sm:p-7 rounded-2xl border border-blue-200 shadow-xs">
              <h4 className="font-serif font-bold text-base text-[#0c1a40] mb-1">
                Send an Admissions Enquiry
              </h4>
              <p className="text-xs text-blue-900/70 mb-4">
                Our admissions officers respond within one business day.
              </p>

              {!enquirySent ? (
                <form onSubmit={handleSendEnquiry} className="space-y-3 text-xs font-sans">
                  <div>
                    <label className="block text-[#0c1a40] font-medium mb-1">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      value={enquiryForm.name}
                      onChange={(e) => setEnquiryForm({ ...enquiryForm, name: e.target.value })}
                      placeholder="Enter parent or guardian full name"
                      className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[#0c1a40] font-medium mb-1">Email *</label>
                      <input
                        type="email"
                        required
                        value={enquiryForm.email}
                        onChange={(e) => setEnquiryForm({ ...enquiryForm, email: e.target.value })}
                        placeholder="parent@example.com"
                        className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                      />
                    </div>
                    <div>
                      <label className="block text-[#0c1a40] font-medium mb-1">Phone</label>
                      <input
                        type="tel"
                        value={enquiryForm.phone}
                        onChange={(e) => setEnquiryForm({ ...enquiryForm, phone: e.target.value })}
                        placeholder="+267 ..."
                        className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[#0c1a40] font-medium mb-1">Enquiry Subject</label>
                    <select
                      value={enquiryForm.subject}
                      onChange={(e) => setEnquiryForm({ ...enquiryForm, subject: e.target.value })}
                      className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                    >
                      <option>General Admissions Query (Preschool to A-Levels)</option>
                      <option>New Forms 1 & 2 2027 Classrooms Inquiry</option>
                      <option>Masire Boarding Houses (Girls & Boys)</option>
                      <option>Cambridge Examination Centre Inquiries</option>
                      <option>Kolobeng Jaguars Sports & Athletics</option>
                      <option>Fees Structure & Sibling Discounts</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[#0c1a40] font-medium mb-1">Message *</label>
                    <textarea
                      required
                      rows={3}
                      value={enquiryForm.message}
                      onChange={(e) => setEnquiryForm({ ...enquiryForm, message: e.target.value })}
                      placeholder="Please let us know how we can assist you..."
                      className="w-full p-2.5 bg-blue-50/40 border border-blue-200 rounded-lg text-[#0c1a40] focus:outline-hidden focus:border-blue-900"
                    />
                  </div>

                  {enquiryError && (
                    <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-900 text-xs space-y-1.5">
                      <div className="flex items-start gap-2 font-semibold">
                        <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                        <span>{enquiryError}</span>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-[11px] pl-6">
                        <a href="tel:+2673161140" className="underline font-semibold text-[#0c1a40]">
                          +267 316 1140
                        </a>
                        <a href="tel:+2673162208" className="underline font-semibold text-[#0c1a40]">
                          +267 316 2208
                        </a>
                        <a
                          href={general.socials.whatsapp || 'https://wa.me/26778465196'}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="underline font-semibold text-amber-800"
                        >
                          WhatsApp +267 78 465 196
                        </a>
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={enquirySubmitting}
                    className="w-full py-2.5 px-4 bg-[#0c1a40] hover:bg-[#162a6b] disabled:opacity-60 text-white font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <Send className="w-3.5 h-3.5 text-amber-400" />
                    <span>{enquirySubmitting ? 'Sending Message...' : 'Send Message to Admissions'}</span>
                  </button>
                </form>
              ) : (
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl text-center space-y-2">
                  <CheckCircle className="w-8 h-8 text-amber-500 mx-auto" />
                  <h5 className="font-serif font-bold text-sm text-[#0c1a40]">Enquiry Received</h5>
                  <p className="text-xs text-blue-900/80">
                    Thank you, <strong>{enquiryForm.name}</strong>. Your enquiry has been routed to{' '}
                    <strong>{general.contacts.admissionsEmail}</strong>. Our admissions team will be in touch shortly.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setEnquirySent(false);
                      setEnquiryForm({
                        name: '',
                        email: '',
                        phone: '',
                        subject: 'General Admissions Query',
                        message: '',
                      });
                    }}
                    className="text-xs text-[#0c1a40] underline font-medium cursor-pointer pt-1 block mx-auto"
                  >
                    Send another query
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Location & Directions Interactive Map Section */}
        <div className="mt-8 rounded-2xl border border-blue-200 overflow-hidden bg-white shadow-xs">
          <div className="p-6 bg-gradient-to-r from-blue-50 via-white to-amber-50 flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-sans border-b border-blue-100">
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-[#0c1a40] text-amber-400 flex items-center justify-center shrink-0 shadow-xs">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <span className="font-serif font-bold text-[#0c1a40] text-sm block">
                  {general.name} Campus Location · {general.address.city}
                </span>
                <span className="text-blue-900/75">
                  {general.address.plot}, {general.address.area}, {general.address.city}, {general.address.country} · GPS: {general.address.gps}
                </span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <a
                href={general.admissionsPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 bg-[#0c1a40] text-white rounded-lg font-semibold hover:bg-[#162a6b] transition-colors whitespace-nowrap shadow-xs"
              >
                Apply via Portal ↗
              </a>
              <a
                href={general.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 bg-amber-500 text-[#081226] font-bold rounded-lg hover:bg-amber-400 transition-colors whitespace-nowrap flex items-center gap-1.5 shadow-xs"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Open Google Maps Directions</span>
              </a>
            </div>
          </div>

          {/* Embedded Google Map Iframe with clean offline/blocked fallback underneath */}
          <div className="relative w-full h-80 sm:h-96 bg-blue-50 overflow-hidden">
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-blue-50 via-white to-amber-50/60">
              <div className="w-11 h-11 rounded-xl bg-[#0c1a40] text-amber-400 flex items-center justify-center mb-3 shadow-xs">
                <MapPin className="w-5 h-5" />
              </div>
              <div className="font-serif font-bold text-base text-[#0c1a40]">
                {general.name} · {general.address.plot}, {general.address.area}
              </div>
              <div className="text-xs text-blue-900 mt-1">
                {general.address.city}, {general.address.country} · GPS: {general.address.gps}
              </div>
              <div className="text-xs text-blue-800 mt-1">
                Tel: +267 316 1140 / +267 316 2208
              </div>
              <a
                href={general.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white text-xs font-semibold shadow-xs"
              >
                <Navigation className="w-3.5 h-3.5 text-amber-400" />
                <span>Open Google Maps Directions</span>
              </a>
            </div>
            <iframe
              title={`${general.name} Google Map`}
              src="https://maps.google.com/maps?q=-24.619000,25.909500+(Livingstone+Kolobeng+College)&t=&z=16&ie=UTF8&iwloc=&output=embed"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen={false}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="relative z-10 w-full h-full"
            />
            <div className="absolute bottom-3 left-3 z-20 bg-[#0c1a40]/95 text-white text-[11px] font-mono px-3 py-1.5 rounded-lg border border-blue-800 flex items-center gap-2 pointer-events-none">
              <MapPin className="w-3 h-3 text-amber-400 shrink-0" />
              <span>LKC Campus · GPS {general.address.gps}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

