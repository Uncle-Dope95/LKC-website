import React, { useState } from 'react';
import { useCmsSection } from '../services/cmsDataService';
import { Calculator, Download, FileText, Info, Landmark, Printer, X } from 'lucide-react';

export const FeeCalculator: React.FC = () => {
  const fees = useCmsSection('fees');
  const general = useCmsSection('general');

  const structure = fees.structure;
  const bankAccounts = fees.bankAccounts;
  const policyRules = fees.policyRules;

  const bandEntries = Object.entries(structure.tuitionPerTerm);
  const defaultLevelKey = structure.tuitionPerTerm['form-1']
    ? 'form-1'
    : (bandEntries[0]?.[0] || 'form-1');

  const [levelKey, setLevelKey] = useState<string>(defaultLevelKey);
  const [isBoarding, setIsBoarding] = useState<boolean>(false);
  const [paymentMode, setPaymentMode] = useState<'termly' | 'annual'>('termly');
  const [isNewStudent, setIsNewStudent] = useState<boolean>(true);
  const [siblingCount, setSiblingCount] = useState<number>(0);
  const [isTrustFund, setIsTrustFund] = useState<boolean>(false);
  const [selectedTransportZone, setSelectedTransportZone] = useState<number | null>(null);
  const [selectedOptionalIds, setSelectedOptionalIds] = useState<string[]>([]);
  const [showInvoiceModal, setShowInvoiceModal] = useState<boolean>(false);
  const [quoteReference, setQuoteReference] = useState<string>('');
  const [showPdfModal, setShowPdfModal] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'calculator' | 'schedule' | 'banks' | 'policy'>('calculator');

  const activeLevelKey = structure.tuitionPerTerm[levelKey] ? levelKey : defaultLevelKey;
  const selectedConfig = structure.tuitionPerTerm[activeLevelKey] || bandEntries[0]?.[1];
  const termsCount = selectedConfig?.termsCount || 3;

  // Base tuition
  const baseTermTuition = selectedConfig?.term || 0;
  const baseAnnualTuition = selectedConfig?.annual || 0;

  // Sibling discount (5% per younger sibling on tuition only, ineligible if trust fund)
  const siblingDiscountPct = (!isTrustFund && siblingCount > 0)
    ? Math.min(15, siblingCount * structure.siblingDiscountPercentage)
    : 0;
  const termSiblingDiscount = baseTermTuition * (siblingDiscountPct / 100);
  const netTermTuition = baseTermTuition - termSiblingDiscount;

  // Annual discount: 2.5% if paid before first day of Term 1 (ineligible if trust fund)
  let annualTuition = baseAnnualTuition;
  let annualPromptDiscount = 0;
  if (paymentMode === 'annual') {
    const annualSiblingDiscount = termSiblingDiscount * termsCount;
    const subtotalAnnualTuition = baseAnnualTuition - annualSiblingDiscount;
    if (!isTrustFund) {
      annualPromptDiscount = Math.round(subtotalAnnualTuition * (structure.annualDiscountPercentage / 100));
      annualTuition = subtotalAnnualTuition - annualPromptDiscount;
    } else {
      annualTuition = subtotalAnnualTuition;
    }
  }

  // Boarding
  const term1Boarding = isBoarding ? structure.boardingSchedule.term1 : 0;
  const annualBoarding = isBoarding ? structure.boardingSchedule.annual : 0;

  // One-off fees
  const entranceFee = isNewStudent ? structure.oneOffFees.entranceAssessment : 0;
  const registrationFee = isNewStudent ? structure.oneOffFees.registrationEnrollment : 0;
  const devLevy = isNewStudent
    ? (activeLevelKey === 'a-levels'
        ? structure.oneOffFees.developmentLevyALevel
        : structure.oneOffFees.developmentLevyForms1to5)
    : 0;
  const totalOneOff = entranceFee + registrationFee + devLevy;

  // Optional services
  const transportCostPerTerm =
    !isBoarding && selectedTransportZone !== null && structure.transportRoutes[selectedTransportZone]
      ? structure.transportRoutes[selectedTransportZone].costPerTerm
      : 0;

  const activeOptionalServices = structure.optionalServices.filter((svc) => {
    if (isBoarding && svc.id === 'lunch') return false;
    return selectedOptionalIds.includes(svc.id);
  });
  const optionalServicesCostPerTerm = activeOptionalServices.reduce(
    (sum, svc) => sum + svc.costPerTerm,
    0
  );

  const totalOptionalPerTerm = transportCostPerTerm + optionalServicesCostPerTerm;
  const totalOptionalAnnual = totalOptionalPerTerm * termsCount;

  // Totals
  const totalDueTerm1 =
    (paymentMode === 'termly' ? netTermTuition : annualTuition) +
    (paymentMode === 'termly' ? term1Boarding : annualBoarding) +
    (paymentMode === 'termly' ? totalOptionalPerTerm : totalOptionalAnnual) +
    totalOneOff;

  const regularTerm2Due =
    netTermTuition + (isBoarding ? structure.boardingSchedule.term2 : 0) + totalOptionalPerTerm;
  const regularTerm3Due =
    termsCount === 3
      ? netTermTuition + (isBoarding ? structure.boardingSchedule.term3 : 0) + totalOptionalPerTerm
      : 0;

  const formatBWP = (num: number) => {
    return `${structure.currency || 'P'} ` + Math.round(num).toLocaleString('en-BW');
  };

  const toggleOptionalService = (id: string) => {
    setSelectedOptionalIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleOpenInvoice = () => {
    setQuoteReference(
      `LKC-${structure.academicYear || '2026'}-${Math.floor(100000 + Math.random() * 900000)}`
    );
    setShowInvoiceModal(true);
  };

  const pdfUrl = general.contacts.feePolicyPdfUrl || structure.pdfDocumentUrl;

  return (
    <section id="fees" className="py-20 bg-blue-50/40 border-b border-blue-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header with Official Document Badge */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-8 border-b border-blue-200">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-amber-500/15 border border-amber-500/30 text-[#0c1a40] text-xs font-mono uppercase tracking-wider mb-3">
              <span>Official {structure.academicYear} Academic Year</span>
              <span aria-hidden="true">·</span>
              <span className="font-semibold">IGCSE School Fees Policy</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#0c1a40] tracking-tight text-balance">
              {structure.academicYear} Fees Policy & Financial Schedule
            </h2>
            <p className="text-sm sm:text-base text-blue-900/80 leading-relaxed font-sans mt-3">
              Approved schedule for {general.name}. Detailed tuition installments, boarding fees, {structure.annualDiscountPercentage}% annual prompt discount, sibling concessions, and official bank remittance accounts.
            </p>
          </div>

          {/* Quick PDF Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setShowPdfModal(true)}
              className="px-4 py-2.5 bg-[#0c1a40] hover:bg-[#162a6b] text-amber-400 font-semibold text-xs rounded-lg transition-colors flex items-center gap-2 shadow-xs cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              <span>Preview Official PDF</span>
            </button>
            <a
              href={pdfUrl}
              download="Livingstone_Kolobeng_College_Fees_Policy_2026.pdf"
              className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs rounded-lg transition-colors flex items-center gap-2 shadow-xs"
            >
              <Download className="w-4 h-4" />
              <span>Download Policy PDF</span>
            </a>
          </div>
        </div>

        {/* View Mode Tabs */}
        <div className="flex items-center gap-2 mb-8 overflow-x-auto pb-2 border-b border-blue-200">
          <button
            type="button"
            onClick={() => setActiveTab('calculator')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold tracking-wide transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'calculator'
                ? 'bg-[#0c1a40] text-white shadow-xs'
                : 'text-blue-900/80 hover:text-[#0c1a40] hover:bg-blue-100/70'
            }`}
          >
            <Calculator className="w-3.5 h-3.5 text-amber-400" />
            <span>Interactive Fee Calculator</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('schedule')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold tracking-wide transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'schedule'
                ? 'bg-[#0c1a40] text-white shadow-xs'
                : 'text-blue-900/80 hover:text-[#0c1a40] hover:bg-blue-100/70'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>Installment Due Dates Table</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('banks')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold tracking-wide transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'banks'
                ? 'bg-[#0c1a40] text-white shadow-xs'
                : 'text-blue-900/80 hover:text-[#0c1a40] hover:bg-blue-100/70'
            }`}
          >
            <Landmark className="w-3.5 h-3.5 text-amber-400" />
            <span>Bank Remittance Details ({bankAccounts.length} Banks)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('policy')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold tracking-wide transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'policy'
                ? 'bg-[#0c1a40] text-white shadow-xs'
                : 'text-blue-900/80 hover:text-[#0c1a40] hover:bg-blue-100/70'
            }`}
          >
            <Info className="w-3.5 h-3.5 text-amber-400" />
            <span>Official Policy Rules (Points 1–{policyRules.length})</span>
          </button>
        </div>

        {/* Tab 1: Interactive Fee Calculator */}
        {activeTab === 'calculator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-12">
            {/* Left Controls (7 cols) */}
            <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-xl border border-blue-200 shadow-xs space-y-7">
              {/* Step 1: Grade Selection */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#0c1a40] mb-3">
                  1. Select Grade Level
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {bandEntries.map(([id, band]) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setLevelKey(id)}
                      className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                        activeLevelKey === id
                          ? 'border-[#0c1a40] bg-[#0c1a40] text-white shadow-xs'
                          : 'border-blue-200 bg-blue-50/40 text-[#0c1a40] hover:bg-blue-100/60'
                      }`}
                    >
                      <div className="font-semibold text-xs">{band.label}</div>
                      <div
                        className={`text-[11px] mt-1 font-mono tabular-nums ${
                          activeLevelKey === id ? 'text-amber-300' : 'text-blue-900/70'
                        }`}
                      >
                        {formatBWP(band.term)} / term · {formatBWP(band.annual)}/yr
                      </div>
                    </button>
                  ))}
                </div>
                {termsCount === 2 && (
                  <div className="mt-2.5 text-xs bg-amber-50 text-[#0c1a40] p-2.5 rounded-md border border-amber-300">
                    <strong>Note:</strong> {selectedConfig?.label} is structured into <strong>2 billing terms</strong> (Term 1 & Term 2) at {formatBWP(baseTermTuition)} each to accommodate early Cambridge examination sitting.
                  </div>
                )}
              </div>

              {/* Step 2: Day vs Boarding */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#0c1a40] mb-3">
                  2. Residential Boarding Option (Masire Hostels)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setIsBoarding(false)}
                    className={`p-4 rounded-lg border text-left transition-all cursor-pointer ${
                      !isBoarding
                        ? 'border-[#0c1a40] bg-[#0c1a40] text-white'
                        : 'border-blue-200 bg-blue-50/40 text-[#0c1a40] hover:bg-blue-100/60'
                    }`}
                  >
                    <div className="font-semibold text-sm">Day Scholar</div>
                    <div className={`text-xs mt-1 ${!isBoarding ? 'text-blue-200' : 'text-blue-900/70'}`}>
                      Standard tuition only (07:30 – 16:30 CAT)
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsBoarding(true)}
                    className={`p-4 rounded-lg border text-left transition-all cursor-pointer ${
                      isBoarding
                        ? 'border-[#0c1a40] bg-[#0c1a40] text-white'
                        : 'border-blue-200 bg-blue-50/40 text-[#0c1a40] hover:bg-blue-100/60'
                    }`}
                  >
                    <div className="font-semibold text-sm">
                      Resident Boarding (Annual {formatBWP(structure.boardingSchedule.annual)})
                    </div>
                    <div className={`text-xs mt-1 font-mono tabular-nums ${isBoarding ? 'text-amber-300' : 'text-blue-900/70'}`}>
                      T1: {formatBWP(structure.boardingSchedule.term1)} | T2: {formatBWP(structure.boardingSchedule.term2)} | T3: {formatBWP(structure.boardingSchedule.term3)}
                    </div>
                  </button>
                </div>
              </div>

              {/* Step 3: Payment Schedule Mode */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#0c1a40] mb-3">
                  3. Payment Schedule & Advance Rebate
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentMode('termly')}
                    className={`p-3.5 rounded-lg border text-left transition-all cursor-pointer ${
                      paymentMode === 'termly'
                        ? 'border-[#0c1a40] bg-[#0c1a40] text-white'
                        : 'border-blue-200 bg-blue-50/40 text-[#0c1a40] hover:bg-blue-100/60'
                    }`}
                  >
                    <div className="font-semibold text-xs sm:text-sm">Term by Term (2 Installments/Term)</div>
                    <div className={`text-[11px] mt-1 ${paymentMode === 'termly' ? 'text-blue-200' : 'text-blue-900/70'}`}>
                      1st installment end of preceding term, 2nd by 1st month end
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMode('annual')}
                    className={`p-3.5 rounded-lg border text-left transition-all cursor-pointer ${
                      paymentMode === 'annual'
                        ? 'border-[#0c1a40] bg-[#0c1a40] text-white'
                        : 'border-blue-200 bg-blue-50/40 text-[#0c1a40] hover:bg-blue-100/60'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold text-xs sm:text-sm">Full Year Advance</span>
                      <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-400 text-[#081226]">
                        {structure.annualDiscountPercentage}% Rebate
                      </span>
                    </div>
                    <div className={`text-[11px] mt-1 ${paymentMode === 'annual' ? 'text-amber-300' : 'text-blue-900/70'}`}>
                      Paid prior to the first day of Term 1 (Policy Item 8)
                    </div>
                  </button>
                </div>
              </div>

              {/* Step 4: Sibling & Trust Fund Concessions */}
              <div className="pt-4 border-t border-blue-100 space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#0c1a40] mb-1.5">
                    4. Sibling Concession & Source of Funding
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <span className="text-xs text-blue-900/80 block mb-1">
                        Younger enrolled siblings ({structure.siblingDiscountPercentage}% discount each on tuition):
                      </span>
                      <select
                        value={siblingCount}
                        onChange={(e) => setSiblingCount(Number(e.target.value))}
                        disabled={isTrustFund}
                        className="w-full text-xs p-2.5 bg-blue-50/50 border border-blue-200 rounded-lg text-[#0c1a40] disabled:opacity-50"
                      >
                        <option value={0}>Eldest Child (0% - Pays Full Schedule)</option>
                        <option value={1}>2nd Child ({structure.siblingDiscountPercentage}% Discount on Tuition)</option>
                        <option value={2}>3rd Child ({structure.siblingDiscountPercentage * 2}% Discount on Tuition)</option>
                        <option value={3}>4th+ Child ({Math.min(15, structure.siblingDiscountPercentage * 3)}% Max Sibling Discount)</option>
                      </select>
                    </div>

                    <div className="flex items-center">
                      <label className="flex items-start gap-2.5 cursor-pointer p-2.5 rounded-lg bg-blue-50/50 border border-blue-200 w-full">
                        <input
                          type="checkbox"
                          checked={isTrustFund}
                          onChange={(e) => {
                            setIsTrustFund(e.target.checked);
                            if (e.target.checked) setSiblingCount(0);
                          }}
                          className="mt-0.5 rounded text-[#0c1a40] border-blue-300"
                        />
                        <span className="text-[11px] text-blue-900/85">
                          <strong>Trust Fund Payment:</strong> Under policy clause 9, no discounts apply to trust fund accounts.
                        </span>
                      </label>
                    </div>
                  </div>
                </div>

                {/* New Student Levies */}
                <label className="flex items-center gap-3 cursor-pointer pt-2">
                  <input
                    type="checkbox"
                    checked={isNewStudent}
                    onChange={(e) => setIsNewStudent(e.target.checked)}
                    className="w-4 h-4 text-[#0c1a40] rounded border-blue-300"
                  />
                  <span className="text-xs font-medium text-[#0c1a40]">
                    New Student Admission (Entrance {formatBWP(structure.oneOffFees.entranceAssessment)} + Registration {formatBWP(structure.oneOffFees.registrationEnrollment)} + Development Levy{' '}
                    {activeLevelKey === 'a-levels'
                      ? formatBWP(structure.oneOffFees.developmentLevyALevel)
                      : formatBWP(structure.oneOffFees.developmentLevyForms1to5)}
                    )
                  </span>
                </label>
              </div>

              {/* Step 5: Optional Add-ons */}
              <div className="pt-4 border-t border-blue-100 space-y-3">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#0c1a40]">
                  5. Optional Add-On Services
                </label>

                {!isBoarding && (
                  <div>
                    <div className="text-xs text-blue-900/80 mb-1">Campus Transit Bus Route:</div>
                    <select
                      value={selectedTransportZone !== null ? selectedTransportZone : ''}
                      onChange={(e) =>
                        setSelectedTransportZone(e.target.value === '' ? null : Number(e.target.value))
                      }
                      className="w-full text-xs p-2.5 bg-blue-50/50 border border-blue-200 rounded-lg text-[#0c1a40]"
                    >
                      <option value="">No Transport Required (Self drop-off)</option>
                      {structure.transportRoutes.map((route, i) => (
                        <option key={route.zone} value={i}>
                          {route.zone} (+{formatBWP(route.costPerTerm)}/term)
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {structure.optionalServices.map((svc) => {
                  if (isBoarding && svc.id === 'lunch') return null;
                  const checked = selectedOptionalIds.includes(svc.id);
                  return (
                    <label key={svc.id} className="flex items-center gap-2.5 cursor-pointer text-xs text-[#0c1a40]">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleOptionalService(svc.id)}
                        className="rounded text-[#0c1a40] border-blue-300"
                      />
                      <span>
                        {svc.name} (+{formatBWP(svc.costPerTerm)}/term)
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Right Quotation Card (5 cols) */}
            <div className="lg:col-span-5 bg-gradient-to-b from-[#0c1a40] to-[#081226] text-white p-6 sm:p-8 rounded-xl shadow-md flex flex-col justify-between sticky top-28 border border-blue-900">
              <div>
                <div className="flex items-center justify-between pb-4 border-b border-blue-900 mb-6">
                  <div>
                    <div className="text-xs uppercase tracking-widest text-amber-400 font-mono">
                      Official {structure.academicYear} Quote
                    </div>
                    <h3 className="text-lg font-serif font-bold text-white">{selectedConfig?.label}</h3>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-mono text-blue-200">BWP (Pula)</span>
                  </div>
                </div>

                {/* Itemized Rows */}
                <div className="space-y-3 text-xs text-blue-100 font-sans mb-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-white font-medium">
                        Base Tuition ({paymentMode === 'annual' ? `${termsCount} Terms` : 'Term 1'})
                      </div>
                      <div className="text-[11px] text-blue-300 font-mono tabular-nums">
                        {paymentMode === 'annual' ? formatBWP(baseAnnualTuition) : formatBWP(baseTermTuition)}
                      </div>
                    </div>
                    <div className="font-mono text-white text-right tabular-nums">
                      {paymentMode === 'annual' ? formatBWP(baseAnnualTuition) : formatBWP(baseTermTuition)}
                    </div>
                  </div>

                  {siblingDiscountPct > 0 && (
                    <div className="flex justify-between text-amber-300">
                      <div>Sibling Concession ({siblingDiscountPct}%)</div>
                      <div className="font-mono tabular-nums">
                        -{formatBWP(paymentMode === 'annual' ? termSiblingDiscount * termsCount : termSiblingDiscount)}
                      </div>
                    </div>
                  )}

                  {annualPromptDiscount > 0 && (
                    <div className="flex justify-between text-amber-400">
                      <div>{structure.annualDiscountPercentage}% Advance Payment Rebate</div>
                      <div className="font-mono tabular-nums">-{formatBWP(annualPromptDiscount)}</div>
                    </div>
                  )}

                  {isBoarding && (
                    <div className="flex justify-between items-start pt-2 border-t border-blue-900">
                      <div>
                        <div className="text-white font-medium">Masire Boarding Accommodation</div>
                        <div className="text-[11px] text-blue-300">
                          {paymentMode === 'annual'
                            ? `Full Year (${formatBWP(structure.boardingSchedule.annual)})`
                            : `Term 1 (${formatBWP(structure.boardingSchedule.term1)})`}
                        </div>
                      </div>
                      <div className="font-mono text-white tabular-nums">
                        {paymentMode === 'annual' ? formatBWP(annualBoarding) : formatBWP(term1Boarding)}
                      </div>
                    </div>
                  )}

                  {isNewStudent && totalOneOff > 0 && (
                    <div className="pt-2 border-t border-blue-900 space-y-1">
                      <div className="text-amber-400 text-[11px] uppercase tracking-wider font-semibold">
                        New Student Levies (Payable with 1st Installment):
                      </div>
                      <div className="flex justify-between text-blue-100 pl-2">
                        <span>Entrance Fee + Registration</span>
                        <span className="font-mono tabular-nums">{formatBWP(entranceFee + registrationFee)}</span>
                      </div>
                      <div className="flex justify-between text-blue-100 pl-2">
                        <span>Development Levy (Once-Off)</span>
                        <span className="font-mono tabular-nums">{formatBWP(devLevy)}</span>
                      </div>
                    </div>
                  )}

                  {totalOptionalPerTerm > 0 && (
                    <div className="pt-2 border-t border-blue-900 space-y-1">
                      <div className="text-blue-200 text-[11px] uppercase tracking-wider font-semibold">
                        Optional Services ({paymentMode === 'annual' ? 'Annual' : 'Term 1'}):
                      </div>
                      <div className="flex justify-between text-blue-100 pl-2">
                        <span>Transport / Optional Add-Ons</span>
                        <span className="font-mono tabular-nums">
                          {formatBWP(paymentMode === 'annual' ? totalOptionalAnnual : totalOptionalPerTerm)}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Total Box */}
                <div className="p-4 bg-[#081226] rounded-lg border border-blue-800">
                  <div className="flex items-baseline justify-between mb-1">
                    <span className="text-xs uppercase tracking-wider text-blue-200">
                      {paymentMode === 'annual' ? 'Total Annual Payable' : 'Payable for Term 1'}
                    </span>
                    <span className="text-2xl font-serif font-bold text-amber-400 font-mono tabular-nums">
                      {formatBWP(totalDueTerm1)}
                    </span>
                  </div>
                  {paymentMode === 'termly' && (
                    <div className="text-[11px] text-blue-200 space-y-0.5 pt-2 border-t border-blue-900 mt-2">
                      <div className="flex justify-between">
                        <span>Term 2 Payable:</span>
                        <span className="font-mono text-white tabular-nums">{formatBWP(regularTerm2Due)}</span>
                      </div>
                      {termsCount === 3 && (
                        <div className="flex justify-between">
                          <span>Term 3 Payable:</span>
                          <span className="font-mono text-white tabular-nums">{formatBWP(regularTerm3Due)}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-6 mt-6 border-t border-blue-900 space-y-2.5">
                <button
                  type="button"
                  onClick={handleOpenInvoice}
                  className="w-full py-3 px-4 bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <Printer className="w-4 h-4" />
                  <span>Generate Itemized Quotation</span>
                </button>
                <div className="text-[11px] text-blue-200 text-center flex items-center justify-center gap-2">
                  <span>Bursar WhatsApp:</span>
                  <a
                    href={general.contacts.bursarWhatsappLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-300 hover:underline font-mono"
                  >
                    {general.contacts.bursarWhatsapp}
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Installment Due Dates Table (Dynamic from CMS) */}
        {activeTab === 'schedule' && (
          <div className="bg-white rounded-xl border border-blue-200 shadow-xs overflow-hidden mb-12">
            <div className="p-6 bg-[#0c1a40] text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-serif font-bold text-lg">IGCSE School Fees Policy · Installment Schedules</h3>
                <p className="text-xs text-blue-200">
                  All fees payable in 2 installments per term as per policy rule 1
                </p>
              </div>
              <span className="text-xs font-mono px-2.5 py-1 bg-amber-400 text-[#081226] rounded font-semibold">
                {structure.academicYear} Academic Year
              </span>
            </div>

            <div className="p-6 space-y-8 text-xs sm:text-sm">
              {bandEntries.map(([id, band]) => (
                <div key={id}>
                  <div className="flex items-baseline justify-between mb-2">
                    <h4 className="font-serif font-bold text-base text-[#0c1a40]">
                      {band.label}: Term Fees {formatBWP(band.term)} | Annual Fees {formatBWP(band.annual)}
                      {band.termsCount === 2 ? ' (2 Terms)' : ''}
                    </h4>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse border border-blue-200 text-xs text-left">
                      <thead className="bg-blue-50 text-[#0c1a40] font-semibold">
                        <tr>
                          <th className="border border-blue-200 p-2.5">Term</th>
                          <th className="border border-blue-200 p-2.5">1st Payment</th>
                          <th className="border border-blue-200 p-2.5">Due Date</th>
                          <th className="border border-blue-200 p-2.5">2nd Payment</th>
                          <th className="border border-blue-200 p-2.5">Due Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-blue-100 font-mono tabular-nums text-[#0c1a40]">
                        {band.installments.map((inst, idx) => (
                          <tr key={idx}>
                            <td className="border border-blue-200 p-2.5 font-sans font-semibold">{inst.termName}</td>
                            <td className="border border-blue-200 p-2.5">{formatBWP(inst.pay1)}</td>
                            <td className="border border-blue-200 p-2.5 text-blue-900/80">{inst.due1}</td>
                            <td className="border border-blue-200 p-2.5">{formatBWP(inst.pay2)}</td>
                            <td className="border border-blue-200 p-2.5 text-blue-900/80">{inst.due2}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}

              {/* Boarding Schedule & External Exams */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-blue-200">
                <div className="p-4 bg-amber-50 rounded-lg border border-amber-300">
                  <div className="font-serif font-bold text-[#0c1a40] mb-1">
                    Boarding Annual Fees: {formatBWP(structure.boardingSchedule.annual)}
                  </div>
                  <div className="font-mono text-xs space-y-1 text-[#0c1a40] tabular-nums">
                    <div>· Term 1: {formatBWP(structure.boardingSchedule.term1)}</div>
                    <div>· Term 2: {formatBWP(structure.boardingSchedule.term2)}</div>
                    <div>· Term 3: {formatBWP(structure.boardingSchedule.term3)}</div>
                  </div>
                </div>
                <div className="p-4 bg-blue-50/70 rounded-lg border border-blue-200">
                  <div className="font-serif font-bold text-[#0c1a40] mb-1">External Examination Fees</div>
                  <p className="text-xs text-blue-900/80 leading-relaxed">
                    Please note that all external examination fees will be charged separately. All Form 5 examination fees must be paid by <strong>31 July {structure.academicYear}</strong> to ensure confirmation of examination entry.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Official Bank Details */}
        {activeTab === 'banks' && (
          <div className="space-y-6 mb-12">
            <div className="bg-[#0c1a40] text-white p-6 rounded-xl border border-blue-900">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="text-xs font-mono uppercase tracking-wider text-amber-400">
                    Official Remittance Channels
                  </div>
                  <h3 className="text-xl font-serif font-bold text-white mt-1">Institutional Bank Accounts</h3>
                  <p className="text-xs text-blue-200 mt-1">
                    Account Name for all bank transfers:{' '}
                    <strong className="text-white">{bankAccounts[0]?.accountName || 'Lavender Projects'}</strong>
                  </p>
                </div>
                <div className="p-3 bg-[#162a6b] rounded-lg border border-blue-800 text-xs">
                  <span className="text-blue-200 block font-mono">Proof of Payment WhatsApp:</span>
                  <a
                    href={general.contacts.bursarWhatsappLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-400 font-bold font-mono hover:underline"
                  >
                    {general.contacts.bursarWhatsapp}
                  </a>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {bankAccounts.map((bank) => (
                <div
                  key={bank.bankName}
                  className="bg-white p-6 rounded-xl border border-blue-200 shadow-xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between pb-3 border-b border-blue-100 mb-4">
                      <h4 className="font-serif font-bold text-[#0c1a40] text-base">{bank.bankName}</h4>
                      <Landmark className="w-4 h-4 text-amber-500" />
                    </div>
                    <div className="space-y-2.5 text-xs text-blue-900/85 font-sans">
                      <div>
                        <span className="text-blue-800/70 block text-[11px]">Account Name:</span>
                        <span className="font-semibold text-[#0c1a40]">{bank.accountName}</span>
                      </div>
                      <div>
                        <span className="text-blue-800/70 block text-[11px]">Account Number:</span>
                        <span className="font-mono font-bold text-[#0c1a40] text-sm tracking-wide bg-blue-50 border border-blue-100 px-2 py-0.5 rounded inline-block tabular-nums">
                          {bank.accountNumber}
                        </span>
                      </div>
                      <div>
                        <span className="text-blue-800/70 block text-[11px]">Branch:</span>
                        <span className="font-medium text-[#0c1a40]">
                          {bank.branch} (Code: {bank.branchCode})
                        </span>
                      </div>
                      <div>
                        <span className="text-blue-800/70 block text-[11px]">Swift Code:</span>
                        <span className="font-mono text-[#0c1a40]">{bank.swiftCode}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-blue-100 text-[11px] text-blue-800/75">
                    Quote student full name as reference
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 bg-amber-50 rounded-xl border border-amber-300 text-xs text-[#0c1a40] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <strong>Important Remittance Instruction:</strong> Kindly reference all payments with student&apos;s full name. Email proof of payment to the bursar on{' '}
                <a href={`mailto:${general.contacts.accountsEmail}`} className="underline font-bold">
                  {general.contacts.accountsEmail}
                </a>{' '}
                or WhatsApp{' '}
                <a
                  href={general.contacts.bursarWhatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline font-bold"
                >
                  {general.contacts.bursarWhatsapp}
                </a>
                .
              </div>
              <a
                href={general.contacts.bursarWhatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-1.5 bg-[#0c1a40] hover:bg-[#162a6b] text-amber-400 rounded-md font-semibold text-xs whitespace-nowrap text-center transition"
              >
                Send Proof on WhatsApp ↗
              </a>
            </div>
          </div>
        )}

        {/* Tab 4: Policy Terms */}
        {activeTab === 'policy' && (
          <div className="bg-white rounded-xl border border-blue-200 shadow-xs p-6 sm:p-8 mb-12">
            <div className="max-w-3xl mb-6">
              <h3 className="font-serif font-bold text-xl text-[#0c1a40] mb-2">
                {general.name} – Fees Policy Provisions
              </h3>
              <p className="text-xs text-blue-900/80">
                The following {policyRules.length} policy provisions are officially gazetted for the {structure.academicYear} academic calendar.
              </p>
            </div>

            <div className="space-y-4">
              {policyRules.map((rule, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-lg bg-blue-50/40 border border-blue-200/80 flex items-start gap-3 text-xs sm:text-sm text-[#0c1a40] leading-relaxed"
                >
                  <div className="w-6 h-6 rounded-full bg-[#0c1a40] text-amber-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 tabular-nums">
                    {idx + 1}
                  </div>
                  <div className="flex-1">{rule}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* PDF Document Preview Modal */}
      {showPdfModal && (
        <div className="fixed inset-0 z-50 bg-[#081226]/85 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full h-[90vh] shadow-2xl border border-blue-200 flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 sm:p-6 bg-[#0c1a40] text-white flex items-center justify-between border-b border-blue-900">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="font-serif font-bold text-base sm:text-lg">
                    {general.name} · {structure.academicYear} Fees Policy
                  </h3>
                  <div className="text-xs text-blue-200">Official Bursary & Fees Schedule Document</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={pdfUrl}
                  download="Livingstone_Kolobeng_College_Fees_Policy_2026.pdf"
                  className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs rounded-lg transition flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Download</span>
                </a>
                <button
                  type="button"
                  onClick={() => setShowPdfModal(false)}
                  className="p-1.5 text-blue-200 hover:text-white rounded-lg hover:bg-blue-900 transition cursor-pointer"
                  aria-label="Close PDF preview"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Embedded PDF View */}
            <div className="flex-1 bg-blue-50 relative">
              <iframe
                src={`${pdfUrl}#toolbar=1&navpanes=0`}
                title={`${general.name} ${structure.academicYear} Fees Policy`}
                className="w-full h-full border-none"
              />
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-blue-50 border-t border-blue-200 text-xs text-[#0c1a40] flex flex-col sm:flex-row items-center justify-between gap-2">
              <div>
                {general.address.postalBox} · {general.address.plot} · {general.address.city} · Tel: {general.contacts.phone} · email: {general.contacts.accountsEmail}
              </div>
              <div className="text-blue-900/75">Official LKC Bursary & Finance Directorate</div>
            </div>
          </div>
        </div>
      )}

      {/* Formal Pro-Forma Invoice Modal */}
      {showInvoiceModal && (
        <div className="fixed inset-0 z-50 bg-[#081226]/80 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-xl max-w-2xl w-full p-8 shadow-2xl border border-blue-200 relative my-8 text-[#0c1a40]">
            <button
              type="button"
              onClick={() => setShowInvoiceModal(false)}
              className="absolute top-5 right-5 p-1.5 rounded-md text-blue-900/60 hover:text-[#0c1a40] hover:bg-blue-50 transition-colors cursor-pointer"
              aria-label="Close quotation modal"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Invoice Header */}
            <div className="border-b border-blue-200 pb-6 mb-6">
              <div className="flex justify-between items-start gap-4">
                <div>
                  <h3 className="font-serif font-bold text-xl text-[#0c1a40]">{general.name}</h3>
                  <div className="text-xs text-blue-900/75 font-sans mt-0.5">
                    {general.address.plot}, {general.address.area}, {general.address.city}, {general.address.country}
                  </div>
                  <div className="text-xs text-blue-900/75 font-sans">
                    Cambridge International Centre · {general.contacts.accountsEmail} · Tel: {general.contacts.phone}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xs uppercase font-mono tracking-wider text-amber-700 font-bold">
                    Pro-Forma Quotation
                  </div>
                  <div className="text-xs text-blue-900/80 font-mono mt-0.5">REF: {quoteReference}</div>
                  <div className="text-xs text-blue-900/70 mt-0.5">{structure.academicYear} Academic Year</div>
                </div>
              </div>
            </div>

            {/* Configuration Details */}
            <div className="bg-blue-50/50 p-4 rounded-lg border border-blue-200 text-xs text-blue-900 mb-6 grid grid-cols-2 gap-4">
              <div>
                <span className="text-blue-800/70 block">Academic Level:</span>
                <span className="font-semibold text-[#0c1a40]">{selectedConfig?.label}</span>
              </div>
              <div>
                <span className="text-blue-800/70 block">Enrollment Status:</span>
                <span className="font-semibold text-[#0c1a40]">
                  {isNewStudent ? 'New Admission' : 'Continuing Student'} ({isBoarding ? 'Boarding' : 'Day Scholar'})
                </span>
              </div>
              <div>
                <span className="text-blue-800/70 block">Payment Mode:</span>
                <span className="font-semibold text-[#0c1a40]">
                  {paymentMode === 'annual'
                    ? `Full Year (${termsCount} Terms with ${structure.annualDiscountPercentage}% rebate)`
                    : 'Term 1 Installment Basis'}
                </span>
              </div>
              <div>
                <span className="text-blue-800/70 block">Bursary Remittance:</span>
                <span className="font-semibold text-[#0c1a40]">
                  {bankAccounts.map((b) => b.bankName.split(' ')[0]).join(' / ')}
                </span>
              </div>
            </div>

            {/* Table */}
            <div className="border border-blue-200 rounded-lg overflow-hidden mb-6 text-xs">
              <div className="bg-blue-50 p-3 font-semibold text-[#0c1a40] flex justify-between">
                <span>Description</span>
                <span>Amount ({structure.currency || 'BWP'})</span>
              </div>
              <div className="divide-y divide-blue-100">
                <div className="p-3 flex justify-between">
                  <span>Tuition ({paymentMode === 'annual' ? `${termsCount} Terms Full Year` : 'Term 1'})</span>
                  <span className="font-mono font-medium tabular-nums">
                    {formatBWP(paymentMode === 'annual' ? baseAnnualTuition : baseTermTuition)}
                  </span>
                </div>
                {siblingDiscountPct > 0 && (
                  <div className="p-3 flex justify-between text-[#162a6b]">
                    <span>Sibling Concession ({siblingDiscountPct}% on Tuition)</span>
                    <span className="font-mono font-medium tabular-nums">
                      -{formatBWP(paymentMode === 'annual' ? termSiblingDiscount * termsCount : termSiblingDiscount)}
                    </span>
                  </div>
                )}
                {annualPromptDiscount > 0 && (
                  <div className="p-3 flex justify-between text-amber-800">
                    <span>{structure.annualDiscountPercentage}% Advance Payment Rebate</span>
                    <span className="font-mono font-medium tabular-nums">-{formatBWP(annualPromptDiscount)}</span>
                  </div>
                )}
                {isBoarding && (
                  <div className="p-3 flex justify-between">
                    <span>
                      Masire Boarding (
                      {paymentMode === 'annual'
                        ? `Full Year ${formatBWP(structure.boardingSchedule.annual)}`
                        : `Term 1 ${formatBWP(structure.boardingSchedule.term1)}`}
                      )
                    </span>
                    <span className="font-mono font-medium tabular-nums">
                      {formatBWP(paymentMode === 'annual' ? annualBoarding : term1Boarding)}
                    </span>
                  </div>
                )}
                {isNewStudent && totalOneOff > 0 && (
                  <>
                    <div className="p-3 flex justify-between">
                      <span>Entrance Assessment Fee</span>
                      <span className="font-mono font-medium tabular-nums">{formatBWP(entranceFee)}</span>
                    </div>
                    <div className="p-3 flex justify-between">
                      <span>Registration / Enrollment Fee</span>
                      <span className="font-mono font-medium tabular-nums">{formatBWP(registrationFee)}</span>
                    </div>
                    <div className="p-3 flex justify-between">
                      <span>Institutional Development Levy (Once-Off)</span>
                      <span className="font-mono font-medium tabular-nums">{formatBWP(devLevy)}</span>
                    </div>
                  </>
                )}
                {totalOptionalPerTerm > 0 && (
                  <div className="p-3 flex justify-between">
                    <span>Selected Optional Services (Transport / Meals / Music)</span>
                    <span className="font-mono font-medium tabular-nums">
                      {formatBWP(paymentMode === 'annual' ? totalOptionalAnnual : totalOptionalPerTerm)}
                    </span>
                  </div>
                )}
              </div>
              <div className="bg-[#0c1a40] text-white p-3 font-semibold flex justify-between text-sm">
                <span>Total Amount Due</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">{formatBWP(totalDueTerm1)}</span>
              </div>
            </div>

            {/* Print and Actions */}
            <div className="flex items-center justify-between gap-4 pt-2">
              <span className="text-[11px] text-blue-900/75">
                Official banking: {bankAccounts[0]?.accountName || 'Lavender Projects'} · Proof to WhatsApp: {general.contacts.bursarWhatsapp}
              </span>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 bg-[#0c1a40] text-white rounded-lg text-xs font-medium hover:bg-[#162a6b] transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-amber-400" />
                <span>Print Quotation</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

