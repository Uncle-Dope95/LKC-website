import React from 'react';
import { useCmsSection } from '../services/cmsDataService';
import {
  ShieldCheck,
  ArrowUp,
  ExternalLink,
  Bed,
  Compass,
  GraduationCap,
  Trophy,
  Flame,
  Navigation,
  Timer,
  Building2,
} from 'lucide-react';
import { InstagramIcon, TikTokIcon, FacebookIcon, WhatsAppIcon } from './SocialIcons';
import { handleImageFallback } from '../utils/imageFallback';
import type { PageKey } from '../types';

interface FooterProps {
  onNavigate?: (page: PageKey) => void;
  onOpenAdmissions: () => void;
  onOpenPortal: () => void;
  onOpenProspectus: () => void;
  onOpenAdminCms?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenProspectus,
}) => {
  const general = useCmsSection('general');
  const boarding = useCmsSection('boarding');
  const footer = useCmsSection('footer');
  const settings = useCmsSection('settings');

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNav = (page: PageKey) => {
    if (onNavigate) {
      onNavigate(page);
      scrollToTop();
    }
  };

  const phoneHref = `tel:${general.contacts.phone.replace(/\s+/g, '')}`;

  return (
    <footer className="bg-[#081226] text-blue-200 text-xs font-sans border-t border-blue-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-16 pb-12">

        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-blue-900">

          {/* Brand & Ethos (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 flex items-center justify-center shrink-0">
                <img
                  src={general.logoUrl}
                  alt={general.name}
                  loading="lazy"
                  onError={handleImageFallback}
                  className="w-12 h-12 object-contain"
                />
              </div>
              <div>
                <span className="font-serif font-bold text-base text-white block">
                  {general.name}
                </span>
                <span className="text-[11px] text-amber-400 tracking-wider font-mono">
                  "{general.motto}" · {general.mottoEnglish}
                </span>
              </div>
            </div>

            <p className="text-blue-100 text-xs leading-relaxed max-w-sm">
              {footer.tagline}
            </p>

            <div className="flex items-center gap-2 text-amber-300 text-[11px]">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{general.cambridgeCentreNo}</span>
            </div>

            {/* Social channels with authentic brand SVGs */}
            {footer.showSocialLinks && (
              <div className="pt-2 flex flex-wrap items-center gap-2.5 text-xs">
                <a
                  href={general.socials.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#0c1a40] text-amber-300 border border-blue-800 hover:bg-[#162a6b] transition-colors"
                  title={`Chat on WhatsApp: ${general.socials.whatsappNumber}`}
                >
                  <WhatsAppIcon className="w-4 h-4" />
                  <span>{general.socials.whatsappNumber}</span>
                </a>

                <a
                  href={general.socials.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-full hover:scale-110 transition-transform bg-white/10 border border-white/15"
                  title={`Instagram: ${general.socials.instagramHandle}`}
                  aria-label="LKC Instagram"
                >
                  <InstagramIcon className="w-4 h-4" />
                </a>

                <a
                  href={general.socials.tiktok}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-full hover:scale-110 transition-transform bg-white/10 border border-white/15"
                  title={`TikTok: ${general.socials.tiktokHandle}`}
                  aria-label="LKC TikTok"
                >
                  <TikTokIcon className="w-4 h-4" />
                </a>

                <a
                  href={general.socials.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-full hover:scale-110 transition-transform bg-white/10 border border-white/15"
                  title={`Facebook: ${general.socials.facebookHandle}`}
                  aria-label="LKC Facebook"
                >
                  <FacebookIcon className="w-4 h-4" />
                </a>
              </div>
            )}
          </div>

          {/* Column: Dedicated Pages */}
          <div className="space-y-3">
            <div className="font-serif font-bold text-amber-400 uppercase tracking-wider text-[11px]">
              {footer.quickLinksTitle || 'Campus & Academics'}
            </div>
            <ul className="space-y-2 text-blue-100 text-[11px]">
              <li>
                <a
                  href="#campus"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('campus');
                  }}
                  className="hover:text-white transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <Building2 className="w-3 h-3 text-amber-400" />
                  <span>Campus & Leadership Desk</span>
                </a>
              </li>
              <li>
                <a
                  href="#departments"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('departments');
                  }}
                  className="hover:text-white transition-colors cursor-pointer text-left block"
                >
                  8 Academic Departments & Faculty
                </a>
              </li>
              <li>
                <a
                  href="#achievers"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('achievers');
                  }}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left flex items-center gap-1.5 font-semibold text-amber-300"
                >
                  <Trophy className="w-3 h-3 text-amber-400" />
                  <span>Top Achievers ({settings.activeAchieversYear || '2025'})</span>
                </a>
              </li>
              <li>
                <a
                  href="#sports"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('sports');
                  }}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left flex items-center gap-1.5 font-medium text-blue-100"
                >
                  <Trophy className="w-3 h-3 text-amber-400" />
                  <span>Sports & Four College Houses</span>
                </a>
              </li>
              <li>
                <a
                  href="#athletics"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('athletics');
                  }}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left flex items-center gap-1.5 font-medium text-blue-100"
                >
                  <Timer className="w-3 h-3 text-amber-400" />
                  <span>Track & Field Athletics</span>
                </a>
              </li>
              <li>
                <a
                  href="#jaguars"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('jaguars');
                  }}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left flex items-center gap-1.5 font-semibold text-amber-300"
                >
                  <Flame className="w-3 h-3 text-amber-400" />
                  <span>The Jaguars (1st XV Rugby)</span>
                </a>
              </li>
              <li>
                <a
                  href="#boarding"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('boarding');
                  }}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <Bed className="w-3 h-3 text-amber-400" />
                  <span>Boarding Houses ({boarding.capacity} Beds)</span>
                </a>
              </li>
              <li>
                <a
                  href="#excursions"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('excursions');
                  }}
                  className="hover:text-amber-300 transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <Compass className="w-3 h-3 text-amber-400" />
                  <span>Educational Excursions</span>
                </a>
              </li>
              <li>
                <a
                  href="#alumni"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('alumni');
                  }}
                  className="hover:text-amber-300 transition-colors cursor-pointer text-left flex items-center gap-1.5"
                >
                  <GraduationCap className="w-3 h-3 text-amber-400" />
                  <span>Alumni Network Registry</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Column: Admissions & Policies */}
          <div className="space-y-3">
            <div className="font-serif font-bold text-amber-400 uppercase tracking-wider text-[11px]">
              {footer.admissionsTitle || 'Portals & Admissions'}
            </div>
            <ul className="space-y-2 text-blue-100 text-[11px]">
              <li>
                <a
                  href={general.admissionsPortalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-amber-400 hover:underline transition-colors flex items-center gap-1 font-bold"
                >
                  <span>Apply for Admission (Online)</span>
                  <ExternalLink className="w-3 h-3 text-amber-400" />
                </a>
              </li>
              <li>
                <a
                  href={general.parentsPortalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-amber-300 transition-colors flex items-center gap-1"
                >
                  <span>Parents Portal (lkcportal.com)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a
                  href={general.teachersPortalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors flex items-center gap-1"
                >
                  <span>Teachers & Staff Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a
                  href="#fees"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('fees');
                  }}
                  className="hover:text-white transition-colors cursor-pointer text-left block"
                >
                  Tuition Fees & Calculator (BWP)
                </a>
              </li>
              <li>
                <a
                  href="#news"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('news');
                  }}
                  className="hover:text-white transition-colors cursor-pointer text-left block"
                >
                  College News & 2026 Events
                </a>
              </li>
              <li>
                <a
                  href={general.contacts.feePolicyPdfUrl}
                  download="Livingstone-Kolobeng-College-2026-Fees-Policy.pdf"
                  className="text-amber-400 hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>2026 Fees Policy (Download PDF)</span>
                </a>
              </li>
              <li>
                <a
                  href={general.contacts.bursarWhatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-amber-300 hover:underline"
                >
                  Bursar WhatsApp: {general.contacts.bursarWhatsapp}
                </a>
              </li>
              <li>
                <button type="button" onClick={onOpenProspectus} className="hover:text-amber-400 text-left transition-colors cursor-pointer">
                  Download 2026/27 Prospectus
                </button>
              </li>
            </ul>
          </div>

          {/* Column: Campus Location & Phone */}
          <div className="space-y-3">
            <div className="font-serif font-bold text-amber-400 uppercase tracking-wider text-[11px]">
              Campus Location
            </div>
            <div className="space-y-2 text-blue-100 text-[11px] leading-relaxed">
              <p>{general.address.plot}<br />{general.address.area}, {general.address.city}, {general.address.country}</p>
              <p>Postal: {general.address.postalBox}</p>
              <p className="font-mono text-amber-300 text-[10px]">GPS: {general.address.gps}</p>
              <div className="pt-1">
                <a
                  href={general.googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold transition-colors shadow-xs"
                >
                  <Navigation className="w-3 h-3" />
                  <span>Open Google Maps Directions</span>
                </a>
              </div>
              <p className="pt-1">
                Switchboard: <a href={phoneHref} className="hover:text-white font-mono text-white font-bold">{general.contacts.phone}</a>
              </p>
              <p>
                Principal: <a href={`mailto:${general.contacts.principalEmail}`} className="text-blue-100 hover:text-white">{general.contacts.principalEmail}</a>
              </p>
              <p>Hours: {general.contacts.officeHours}</p>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-blue-200">
          <div>
            <span>© {new Date().getFullYear()} {footer.copyrightText || general.name}</span>
          </div>

          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <span>{footer.bottomNotice}</span>
            <span aria-hidden="true">·</span>
            <span>Home of the {general.mascot}</span>
            <button
              type="button"
              onClick={scrollToTop}
              className="p-1.5 rounded-md bg-[#0c1a40] hover:bg-[#162a6b] text-blue-100 hover:text-white transition-colors flex items-center gap-1 cursor-pointer border border-blue-800"
              title="Return to top"
            >
              <ArrowUp className="w-3.5 h-3.5" />
              <span>Back to Top</span>
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
