import React, { useState } from 'react';
import {
  Menu,
  X,
  Phone,
  ExternalLink,
  Bed,
  Compass,
  GraduationCap,
  Home,
  Trophy,
  Sparkles,
  Shield,
  Building2,
  BookOpen,
  Timer,
  Wallet,
  Newspaper,
  Mail,
  Sun,
  Moon,
} from 'lucide-react';
import { useCmsSection } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import type { ThemeMode } from '../utils/theme';
import { InstagramIcon, TikTokIcon, FacebookIcon, WhatsAppIcon } from './SocialIcons';
import type { PageKey } from '../types';

export type NavPage = PageKey;

interface HeaderProps {
  activePage: NavPage;
  onNavigate: (page: NavPage) => void;
  onOpenAdmissions: () => void;
  onOpenPortal: () => void;
  onOpenAdminCms?: () => void;
  theme?: ThemeMode;
  onToggleTheme?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activePage,
  onNavigate,
  onOpenPortal,
  theme = 'light',
  onToggleTheme,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const general = useCmsSection('general');
  const boarding = useCmsSection('boarding');
  const navigation = useCmsSection('navigation');
  const settings = useCmsSection('settings');

  const visibleNavItems = [...navigation]
    .filter((item) => item.visible)
    .sort((a, b) => a.order - b.order);

  const handleNavClick = (page: NavPage) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const phoneHref = `tel:${general.contacts.phone.replace(/\s+/g, '')}`;

  const getMobileIcon = (pageKey: PageKey) => {
    switch (pageKey) {
      case 'home':
        return <Home className="w-4 h-4 text-blue-700" />;
      case 'campus':
        return <Building2 className="w-4 h-4 text-[#162a6b]" />;
      case 'boarding':
        return <Bed className="w-4 h-4 text-amber-600" />;
      case 'excursions':
        return <Compass className="w-4 h-4 text-[#162a6b]" />;
      case 'alumni':
        return <GraduationCap className="w-4 h-4 text-amber-600" />;
      case 'achievers':
        return <Trophy className="w-4 h-4 text-amber-500" />;
      case 'sports':
        return <Trophy className="w-4 h-4 text-[#0c1a40]" />;
      case 'athletics':
        return <Timer className="w-4 h-4 text-amber-600" />;
      case 'jaguars':
        return <Shield className="w-4 h-4 text-amber-500" />;
      case 'departments':
      case 'curriculum':
        return <BookOpen className="w-4 h-4 text-[#162a6b]" />;
      case 'fees':
        return <Wallet className="w-4 h-4 text-amber-600" />;
      case 'news':
      case 'events':
        return <Newspaper className="w-4 h-4 text-[#162a6b]" />;
      case 'contact':
        return <Mail className="w-4 h-4 text-[#162a6b]" />;
      default:
        return <Home className="w-4 h-4 text-blue-700" />;
    }
  };

  return (
    <>
      {/* Top advisory notification strip with LKC Royal Blue, White & Gold accents */}
      <div className="bg-[#081226] text-blue-100 text-xs py-1.5 px-3 sm:px-6 border-b border-blue-900">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs tracking-wide">
          <div className="flex items-center gap-2.5">
            <span className="font-semibold text-amber-400">Cambridge International Centre</span>
            <span className="text-blue-400" aria-hidden="true">·</span>
            <span className="hidden sm:inline text-blue-100">
              {general.address.plot}, {general.address.area}, {general.address.city}
            </span>
            <span className="hidden xl:inline text-blue-400" aria-hidden="true">·</span>
            <span className="hidden xl:inline text-amber-300 font-medium">
              {settings.admissionsOpen ? 'Preschool to A-Levels · Admissions Open' : 'Cambridge Preschool to A-Levels'}
            </span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 text-blue-100 flex-wrap">
            <a href={phoneHref} className="flex items-center gap-1 hover:text-amber-300 transition-colors">
              <Phone className="w-3 h-3 text-amber-400" />
              <span className="hidden sm:inline">{general.contacts.phone}</span>
            </a>

            {/* Social Icons */}
            <div className="flex items-center gap-1.5 pl-1 sm:border-l sm:border-blue-800">
              <a
                href={general.socials.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1 rounded-full hover:scale-110 transition-transform"
                title={`Official WhatsApp: ${general.socials.whatsappNumber}`}
                aria-label="Chat on WhatsApp"
              >
                <WhatsAppIcon className="w-4 h-4" />
              </a>
              <a
                href={general.socials.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1 rounded-full hover:scale-110 transition-transform"
                title={`Instagram: ${general.socials.instagramHandle}`}
                aria-label="LKC Instagram"
              >
                <InstagramIcon className="w-4 h-4" />
              </a>
              <a
                href={general.socials.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1 rounded-full hover:scale-110 transition-transform"
                title={`TikTok: ${general.socials.tiktokHandle}`}
                aria-label="LKC TikTok"
              >
                <TikTokIcon className="w-4 h-4" />
              </a>
              <a
                href={general.socials.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1 rounded-full hover:scale-110 transition-transform"
                title={`Facebook: ${general.socials.facebookHandle}`}
                aria-label="LKC Facebook"
              >
                <FacebookIcon className="w-4 h-4" />
              </a>
            </div>

            {/* Portals Styled as Distinct Interactive Buttons */}
            <div className="flex items-center gap-1.5 sm:border-l sm:border-blue-800 sm:pl-2">
              <a
                href={general.parentsPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-0.5 rounded-md bg-amber-400 text-[#081226] hover:bg-amber-300 border border-amber-300 font-bold text-[11px] transition-all shadow-xs cursor-pointer"
              >
                Parents Portal
              </a>
              <a
                href={general.teachersPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-0.5 rounded-md bg-[#162a6b] text-white hover:bg-blue-700 border border-blue-600 font-semibold text-[11px] transition-all shadow-xs cursor-pointer hidden sm:inline-block"
              >
                Teachers Portal
              </a>
              <button
                type="button"
                onClick={onOpenPortal}
                className="px-2.5 py-0.5 rounded-md bg-white/10 text-amber-300 hover:bg-white hover:text-[#081226] border border-amber-400/50 font-semibold text-[11px] transition-all cursor-pointer"
              >
                Portals Hub
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Top Bar */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-blue-100 shadow-xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-5 min-h-20 py-2 flex flex-wrap lg:flex-nowrap items-center justify-between gap-2">
          {/* Zone 1: Logo and Institution Wordmark */}
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick('home');
            }}
            className="flex items-center gap-2 whitespace-nowrap shrink-0 group text-left cursor-pointer"
          >
            <div className="w-10 h-10 xl:w-11 xl:h-11 flex items-center justify-center shrink-0">
              <img
                src={general.logoUrl}
                alt={`${general.name} Logo`}
                onError={handleImageFallback}
                className="w-10 h-10 xl:w-11 xl:h-11 object-contain filter drop-shadow-xs group-hover:scale-105 transition-transform"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-xs xl:text-sm font-serif font-bold tracking-tight text-[#0c1a40] group-hover:text-[#162a6b] transition-colors leading-tight">
                {general.name}
              </span>
              <span className="text-[10px] text-blue-900 font-sans tracking-wide flex items-center gap-1">
                <span>{general.address.city} · Est. {general.established}</span>
                <span className="text-amber-600 font-serif italic font-semibold hidden 2xl:inline">· {general.motto}</span>
              </span>
            </div>
          </a>

          {/* Zone 2: Dynamic Stacked Navigation Links (wraps cleanly so no links ever clip on 1024px-1280px screens) */}
          <nav className="hidden lg:flex flex-wrap items-center justify-center gap-x-0.5 gap-y-1 text-[#0c1a40] min-w-0 flex-1">
            {visibleNavItems.map((item) => {
              const isActive = activePage === item.pageKey;
              const badgeText =
                item.pageKey === 'boarding'
                  ? `${boarding.capacity} Beds`
                  : item.pageKey === 'achievers'
                  ? settings.activeAchieversYear || item.badge || 'Awards'
                  : item.badge;

              return (
                <a
                  key={item.id}
                  href={`#${item.pageKey}`}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick(item.pageKey);
                  }}
                  className={`flex flex-col items-center justify-center text-center px-1.5 py-1 rounded-lg transition-all cursor-pointer shrink-0 ${
                    isActive
                      ? 'bg-blue-50 text-[#0c1a40] font-bold border-b-2 border-amber-500'
                      : 'hover:bg-blue-50/70 hover:text-[#162a6b]'
                  }`}
                >
                  <span className="text-[11px] font-semibold whitespace-nowrap leading-tight">
                    {item.label}
                  </span>
                  {badgeText ? (
                    <span className="text-[9px] font-mono px-1.5 rounded-full bg-amber-100 text-[#0c1a40] font-bold border border-amber-300 flex items-center gap-0.5 leading-tight mt-0.5">
                      {item.pageKey === 'achievers' && <Sparkles className="w-2 h-2 text-amber-600" />}
                      <span>{badgeText}</span>
                    </span>
                  ) : (
                    <span className="text-[9px] text-blue-700/80 whitespace-nowrap leading-tight mt-0.5">
                      {item.sublabel}
                    </span>
                  )}
                </a>
              );
            })}
          </nav>

          {/* Zone 3: Theme Toggle & Apply Button */}
          <div className="hidden sm:flex items-center gap-2 shrink-0">
            {onToggleTheme && (
              <button
                type="button"
                onClick={onToggleTheme}
                data-testid="theme-toggle"
                aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
                aria-pressed={theme === 'dark'}
                title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
                className="p-2 rounded-lg border border-blue-200 bg-blue-50/60 hover:bg-blue-50 text-[#0c1a40] dark:border-blue-800 dark:bg-[#132752] dark:text-amber-300 dark:hover:bg-[#1a346b] transition-colors cursor-pointer"
              >
                {theme === 'dark' ? (
                  <Sun className="w-4 h-4 text-amber-400" aria-hidden="true" />
                ) : (
                  <Moon className="w-4 h-4 text-[#0c1a40]" aria-hidden="true" />
                )}
              </button>
            )}
            <a
              href={general.admissionsPortalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2 text-[11px] xl:text-xs font-semibold text-white bg-gradient-to-r from-[#0c1a40] to-[#162a6b] rounded-lg hover:from-[#162a6b] hover:to-[#0c1a40] transition-all shadow-xs whitespace-nowrap shrink-0 cursor-pointer border border-blue-900 flex items-center gap-1"
            >
              <span>Apply for Admission</span>
              <ExternalLink className="w-3 h-3 text-amber-400" />
            </a>
          </div>

          {/* Mobile theme toggle & hamburger button */}
          <div className="flex items-center gap-2 lg:hidden">
            {onToggleTheme && (
              <button
                type="button"
                onClick={onToggleTheme}
                data-testid="theme-toggle-mobile"
                aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
                aria-pressed={theme === 'dark'}
                title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
                className="p-2 rounded-md border border-blue-200 bg-blue-50/60 text-[#0c1a40] dark:border-blue-800 dark:bg-[#132752] dark:text-amber-300 transition-colors cursor-pointer sm:hidden"
              >
                {theme === 'dark' ? (
                  <Sun className="w-4 h-4 text-amber-400" aria-hidden="true" />
                ) : (
                  <Moon className="w-4 h-4 text-[#0c1a40]" aria-hidden="true" />
                )}
              </button>
            )}
            <a
              href={general.admissionsPortalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 text-xs font-semibold text-white bg-[#0c1a40] rounded-md sm:hidden cursor-pointer"
            >
              Apply
            </a>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md text-[#0c1a40] hover:bg-blue-50 transition-colors cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-b border-blue-100 px-6 py-5 shadow-lg max-h-[80vh] overflow-y-auto">
            <nav className="flex flex-col gap-2 text-sm font-medium text-[#0c1a40]">
              {visibleNavItems.map((item) => {
                const isActive = activePage === item.pageKey;
                return (
                  <a
                    key={item.id}
                    href={`#${item.pageKey}`}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavClick(item.pageKey);
                    }}
                    className={`text-left py-2.5 px-3 rounded-lg flex items-center justify-between cursor-pointer ${
                      isActive
                        ? 'bg-blue-50 text-[#0c1a40] font-bold border border-blue-200'
                        : 'hover:bg-blue-50/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      {getMobileIcon(item.pageKey)}
                      <span>
                        {item.label} {item.sublabel ? `(${item.sublabel})` : ''}
                      </span>
                    </div>
                    {item.badge && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-100 text-[#0c1a40] font-bold">
                        {item.badge}
                      </span>
                    )}
                  </a>
                );
              })}

              <a
                href="#news"
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick('news');
                }}
                className={`text-left py-2.5 px-3 rounded-lg flex items-center justify-between cursor-pointer ${
                  activePage === 'news' ? 'bg-blue-50 font-bold border border-blue-200' : 'hover:bg-blue-50/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Newspaper className="w-4 h-4 text-[#162a6b]" />
                  <span>College News & Events Calendar</span>
                </div>
              </a>

              <div className="pt-3 border-t border-blue-100 flex flex-col gap-2.5">
                <a
                  href={general.admissionsPortalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-full py-2.5 px-4 text-center rounded-lg bg-[#0c1a40] text-white font-semibold text-xs hover:bg-[#162a6b] block"
                >
                  Apply for Admission (Online Portal)
                </a>
              </div>
            </nav>
          </div>
        )}
      </header>
    </>
  );
};
