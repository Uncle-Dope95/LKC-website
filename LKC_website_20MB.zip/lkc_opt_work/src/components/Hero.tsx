import React from 'react';
import { ArrowRight, Download, MapPin, Award, BookOpen } from 'lucide-react';
import { useCmsSection } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import type { PageKey } from '../types';

interface HeroProps {
  onNavigate?: (page: PageKey) => void;
  onOpenAdmissions: () => void;
  onOpenProspectus: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onNavigate, onOpenProspectus }) => {
  const hero = useCmsSection('hero');
  const general = useCmsSection('general');

  return (
    <section className="relative bg-[#081226] text-white overflow-hidden">
      {/* Background Hero Image with measured Blue contrast scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src={hero.heroImage || './assets/aistudio/image_efcc4027.png'}
          alt={`${general.name} campus grounds and entrance in Gaborone, Botswana`}
          data-no-global-zoom="true"
          onError={handleImageFallback}
          className="w-full h-full object-cover object-center brightness-90"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#081226]/95 via-[#0c1a40]/85 to-[#162a6b]/70" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 pt-16 pb-20 lg:pt-24 lg:pb-28">
        <div className="max-w-3xl">
          {/* Unboxed metadata kicker */}
          <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-widest text-amber-400 font-sans font-semibold mb-4">
            <span>{general.motto}</span>
            <span aria-hidden="true" className="text-blue-400">·</span>
            <span>{general.mottoEnglish}</span>
            <span aria-hidden="true" className="text-blue-400">·</span>
            <span>{hero.badgeText || general.cambridgeCentreNo}</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-serif font-bold text-white tracking-tight leading-tight text-balance mb-6">
            {hero.headlineTop}{' '}
            <span className="text-amber-400">{hero.headlineAccent}</span>
            {hero.headlineBottom ? ` — ${hero.headlineBottom}` : ''}
          </h1>

          <p className="text-base sm:text-lg text-blue-100 leading-relaxed font-sans max-w-2xl mb-8">
            {hero.description}
          </p>

          <div className="flex flex-wrap items-center gap-3.5 mb-12">
            <a
              href={general.admissionsPortalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3.5 text-sm font-bold text-[#0c1a40] bg-amber-400 rounded-lg hover:bg-amber-300 transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              <span>Apply for 2026/2027</span>
              <ArrowRight className="w-4 h-4" />
            </a>
            <a
              href="#fees"
              onClick={(e) => {
                if (onNavigate) {
                  e.preventDefault();
                  onNavigate('fees');
                }
              }}
              className="px-5 py-3.5 text-sm font-medium text-white bg-white/10 hover:bg-white/20 border border-white/25 rounded-lg transition-colors cursor-pointer"
            >
              Calculate Term Fees
            </a>
          </div>

          {/* Quick trust metrics from CMS */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-8 border-t border-blue-800/70 text-blue-100">
            <div>
              <div className="text-2xl lg:text-3xl font-serif font-bold text-amber-400 tabular-nums">
                {hero.stat1Value}
              </div>
              <div className="text-xs text-blue-100 mt-1">{hero.stat1Label}</div>
            </div>
            <div>
              <div className="text-2xl lg:text-3xl font-serif font-bold text-amber-400 tabular-nums">
                {hero.stat2Value}
              </div>
              <div className="text-xs text-blue-100 mt-1">{hero.stat2Label}</div>
            </div>
            <div>
              <div className="text-2xl lg:text-3xl font-serif font-bold text-amber-400 tabular-nums">
                {hero.stat3Value}
              </div>
              <div className="text-xs text-blue-100 mt-1">{hero.stat3Label}</div>
            </div>
            <div>
              <div className="text-2xl lg:text-3xl font-serif font-bold text-amber-400 tabular-nums">
                {hero.stat4Value}
              </div>
              <div className="text-xs text-blue-100 mt-1">{hero.stat4Label}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Operational Utility Ribbon */}
      <div className="relative z-10 bg-[#081226] border-t border-blue-900 text-blue-100 py-3.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 text-xs font-sans">
          <div className="flex flex-wrap items-center gap-6">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{`${general.address.plot}, ${general.address.area}, ${general.address.city}, ${general.address.country}`}</span>
            </div>
            <div className="hidden md:flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{general.cambridgeCentreNo}</span>
            </div>
            <div className="hidden lg:flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Preschool, Forms 1–5 & Cambridge AS/A2 Levels</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={onOpenProspectus}
              className="flex items-center gap-1.5 text-white hover:text-amber-300 transition-colors cursor-pointer font-medium"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>Download 2026/27 Prospectus</span>
            </button>
            <span className="text-blue-700" aria-hidden="true">|</span>
            <span className="text-amber-400 font-semibold">Day & Boarding Available</span>
          </div>
        </div>
      </div>
    </section>
  );
};
