import React, { useState } from 'react';
import {
  ArrowRight,
  Award,
  Bed,
  BookOpen,
  Building2,
  Calendar,
  Compass,
  Flame,
  GraduationCap,
  MapPin,
  Newspaper,
  Phone,
  PlayCircle,
  Shield,
  Sparkles,
  Timer,
  Trophy,
  Wallet,
  X,
} from 'lucide-react';
import { Hero } from './Hero';
import { AlumniTestimonials } from './AlumniTestimonials';
import { useCmsSection, useFeaturedCmsItems } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { openImageViewer } from './ImageLightboxModal';
import type { CmsItem, PageKey } from '../types';

interface HomePageProps {
  onNavigate: (page: PageKey) => void;
  onOpenAdmissions: () => void;
  onOpenProspectus: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onOpenAdmissions,
  onOpenProspectus,
}) => {
  const general = useCmsSection('general');
  const hero = useCmsSection('hero');
  const about = useCmsSection('about');
  const media = useCmsSection('media');
  const settings = useCmsSection('settings');
  const featuredItems = useFeaturedCmsItems().slice(
    0,
    Math.max(1, settings.homepageMaxFeaturedItems || 6)
  );

  const schoolVideoAsset =
    media.find((m) => m.id === 'm-18') ||
    media.find((m) => m.mediaType === 'video' && m.category === 'Campus') ||
    media.find((m) => m.mediaType === 'video');
  const schoolVideoUrl = schoolVideoAsset?.url || './assets/aistudio/school_video_5ac9eb5b.mp4';
  const schoolVideoPoster = hero.heroImage || './assets/aistudio/image_efcc4027.png';

  const [selectedFeaturedItem, setSelectedFeaturedItem] = useState<CmsItem | null>(null);

  const featuredNewsAndEvents = featuredItems.filter(
    (item) => item.pageKey === 'news' || item.pageKey === 'events'
  );
  const featuredHighlights = featuredItems.filter(
    (item) => item.pageKey !== 'news' && item.pageKey !== 'events'
  );

  const quickDirectory: {
    pageKey: PageKey;
    title: string;
    subtitle: string;
    icon: React.ReactNode;
    accent?: boolean;
  }[] = [
    {
      pageKey: 'campus',
      title: 'Campus & Heritage',
      subtitle: 'Leadership Desk, Senior Management & 2027 Classroom Wing',
      icon: <Building2 className="w-5 h-5" />,
    },
    {
      pageKey: 'departments',
      title: '8 Academic Departments',
      subtitle: 'ICT, Maths, Science, Creatives, PE, Humanities, Languages & Commercials',
      icon: <BookOpen className="w-5 h-5" />,
    },
    {
      pageKey: 'curriculum',
      title: 'Cambridge Curriculum',
      subtitle: 'Preschool, Lower Secondary, Pre-IGCSE, IGCSE & Sixth Form AS/A2',
      icon: <GraduationCap className="w-5 h-5" />,
    },
    {
      pageKey: 'boarding',
      title: 'Boarding Houses',
      subtitle: '100 Beds across Lady Olebile & Sir Ketumile Masire Houses',
      icon: <Bed className="w-5 h-5" />,
    },
    {
      pageKey: 'achievers',
      title: 'Top Achievers',
      subtitle: 'Outstanding Cambridge Learner Awards & Multi-Year Honor Roll',
      icon: <Award className="w-5 h-5" />,
      accent: true,
    },
    {
      pageKey: 'sports',
      title: 'Sports & Four Houses',
      subtitle: 'Bathoen, Khama, Sechele & Moremi Inter-House Competition',
      icon: <Trophy className="w-5 h-5" />,
    },
    {
      pageKey: 'athletics',
      title: 'Track & Field Athletics',
      subtitle: 'Sprints, Distance, Relays, Throws, Jumps & Zonal Championships',
      icon: <Timer className="w-5 h-5" />,
    },
    {
      pageKey: 'jaguars',
      title: 'The Jaguars Rugby',
      subtitle: 'Official 1st XV & Junior Rugby Club · Stand-Alone Teams',
      icon: <Shield className="w-5 h-5" />,
      accent: true,
    },
    {
      pageKey: 'excursions',
      title: 'Educational Excursions',
      subtitle: 'Curated National, Regional & International Field Expeditions',
      icon: <Compass className="w-5 h-5" />,
    },
    {
      pageKey: 'alumni',
      title: 'Alumni Registry',
      subtitle: 'Verified Old Kolobengans Directory & Graduate Mentors',
      icon: <Sparkles className="w-5 h-5" />,
    },
    {
      pageKey: 'fees',
      title: 'Fees & BWP Calculator',
      subtitle: 'Official Tuition Schedule, Levies, Boarding & Family Discounts',
      icon: <Wallet className="w-5 h-5" />,
    },
    {
      pageKey: 'news',
      title: 'News & 2026 Events',
      subtitle: 'Official College Bulletins, Term Dates & Event Posters',
      icon: <Newspaper className="w-5 h-5" />,
    },
  ];

  const featuredCardsToShow =
    featuredItems.length > 0 ? featuredItems : [...featuredNewsAndEvents, ...featuredHighlights];

  const publishedLeadership = (about.leadership || [])
    .filter((m) => m.status !== 'unpublished' && m.status !== 'archived')
    .sort((a, b) => (a.order ?? 99) - (b.order ?? 99));

  const executivePair = publishedLeadership.filter(
    (m) =>
      m.role.toLowerCase() === 'managing director' ||
      m.role.toLowerCase() === 'principal' ||
      m.id === 'lead-md' ||
      m.id === 'lead-principal'
  );
  const smtMembers = publishedLeadership.filter((m) => !executivePair.includes(m));
  const publishedDirectors = (about.directors || [])
    .filter((d) => d.status !== 'unpublished' && d.status !== 'archived')
    .sort((a, b) => (a.order ?? 99) - (b.order ?? 99));

  return (
    <div className="bg-white text-[#0c1a40]">
      {/* 1. Primary Hero Showcase */}
      <Hero
        onNavigate={onNavigate}
        onOpenAdmissions={onOpenAdmissions}
        onOpenProspectus={onOpenProspectus}
      />

      {/* 2. Brief Welcome & Cambridge Philosophy Overview */}
      <section className="py-16 bg-blue-50/40 border-b border-blue-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7 space-y-4">
            <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold">
              {about.heritageBadge}
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#0c1a40] tracking-tight text-balance">
              {about.heritageHeading}
            </h2>
            <div className="w-16 h-0.5 bg-amber-500" />
            <p className="text-sm sm:text-base text-blue-950/85 leading-relaxed">
              {about.heritageParagraph1}
            </p>
            <p className="text-sm text-blue-900/80 leading-relaxed">
              {about.heritageParagraph2}
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <a
                href="#campus"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('campus');
                }}
                className="px-5 py-2.5 bg-[#0c1a40] hover:bg-[#162a6b] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>Explore Campus & Leadership</span>
                <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
              </a>
              <a
                href="#curriculum"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('curriculum');
                }}
                className="px-5 py-2.5 bg-white hover:bg-blue-50 text-[#0c1a40] border border-blue-200 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Cambridge Curriculum Overview
              </a>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#0c1a40] text-white p-7 rounded-2xl border border-blue-900 shadow-md space-y-4">
            <div className="text-xs font-mono uppercase tracking-wider text-amber-400 font-bold">
              Mission · Vision · Values
            </div>
            <h3 className="text-xl font-serif font-bold text-white">
              {general.cambridgeCentreNo}
            </h3>
            <p className="text-xs text-blue-100 leading-relaxed">{about.missionText}</p>
            <div className="flex flex-wrap gap-2 pt-2 border-t border-blue-800">
              {about.valuesList.map((val) => (
                <span
                  key={val}
                  className="px-2.5 py-1 rounded-md bg-white/10 border border-white/15 text-[11px] font-semibold text-amber-300"
                >
                  {val}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 2A. School Campus Video Showcase */}
      <section className="py-14 bg-white border-b border-blue-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-5 space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-700 font-bold">
              <PlayCircle className="w-4 h-4" />
              <span>Campus Film · Block 8 Gaborone</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40] tracking-tight text-balance">
              Experience Life at {general.name}
            </h2>
            <p className="text-sm text-blue-950/85 leading-relaxed">
              Take a look around our landscaped Gaborone campus—featuring tree-lined walkways, Sechele Hall, academic classroom blocks, and The Jaguars rugby complex.
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <a
                href="#campus"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('campus');
                }}
                className="px-5 py-2.5 bg-[#0c1a40] hover:bg-[#162a6b] text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>Explore Full Campus</span>
                <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
              </a>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="rounded-2xl overflow-hidden border-2 border-blue-200 bg-[#081226] shadow-md">
              <video
                controls
                playsInline
                preload="metadata"
                poster={schoolVideoPoster}
                aria-label="Livingstone Kolobeng College School Video"
                className="w-full max-h-[460px] object-contain bg-[#081226] block mx-auto"
              >
                <source src={schoolVideoUrl} type="video/mp4" />
                Your browser does not support embedded video playback.
              </video>
            </div>
          </div>
        </div>
      </section>

      {/* 2B. School Leadership (MD, Principal & Senior Management Team — Portraits, Names & Designations Only) */}
      {publishedLeadership.length > 0 && (
        <section className="py-16 bg-white border-b border-blue-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
              <div>
                <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1">
                  Executive Governance & Senior Management Team
                </div>
                <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
                  Our School Leadership
                </h2>
                <p className="text-xs sm:text-sm text-blue-900/80 mt-1 max-w-2xl">
                  Academic and institutional stewardship under the Managing Director, Principal, and Senior Management Team.
                </p>
              </div>
              <a
                href="#campus"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('campus');
                }}
                className="px-4 py-2 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#0c1a40] border border-blue-200 text-xs font-semibold cursor-pointer transition-colors self-start sm:self-auto shrink-0"
              >
                Leadership Messages & Campus →
              </a>
            </div>

            {/* Executive Pair: Managing Director & Principal */}
            {executivePair.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 max-w-4xl mx-auto">
                {executivePair.map((leader, idx) => (
                  <div
                    key={leader.id || leader.name || idx}
                    className="bg-blue-50/40 rounded-2xl border-2 border-blue-200 hover:border-amber-400 transition-all p-5 flex items-center gap-5 shadow-xs"
                  >
                    <div className="w-28 sm:w-32 aspect-[4/5] rounded-xl overflow-hidden bg-[#0c1a40] border-2 border-amber-400 shrink-0">
                      {leader.image ? (
                        <img
                          key={`${leader.id}-${leader.image}`}
                          src={leader.image}
                          alt={leader.name}
                          loading="lazy"
                          onError={handleImageFallback}
                          className="w-full h-full object-cover object-top"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-amber-300 font-serif font-bold text-2xl">
                          {leader.name.split(' ').slice(-1)[0]?.[0] || 'L'}
                        </div>
                      )}
                    </div>
                    <div className="min-w-0">
                      <span className="inline-block text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-md bg-[#0c1a40] text-amber-300 mb-2">
                        {leader.role}
                      </span>
                      <h3 className="font-serif font-bold text-lg sm:text-xl text-[#0c1a40] leading-snug">
                        {leader.name}
                      </h3>
                      <p className="text-xs text-blue-800 font-medium mt-1">
                        {leader.title}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Senior Management Team (SMT) Grid */}
            {smtMembers.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
                {smtMembers.map((member, idx) => (
                  <div
                    key={member.id || member.name || idx}
                    className="bg-white rounded-2xl border border-blue-200 hover:border-amber-400 transition-all overflow-hidden shadow-xs flex flex-col"
                  >
                    <div className="aspect-[4/5] bg-[#0c1a40] overflow-hidden border-b border-blue-100">
                      {member.image ? (
                        <img
                          key={`${member.id}-${member.image}`}
                          src={member.image}
                          alt={member.name}
                          loading="lazy"
                          onError={handleImageFallback}
                          className="w-full h-full object-cover object-top"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-amber-300 font-serif font-bold text-2xl p-4 text-center">
                          <span>{member.name.split(' ').slice(-1)[0]?.[0] || 'L'}</span>
                          <span className="text-[10px] font-mono text-blue-200 mt-1 font-normal">
                            Portrait Pending
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-700 block mb-1">
                          {member.role}
                        </span>
                        <h3 className="font-serif font-bold text-sm sm:text-base text-[#0c1a40] leading-snug">
                          {member.name}
                        </h3>
                      </div>
                      {member.department && (
                        <p className="text-[11px] text-blue-800 mt-2 pt-2 border-t border-blue-100">
                          {member.department}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Separate Directors Section (Below SMT) */}
            {publishedDirectors.length > 0 && (
              <div id="directors" className="mt-12 pt-10 border-t border-blue-100">
                <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-7">
                  <div>
                    <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1">
                      Academic & Infrastructure Directorate
                    </div>
                    <h3 className="text-xl sm:text-2xl font-serif font-bold text-[#0c1a40]">
                      Directors
                    </h3>
                    <p className="text-xs sm:text-sm text-blue-900/80 mt-1 max-w-2xl">
                      Divisional leadership overseeing Lower School, Upper School, and ICT Infrastructure.
                    </p>
                  </div>
                  <span className="text-[11px] font-mono text-[#0c1a40] bg-blue-50 border border-blue-200 px-3 py-1 rounded-lg self-start sm:self-auto shrink-0 font-semibold">
                    College Directorate
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 max-w-5xl mx-auto">
                  {publishedDirectors.map((director, idx) => (
                    <div
                      key={director.id || director.name || idx}
                      className="bg-white rounded-2xl border border-blue-200 hover:border-amber-400 transition-all overflow-hidden shadow-xs flex flex-col"
                    >
                      <div className="aspect-[4/5] bg-[#0c1a40] overflow-hidden border-b border-blue-100">
                        {director.image ? (
                          <img
                            key={`${director.id}-${director.image}`}
                            src={director.image}
                            alt={director.name}
                            loading="lazy"
                            onError={handleImageFallback}
                            className="w-full h-full object-cover object-top"
                          />
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center text-amber-300 font-serif font-bold text-2xl p-4 text-center">
                            <span>{director.name.split(' ').slice(-1)[0]?.[0] || 'D'}</span>
                            <span className="text-[10px] font-mono text-blue-200 mt-1 font-normal">
                              Portrait Pending
                            </span>
                          </div>
                        )}
                      </div>
                      <div className="p-4 flex-1 flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-700 block mb-1">
                            {director.role || director.title}
                          </span>
                          <h4 className="font-serif font-bold text-base text-[#0c1a40] leading-snug">
                            {director.name}
                          </h4>
                          {director.bio && director.bio.trim() && (
                            <p className="text-xs text-blue-950/80 leading-relaxed mt-2 line-clamp-3">
                              {director.bio}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {/* 3. Curated Homepage Featured News, Events & Highlights */}
      <section className="py-16 bg-white border-b border-blue-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1">
                College Spotlight · Featured Updates
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
                Featured News, Events & College Highlights
              </h2>
              <p className="text-xs sm:text-sm text-blue-900/80 mt-1 max-w-2xl">
                Curated announcements, upcoming dates, and college milestones selected for the homepage. Visit dedicated pages for full archives and details.
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <a
                href="#news"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('news');
                }}
                className="px-4 py-2 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#0c1a40] border border-blue-200 text-xs font-semibold cursor-pointer transition-colors"
              >
                All News & Bulletins →
              </a>
              <a
                href="#events"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('events');
                }}
                className="px-4 py-2 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white text-xs font-semibold cursor-pointer transition-colors"
              >
                Calendar & Events →
              </a>
            </div>
          </div>

          {featuredCardsToShow.length === 0 ? (
            <div className="p-10 rounded-2xl bg-blue-50/50 border border-blue-200 text-center">
              <Newspaper className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <h3 className="font-serif font-bold text-base text-[#0c1a40]">
                No Featured Items Selected Yet
              </h3>
              <p className="text-xs text-blue-900/75 mt-1 max-w-md mx-auto">
                Administrators can feature published News, Events, or Page Highlights on the homepage from the Content Management System.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredCardsToShow.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl border border-blue-200 overflow-hidden shadow-xs hover:shadow-md hover:border-amber-400 transition-all flex flex-col justify-between group"
                >
                  <div>
                    {item.thumbnailUrl ? (
                      <div className="aspect-[16/9] bg-[#081226] overflow-hidden relative">
                        <img
                          src={item.thumbnailUrl}
                          alt={item.title}
                          loading="lazy"
                          onError={handleImageFallback}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute top-3 left-3 px-2.5 py-0.5 rounded-md bg-[#0c1a40]/90 text-amber-300 text-[10px] font-mono font-bold uppercase border border-amber-400/30">
                          {item.category}
                        </div>
                      </div>
                    ) : (
                      <div className="px-5 pt-5">
                        <span className="inline-block px-2.5 py-0.5 rounded-md bg-blue-50 text-[#0c1a40] text-[10px] font-mono font-bold uppercase border border-blue-200">
                          {item.category}
                        </span>
                      </div>
                    )}

                    <div className="p-5">
                      {(item.eventDate || item.publishAt) && (
                        <div className="flex items-center gap-1.5 text-[11px] font-mono text-amber-700 font-semibold mb-1.5">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{item.eventDate || item.publishAt}</span>
                        </div>
                      )}
                      <h3 className="font-serif font-bold text-lg text-[#0c1a40] leading-snug mb-2">
                        {item.title}
                      </h3>
                      <p className="text-xs text-blue-950/80 leading-relaxed line-clamp-3">
                        {item.excerpt}
                      </p>
                    </div>
                  </div>

                  <div className="px-5 py-3.5 bg-blue-50/50 border-t border-blue-100 flex items-center justify-between text-xs">
                    <button
                      type="button"
                      onClick={() => setSelectedFeaturedItem(item)}
                      className="font-semibold text-[#0c1a40] hover:text-amber-700 cursor-pointer"
                    >
                      Read Preview
                    </button>
                    <a
                      href={`#${item.pageKey}`}
                      onClick={(e) => {
                        e.preventDefault();
                        onNavigate(item.pageKey);
                      }}
                      className="font-bold text-amber-700 hover:text-amber-600 flex items-center gap-1 cursor-pointer"
                    >
                      <span>Open {item.pageKey} Page</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 4. Quick Links Directory to Dedicated College Pages */}
      <section className="py-16 bg-blue-50/30 border-b border-blue-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="max-w-2xl mb-10">
            <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1">
              Explore Livingstone Kolobeng College
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#0c1a40]">
              Dedicated College Pages & Academic Directory
            </h2>
            <p className="text-xs sm:text-sm text-blue-900/80 mt-1">
              Select any portal section below to open its full dedicated page.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickDirectory.map((card) => (
              <a
                key={card.pageKey}
                href={`#${card.pageKey}`}
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate(card.pageKey);
                }}
                className={`p-5 rounded-2xl border text-left transition-all flex flex-col justify-between cursor-pointer group ${
                  card.accent
                    ? 'bg-gradient-to-br from-[#0c1a40] to-[#162a6b] text-white border-blue-900 hover:border-amber-400 shadow-sm'
                    : 'bg-white text-[#0c1a40] border-blue-200 hover:border-amber-400 hover:shadow-sm'
                }`}
              >
                <div>
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${
                      card.accent
                        ? 'bg-amber-400 text-[#081226]'
                        : 'bg-blue-50 text-[#0c1a40] border border-blue-100'
                    }`}
                  >
                    {card.icon}
                  </div>
                  <h3
                    className={`font-serif font-bold text-base mb-1 ${
                      card.accent ? 'text-white' : 'text-[#0c1a40]'
                    }`}
                  >
                    {card.title}
                  </h3>
                  <p
                    className={`text-xs leading-relaxed ${
                      card.accent ? 'text-blue-100' : 'text-blue-900/75'
                    }`}
                  >
                    {card.subtitle}
                  </p>
                </div>

                <div
                  className={`mt-4 pt-3 border-t flex items-center justify-between text-xs font-semibold ${
                    card.accent
                      ? 'border-white/15 text-amber-300'
                      : 'border-blue-100 text-[#0c1a40] group-hover:text-amber-700'
                  }`}
                >
                  <span>Visit Page</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* 4B. Alumni Testimonials Marquee */}
      <AlumniTestimonials onNavigate={onNavigate} variant="homepage" />

      {/* 5. Concise Contact & Admissions Strip */}
      <section className="py-12 bg-[#0c1a40] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 text-xs font-mono text-amber-400 font-bold uppercase tracking-wider">
              <Flame className="w-3.5 h-3.5" />
              <span>Admissions & Campus Visits</span>
            </div>
            <h3 className="text-2xl font-serif font-bold text-white">
              Ready to Join {general.name}?
            </h3>
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 text-xs text-blue-100">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                {general.address.plot}, {general.address.area}, {general.address.city}
              </span>
              <span className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                {general.contacts.phone}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onOpenAdmissions}
              className="px-5 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs cursor-pointer transition-colors"
            >
              Enquire for Admission
            </button>
            <a
              href="#fees"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('fees');
              }}
              className="px-5 py-2.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-semibold text-xs border border-white/20 cursor-pointer transition-colors"
            >
              Fee Structure & Calculator
            </a>
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('contact');
              }}
              className="px-5 py-2.5 rounded-lg bg-white text-[#0c1a40] hover:bg-blue-50 font-semibold text-xs cursor-pointer transition-colors"
            >
              Contact Directory & Map
            </a>
          </div>
        </div>
      </section>

      {/* Featured Item Reader Modal */}
      {selectedFeaturedItem && (
        <div
          className="fixed inset-0 z-50 bg-[#081226]/85 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setSelectedFeaturedItem(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[88vh] overflow-y-auto shadow-2xl border border-blue-200 p-6 sm:p-8 relative text-[#0c1a40]"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setSelectedFeaturedItem(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-blue-500 hover:text-[#0c1a40] hover:bg-blue-50 cursor-pointer"
              aria-label="Close reader"
            >
              <X className="w-5 h-5" />
            </button>

            {selectedFeaturedItem.thumbnailUrl && (
              <div className="aspect-[16/9] rounded-xl overflow-hidden bg-[#081226] mb-5">
                <img
                  src={selectedFeaturedItem.thumbnailUrl}
                  alt={selectedFeaturedItem.title}
                  onError={handleImageFallback}
                  onClick={() =>
                    openImageViewer({
                      src: selectedFeaturedItem.thumbnailUrl!,
                      title: selectedFeaturedItem.title,
                      subtitle: selectedFeaturedItem.category,
                    })
                  }
                  data-zoomable-image="true"
                  className="w-full h-full object-cover cursor-zoom-in"
                />
              </div>
            )}

            <div className="text-xs font-mono uppercase tracking-wider text-amber-700 font-bold mb-1">
              {selectedFeaturedItem.category}
              {selectedFeaturedItem.publishAt ? ` · ${selectedFeaturedItem.publishAt}` : ''}
            </div>
            <h3 className="text-2xl font-serif font-bold text-[#0c1a40] mb-3">
              {selectedFeaturedItem.title}
            </h3>
            <p className="text-sm text-blue-950 font-medium leading-relaxed mb-3">
              {selectedFeaturedItem.excerpt}
            </p>
            {typeof selectedFeaturedItem.content?.body === 'string' && (
              <p className="text-xs sm:text-sm text-blue-900/85 leading-relaxed whitespace-pre-line">
                {selectedFeaturedItem.content.body}
              </p>
            )}

            <div className="mt-6 pt-4 border-t border-blue-100 flex items-center justify-between">
              <a
                href={`#${selectedFeaturedItem.pageKey}`}
                onClick={(e) => {
                  e.preventDefault();
                  const target = selectedFeaturedItem.pageKey;
                  setSelectedFeaturedItem(null);
                  onNavigate(target);
                }}
                className="px-4 py-2 bg-[#0c1a40] text-white rounded-lg text-xs font-semibold hover:bg-[#162a6b] flex items-center gap-1.5 cursor-pointer"
              >
                <span>View Full Section ({selectedFeaturedItem.pageKey})</span>
                <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
              </a>
              <button
                type="button"
                onClick={() => setSelectedFeaturedItem(null)}
                className="px-4 py-2 bg-blue-50 text-[#0c1a40] rounded-lg text-xs font-semibold hover:bg-blue-100 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
