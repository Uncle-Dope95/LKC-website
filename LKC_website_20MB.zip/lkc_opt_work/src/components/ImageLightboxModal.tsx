import React, { useEffect, useState, useCallback } from 'react';
import { Download, RotateCcw, X, ZoomIn, ZoomOut } from 'lucide-react';

export interface ImageViewerPayload {
  src: string;
  title?: string;
  subtitle?: string;
  downloadName?: string;
}

const IMAGE_VIEWER_EVENT = 'lkc-open-image-viewer';

export function openImageViewer(payload: ImageViewerPayload): void {
  if (typeof window === 'undefined' || !payload?.src) return;
  window.dispatchEvent(new CustomEvent<ImageViewerPayload>(IMAGE_VIEWER_EVENT, { detail: payload }));
}

export function buildDownloadFilename(src: string, preferredTitle?: string): string {
  const cleanSrc = src.split('?')[0].split('#')[0];
  const extMatch = cleanSrc.match(/\.([a-zA-Z0-9]{2,5})$/);
  const ext = extMatch ? extMatch[1].toLowerCase() : 'jpg';
  if (preferredTitle && preferredTitle.trim()) {
    const slug = preferredTitle
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
    if (slug) return `${slug}.${ext}`;
  }
  const base = cleanSrc.split('/').pop() || `lkc-image.${ext}`;
  return base.includes('.') ? base : `${base}.${ext}`;
}

export async function downloadImageFile(src: string, preferredTitle?: string): Promise<void> {
  if (!src || typeof document === 'undefined') return;
  const filename = buildDownloadFilename(src, preferredTitle);
  const triggerAnchor = (href: string) => {
    const a = document.createElement('a');
    a.href = href;
    a.download = filename;
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  if (typeof window !== 'undefined' && /^https?:$/i.test(window.location.protocol) && !src.startsWith('data:') && !src.startsWith('blob:')) {
    try {
      const response = await fetch(src);
      if (response.ok) {
        const blob = await response.blob();
        const objectUrl = URL.createObjectURL(blob);
        triggerAnchor(objectUrl);
        window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
        return;
      }
    } catch {
      // Fallback to direct anchor download below
    }
  }

  triggerAnchor(src);
}

function shouldIgnoreGlobalImageClick(img: HTMLImageElement): boolean {
  if (!img || !img.getAttribute('src')) return true;
  if (img.dataset.noGlobalZoom === 'true') return true;
  if (img.closest('[data-no-global-zoom="true"]')) return true;
  if (img.closest('[role="dialog"][data-lkc-lightbox="true"]')) return true;

  const src = img.getAttribute('src') || '';
  if (/logo_33a39ff7\.png/i.test(src)) return true;

  // Ignore tiny decorative icons/avatars inside interactive links or cards unless explicitly opted in
  if (img.dataset.zoomableImage === 'true') return false;
  if (img.closest('a')) return true;
  if (img.closest('button')) return true;
  if (img.closest('header') || img.closest('nav') || img.closest('footer')) return true;
  if (img.closest('[data-lkc-card-clickable="true"]')) return true;

  const rect = img.getBoundingClientRect();
  if (rect.width < 48 || rect.height < 48) return true;

  return false;
}

export const ImageLightboxHost: React.FC = () => {
  const [payload, setPayload] = useState<ImageViewerPayload | null>(null);
  const [zoomScale, setZoomScale] = useState<number>(1);

  const closeViewer = useCallback(() => {
    setPayload(null);
    setZoomScale(1);
  }, []);

  useEffect(() => {
    const handleCustomOpen = (e: Event) => {
      const detail = (e as CustomEvent<ImageViewerPayload>).detail;
      if (detail?.src) {
        setPayload(detail);
        setZoomScale(1);
      }
    };

    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      const img = target.closest('img') as HTMLImageElement | null;
      if (!img) return;
      if (shouldIgnoreGlobalImageClick(img)) return;

      const src = img.getAttribute('src') || img.currentSrc;
      if (!src) return;
      e.preventDefault();
      e.stopPropagation();

      setPayload({
        src,
        title: img.alt?.trim() || 'Livingstone Kolobeng College Photograph',
        subtitle: 'Livingstone Kolobeng College · Gaborone, Botswana',
      });
      setZoomScale(1);
    };

    window.addEventListener(IMAGE_VIEWER_EVENT, handleCustomOpen);
    document.addEventListener('click', handleGlobalClick);
    return () => {
      window.removeEventListener(IMAGE_VIEWER_EVENT, handleCustomOpen);
      document.removeEventListener('click', handleGlobalClick);
    };
  }, []);

  useEffect(() => {
    if (!payload) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        closeViewer();
      } else if (e.key === '+' || e.key === '=') {
        setZoomScale((prev) => Math.min(4, Number((prev + 0.25).toFixed(2))));
      } else if (e.key === '-' || e.key === '_') {
        setZoomScale((prev) => Math.max(0.5, Number((prev - 0.25).toFixed(2))));
      } else if (e.key === '0') {
        setZoomScale(1);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [payload, closeViewer]);

  if (!payload) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={payload.title || 'Image viewer'}
      data-lkc-lightbox="true"
      className="fixed inset-0 z-[70] bg-[#081226]/92 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6"
      onClick={closeViewer}
    >
      <div
        className="relative max-w-[96vw] sm:max-w-[94vw] w-full h-[94vh] max-h-[94vh] bg-[#0c1a40] rounded-2xl border border-blue-800 shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-4 sm:px-5 py-3.5 bg-[#081226] border-b border-blue-900 flex flex-wrap items-center justify-between gap-3 text-white">
          <div className="min-w-0">
            <h3 className="text-sm sm:text-base font-serif font-bold text-white truncate">
              {payload.title || 'College Photograph'}
            </h3>
            {payload.subtitle && (
              <p className="text-xs text-amber-400 truncate">{payload.subtitle}</p>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center bg-blue-950 rounded-lg border border-blue-800 px-1 py-0.5 text-xs text-blue-100">
              <button
                type="button"
                onClick={() => setZoomScale((prev) => Math.max(0.5, Number((prev - 0.25).toFixed(2))))}
                className="p-1.5 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                title="Zoom Out"
                aria-label="Zoom out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="px-2 font-mono text-[11px] text-amber-400 min-w-[3.2rem] text-center">
                {Math.round(zoomScale * 100)}%
              </span>
              <button
                type="button"
                onClick={() => setZoomScale((prev) => Math.min(4, Number((prev + 0.25).toFixed(2))))}
                className="p-1.5 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                title="Zoom In"
                aria-label="Zoom in"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setZoomScale(1)}
                className="p-1.5 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer ml-0.5"
                title="Reset Zoom"
                aria-label="Reset zoom"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              type="button"
              onClick={() => downloadImageFile(payload.src, payload.downloadName || payload.title)}
              className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Download Image"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>

            <button
              type="button"
              onClick={closeViewer}
              className="p-1.5 rounded-lg bg-blue-900/60 hover:bg-blue-800 text-white transition-colors cursor-pointer"
              aria-label="Close image preview"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div
          className="flex-1 overflow-auto p-4 sm:p-6 flex items-center justify-center bg-[#081226] min-h-[64vh]"
          onWheel={(e) => {
            if (e.deltaY < 0) {
              setZoomScale((prev) => Math.min(4, Number((prev + 0.15).toFixed(2))));
            } else if (e.deltaY > 0) {
              setZoomScale((prev) => Math.max(0.5, Number((prev - 0.15).toFixed(2))));
            }
          }}
        >
          <div
            className="transition-transform duration-150 origin-center flex items-center justify-center"
            style={{ transform: `scale(${zoomScale})` }}
          >
            <img
              src={payload.src}
              alt={payload.title || 'Photograph'}
              data-no-global-zoom="true"
              className="h-[74vh] sm:h-[78vh] w-auto max-w-[90vw] object-contain rounded-xl shadow-2xl select-none"
            />
          </div>
        </div>

        <div className="px-5 py-2.5 bg-[#081226] border-t border-blue-900 flex flex-wrap items-center justify-between gap-2 text-xs text-blue-200">
          <span>Use Zoom In / Zoom Out or scroll wheel to inspect details</span>
          <span className="text-amber-400 font-mono text-[11px]">Click Download to save original file</span>
        </div>
      </div>
    </div>
  );
};
