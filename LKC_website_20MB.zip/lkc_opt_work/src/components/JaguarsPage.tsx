import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Shield,
  Trophy,
  Flame,
  Calendar,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  X,
  MapPin,
  Clock,
  Download
} from 'lucide-react';
import { useCmsSection, usePublishedCmsItems } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { downloadImageFile } from './ImageLightboxModal';

interface JaguarsPageProps {
  onOpenAdmissions?: () => void;
  onNavigateToSports?: () => void;
}

export const JaguarsPage: React.FC<JaguarsPageProps> = ({
  onNavigateToSports
}) => {
  const jaguars = useCmsSection('jaguars');
  const general = useCmsSection('general');
  const jaguarsItems = usePublishedCmsItems('jaguars');

  const [activeModalImage, setActiveModalImage] = useState<{ url: string; title: string; subtitle?: string } | null>(null);
  const [zoomScale, setZoomScale] = useState<number>(1);

  const isImageUrl = (url?: string) =>
    Boolean(
      url &&
        (/\.(png|jpe?g|webp|gif|svg)(\?|$)/i.test(url) ||
          url.startsWith('/uploads/') ||
          url.startsWith('./uploads/'))
    );

  const rugbyPhotos = (jaguars.photos || []).filter(
    (p) =>
      Boolean(p.url && p.url.trim()) &&
      p.status !== 'unpublished' &&
      p.status !== 'archived'
  );

  return (
    <div className="bg-white min-h-screen text-[#0c1a40]">

      {/* Rugby Hero Section in LKC Blue & Gold */}
      <section className="relative bg-gradient-to-b from-[#081226] via-[#0c1a40] to-[#162a6b] text-white py-20 lg:py-28 px-4 sm:px-6 overflow-hidden border-b border-amber-400/30">
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="max-w-3xl space-y-5">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 text-xs font-mono uppercase tracking-widest"
            >
              <Shield className="w-4 h-4 text-amber-400" />
              <span>LKC Standalone Rugby Team · Est. {jaguars.established}</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-4xl sm:text-6xl font-serif font-bold tracking-tight text-white leading-tight"
            >
              {jaguars.name}
            </motion.h1>

            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="flex flex-wrap items-center gap-2 text-amber-400 font-mono text-sm tracking-wider uppercase font-semibold"
            >
              <span>{jaguars.motto}</span>
              <span>·</span>
              <span className="text-blue-100 italic font-serif normal-case">{jaguars.mottoLatin}</span>
            </motion.div>

            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-blue-100 text-base sm:text-lg leading-relaxed font-sans"
            >
              {jaguars.overview}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="pt-2 flex flex-wrap items-center gap-3"
            >
              <a
                href={general.admissionsPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs sm:text-sm rounded-xl shadow-lg transition flex items-center gap-2"
              >
                <span>Trial for The Jaguars / Admissions ↗</span>
              </a>

              <a
                href="#fixtures"
                className="px-5 py-3 bg-blue-900/70 hover:bg-blue-800 text-white font-medium text-xs sm:text-sm rounded-xl border border-blue-700 transition flex items-center gap-2"
              >
                <Calendar className="w-4 h-4 text-amber-400" />
                <span>Season Fixtures</span>
              </a>

              {onNavigateToSports && (
                <a
                  href="#sports"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigateToSports();
                  }}
                  className="px-5 py-3 bg-white/10 hover:bg-white/20 text-white font-medium text-xs sm:text-sm rounded-xl border border-white/20 transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Trophy className="w-4 h-4 text-amber-400" />
                  <span>All Campus Sports & House Trophy →</span>
                </a>
              )}
            </motion.div>
          </div>
        </div>
      </section>

      {/* The Jaguars Rugby Creed */}
      <section className="py-16 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold block mb-1">
            Rugby Heritage & Code of Honor
          </span>
          <h2 className="text-3xl font-serif font-bold text-[#0c1a40]">
            The Jaguars Rugby Creed
          </h2>
          <p className="text-blue-950 text-xs sm:text-sm mt-2">
            Every student donning the blue, gold and white jersey is held to the highest standard of character.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {jaguars.creed.map((item, idx) => (
            <motion.div
              key={idx}
              whileHover={{ y: -4 }}
              className="bg-white p-6 rounded-2xl border border-blue-200 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#0c1a40] border border-blue-200 flex items-center justify-center mb-4">
                  <Shield className="w-5 h-5 text-amber-600" />
                </div>
                <h3 className="font-serif font-bold text-base text-[#0c1a40] mb-2">
                  {item.title}
                </h3>
                <p className="text-xs text-blue-950 leading-relaxed">
                  {item.desc}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-blue-100 text-[10px] font-mono text-amber-700 font-bold uppercase tracking-wider">
                Jaguar Pillar 0{idx + 1}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* The Squads */}
      <section className="py-16 px-4 sm:px-6 bg-blue-50/50 border-y border-blue-100">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold block mb-1">
                {jaguars.clubName}
              </span>
              <h2 className="text-3xl font-serif font-bold text-[#0c1a40]">
                Jaguars Rugby Squads
              </h2>
            </div>
            <div className="text-xs text-blue-800 font-mono">
              Home Ground: {jaguars.homeGround}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {jaguars.squads.map((sq, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -4 }}
                className="bg-white rounded-2xl p-6 sm:p-7 border border-blue-200 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="px-2.5 py-1 rounded-md text-[11px] font-mono font-bold bg-[#0c1a40] text-amber-300">
                      {sq.tier}
                    </span>
                    <span className="text-xs font-semibold text-[#0c1a40] bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-300">
                      Active Squad
                    </span>
                  </div>

                  <h3 className="font-serif font-bold text-xl text-[#0c1a40]">
                    {sq.name}
                  </h3>

                  <div className="mt-2 text-xs text-blue-900 space-y-1">
                    <div><strong className="text-[#0c1a40]">Captain:</strong> {sq.captain}</div>
                    {sq.viceCaptain && (
                      <div><strong className="text-[#0c1a40]">Vice-Captain:</strong> {sq.viceCaptain}</div>
                    )}
                  </div>

                  <p className="text-xs sm:text-sm text-blue-950 mt-3 leading-relaxed">
                    {sq.description}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-blue-100 flex items-center justify-between text-xs font-medium">
                  <span className="text-blue-800">Season Form:</span>
                  <span className="text-amber-700 font-semibold">{sq.record2025}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Anatomy of the Jaguars Pack & Backline */}
      <section className="py-16 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold block mb-1">
            Rugby Position Disciplines
          </span>
          <h2 className="text-3xl font-serif font-bold text-[#0c1a40]">
            The Anatomy of the Pack & Backline
          </h2>
          <p className="text-blue-950 text-xs sm:text-sm mt-2">
            Every position demands specialized athleticism, spatial awareness, and fearless commitment.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {jaguars.positionsPack.map((pos, idx) => (
            <div key={idx} className="bg-white p-5 rounded-xl border border-blue-200 shadow-xs">
              <span className="text-[10px] font-mono uppercase font-bold text-amber-700 block mb-1">
                Unit {idx + 1}
              </span>
              <h4 className="font-serif font-bold text-base text-[#0c1a40] mb-1">
                {pos.unit}
              </h4>
              <div className="text-xs font-medium text-[#162a6b] mb-2">
                {pos.roles}
              </div>
              <p className="text-xs text-blue-950 leading-relaxed">
                {pos.duty}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Official Fixtures Section (Populated from CMS Backend) */}
      <section id="fixtures" className="py-16 px-4 sm:px-6 bg-[#0c1a40] text-white border-y border-blue-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-mono uppercase tracking-widest text-amber-400 font-bold block mb-1">
              LKC Matchday Calendar
            </span>
            <h2 className="text-3xl font-serif font-bold text-white">
              Official Rugby Fixtures & Derbies
            </h2>
            <p className="text-blue-100 text-xs sm:text-sm mt-2">
              Come support the Jaguars at {jaguars.homeGround}.
            </p>
          </div>

          {jaguars.fixtures2026.length === 0 ? (
            <div className="max-w-2xl mx-auto p-8 rounded-2xl bg-[#081226] border border-blue-800 text-center">
              <Calendar className="w-8 h-8 text-amber-400 mx-auto mb-3" />
              <h3 className="font-serif font-bold text-lg text-white mb-1">
                Upcoming Match Fixtures Pending Release
              </h3>
              <p className="text-xs sm:text-sm text-blue-100 leading-relaxed">
                Confirmed derby dates, venues, and kick-off schedules are published directly by the LKC Sports Directorate for the upcoming season.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
              {jaguars.fixtures2026.map((fix, idx) => (
                <div
                  key={fix.id || idx}
                  className="bg-[#081226] border border-blue-800 rounded-2xl p-5 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-[11px] font-mono text-amber-300 font-bold">
                        {fix.date}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                        {fix.status}
                      </span>
                    </div>
                    <h4 className="font-serif font-bold text-base text-white">
                      vs. {fix.opponent}
                    </h4>
                    <div className="text-xs text-blue-100 flex items-center gap-1.5 mt-2">
                      <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>{fix.venue}</span>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-blue-900 text-[11px] text-amber-300 font-mono">
                    {fix.tournament}
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="mt-10 text-center text-xs text-blue-100 font-mono">
            Direct Line to Jaguars Rugby Office: Head Coach {jaguars.headCoach} ·{' '}
            <a href={`mailto:${general.contacts.principalEmail}`} className="text-amber-400 underline">
              {general.contacts.principalEmail}
            </a>
          </div>
        </div>
      </section>

      {/* Weekly Training Schedule */}
      <section className="py-16 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold block mb-1">
            High-Performance Routine
          </span>
          <h2 className="text-3xl font-serif font-bold text-[#0c1a40]">
            Jaguars Weekly Training Timetable
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {jaguars.trainingSchedule.map((ts, i) => (
            <div key={i} className="bg-white p-5 rounded-xl border border-blue-200 shadow-xs">
              <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#0c1a40] mb-2">
                <Clock className="w-3.5 h-3.5 text-amber-600" />
                <span>{ts.day}</span>
              </div>
              <div className="text-xs font-semibold text-blue-900 mb-1">{ts.time}</div>
              <div className="text-xs font-bold text-[#0c1a40] mb-2">{ts.focus}</div>
              <div className="text-[11px] text-blue-800 pt-2 border-t border-blue-100 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-amber-600" />
                <span>{ts.venue}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Visual Rugby Gallery */}
      <section className="py-16 px-4 sm:px-6 bg-blue-50/40 border-t border-blue-100">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold block mb-1">
                The Jaguars In Action
              </span>
              <h2 className="text-3xl font-serif font-bold text-[#0c1a40]">
                Matchday & Pitch Gallery
              </h2>
            </div>
            {(rugbyPhotos.length > 0 || jaguarsItems.length > 0) && (
              <span className="text-xs text-blue-800">Click any image to inspect details</span>
            )}
          </div>

          {rugbyPhotos.length === 0 && jaguarsItems.length === 0 ? (
            <div className="p-10 rounded-2xl bg-white border border-blue-200 text-center space-y-2">
              <Shield className="w-8 h-8 text-amber-600 mx-auto" />
              <h3 className="font-serif font-bold text-lg text-[#0c1a40]">
                Jaguars Matchday & Pitch Gallery
              </h3>
              <p className="text-xs sm:text-sm text-blue-900/80 max-w-xl mx-auto leading-relaxed">
                Official LKC Jaguars 1st XV and Junior Squad matchday photography uploaded via the College CMS appears here automatically once published.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {rugbyPhotos.map((photo, i) => (
                <motion.div
                  key={`${i}-${photo.url}`}
                  whileHover={{ y: -4 }}
                  onClick={() =>
                    setActiveModalImage({
                      url: photo.url,
                      title: photo.title,
                      subtitle: photo.location || photo.category,
                    })
                  }
                  className="bg-white rounded-2xl overflow-hidden border border-blue-200 shadow-xs cursor-pointer group flex flex-col"
                >
                  <div className="relative aspect-[4/3] overflow-hidden bg-[#081226]">
                    <img
                      src={photo.url}
                      alt={photo.title}
                      loading="lazy"
                      onError={handleImageFallback}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-[#0c1a40]/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <span className="flex items-center gap-1.5 text-xs text-white bg-[#081226] px-3 py-1.5 rounded-md font-medium border border-amber-400/50">
                        <ZoomIn className="w-3.5 h-3.5 text-amber-400" />
                        <span>Inspect Photo</span>
                      </span>
                    </div>
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] font-mono font-bold text-amber-700 uppercase">
                        {photo.category}
                      </span>
                      <h3 className="font-serif font-bold text-sm text-[#0c1a40] mt-1">
                        {photo.title}
                      </h3>
                      <p className="text-xs text-blue-900 mt-1 line-clamp-2">
                        {photo.caption}
                      </p>
                      {photo.location && (
                        <div className="mt-2 pt-2 border-t border-blue-100 flex items-center gap-1.5 text-[11px] font-mono text-blue-800">
                          <MapPin className="w-3 h-3 text-amber-600 shrink-0" />
                          <span>{photo.location}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}

              {jaguarsItems.map((item) => {
                const imgUrl =
                  item.thumbnailUrl || (isImageUrl(item.mediaUrl) ? item.mediaUrl : undefined);
                return (
                  <motion.div
                    key={item.id}
                    whileHover={{ y: -4 }}
                    onClick={() =>
                      imgUrl &&
                      setActiveModalImage({
                        url: imgUrl,
                        title: item.title,
                        subtitle: item.category,
                      })
                    }
                    className={`bg-white rounded-2xl overflow-hidden border border-blue-200 shadow-xs flex flex-col ${
                      imgUrl ? 'cursor-pointer group' : ''
                    }`}
                  >
                    {imgUrl && (
                      <div className="relative aspect-[4/3] overflow-hidden bg-[#081226]">
                        <img
                          src={imgUrl}
                          alt={item.title}
                          loading="lazy"
                          onError={handleImageFallback}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-[#0c1a40]/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <span className="flex items-center gap-1.5 text-xs text-white bg-[#081226] px-3 py-1.5 rounded-md font-medium border border-amber-400/50">
                            <ZoomIn className="w-3.5 h-3.5 text-amber-400" />
                            <span>Inspect Photo</span>
                          </span>
                        </div>
                      </div>
                    )}
                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] font-mono font-bold text-amber-700 uppercase">
                          {item.category}
                        </span>
                        <h3 className="font-serif font-bold text-sm text-[#0c1a40] mt-1">
                          {item.title}
                        </h3>
                        <p className="text-xs text-blue-900 mt-1 line-clamp-2">
                          {item.excerpt}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Recruitment Call-to-Action */}
      <section className="py-16 px-4 sm:px-6 bg-gradient-to-r from-[#081226] via-[#162a6b] to-[#081226] text-white text-center">
        <div className="max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-mono font-bold border border-amber-400/40 uppercase">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>Join The Pride · LKC Rugby Recruitment</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">
            Ready to Wear the Jaguar Crest?
          </h2>
          <p className="text-blue-100 text-sm leading-relaxed">
            {general.name} welcomes ambitious student-athletes seeking uncompromising academic rigour combined with premier rugby coaching. Apply for admission or register for upcoming squad trials.
          </p>
          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <a
              href={general.admissionsPortalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-7 py-3 bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs sm:text-sm rounded-xl shadow-lg transition"
            >
              Apply for Admission (Portal) ↗
            </a>
            <a
              href={`tel:${general.contacts.phone.replace(/\s+/g, '')}`}
              className="px-6 py-3 bg-blue-900/70 hover:bg-blue-800 text-white font-medium text-xs sm:text-sm rounded-xl border border-blue-700 transition"
            >
              Contact Sports Registry ({general.contacts.phone})
            </a>
          </div>
        </div>
      </section>

      {/* Interactive Lightbox */}
      <AnimatePresence>
        {activeModalImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              setActiveModalImage(null);
              setZoomScale(1);
            }}
            className="fixed inset-0 z-50 bg-[#081226]/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#0c1a40] border border-blue-800 rounded-2xl max-w-[96vw] sm:max-w-[94vw] w-full overflow-hidden shadow-2xl flex flex-col h-[94vh] max-h-[94vh]"
            >
              <div className="px-5 py-3.5 bg-[#081226] border-b border-blue-900 flex items-center justify-between text-white">
                <div>
                  <h3 className="font-serif font-bold text-sm sm:text-base text-white">
                    {activeModalImage.title}
                  </h3>
                  {activeModalImage.subtitle && (
                    <p className="text-xs text-amber-400">{activeModalImage.subtitle}</p>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-blue-950 rounded-lg border border-blue-800 px-1 py-0.5 text-xs text-blue-100">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setZoomScale((prev) => Math.max(prev - 0.25, 0.5));
                      }}
                      className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                      title="Zoom Out"
                    >
                      <ZoomOut className="w-4 h-4" />
                    </button>
                    <span className="px-1.5 font-mono text-[11px] text-amber-400">
                      {Math.round(zoomScale * 100)}%
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setZoomScale((prev) => Math.min(prev + 0.25, 4));
                      }}
                      className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                      title="Zoom In"
                    >
                      <ZoomIn className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setZoomScale(1);
                      }}
                      className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer ml-1"
                      title="Reset Zoom"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      downloadImageFile(activeModalImage.url, activeModalImage.title);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                    title="Download Image"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Download</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveModalImage(null);
                      setZoomScale(1);
                    }}
                    className="p-1.5 rounded-lg bg-blue-900/60 hover:bg-blue-800 text-white transition-colors cursor-pointer"
                    aria-label="Close image preview"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-[#081226] min-h-[64vh]">
                <div
                  className="transition-transform duration-200 origin-center flex items-center justify-center"
                  style={{ transform: `scale(${zoomScale})` }}
                >
                  <img
                    src={activeModalImage.url}
                    alt={activeModalImage.title}
                    onError={handleImageFallback}
                    className="h-[74vh] sm:h-[78vh] w-auto max-w-[90vw] object-contain rounded-xl shadow-2xl"
                  />
                </div>
              </div>

              <div className="px-5 py-2.5 bg-[#081226] border-t border-blue-900 flex items-center justify-between text-xs text-blue-200">
                <span>{general.name} · Jaguars Rugby Football Club</span>
                <span className="text-amber-400 font-mono text-[11px]">Use +/- buttons above to inspect details</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};
