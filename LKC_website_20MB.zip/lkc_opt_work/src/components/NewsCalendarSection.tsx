import React from 'react';
import { useCmsSection } from '../services/cmsDataService';
import { GraduationCap, Bell, Calendar } from 'lucide-react';

export const NewsCalendarSection: React.FC = () => {
  const calendar = useCmsSection('calendar');
  const announcements = useCmsSection('announcements');
  const alumni = useCmsSection('alumni');
  const general = useCmsSection('general');

  const activeAnnouncements = announcements.filter((item) => item.active);
  const approvedAlumni = alumni.filter((item) => item.status === 'approved');

  return (
    <section id="calendar" className="py-20 bg-white border-b border-blue-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-2">
            Academic Schedule & Institutional Notices
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#0c1a40] tracking-tight text-balance">
            2026 Academic Term Calendar & Alumni Registry
          </h2>
          <div className="w-16 h-0.5 bg-amber-500 mt-4 mb-6" />
          <p className="text-base text-blue-900/80 leading-relaxed font-sans">
            Our term calendar synchronizes with both the national Botswana school calendar and international Cambridge examination windows, ensuring balanced athletic, cultural, and revision periods.
          </p>
        </div>

        {/* Active CMS Announcements (when added by Admin) */}
        {activeAnnouncements.length > 0 && (
          <div className="mb-14 space-y-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-700 font-bold">
              <Bell className="w-4 h-4 text-amber-500" />
              <span>Official College Notices & Bulletins</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {activeAnnouncements.map((notice) => (
                <div
                  key={notice.id}
                  className="p-6 rounded-xl bg-gradient-to-br from-[#0c1a40] to-[#162a6b] text-white border border-blue-900 shadow-sm flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between text-[11px] font-mono text-amber-400 mb-2">
                      <span>{notice.category}</span>
                      <span>{notice.date}</span>
                    </div>
                    <h3 className="font-serif font-bold text-lg text-white mb-2">{notice.title}</h3>
                    <p className="text-xs text-blue-100 leading-relaxed font-sans">{notice.body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Term Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
          {calendar.map((term) => (
            <div
              key={term.term}
              className="bg-blue-50/40 p-6 sm:p-7 rounded-xl border border-blue-200 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono uppercase tracking-wider text-amber-700 font-semibold flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-amber-500" />
                    <span>{term.term}</span>
                  </span>
                  <span className="text-xs text-blue-900/60 font-mono">2026</span>
                </div>
                <h3 className="text-xl font-serif font-bold text-[#0c1a40] mb-2">{term.title}</h3>

                {/* Dates */}
                <div className="space-y-2 py-3 border-y border-blue-200/80 text-xs text-blue-900/80 font-sans mb-4">
                  <div className="flex justify-between gap-2">
                    <span className="text-blue-900/60">Duration:</span>
                    <span className="font-semibold text-[#0c1a40]">
                      {term.start} – {term.end}
                    </span>
                  </div>
                  <div className="flex justify-between gap-2">
                    <span className="text-blue-900/60">Mid-Term Recess:</span>
                    <span className="font-medium text-[#0c1a40]">{term.midTermBreak}</span>
                  </div>
                </div>

                {/* Key Milestones */}
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-blue-900/60 font-semibold mb-2">
                    Key Term Milestones:
                  </div>
                  <ul className="space-y-1.5 text-xs text-blue-900/85 font-sans">
                    {term.milestones.map((m: string, i: number) => (
                      <li key={i} className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                        <span>{m}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-4 mt-6 border-t border-blue-200/80 text-[11px] text-blue-900/65 flex items-center justify-between">
                <span>{general.name}</span>
                <span className="font-mono">13 Weeks</span>
              </div>
            </div>
          ))}
        </div>

        {/* Verified Alumni & University Matriculation */}
        <div className="bg-blue-50/40 p-8 sm:p-10 rounded-xl border border-blue-200 shadow-xs">
          <div className="max-w-2xl mb-8">
            <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold mb-1">
              Old Kolobengans · Verified Graduate Registry
            </div>
            <h3 className="text-2xl font-serif font-bold text-[#0c1a40]">
              Where LKC Cambridge Graduates Excel
            </h3>
            <p className="text-sm text-blue-900/80 mt-1">
              Equipped with Cambridge IGCSE and A-Level credentials, verified LKC alumni submit their university placements and career milestones for publication by College Administration.
            </p>
          </div>

          {approvedAlumni.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {approvedAlumni.map((alum) => (
                <div
                  key={alum.id}
                  className="p-5 bg-white rounded-lg border border-blue-200 flex flex-col justify-between shadow-xs"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs text-blue-900/60 font-mono mb-2">
                      <span>Class of {alum.gradYear}</span>
                      <GraduationCap className="w-4 h-4 text-amber-500" />
                    </div>
                    <h4 className="font-serif font-bold text-base text-[#0c1a40] mb-1">{alum.name}</h4>
                    <div className="text-xs text-amber-700 font-medium mb-3 leading-tight">
                      {alum.cambridgeHonors || alum.currentRole}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-blue-100 text-xs">
                    <div className="font-semibold text-[#0c1a40]">{alum.university}</div>
                    <div className="text-blue-900/70 text-[11px]">{alum.course}</div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-6 bg-white rounded-xl border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="font-serif font-bold text-base text-[#0c1a40] mb-1">
                  Alumni Directory Open for Verified Graduate Submissions
                </div>
                <p className="text-xs text-blue-900/75 max-w-2xl leading-relaxed">
                  Our public alumni showcase displays only verified Old Kolobengans approved through the college registry. Former students may register their profile via the Alumni page.
                </p>
              </div>
              <a
                href="#alumni"
                className="px-4 py-2.5 bg-[#0c1a40] hover:bg-[#162a6b] text-amber-400 font-semibold text-xs rounded-lg transition-colors whitespace-nowrap shrink-0 text-center"
              >
                Visit Alumni Registry
              </a>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

