import React, { useEffect, useState } from 'react';
import { Calendar, Newspaper, MapPin, Clock, CheckCircle2, X, Search, ZoomIn, Download } from 'lucide-react';
import { useCmsSection, usePublishedCmsItems } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { downloadImageFile, openImageViewer } from './ImageLightboxModal';
import type { CmsItem } from '../types';

interface NewsEventsPageProps {
  initialTab?: 'news' | 'events';
}

export const NewsEventsPage: React.FC<NewsEventsPageProps> = ({ initialTab = 'news' }) => {
  const [activeTab, setActiveTab] = useState<'news' | 'events'>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItem, setSelectedItem] = useState<CmsItem | null>(null);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  const newsItems = usePublishedCmsItems('news');
  const eventItems = usePublishedCmsItems('events');
  const calendar = useCmsSection('calendar');
  const announcements = useCmsSection('announcements').filter(
    (a) => a.active && (!a.status || a.status === 'published')
  );
  const general = useCmsSection('general');

  const q = searchQuery.toLowerCase().trim();
  const filteredNews = newsItems.filter(
    (item) =>
      !q ||
      item.title.toLowerCase().includes(q) ||
      item.excerpt.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q)
  );
  const filteredEvents = eventItems.filter(
    (item) =>
      !q ||
      item.title.toLowerCase().includes(q) ||
      item.excerpt.toLowerCase().includes(q) ||
      (item.eventLocation || '').toLowerCase().includes(q)
  );

  return (
    <div className="bg-blue-50/30 min-h-screen text-[#0c1a40] pb-20">
      <div className="bg-gradient-to-br from-[#081226] via-[#0c1a40] to-[#162a6b] text-white py-14 px-4 sm:px-6 border-b border-blue-900">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <div className="text-xs font-mono text-amber-400 uppercase tracking-widest mb-2">
              {general.name} · Official Communications
            </div>
            <h1 className="text-3xl sm:text-5xl font-serif font-bold tracking-tight">
              College News, Announcements & Events Calendar
            </h1>
            <p className="text-sm text-blue-100 mt-2 max-w-2xl">
              Browse full institutional bulletins, examination updates, term dates, and upcoming campus events.
            </p>
          </div>

          <div className="flex items-center bg-white/10 p-1 rounded-xl border border-white/20 shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('news')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors ${
                activeTab === 'news'
                  ? 'bg-amber-400 text-[#081226] font-bold'
                  : 'text-white hover:bg-white/10'
              }`}
            >
              <Newspaper className="w-3.5 h-3.5" />
              <span>News & Bulletins ({filteredNews.length + announcements.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('events')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors ${
                activeTab === 'events'
                  ? 'bg-amber-400 text-[#081226] font-bold'
                  : 'text-white hover:bg-white/10'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Events & Term Calendar ({filteredEvents.length})</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-10 space-y-10">
        {/* Search Filter */}
        <div className="bg-white p-4 rounded-2xl border border-blue-200 shadow-xs relative">
          <Search className="w-4 h-4 text-blue-400 absolute left-7 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search articles, notices, events, or campus venues..."
            className="w-full pl-10 pr-4 py-2.5 bg-blue-50/40 border border-blue-200 rounded-xl text-xs sm:text-sm focus:outline-hidden focus:border-[#0c1a40]"
          />
        </div>

        {activeTab === 'news' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredNews.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedItem(item)}
                  className="bg-white rounded-2xl border border-blue-200 overflow-hidden shadow-xs hover:shadow-md hover:border-amber-400 transition-all cursor-pointer flex flex-col justify-between"
                >
                  <div>
                    {item.thumbnailUrl && (
                      <div className="aspect-[16/9] bg-[#081226] overflow-hidden">
                        <img
                          src={item.thumbnailUrl}
                          alt={item.title}
                          loading="lazy"
                          onError={handleImageFallback}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    <div className="p-5">
                      <div className="flex items-center justify-between text-[11px] font-mono text-amber-700 font-bold mb-1.5">
                        <span>{item.category}</span>
                        <span>{item.publishAt || item.updatedAt.slice(0, 10)}</span>
                      </div>
                      <h2 className="font-serif font-bold text-lg text-[#0c1a40] mb-2">
                        {item.title}
                      </h2>
                      <p className="text-xs text-blue-950/80 leading-relaxed">
                        {item.excerpt}
                      </p>
                    </div>
                  </div>
                  <div className="px-5 py-3 bg-blue-50/50 border-t border-blue-100 text-xs font-semibold text-[#0c1a40]">
                    Read Full Bulletin →
                  </div>
                </div>
              ))}

              {announcements.map((notice) => (
                <div
                  key={notice.id}
                  className="rounded-2xl bg-gradient-to-br from-[#0c1a40] to-[#162a6b] text-white border border-blue-900 shadow-sm overflow-hidden flex flex-col"
                >
                  {notice.thumbnailUrl && (
                    <div className="aspect-[16/9] bg-[#081226] overflow-hidden">
                      <img
                        src={notice.thumbnailUrl}
                        alt={notice.title}
                        loading="lazy"
                        onError={handleImageFallback}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <div className="p-6">
                    <div className="flex items-center justify-between text-[11px] font-mono text-amber-400 mb-2">
                      <span>{notice.category}</span>
                      <span>{notice.date}</span>
                    </div>
                    <h3 className="font-serif font-bold text-lg text-white mb-2">
                      {notice.title}
                    </h3>
                    <p className="text-xs text-blue-100 leading-relaxed">{notice.body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'events' && (
          <div className="space-y-12">
            {/* CMS Events */}
            <div>
              <h2 className="text-2xl font-serif font-bold text-[#0c1a40] mb-5">
                Upcoming & Completed College Events
              </h2>
              {filteredEvents.length === 0 ? (
                <div className="p-8 bg-white rounded-2xl border border-blue-200 text-center text-xs text-blue-900">
                  No published events match your filter right now.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredEvents.map((ev) => (
                    <div
                      key={ev.id}
                      onClick={() => setSelectedItem(ev)}
                      className="bg-white rounded-2xl border border-blue-200 overflow-hidden shadow-xs hover:border-amber-400 transition-all cursor-pointer flex flex-col justify-between"
                    >
                      <div>
                        {ev.thumbnailUrl && (
                          <div className="aspect-[16/9] bg-[#081226] overflow-hidden relative">
                            <img
                              src={ev.thumbnailUrl}
                              alt={ev.title}
                              loading="lazy"
                              onError={handleImageFallback}
                              className="w-full h-full object-cover"
                            />
                            {ev.eventCompleted && (
                              <span className="absolute top-3 right-3 px-2.5 py-0.5 rounded-full bg-[#0c1a40] text-amber-300 text-[10px] font-mono font-bold border border-amber-400/40 flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3" /> Completed
                              </span>
                            )}
                          </div>
                        )}
                        <div className="p-5 space-y-2">
                          <span className="text-[10px] font-mono uppercase text-amber-700 font-bold">
                            {ev.category}
                          </span>
                          <h3 className="font-serif font-bold text-lg text-[#0c1a40]">
                            {ev.title}
                          </h3>
                          <p className="text-xs text-blue-950/80 leading-relaxed">
                            {ev.excerpt}
                          </p>
                          <div className="pt-2 space-y-1 text-[11px] text-blue-900 font-mono">
                            {ev.eventDate && (
                              <div className="flex items-center gap-1.5">
                                <Calendar className="w-3.5 h-3.5 text-amber-600" />
                                <span>{ev.eventDate}</span>
                              </div>
                            )}
                            {ev.eventTime && (
                              <div className="flex items-center gap-1.5">
                                <Clock className="w-3.5 h-3.5 text-amber-600" />
                                <span>{ev.eventTime}</span>
                              </div>
                            )}
                            {ev.eventLocation && (
                              <div className="flex items-center gap-1.5">
                                <MapPin className="w-3.5 h-3.5 text-amber-600" />
                                <span>{ev.eventLocation}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="px-5 py-3 bg-blue-50/50 border-t border-blue-100 text-xs font-semibold text-[#0c1a40]">
                        View Event Details →
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 2026 Term Calendar */}
            <div>
              <h2 className="text-2xl font-serif font-bold text-[#0c1a40] mb-5">
                Official 2026 Academic Term Calendar
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {calendar.map((term) => (
                  <div
                    key={term.term}
                    className="bg-white p-6 rounded-2xl border border-blue-200 shadow-xs space-y-3"
                  >
                    <div className="flex items-center justify-between text-xs font-mono text-amber-700 font-bold">
                      <span>{term.term}</span>
                      <span>2026</span>
                    </div>
                    <h3 className="font-serif font-bold text-lg text-[#0c1a40]">{term.title}</h3>
                    <div className="text-xs text-blue-900 space-y-1 border-y border-blue-100 py-3">
                      <div className="flex justify-between">
                        <span>Dates:</span>
                        <span className="font-semibold">{term.start} – {term.end}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Half-Term Break:</span>
                        <span className="font-medium">{term.midTermBreak}</span>
                      </div>
                    </div>
                    <ul className="space-y-1.5 text-xs text-blue-950/85">
                      {term.milestones.map((m, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                          <span>{m}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {selectedItem && (
        <div
          className="fixed inset-0 z-50 bg-[#081226]/85 flex items-center justify-center p-4"
          onClick={() => setSelectedItem(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[88vh] overflow-y-auto p-6 sm:p-8 shadow-2xl border border-blue-200 relative text-[#0c1a40]"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setSelectedItem(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-blue-500 hover:bg-blue-50 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            {selectedItem.thumbnailUrl && (
              <div className="aspect-[16/9] bg-[#081226] rounded-xl overflow-hidden mb-5 relative group">
                <img
                  src={selectedItem.thumbnailUrl}
                  alt={selectedItem.title}
                  onError={handleImageFallback}
                  onClick={() =>
                    openImageViewer({
                      src: selectedItem.thumbnailUrl!,
                      title: selectedItem.title,
                      subtitle: selectedItem.category,
                    })
                  }
                  data-zoomable-image="true"
                  className="w-full h-full object-cover cursor-zoom-in"
                />
                <div className="absolute bottom-3 right-3 flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() =>
                      openImageViewer({
                        src: selectedItem.thumbnailUrl!,
                        title: selectedItem.title,
                        subtitle: selectedItem.category,
                      })
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-[#081226]/90 hover:bg-[#081226] text-amber-300 border border-amber-400/40 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                    <span>Zoom</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => downloadImageFile(selectedItem.thumbnailUrl!, selectedItem.title)}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              </div>
            )}
            <div className="text-xs font-mono uppercase text-amber-700 font-bold mb-1">
              {selectedItem.category}
              {selectedItem.eventDate ? ` · Event: ${selectedItem.eventDate}` : ''}
            </div>
            <h2 className="text-2xl font-serif font-bold text-[#0c1a40] mb-3">
              {selectedItem.title}
            </h2>
            <p className="text-sm font-medium text-blue-950 mb-4 leading-relaxed">
              {selectedItem.excerpt}
            </p>
            {typeof selectedItem.content?.body === 'string' && (
              <p className="text-xs sm:text-sm text-blue-900/85 leading-relaxed whitespace-pre-line">
                {selectedItem.content.body}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
