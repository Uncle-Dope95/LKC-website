import React, { useState } from 'react';
import {
  X,
  Shield,
  ExternalLink,
  Users,
  GraduationCap,
  KeyRound,
  Bell,
} from 'lucide-react';
import { isStaticSiteMode, useCmsSection } from '../services/cmsDataService';

interface PortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAdminCms?: () => void;
}

export const PortalModal: React.FC<PortalModalProps> = ({ isOpen, onClose, onOpenAdminCms }) => {
  const staticMode = isStaticSiteMode();
  const general = useCmsSection('general');
  const announcements = useCmsSection('announcements');
  const [activeTab, setActiveTab] = useState<'portals' | 'grades' | 'timetable' | 'notices'>('portals');

  if (!isOpen) return null;

  const activeAnnouncements = announcements.filter((a) => a.active);

  return (
    <div className="fixed inset-0 z-50 bg-[#081226]/90 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl border border-blue-200 relative my-6 text-[#0c1a40]">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg text-blue-900/60 hover:text-[#0c1a40] hover:bg-blue-50 transition-colors cursor-pointer"
          aria-label="Close portal modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Portal Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-blue-100">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-700 font-semibold mb-1">
              <Shield className="w-4 h-4 text-amber-500" />
              <span>Official School Portal · lkcportal.com</span>
              <span aria-hidden="true">·</span>
              <span>{general.cambridgeCentreNo}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#0c1a40]">
              LKC Secure School Management & Admissions Portal
            </h2>
            <p className="text-xs text-blue-900/75 mt-0.5">
              Access the central hub for student admissions, parent academic reports, fees, and staff registers.
            </p>
          </div>
        </div>

        {/* Official Portal Access Gateway Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
          {/* Card 1: Apply for Admission */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-[#0c1a40] to-[#162a6b] text-white flex flex-col justify-between shadow-md border border-blue-900">
            <div>
              <div className="w-10 h-10 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center mb-3">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400">
                Online Admissions
              </span>
              <h3 className="font-serif font-bold text-base text-white mt-1">Apply for Admission</h3>
              <p className="text-xs text-blue-100 mt-1 leading-relaxed">
                Secure school portal where all student registrations, document uploads, and diagnostic assessments are submitted.
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-white/15">
              <a
                href={general.admissionsPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-[#081226] font-bold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <span>Open Admissions Portal</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <span className="text-[10px] font-mono text-amber-300 mt-1.5 text-center block truncate">
                {general.admissionsPortalUrl.replace(/^https?:\/\//, '')}
              </span>
            </div>
          </div>

          {/* Card 2: Parents Portal */}
          <div className="p-5 rounded-2xl bg-blue-50/50 border border-blue-200 flex flex-col justify-between shadow-xs hover:border-blue-400 transition-colors">
            <div>
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-[#0c1a40] flex items-center justify-center mb-3">
                <Users className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#162a6b]">
                Parent Gateway
              </span>
              <h3 className="font-serif font-bold text-base text-[#0c1a40] mt-1">Parents Portal</h3>
              <p className="text-xs text-blue-900/80 mt-1 leading-relaxed">
                Live access to your child&apos;s Cambridge report cards, term attendance, fee account ledgers, and teacher notices.
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-blue-200">
              <a
                href={general.parentsPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-3 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <span>Login to Parents Portal</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <span className="text-[10px] font-mono text-blue-900/65 mt-1.5 text-center block truncate">
                {general.parentsPortalUrl.replace(/^https?:\/\//, '')}
              </span>
            </div>
          </div>

          {/* Card 3: Teachers Portal */}
          <div className="p-5 rounded-2xl bg-blue-50/50 border border-blue-200 flex flex-col justify-between shadow-xs hover:border-amber-400 transition-colors">
            <div>
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-[#0c1a40] flex items-center justify-center mb-3">
                <KeyRound className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-800">
                Faculty & Administration
              </span>
              <h3 className="font-serif font-bold text-base text-[#0c1a40] mt-1">
                Teachers & Staff Portal
              </h3>
              <p className="text-xs text-blue-900/80 mt-1 leading-relaxed">
                Faculty gradebook entry, timetable scheduling, Cambridge syllabus tracking, and internal academic communications.
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-blue-200 space-y-2">
              <a
                href={general.teachersPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-3 rounded-lg bg-[#162a6b] hover:bg-[#0c1a40] text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <span>Login to Teachers Portal</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              {!staticMode && onOpenAdminCms && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenAdminCms();
                  }}
                  className="w-full py-2 px-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Shield className="w-3.5 h-3.5" />
                  <span>Open College CMS Backend</span>
                </button>
              )}
              <span className="text-[10px] font-mono text-blue-900/65 text-center block truncate">
                {general.teachersPortalUrl.replace(/^https?:\/\//, '')}
              </span>
            </div>
          </div>
        </div>

        {/* Feature Tabs */}
        <div className="flex items-center gap-2 border-b border-blue-200 mb-6 overflow-x-auto text-xs font-sans">
          {[
            { id: 'portals', label: 'All Portal Access Points' },
            { id: 'grades', label: 'Cambridge Report Preview' },
            { id: 'timetable', label: 'Class Timetable' },
            { id: 'notices', label: 'College Notices' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as 'portals' | 'grades' | 'timetable' | 'notices')}
              className={`py-2.5 px-4 border-b-2 font-medium whitespace-nowrap cursor-pointer transition-colors ${
                activeTab === tab.id
                  ? 'border-[#0c1a40] text-[#0c1a40] font-bold'
                  : 'border-transparent text-blue-900/60 hover:text-[#0c1a40]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content: Portals overview */}
        {activeTab === 'portals' && (
          <div className="p-4 bg-blue-50/60 rounded-xl border border-blue-200 text-xs text-blue-900/85 leading-relaxed space-y-2">
            <h4 className="font-serif font-bold text-[#0c1a40] text-sm flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-amber-500" />
              <span>Everything Handled on the Central LKC Cloud Portal</span>
            </h4>
            <p>
              {general.name} operates a fully integrated school management system hosted at{' '}
              <strong>lkcportal.com</strong>. Prospective parents can register learners for 2026/27, upload prerequisite diagnostic transcripts, and track admission status in real-time. Enrolled parents and learners access continuous assessment marks, Cambridge mock results, and term accounts.
            </p>
          </div>
        )}

        {/* Tab 2: Grades & Report Card */}
        {activeTab === 'grades' && (
          <div className="space-y-4 text-xs font-sans">
            <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-blue-50/50 rounded-lg border border-blue-200">
              <div>
                <span className="text-blue-900/65 block text-[11px]">Term Assessment Series:</span>
                <span className="font-bold text-[#0c1a40]">Cambridge IGCSE Mock Series</span>
              </div>
              <div className="flex items-center gap-4 text-blue-900">
                <div>
                  <span className="text-blue-900/65 block text-[11px]">Sample Grade Scale:</span>
                  <span className="font-bold text-[#0c1a40] font-mono text-sm">A* / A Distinction Standard</span>
                </div>
                <div>
                  <span className="text-blue-900/65 block text-[11px]">Portal Feed:</span>
                  <span className="font-bold text-amber-700 font-mono text-sm">Live via lkcportal.com</span>
                </div>
              </div>
            </div>

            <div className="border border-blue-200 rounded-lg overflow-hidden">
              <div className="grid grid-cols-12 bg-blue-50 p-2.5 font-semibold text-[#0c1a40] text-[11px] uppercase tracking-wider">
                <div className="col-span-6">Subject & Cambridge Syllabus</div>
                <div className="col-span-3 text-center">Sample Band</div>
                <div className="col-span-3 text-right">Grade Benchmark</div>
              </div>
              <div className="divide-y divide-blue-100 text-[#0c1a40]">
                <div className="grid grid-cols-12 p-2.5 items-center">
                  <div className="col-span-6 font-medium">Cambridge Extended Mathematics (0580)</div>
                  <div className="col-span-3 text-center font-mono tabular-nums">90% – 100%</div>
                  <div className="col-span-3 text-right font-bold text-amber-700">A* Distinction</div>
                </div>
                <div className="grid grid-cols-12 p-2.5 items-center">
                  <div className="col-span-6 font-medium">Cambridge Chemistry (0620)</div>
                  <div className="col-span-3 text-center font-mono tabular-nums">90% – 100%</div>
                  <div className="col-span-3 text-right font-bold text-amber-700">A* Distinction</div>
                </div>
                <div className="grid grid-cols-12 p-2.5 items-center">
                  <div className="col-span-6 font-medium">Cambridge Physics (0625)</div>
                  <div className="col-span-3 text-center font-mono tabular-nums">90% – 100%</div>
                  <div className="col-span-3 text-right font-bold text-amber-700">A* Distinction</div>
                </div>
                <div className="grid grid-cols-12 p-2.5 items-center">
                  <div className="col-span-6 font-medium">Cambridge Computer Science (0478)</div>
                  <div className="col-span-3 text-center font-mono tabular-nums">90% – 100%</div>
                  <div className="col-span-3 text-right font-bold text-amber-700">A* Distinction</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Timetable */}
        {activeTab === 'timetable' && (
          <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-200 text-xs text-blue-900/85 leading-relaxed">
            <h5 className="font-semibold text-[#0c1a40] mb-2">Weekly Cambridge Lesson Schedule</h5>
            <p>
              School begins daily at 07:30 CAT. Eight teaching periods daily with laboratory practical double-periods in the afternoon, followed by co-curricular sports and supervised prep in the Masire Boarding Houses.
            </p>
          </div>
        )}

        {/* Tab 4: Notices */}
        {activeTab === 'notices' && (
          <div className="space-y-3 text-xs font-sans">
            {activeAnnouncements.length > 0 ? (
              activeAnnouncements.map((notice) => (
                <div key={notice.id} className="p-3.5 bg-blue-50/50 rounded-xl border border-blue-200">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-[#0c1a40]">{notice.title}</span>
                    <span className="text-[11px] font-mono text-amber-700">{notice.date}</span>
                  </div>
                  <span className="text-blue-900/80 text-[11px] block mt-1">{notice.body}</span>
                </div>
              ))
            ) : (
              <>
                <div className="p-3.5 bg-blue-50/50 rounded-xl border border-blue-200 flex items-start gap-2.5">
                  <Bell className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-[#0c1a40] block">
                      New Forms 1 & 2 Classrooms Construction for 2027
                    </span>
                    <span className="text-blue-900/75 text-[11px] block mt-0.5">
                      12-classroom expansion underway at our Block 8 campus in Gaborone.
                    </span>
                  </div>
                </div>
                <div className="p-3.5 bg-blue-50/50 rounded-xl border border-blue-200 flex items-start gap-2.5">
                  <Bell className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-[#0c1a40] block">
                      Outstanding Cambridge Learner Awards 2025
                    </span>
                    <span className="text-blue-900/75 text-[11px] block mt-0.5">
                      Top in the World Agriculture & Top in Botswana honors recognized across 2025 examinations.
                    </span>
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* Modal Footer */}
        <div className="pt-6 mt-6 border-t border-blue-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-blue-900/75 font-sans">
          <span>
            Official Portal: lkcportal.com · {general.name}
          </span>
          <div className="flex items-center gap-3">
            <a
              href={general.admissionsPortalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-[#081226] font-bold rounded-lg transition-colors flex items-center gap-1.5"
            >
              <span>Apply for Admission (Online Form)</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-blue-100 hover:bg-blue-200 text-[#0c1a40] font-medium rounded-lg transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

