import React, { useState } from 'react';
import { X, Download, Check, BookOpen, Printer, FileText, Send, AlertTriangle } from 'lucide-react';
import { getAllCmsData, useCmsSection, submitProspectusRequest } from '../services/cmsDataService';

interface ProspectusModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProspectusModal: React.FC<ProspectusModalProps> = ({ isOpen, onClose }) => {
  const general = useCmsSection('general');
  const fees = useCmsSection('fees');
  const [downloaded, setDownloaded] = useState(false);
  const [reqName, setReqName] = useState('');
  const [reqEmail, setReqEmail] = useState('');
  const [reqPhone, setReqPhone] = useState('');
  const [reqLevel, setReqLevel] = useState('Lower Secondary (Forms 1-3)');
  const [reqSubmitting, setReqSubmitting] = useState(false);
  const [reqSent, setReqSent] = useState(false);
  const [reqError, setReqError] = useState<string | null>(null);

  if (!isOpen) return null;

  const currency = fees.structure.currency || 'P';
  const oneOff = fees.structure.oneOffFees;
  const pdfUrl = general.contacts.feePolicyPdfUrl || fees.structure.pdfDocumentUrl;

  const handleRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setReqSubmitting(true);
    setReqError(null);
    try {
      await submitProspectusRequest({
        name: reqName.trim(),
        email: reqEmail.trim(),
        phone: reqPhone.trim(),
        level: reqLevel,
      });
      setReqSent(true);
    } catch (err) {
      setReqError(
        err instanceof Error
          ? err.message
          : 'Unable to send prospectus request automatically. Please call +267 316 1140 / +267 316 2208 or message WhatsApp +267 78 465 196.'
      );
    } finally {
      setReqSubmitting(false);
    }
  };

  const handleDownloadProspectus = () => {
    const db = getAllCmsData();
    const deptHtml = db.departments
      .map(
        (d) =>
          `<li><strong>${d.name}</strong> (${d.headOfDepartment.name} · ${d.headOfDepartment.title}): ${d.subjects.join(', ')}</li>`
      )
      .join('');
    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${db.general.name} — Academic Prospectus 2026/2027</title>
<style>
  body { font-family: Georgia, serif; color: #0c1a40; max-width: 820px; margin: 40px auto; padding: 0 24px; line-height: 1.6; }
  h1, h2 { color: #0c1a40; border-bottom: 2px solid #f59e0b; padding-bottom: 6px; }
  .meta { color: #162a6b; font-family: sans-serif; font-size: 13px; margin-bottom: 24px; }
  .card { background: #eff6ff; border: 1px solid #bfdbfe; padding: 16px; border-radius: 8px; margin-bottom: 18px; }
  ul { padding-left: 20px; }
</style>
</head>
<body>
  <h1>${db.general.name} — Academic Prospectus 2026/2027</h1>
  <div class="meta">${db.general.cambridgeCentreNo} · Motto: ${db.general.motto} (${db.general.mottoEnglish}) · ${db.general.address.plot}, ${db.general.address.area}, ${db.general.address.city}, ${db.general.address.country}</div>
  <div class="card">
    <h2>Mission & Institutional Heritage</h2>
    <p>${db.about.heritageParagraph1}</p>
    <p>${db.about.missionText}</p>
  </div>
  <div class="card">
    <h2>Academic Departments</h2>
    <ul>${deptHtml}</ul>
  </div>
  <div class="card">
    <h2>Boarding & Admissions Summary</h2>
    <p>${db.boarding.officialTitle}: ${db.boarding.capacity} Beds (${db.boarding.hostels.map((h) => h.name).join(' & ')}).</p>
    <p>Entrance Assessment: ${currency} ${oneOff.entranceAssessment} · Registration: ${currency} ${oneOff.registrationEnrollment} · Development Levy: ${currency} ${oneOff.developmentLevyForms1to5} (Forms 1–5) / ${currency} ${oneOff.developmentLevyALevel} (A-Levels).</p>
  </div>
  <div class="meta">Admissions: ${db.general.contacts.admissionsEmail} · Switchboard: ${db.general.contacts.phone} · Portal: ${db.general.admissionsPortalUrl}</div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Livingstone_Kolobeng_College_Prospectus_2026_2027.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setDownloaded(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#081226]/85 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-blue-200 relative my-6 text-[#0c1a40]">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-md text-blue-900/60 hover:text-[#0c1a40] hover:bg-blue-50 transition-colors cursor-pointer"
          aria-label="Close prospectus modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6 pb-4 border-b border-blue-100 flex items-start gap-4">
          <div className="w-12 h-12 bg-amber-50 text-amber-700 rounded-lg flex items-center justify-center shrink-0 border border-amber-300">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs uppercase tracking-widest text-amber-700 font-sans font-semibold">
              Official Institutional Publication
            </div>
            <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#0c1a40]">
              LKC Academic Prospectus 2026/2027
            </h2>
            <div className="text-xs text-blue-900/70 font-sans mt-0.5">
              {general.cambridgeCentreNo} · {general.address.city}, {general.address.country}
            </div>
          </div>
        </div>

        {/* Document Preview Contents */}
        <div className="space-y-4 text-xs font-sans text-blue-900/85 max-h-[60vh] overflow-y-auto pr-2">
          <div className="p-4 bg-blue-50/50 rounded-lg border border-blue-200">
            <h4 className="font-serif font-bold text-[#0c1a40] text-sm mb-1.5">
              Executive Summary & Accreditation
            </h4>
            <p className="leading-relaxed">
              {general.name} is an independent co-educational institution registered under the Ministry of Basic Education of Botswana and accredited by Cambridge Assessment International Education ({general.cambridgeCentreNo}). We offer a comprehensive British-based curriculum from Preschool and Form 1 through Cambridge A-Levels.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 bg-blue-50/50 rounded-lg border border-blue-200">
              <div className="font-semibold text-[#0c1a40] mb-1">Academic Divisions</div>
              <ul className="space-y-1 text-blue-900/80 list-disc list-inside text-[11px]">
                <li>Early Years: Preschool Pathway</li>
                <li>Lower Secondary: Forms 1 to 3</li>
                <li>Upper Secondary: Forms 4 & 5 (IGCSE)</li>
                <li>Advanced Level: Sixth Form AS & A2</li>
              </ul>
            </div>

            <div className="p-3.5 bg-blue-50/50 rounded-lg border border-blue-200">
              <div className="font-semibold text-[#0c1a40] mb-1">Campus Amenities</div>
              <ul className="space-y-1 text-blue-900/80 list-disc list-inside text-[11px]">
                <li>Physics, Chemistry & Biology Labs</li>
                <li>15,000 Volume Memorial Library</li>
                <li>100-Bed Masire Boarding Residences</li>
                <li>Athletics Track & Jaguars Rugby Ground</li>
              </ul>
            </div>
          </div>

          <div className="p-4 bg-blue-50/50 rounded-lg border border-blue-200">
            <h4 className="font-serif font-bold text-[#0c1a40] text-sm mb-1.5">Admissions Requirements</h4>
            <p className="leading-relaxed mb-2">
              Entry into all forms is subject to satisfactory performance in the LKC Entrance Examination (English Comprehension and Mathematics), submission of previous academic term reports, and an interview with the academic directorate.
            </p>
            <div className="text-[11px] text-[#0c1a40] space-y-0.5 font-mono tabular-nums">
              <div>· Entrance Assessment Fee: {currency} {oneOff.entranceAssessment}</div>
              <div>· Registration & Enrollment: {currency} {oneOff.registrationEnrollment}</div>
              <div>
                · Institutional Development Levy: {currency} {oneOff.developmentLevyForms1to5.toLocaleString()} (Forms 1–5) / {currency} {oneOff.developmentLevyALevel.toLocaleString()} (A-Levels)
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-amber-50 rounded-lg border border-amber-300 text-[#0c1a40]">
            <div className="font-semibold text-[#0c1a40] mb-0.5">International & SADC Applicants</div>
            <p className="text-[11px] leading-relaxed text-blue-900/80">
              International students are assisted by the college registry in securing student study permits with the Department of Immigration and Citizenship in Botswana.
            </p>
          </div>

          <div className="p-4 bg-white rounded-lg border border-blue-200 space-y-3">
            <div className="font-serif font-bold text-[#0c1a40] text-sm">
              Request Prospectus & Fee Information by Email
            </div>
            {reqSent ? (
              <div className="p-3 rounded-lg bg-blue-50 border border-blue-200 text-xs text-[#0c1a40] flex items-center justify-between gap-2">
                <span>
                  Thank you, <strong>{reqName}</strong>. Admissions has received your prospectus request for{' '}
                  <strong>{reqLevel}</strong>.
                </span>
                <button
                  type="button"
                  onClick={() => setReqSent(false)}
                  className="text-amber-700 underline font-semibold shrink-0 cursor-pointer"
                >
                  New request
                </button>
              </div>
            ) : (
              <form onSubmit={handleRequestSubmit} className="space-y-2.5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    required
                    value={reqName}
                    onChange={(e) => setReqName(e.target.value)}
                    placeholder="Parent / Guardian Name *"
                    className="w-full px-3 py-2 rounded-lg border border-blue-200 bg-blue-50/30 text-xs focus:outline-hidden focus:border-[#0c1a40]"
                  />
                  <input
                    type="email"
                    required
                    value={reqEmail}
                    onChange={(e) => setReqEmail(e.target.value)}
                    placeholder="Email Address *"
                    className="w-full px-3 py-2 rounded-lg border border-blue-200 bg-blue-50/30 text-xs focus:outline-hidden focus:border-[#0c1a40]"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="tel"
                    value={reqPhone}
                    onChange={(e) => setReqPhone(e.target.value)}
                    placeholder="Phone / WhatsApp (Optional)"
                    className="w-full px-3 py-2 rounded-lg border border-blue-200 bg-blue-50/30 text-xs focus:outline-hidden focus:border-[#0c1a40]"
                  />
                  <select
                    value={reqLevel}
                    onChange={(e) => setReqLevel(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-blue-200 bg-white text-xs focus:outline-hidden focus:border-[#0c1a40]"
                  >
                    <option>Preschool (Early Years)</option>
                    <option>Lower Secondary (Forms 1-3)</option>
                    <option>Cambridge IGCSE (Forms 4-5)</option>
                    <option>Sixth Form AS & A2 Levels</option>
                  </select>
                </div>
                {reqError && (
                  <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-900 text-[11px] space-y-1">
                    <div className="flex items-start gap-1.5 font-semibold">
                      <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                      <span>{reqError}</span>
                    </div>
                    <div className="flex flex-wrap gap-3 pl-5">
                      <a href="tel:+2673161140" className="underline font-semibold">+267 316 1140</a>
                      <a href="tel:+2673162208" className="underline font-semibold">+267 316 2208</a>
                      <a href="https://wa.me/26778465196" target="_blank" rel="noopener noreferrer" className="underline font-semibold text-amber-800">WhatsApp +267 78 465 196</a>
                    </div>
                  </div>
                )}
                <button
                  type="submit"
                  disabled={reqSubmitting}
                  className="px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-[#081226] font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{reqSubmitting ? 'Sending Request...' : 'Send Prospectus Request'}</span>
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Modal Actions */}
        <div className="pt-6 mt-6 border-t border-blue-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <a
            href={pdfUrl}
            download="Livingstone_Kolobeng_College_Fees_Policy_2026.pdf"
            className="text-xs text-[#0c1a40] hover:text-amber-700 font-semibold font-sans inline-flex items-center gap-1.5 underline"
          >
            <FileText className="w-3.5 h-3.5 text-amber-500" />
            <span>Download Official 2026 Fees PDF</span>
          </a>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => window.print()}
              className="px-4 py-2 border border-blue-200 rounded-lg text-xs font-medium text-[#0c1a40] hover:bg-blue-50 flex items-center justify-center gap-1.5 cursor-pointer flex-1 sm:flex-none"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadProspectus}
              className="px-5 py-2 bg-[#0c1a40] text-white rounded-lg text-xs font-semibold hover:bg-[#162a6b] transition-colors flex items-center justify-center gap-2 cursor-pointer flex-1 sm:flex-none shadow-xs"
            >
              {downloaded ? (
                <>
                  <Check className="w-4 h-4 text-amber-400" />
                  <span>Downloaded!</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>Download Prospectus</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

