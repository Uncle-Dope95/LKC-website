import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Keyboard,
  X,
  ChevronDown,
  ChevronUp,
  Compass,
  Image as ImageIcon,
  ShieldCheck,
} from 'lucide-react';
import type { PageRoute } from '../App';

interface ShortcutsHelpModalProps {
  isOpen: boolean;
  onToggle: () => void;
  onClose: () => void;
  onNavigate: (page: PageRoute) => void;
  staticMode: boolean;
}

interface ShortcutEntry {
  keys: string[];
  label: string;
  actionPage?: PageRoute;
  note?: string;
}

export const ShortcutsHelpModal: React.FC<ShortcutsHelpModalProps> = ({
  isOpen,
  onToggle,
  onClose,
  onNavigate,
  staticMode,
}) => {
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});
  const closeButtonRef = useRef<HTMLButtonElement | null>(null);
  const triggerButtonRef = useRef<HTMLButtonElement | null>(null);
  const wasOpenRef = useRef(false);

  useEffect(() => {
    if (isOpen) {
      wasOpenRef.current = true;
      const timer = window.setTimeout(() => {
        closeButtonRef.current?.focus();
      }, 40);
      return () => window.clearTimeout(timer);
    } else if (wasOpenRef.current) {
      wasOpenRef.current = false;
      triggerButtonRef.current?.focus();
    }
  }, [isOpen]);

  const toggleGroup = (groupKey: string) => {
    setCollapsedGroups((prev) => ({
      ...prev,
      [groupKey]: !prev[groupKey],
    }));
  };

  const navigationShortcuts: ShortcutEntry[] = [
    { keys: ['Alt', 'H'], label: 'Go to Home Overview', actionPage: 'home' },
    { keys: ['Alt', 'D'], label: 'Go to Academic Departments & Faculty', actionPage: 'departments' },
    { keys: ['Alt', 'C'], label: 'Go to Cambridge Curriculum', actionPage: 'curriculum' },
    { keys: ['Alt', 'F'], label: 'Go to Tuition Fees & Calculator', actionPage: 'fees' },
    { keys: ['Alt', 'N'], label: 'Go to College News & Events', actionPage: 'news' },
    { keys: ['Alt', 'T'], label: 'Scroll smoothly to top of page' },
  ];

  const viewerShortcuts: ShortcutEntry[] = [
    { keys: ['+', '='], label: 'Zoom in inside image viewer' },
    { keys: ['-'], label: 'Zoom out inside image viewer' },
    { keys: ['0'], label: 'Reset image zoom to 100%' },
    { keys: ['Esc'], label: 'Close active viewer or modal' },
  ];

  const accessShortcuts: ShortcutEntry[] = [
    { keys: ['?'], label: 'Toggle this Help & Shortcuts dialog' },
    {
      keys: ['Ctrl', 'Shift', 'A'],
      label: 'Open / Toggle LKC Admin CMS',
      note: staticMode ? 'Available when running the live Node server' : 'Mac: ⌘ + Shift + A',
    },
    { keys: ['Tab'], label: 'Move keyboard focus between interactive controls' },
  ];

  const groups: Array<{
    key: string;
    title: string;
    icon: React.ReactNode;
    items: ShortcutEntry[];
  }> = [
    {
      key: 'navigation',
      title: 'Page Navigation',
      icon: <Compass className="w-3.5 h-3.5 text-amber-600" />,
      items: navigationShortcuts,
    },
    {
      key: 'viewer',
      title: 'Image Lightbox Controls',
      icon: <ImageIcon className="w-3.5 h-3.5 text-blue-700" />,
      items: viewerShortcuts,
    },
    {
      key: 'accessibility',
      title: 'Accessibility & Administration',
      icon: <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />,
      items: accessShortcuts,
    },
  ];

  return (
    <>
      {/* Subtle floating trigger button */}
      <div className="fixed bottom-4 left-4 z-40 print:hidden">
        <button
          ref={triggerButtonRef}
          type="button"
          onClick={onToggle}
          aria-expanded={isOpen}
          aria-controls="lkc-shortcuts-dialog"
          aria-label="Toggle keyboard shortcuts and navigation help"
          title="Keyboard shortcuts & help (?)"
          className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-blue-200/90 bg-white/95 text-[#0c1a40] shadow-md hover:shadow-lg hover:border-[#0c1a40]/40 hover:bg-blue-50/70 transition-all text-xs font-medium backdrop-blur-sm cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
        >
          <Keyboard className="w-3.5 h-3.5 text-[#0c1a40]/80" aria-hidden="true" />
          <span>Shortcuts</span>
          <kbd className="px-1.5 py-0.5 text-[10px] font-mono font-semibold bg-blue-50 text-[#0c1a40] border border-blue-200 rounded">
            ?
          </kbd>
        </button>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="fixed inset-0 z-50 bg-[#081226]/55 backdrop-blur-[2px] flex items-end sm:items-center justify-center p-3 sm:p-6"
            onClick={onClose}
          >
            <motion.section
              id="lkc-shortcuts-dialog"
              role="dialog"
              aria-modal="true"
              aria-labelledby="lkc-shortcuts-title"
              initial={{ opacity: 0, y: 12, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.98 }}
              transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg rounded-2xl bg-white border border-blue-200 shadow-2xl overflow-hidden text-[#0c1a40]"
            >
              {/* Header */}
              <div className="px-5 py-4 bg-[#0c1a40] text-white flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center shrink-0">
                    <Keyboard className="w-4 h-4 text-amber-300" aria-hidden="true" />
                  </div>
                  <div className="min-w-0">
                    <h2
                      id="lkc-shortcuts-title"
                      className="text-sm sm:text-base font-serif font-bold text-white truncate"
                    >
                      Navigation & Keyboard Shortcuts
                    </h2>
                    <p className="text-[11px] text-blue-200 truncate">
                      Quick keyboard controls across Livingstone Kolobeng College
                    </p>
                  </div>
                </div>

                <button
                  ref={closeButtonRef}
                  type="button"
                  onClick={onClose}
                  aria-label="Collapse shortcuts help dialog"
                  title="Collapse (Esc)"
                  className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-blue-100 hover:text-white transition-colors cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-300"
                >
                  <X className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>

              {/* Collapsible Shortcut Groups */}
              <div className="p-4 sm:p-5 max-h-[70vh] overflow-y-auto space-y-3 bg-slate-50/60">
                {groups.map((group) => {
                  const isCollapsed = Boolean(collapsedGroups[group.key]);
                  return (
                    <div
                      key={group.key}
                      className="rounded-xl border border-blue-100 bg-white overflow-hidden"
                    >
                      <button
                        type="button"
                        onClick={() => toggleGroup(group.key)}
                        aria-expanded={!isCollapsed}
                        className="w-full px-3.5 py-2.5 flex items-center justify-between gap-2 text-left bg-blue-50/40 hover:bg-blue-50/80 transition-colors cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-amber-500"
                      >
                        <span className="inline-flex items-center gap-2 text-xs font-semibold text-[#0c1a40] uppercase tracking-wider">
                          {group.icon}
                          {group.title}
                        </span>
                        {isCollapsed ? (
                          <ChevronDown className="w-4 h-4 text-blue-700" aria-hidden="true" />
                        ) : (
                          <ChevronUp className="w-4 h-4 text-blue-700" aria-hidden="true" />
                        )}
                      </button>

                      {!isCollapsed && (
                        <ul className="divide-y divide-blue-50 px-3.5 py-1">
                          {group.items.map((item, idx) => (
                            <li
                              key={`${group.key}-${idx}`}
                              className="py-2 flex items-center justify-between gap-3 text-xs"
                            >
                              <div className="min-w-0">
                                {item.actionPage ? (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      onNavigate(item.actionPage!);
                                      onClose();
                                    }}
                                    className="text-left font-medium text-[#0c1a40] hover:text-blue-700 hover:underline cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded"
                                  >
                                    {item.label}
                                  </button>
                                ) : (
                                  <span className="font-medium text-[#0c1a40]">
                                    {item.label}
                                  </span>
                                )}
                                {item.note && (
                                  <div className="text-[11px] text-slate-500 mt-0.5">
                                    {item.note}
                                  </div>
                                )}
                              </div>

                              <div className="flex items-center gap-1 shrink-0">
                                {item.keys.map((k, kIdx) => (
                                  <React.Fragment key={`${k}-${kIdx}`}>
                                    {kIdx > 0 && (
                                      <span className="text-[10px] text-slate-400 font-semibold">
                                        +
                                      </span>
                                    )}
                                    <kbd className="px-2 py-0.5 text-[11px] font-mono font-semibold bg-slate-100 text-[#0c1a40] border border-slate-300 rounded shadow-[0_1px_0_rgba(15,23,42,0.08)]">
                                      {k}
                                    </kbd>
                                  </React.Fragment>
                                ))}
                              </div>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Footer */}
              <div className="px-5 py-3 bg-white border-t border-blue-100 flex items-center justify-between gap-3 text-[11px] text-slate-600">
                <span>
                  Press <kbd className="px-1.5 py-0.5 font-mono bg-slate-100 border border-slate-300 rounded text-[#0c1a40]">Esc</kbd> or{' '}
                  <kbd className="px-1.5 py-0.5 font-mono bg-slate-100 border border-slate-300 rounded text-[#0c1a40]">?</kbd> to collapse
                </span>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3 py-1.5 rounded-lg bg-[#0c1a40] text-amber-300 hover:bg-[#162a6b] font-semibold transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            </motion.section>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
