import React from 'react';

// Official Brand SVGs with sharp vectors and authentic colors

export const InstagramIcon: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <defs>
      <radialGradient id="lkc-ig-grad" cx="20%" cy="100%" r="150%">
        <stop offset="0%" stopColor="#fdf497" />
        <stop offset="5%" stopColor="#fdf497" />
        <stop offset="45%" stopColor="#fd5949" />
        <stop offset="60%" stopColor="#d6249f" />
        <stop offset="90%" stopColor="#285AEB" />
      </radialGradient>
    </defs>
    <rect x="2" y="2" width="20" height="20" rx="5.5" fill="url(#lkc-ig-grad)" />
    <rect x="6" y="6" width="12" height="12" rx="3.5" stroke="#ffffff" strokeWidth="1.8" fill="none" />
    <circle cx="12" cy="12" r="3" stroke="#ffffff" strokeWidth="1.8" fill="none" />
    <circle cx="16.5" cy="7.5" r="0.9" fill="#ffffff" />
  </svg>
);

export const TikTokIcon: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <rect width="24" height="24" rx="5" fill="#010101" />
    {/* Cyan offset note */}
    <path
      d="M16.6 8.2c-.8-.5-1.4-1.3-1.6-2.2H12.8v8.6c0 1.3-1 2.3-2.3 2.3-1.3 0-2.3-1-2.3-2.3 0-1.2.9-2.2 2.1-2.3V10c-2.4.2-4.3 2.2-4.3 4.6 0 2.5 2.1 4.6 4.6 4.6 2.5 0 4.6-2.1 4.6-4.6V9.4c1.1.8 2.5 1.2 3.9 1.2V8.4c-1 0-1.9-.4-2.8-1.2z"
      fill="#25F4EE"
      transform="translate(-0.6, -0.4)"
      opacity="0.85"
    />
    {/* Red offset note */}
    <path
      d="M16.6 8.2c-.8-.5-1.4-1.3-1.6-2.2H12.8v8.6c0 1.3-1 2.3-2.3 2.3-1.3 0-2.3-1-2.3-2.3 0-1.2.9-2.2 2.1-2.3V10c-2.4.2-4.3 2.2-4.3 4.6 0 2.5 2.1 4.6 4.6 4.6 2.5 0 4.6-2.1 4.6-4.6V9.4c1.1.8 2.5 1.2 3.9 1.2V8.4c-1 0-1.9-.4-2.8-1.2z"
      fill="#FE2C55"
      transform="translate(0.6, 0.4)"
      opacity="0.85"
    />
    {/* Main white note */}
    <path
      d="M16.6 8.2c-.8-.5-1.4-1.3-1.6-2.2H12.8v8.6c0 1.3-1 2.3-2.3 2.3-1.3 0-2.3-1-2.3-2.3 0-1.2.9-2.2 2.1-2.3V10c-2.4.2-4.3 2.2-4.3 4.6 0 2.5 2.1 4.6 4.6 4.6 2.5 0 4.6-2.1 4.6-4.6V9.4c1.1.8 2.5 1.2 3.9 1.2V8.4c-1 0-1.9-.4-2.8-1.2z"
      fill="#FFFFFF"
    />
  </svg>
);

export const FacebookIcon: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <circle cx="12" cy="12" r="11" fill="#1877F2" />
    <path
      d="M13.6 21.8v-7.6h2.6l.4-3h-3v-1.9c0-.9.2-1.5 1.5-1.5h1.6V5.1c-.3 0-1.3-.1-2.4-.1-2.4 0-4 1.5-4 4.1v2.1H8v3h2.3v7.6c1.1.2 2.2.2 3.3 0z"
      fill="#ffffff"
    />
  </svg>
);

export const WhatsAppIcon: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <circle cx="12" cy="12" r="11" fill="#25D366" />
    <path
      d="M17.2 14.5c-.3-.1-1.7-.8-1.9-.9-.3-.1-.5-.1-.7.1-.2.3-.8.9-.9 1.1-.2.2-.3.2-.6.1-.3-.1-1.2-.4-2.3-1.4-.8-.7-1.4-1.6-1.6-1.9-.2-.3 0-.4.1-.6.1-.1.3-.3.4-.5.1-.2.2-.3.3-.4.1-.2 0-.3 0-.5-.1-.1-.7-1.7-1-2.3-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1.1 1.1-1.1 2.6s1.1 3 1.3 3.2c.2.2 2.2 3.4 5.4 4.7.8.3 1.4.5 1.8.7.8.3 1.5.2 2.1.1.6-.1 1.7-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.1-.3-.2-.6-.3z"
      fill="#ffffff"
    />
  </svg>
);

export const YouTubeIcon: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <rect x="2" y="4" width="20" height="16" rx="4" fill="#FF0000" />
    <polygon points="10,8 16,12 10,16" fill="#ffffff" />
  </svg>
);
