import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Trophy,
  Shield,
  Waves,
  Dumbbell,
  Building2,
  Timer,
  Target,
  ArrowRight,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  X,
  Download
} from 'lucide-react';
import { useCmsSection, usePublishedCmsItems } from '../services/cmsDataService';
import { handleImageFallback } from '../utils/imageFallback';
import { downloadImageFile } from './ImageLightboxModal';

interface SportsPageProps {
  onOpenAdmissions?: () => void;
  onNavigateToJaguars?: () => void;
  onNavigateToAthletics?: () => void;
}

export const SportsPage: React.FC<SportsPageProps> = ({
  onNavigateToJaguars,
  onNavigateToAthletics,
}) => {
  const sports = useCmsSection('sports');
  const houses = useCmsSection('houses');
  const general = useCmsSection('general');
  const sportsItems = usePublishedCmsItems('sports');

  const [activeModalImage, setActiveModalImage] = useState<{ url: string; title: string; subtitle?: string } | null>(null);
  const [zoomScale, setZoomScale] = useState<number>(1);

  const isImageUrl = (url?: string) =>
    Boolean(
      url &&
        (/\.(png|jpe?g|webp|gif|svg)(\?|$)/i.test(url) ||
          url.startsWith('/uploads/') ||
          url.startsWith('./uploads/'))
    );

  const sportsPhotos = (sports.photos || []).filter(
    (p) =>
      Boolean(p.url && p.url.trim()) &&
      p.status !== 'unpublished' &&
      p.status !== 'archived'
  );

  return (
    <div className="bg-white min-h-screen text-[#0c1a40]">

      {/* Sports Hero in LKC Blue & Gold */}
      <section className="relative bg-[#0c1a40] text-white py-20 lg:py-24 px-4 sm:px-6 overflow-hidden border-b border-blue-900">
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="max-w-3xl space-y-4">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#081226] border border-blue-800 text-amber-400 text-xs font-mono uppercase tracking-widest"
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>{sports.name} · {general.address.city}, {general.address.country}</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold tracking-tight text-white leading-tight"
            >
              Inspiring Athletic Excellence, Vitality & Sportsmanship
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-blue-100 text-base sm:text-lg leading-relaxed font-sans"
            >
              {sports.intro}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="pt-2 flex flex-wrap items-center gap-3"
            >
              {onNavigateToJaguars && (
                <a
                  href="#jaguars"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigateToJaguars();
                  }}
                  className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2 cursor-pointer"
                >
                  <Shield className="w-4 h-4 text-[#081226]" />
                  <span>Explore The Jaguars Rugby Team ➔</span>
                </a>
              )}
              {onNavigateToAthletics && (
                <a
                  href="#athletics"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigateToAthletics();
                  }}
                  className="px-5 py-3 bg-white hover:bg-blue-50 text-[#0c1a40] font-bold text-xs rounded-xl shadow-sm transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Timer className="w-3.5 h-3.5 text-amber-600" />
                  <span>Track & Field Athletics Page ➔</span>
                </a>
              )}
              <a
                href="#house-trophy"
                className="px-5 py-3 bg-blue-900/70 hover:bg-blue-800 text-white font-medium text-xs rounded-xl border border-blue-700 transition flex items-center gap-1.5"
              >
                <Trophy className="w-3.5 h-3.5 text-amber-400" />
                <span>The Four College Houses</span>
              </a>
              <a
                href="#facilities"
                className="px-5 py-3 bg-white/10 hover:bg-white/20 text-white font-medium text-xs rounded-xl border border-white/20 transition"
              >
                Campus Facilities
              </a>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Feature Banner: The Standalone Jaguars Rugby Team */}
      <section className="bg-gradient-to-r from-[#081226] via-[#162a6b] to-[#081226] text-white py-10 px-4 sm:px-6 border-b border-amber-400/30">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center shrink-0 text-amber-300">
              <Shield className="w-7 h-7" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-amber-400 font-bold block">
                Flagship Varsity Team · Standalone Rugby Club
              </span>
              <h2 className="text-xl sm:text-2xl font-serif font-bold text-white mt-0.5">
                The Kolobeng Jaguars Rugby Team
              </h2>
              <p className="text-blue-100 text-xs sm:text-sm mt-1 max-w-xl">
                Jaguars Rugby stands on its own as LKC's celebrated 1st XV and junior squads — competing proudly in blue, gold, and white.
              </p>
            </div>
          </div>
          {onNavigateToJaguars && (
            <a
              href="#jaguars"
              onClick={(e) => {
                e.preventDefault();
                onNavigateToJaguars();
              }}
              className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs sm:text-sm rounded-xl shadow-lg transition flex items-center gap-2 whitespace-nowrap cursor-pointer shrink-0"
            >
              <span>View Jaguars Rugby Page</span>
              <ArrowRight className="w-4 h-4" />
            </a>
          )}
        </div>
      </section>

      {/* The Four Official College Houses (Equal Prominence, Official Colours Only) */}
      <section id="house-trophy" className="py-16 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold block mb-1">
            Collegial House System · Bathoen · Khama · Sechele · Moremi
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#0c1a40] tracking-tight">
            {sports.houseTrophyRace.trophyName || 'The Four Official College Houses'}
          </h2>
          <p className="text-blue-950 text-xs sm:text-sm mt-3 leading-relaxed">
            {sports.houseTrophyRace.description}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {houses.map((house) => {
            const hex = house.colorHex || house.color || '#0c1a40';
            const colorLabel = house.colorName || 'Official';
            return (
              <motion.div
                key={house.id || house.name}
                whileHover={{ y: -4 }}
                className="bg-white rounded-2xl border border-blue-200 shadow-xs hover:shadow-md overflow-hidden flex flex-col justify-between transition-all"
              >
                <div className="h-2.5 w-full" style={{ backgroundColor: hex }} />
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-4">
                      <span
                        className="inline-flex items-center gap-1.5 text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-md border"
                        style={{
                          backgroundColor: `${hex}15`,
                          borderColor: `${hex}55`,
                          color: '#0c1a40',
                        }}
                      >
                        <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: hex }} />
                        <span>{colorLabel} House</span>
                      </span>
                      {house.badgeUrl && (
                        <img
                          src={house.badgeUrl}
                          alt={`${house.name} emblem`}
                          loading="lazy"
                          onError={handleImageFallback}
                          className="w-9 h-9 rounded-lg object-cover border border-blue-200"
                        />
                      )}
                    </div>

                    {house.photoUrl && (
                      <div className="aspect-[16/9] rounded-xl overflow-hidden bg-blue-50 mb-3 border border-blue-100">
                        <img
                          src={house.photoUrl}
                          alt={house.name}
                          loading="lazy"
                          onError={handleImageFallback}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    <h3 className="font-serif font-bold text-xl text-[#0c1a40]">
                      {house.name}
                    </h3>
                  </div>

                  <div className="mt-4 pt-4 border-t border-blue-100 text-xs space-y-2 text-blue-950">
                    <div className="flex items-center justify-between">
                      <span className="text-blue-800">Patron:</span>
                      <span className="font-semibold text-[#0c1a40]">{house.patron}</span>
                    </div>
                    <p className="text-[11px] leading-relaxed text-blue-900 pt-2 border-t border-blue-100">
                      {house.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Campus Athletic Facilities */}
      <section id="facilities" className="py-16 px-4 sm:px-6 bg-blue-50/50 border-y border-blue-100">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mb-12">
            <span className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold block mb-1">
              State-of-the-Art Infrastructure
            </span>
            <h2 className="text-3xl font-serif font-bold text-[#0c1a40] tracking-tight">
              Sporting Facilities in {general.address.area}
            </h2>
            <p className="text-blue-950 text-xs sm:text-sm mt-2 leading-relaxed">
              The LKC campus features a swimming pool, fully equipped gymnasium, 1,000-seat hall, regulation rugby turf, and running track.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sports.facilities.map((fac, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -4 }}
                className="bg-white p-6 rounded-2xl border border-blue-200 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="w-11 h-11 rounded-xl bg-blue-50 text-[#0c1a40] border border-blue-200 flex items-center justify-center mb-4">
                    {fac.icon === 'Waves' && <Waves className="w-5 h-5 text-[#162a6b]" />}
                    {fac.icon === 'Dumbbell' && <Dumbbell className="w-5 h-5 text-amber-600" />}
                    {fac.icon === 'Building' && <Building2 className="w-5 h-5 text-[#0c1a40]" />}
                    {fac.icon === 'Shield' && <Shield className="w-5 h-5 text-[#0c1a40]" />}
                    {fac.icon === 'Timer' && <Timer className="w-5 h-5 text-amber-600" />}
                    {fac.icon === 'Target' && <Target className="w-5 h-5 text-[#162a6b]" />}
                  </div>
                  <h3 className="font-serif font-bold text-lg text-[#0c1a40] mb-2">
                    {fac.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-blue-950 leading-relaxed">
                    {fac.description}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-blue-100 flex items-center justify-between text-[11px] text-blue-800">
                  <span>{general.address.area} Campus</span>
                  <span className="font-semibold text-[#0c1a40]">Active Daily</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Varsity Sporting Codes */}
      <section className="py-16 px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold block mb-1">
            Competitive Pathways
          </span>
          <h2 className="text-3xl font-serif font-bold text-[#0c1a40]">
            LKC Varsity Sporting Codes
          </h2>
          <p className="text-blue-950 text-xs sm:text-sm mt-2">
            Sanctioned under Cambridge co-curricular standards and inter-school athletic championships.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sports.codes.map((code, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-2xl border border-blue-200 shadow-xs hover:border-amber-400 transition-colors flex flex-col justify-between"
            >
              <div>
                <span className="text-[10px] font-mono font-bold text-amber-700 uppercase tracking-wider block mb-1">
                  {code.season}
                </span>
                <h3 className="font-serif font-bold text-lg text-[#0c1a40] mb-1">
                  {code.name}
                </h3>
                <div className="text-xs text-blue-800 mb-3 font-medium">
                  {code.division}
                </div>
                <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-100 text-xs text-blue-950">
                  <span className="font-semibold text-[#0c1a40] block mb-0.5">Accolades:</span>
                  <span>{code.accolades}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Visual Photo Gallery */}
      <section className="py-16 px-4 sm:px-6 bg-blue-50/40 border-t border-blue-100">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-amber-700 font-bold block mb-1">
                Campus Action
              </span>
              <h2 className="text-3xl font-serif font-bold text-[#0c1a40]">
                LKC Sports In Action
              </h2>
            </div>
            {(sportsPhotos.length > 0 || sportsItems.length > 0) && (
              <span className="text-xs text-blue-800">Click any image to inspect details</span>
            )}
          </div>

          {sportsPhotos.length === 0 && sportsItems.length === 0 ? (
            <div className="p-10 rounded-2xl bg-white border border-blue-200 text-center space-y-2">
              <Trophy className="w-8 h-8 text-amber-600 mx-auto" />
              <h3 className="font-serif font-bold text-lg text-[#0c1a40]">
                LKC Sports Photography Gallery
              </h3>
              <p className="text-xs sm:text-sm text-blue-900/80 max-w-xl mx-auto leading-relaxed">
                Official campus sports, swimming, court, and championship photos uploaded via the College CMS appear here automatically once published.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {sportsPhotos.map((photo, i) => (
                <motion.div
                  key={`${i}-${photo.url}`}
                  whileHover={{ y: -4 }}
                  onClick={() =>
                    setActiveModalImage({
                      url: photo.url,
                      title: photo.title,
                      subtitle: photo.location || photo.category,
                    })
                  }
                  className="bg-white rounded-2xl overflow-hidden border border-blue-200 shadow-xs cursor-pointer group flex flex-col"
                >
                  <div className="relative aspect-[4/3] overflow-hidden bg-[#081226]">
                    <img
                      src={photo.url}
                      alt={photo.title}
                      loading="lazy"
                      onError={handleImageFallback}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-[#0c1a40]/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <span className="flex items-center gap-1.5 text-xs text-white bg-[#081226] px-3 py-1.5 rounded-md font-medium border border-amber-400/50">
                        <ZoomIn className="w-3.5 h-3.5 text-amber-400" />
                        <span>Inspect Photo</span>
                      </span>
                    </div>
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] font-mono font-bold text-amber-700 uppercase">
                        {photo.category}
                      </span>
                      <h3 className="font-serif font-bold text-sm text-[#0c1a40] mt-1">
                        {photo.title}
                      </h3>
                      <p className="text-xs text-blue-900 mt-1 line-clamp-2">
                        {photo.caption}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}

              {sportsItems.map((item) => {
                const imgUrl =
                  item.thumbnailUrl || (isImageUrl(item.mediaUrl) ? item.mediaUrl : undefined);
                return (
                  <motion.div
                    key={item.id}
                    whileHover={{ y: -4 }}
                    onClick={() =>
                      imgUrl &&
                      setActiveModalImage({
                        url: imgUrl,
                        title: item.title,
                        subtitle: item.category,
                      })
                    }
                    className={`bg-white rounded-2xl overflow-hidden border border-blue-200 shadow-xs flex flex-col ${
                      imgUrl ? 'cursor-pointer group' : ''
                    }`}
                  >
                    {imgUrl && (
                      <div className="relative aspect-[4/3] overflow-hidden bg-[#081226]">
                        <img
                          src={imgUrl}
                          alt={item.title}
                          loading="lazy"
                          onError={handleImageFallback}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    )}
                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] font-mono font-bold text-amber-700 uppercase">
                          {item.category}
                        </span>
                        <h3 className="font-serif font-bold text-sm text-[#0c1a40] mt-1">
                          {item.title}
                        </h3>
                        <p className="text-xs text-blue-900 mt-1 line-clamp-2">
                          {item.excerpt}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Interactive Lightbox */}
      <AnimatePresence>
        {activeModalImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              setActiveModalImage(null);
              setZoomScale(1);
            }}
            className="fixed inset-0 z-50 bg-[#081226]/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#0c1a40] border border-blue-800 rounded-2xl max-w-[96vw] sm:max-w-[94vw] w-full overflow-hidden shadow-2xl flex flex-col h-[94vh] max-h-[94vh]"
            >
              <div className="px-5 py-3.5 bg-[#081226] border-b border-blue-900 flex items-center justify-between text-white">
                <div>
                  <h3 className="font-serif font-bold text-sm sm:text-base text-white">
                    {activeModalImage.title}
                  </h3>
                  {activeModalImage.subtitle && (
                    <p className="text-xs text-amber-400">{activeModalImage.subtitle}</p>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-blue-950 rounded-lg border border-blue-800 px-1 py-0.5 text-xs text-blue-100">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setZoomScale((prev) => Math.max(prev - 0.25, 0.5));
                        }}
                        className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                        title="Zoom Out"
                      >
                        <ZoomOut className="w-4 h-4" />
                      </button>
                      <span className="px-1.5 font-mono text-[11px] text-amber-400">
                        {Math.round(zoomScale * 100)}%
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setZoomScale((prev) => Math.min(prev + 0.25, 4));
                        }}
                        className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer"
                        title="Zoom In"
                      >
                        <ZoomIn className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setZoomScale(1);
                        }}
                        className="p-1 text-blue-100 hover:text-white hover:bg-blue-900 rounded cursor-pointer ml-1"
                        title="Reset Zoom"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        downloadImageFile(activeModalImage.url, activeModalImage.title);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                      title="Download Image"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Download</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveModalImage(null);
                        setZoomScale(1);
                      }}
                      className="p-1.5 rounded-lg bg-blue-900/60 hover:bg-blue-800 text-white transition-colors cursor-pointer"
                      aria-label="Close image preview"
                    >
                      <X className="w-5 h-5" />
                    </button>
                </div>
              </div>

              <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-[#081226] min-h-[64vh]">
                <div
                  className="transition-transform duration-200 origin-center flex items-center justify-center"
                  style={{ transform: `scale(${zoomScale})` }}
                >
                  <img
                    src={activeModalImage.url}
                    alt={activeModalImage.title}
                    onError={handleImageFallback}
                    className="h-[74vh] sm:h-[78vh] w-auto max-w-[90vw] object-contain rounded-xl shadow-2xl"
                  />
                </div>
              </div>

              <div className="px-5 py-2.5 bg-[#081226] border-t border-blue-900 flex items-center justify-between text-xs text-blue-200">
                <span>{general.name} · Sports Directorate</span>
                <span className="text-amber-400 font-mono text-[11px]">Use +/- buttons above to inspect details</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};
