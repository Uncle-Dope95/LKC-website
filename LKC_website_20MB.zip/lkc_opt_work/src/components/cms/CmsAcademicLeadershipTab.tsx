import React, { useEffect, useMemo, useState } from 'react';
import {
  Users,
  Plus,
  Edit3,
  Trash2,
  Eye,
  EyeOff,
  Archive,
  CheckCircle2,
  AlertTriangle,
  Search,
  Award,
  HeartHandshake,
  GraduationCap,
  X,
  RotateCcw,
} from 'lucide-react';
import {
  createAcademicAssignment,
  createStaffMember,
  deleteAcademicAssignmentById,
  deleteStaffMemberById,
  fetchAdminAcademicLeadership,
  updateAcademicAssignment,
  updateAcademicAssignmentStatus,
  updateSectionData,
  updateStaffMember,
  useAcademicLeadership,
  useCmsSection,
  type ApiError,
} from '../../services/cmsDataService';
import type {
  AcademicAssignment,
  AcademicAssignmentType,
  CmsUser,
  PublishStatus,
  StaffMember,
  YearGroupKey,
} from '../../types';
import { PhotoUploadField } from './PhotoUploadField';
import { CmsConfirmModal } from './CmsConfirmModal';
import { matchesSearchTokens } from '../../utils/profileSearch';
import {
  assignPortraitToUnifiedProfile,
  buildUnifiedProfileDirectory,
  type UnifiedProfileEntry,
  type UnifiedProfileKind,
} from '../../utils/profileDirectory';
import { openImageViewer } from '../ImageLightboxModal';

interface CmsAcademicLeadershipTabProps {
  currentUser: CmsUser;
  onNotify: (msg: string) => void;
  onRefreshSections?: () => Promise<void>;
}

const YEAR_GROUPS: YearGroupKey[] = [
  'Form 1',
  'Form 2',
  'Form 3',
  'Form 4',
  'Form 5',
  'A Level',
];

const ASSIGNMENT_TYPE_LABELS: Record<AcademicAssignmentType, string> = {
  head_of_year: 'Head of Year',
  a_level_coordinator: 'A-Level Coordinator',
  pastoral_care: 'Pastoral Care, Guidance & Counselling',
};

const STAFF_PER_PAGE = 12;

export const CmsAcademicLeadershipTab: React.FC<CmsAcademicLeadershipTabProps> = ({
  currentUser,
  onNotify,
  onRefreshSections,
}) => {
  const bundle = useAcademicLeadership();
  const teachers = useCmsSection('teachers');
  const departments = useCmsSection('departments');
  const about = useCmsSection('about');
  const boarding = useCmsSection('boarding');

  const isPublisher = currentUser.role === 'super_admin' || currentUser.role === 'admin';

  const [subView, setSubView] = useState<'assignments' | 'staff'>('assignments');
  const [typeFilter, setTypeFilter] = useState<'all' | AcademicAssignmentType>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | PublishStatus>('all');
  const [assignmentSearch, setAssignmentSearch] = useState('');

  const [staffSearch, setStaffSearch] = useState('');
  const [profileKindFilter, setProfileKindFilter] = useState<'all' | UnifiedProfileKind>('all');
  const [incompleteOnly, setIncompleteOnly] = useState(false);
  const [staffPage, setStaffPage] = useState(1);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [deleteAssignmentTarget, setDeleteAssignmentTarget] =
    useState<AcademicAssignment | null>(null);
  const [forceDeleteStaffTarget, setForceDeleteStaffTarget] = useState<{
    staff: StaffMember;
    assignmentCount: number;
  } | null>(null);

  // Create / Edit Assignment Modal State
  const [assignmentModalOpen, setAssignmentModalOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState<AcademicAssignment | null>(null);
  const [assignForm, setAssignForm] = useState<{
    staffId: string;
    assignmentType: AcademicAssignmentType;
    roleTitle: string;
    yearGroup: YearGroupKey | '';
    summary: string;
    responsibilities: string;
    welcomeMessage: string;
    status: PublishStatus;
    sortOrder: number;
  }>({
    staffId: '',
    assignmentType: 'head_of_year',
    roleTitle: 'Head of Year',
    yearGroup: 'Form 1',
    summary: '',
    responsibilities: '',
    welcomeMessage: '',
    status: 'published',
    sortOrder: 10,
  });

  // Preview Profile Modal State
  const [previewAssignment, setPreviewAssignment] = useState<AcademicAssignment | null>(null);

  // Create / Edit Relational Staff Profile Modal State
  const [staffModalOpen, setStaffModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [staffForm, setStaffForm] = useState<{
    surname: string;
    fullName: string;
    displayTitle: string;
    department: string;
    subjectsText: string;
    qualifications: string;
    bio: string;
    image: string;
    status: PublishStatus;
    sortOrder: number;
  }>({
    surname: '',
    fullName: '',
    displayTitle: '',
    department: '',
    subjectsText: '',
    qualifications: '',
    bio: '',
    image: '',
    status: 'published',
    sortOrder: 50,
  });

  // Unified Profile (Teacher / HOD / SMT / Director / Boarding) Portrait & Quick-Edit Modal
  const [editingUnified, setEditingUnified] = useState<UnifiedProfileEntry | null>(null);
  const [unifiedForm, setUnifiedForm] = useState<{
    name: string;
    role: string;
    qualifications: string;
    bio: string;
    image: string;
    status: PublishStatus;
  }>({
    name: '',
    role: '',
    qualifications: '',
    bio: '',
    image: '',
    status: 'published',
  });
  const [savingUnified, setSavingUnified] = useState(false);

  const reload = async () => {
    setLoading(true);
    setError(null);
    try {
      await fetchAdminAcademicLeadership();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load academic leadership records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void reload();
  }, []);

  const allProfiles = useMemo(
    () =>
      buildUnifiedProfileDirectory({
        academicLeadership: bundle,
        teachers,
        departments,
        about,
        boarding,
      }),
    [bundle, teachers, departments, about, boarding]
  );

  const assignableTeacherOptions = useMemo(() => {
    const existingNames = new Set(
      bundle.staffMembers.map((s) => s.fullName.trim().toLowerCase())
    );
    return teachers.filter(
      (t) =>
        t.status !== 'archived' &&
        !existingNames.has(t.name.trim().toLowerCase())
    );
  }, [bundle.staffMembers, teachers]);

  const openNewAssignmentModal = (
    presetType: AcademicAssignmentType = 'head_of_year',
    presetYear: YearGroupKey = 'Form 1'
  ) => {
    setEditingAssignment(null);
    setAssignForm({
      staffId: bundle.staffMembers[0]?.id || '',
      assignmentType: presetType,
      roleTitle: ASSIGNMENT_TYPE_LABELS[presetType],
      yearGroup: presetType === 'head_of_year' ? presetYear : 'A Level',
      summary: '',
      responsibilities: '',
      welcomeMessage: '',
      status: isPublisher ? 'published' : 'draft',
      sortOrder: (bundle.assignments.length + 1) * 10,
    });
    setAssignmentModalOpen(true);
  };

  const openEditAssignmentModal = (assignment: AcademicAssignment) => {
    setEditingAssignment(assignment);
    setAssignForm({
      staffId: assignment.staffId,
      assignmentType: assignment.assignmentType,
      roleTitle: assignment.roleTitle,
      yearGroup: assignment.yearGroup || 'Form 1',
      summary: assignment.summary || '',
      responsibilities: assignment.responsibilities || '',
      welcomeMessage: assignment.welcomeMessage || '',
      status: assignment.status,
      sortOrder: assignment.sortOrder,
    });
    setAssignmentModalOpen(true);
  };

  const handleSaveAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      let resolvedStaffId = assignForm.staffId;
      if (resolvedStaffId.startsWith('teacher-import:')) {
        const teacherId = resolvedStaffId.replace('teacher-import:', '');
        const teacher = teachers.find((t) => t.id === teacherId);
        if (!teacher) {
          throw new Error('Selected faculty teacher could not be found.');
        }
        const nameParts = teacher.name
          .replace(/^(Mr|Mrs|Ms|Miss|Dr|Prof)\.?\s+/i, '')
          .trim()
          .split(/\s+/);
        const surname = nameParts[nameParts.length - 1] || teacher.name;
        const createdStaff = await createStaffMember({
          surname,
          fullName: teacher.name,
          displayTitle: teacher.role || 'Subject Teacher',
          department: teacher.departmentName,
          subjects: teacher.subjects || [],
          qualifications: teacher.qualifications,
          bio: teacher.bio,
          image: teacher.image || null,
          status: 'published',
          sortOrder: (bundle.staffMembers.length + 1) * 10,
        });
        resolvedStaffId = createdStaff.id;
      }

      const payload = {
        staffId: resolvedStaffId,
        assignmentType: assignForm.assignmentType,
        roleTitle: assignForm.roleTitle.trim(),
        yearGroup:
          assignForm.assignmentType === 'head_of_year'
            ? (assignForm.yearGroup as YearGroupKey)
            : assignForm.yearGroup
            ? (assignForm.yearGroup as YearGroupKey)
            : 'A Level',
        summary: assignForm.summary.trim() || undefined,
        responsibilities: assignForm.responsibilities.trim() || undefined,
        welcomeMessage: assignForm.welcomeMessage.trim() || undefined,
        status: assignForm.status,
        sortOrder: Number(assignForm.sortOrder) || 0,
      };
      if (editingAssignment) {
        await updateAcademicAssignment(editingAssignment.id, payload);
        onNotify('Updated academic leadership assignment in SQLite.');
      } else {
        await createAcademicAssignment(payload);
        onNotify('Created new academic leadership assignment.');
      }
      setAssignmentModalOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save assignment.');
    }
  };

  const handleAssignmentStatus = async (a: AcademicAssignment, status: PublishStatus) => {
    setError(null);
    try {
      await updateAcademicAssignmentStatus(a.id, status);
      onNotify(`Assignment '${a.roleTitle}' marked '${status}'.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update assignment status.');
    }
  };

  const confirmDeleteAssignment = async () => {
    if (!deleteAssignmentTarget) return;
    setError(null);
    try {
      await deleteAcademicAssignmentById(deleteAssignmentTarget.id);
      onNotify('Academic assignment removed.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete assignment.');
    } finally {
      setDeleteAssignmentTarget(null);
    }
  };

  const openNewStaffModal = () => {
    setEditingStaff(null);
    setStaffForm({
      surname: '',
      fullName: '',
      displayTitle: '',
      department: '',
      subjectsText: '',
      qualifications: '',
      bio: '',
      image: '',
      status: 'published',
      sortOrder: (bundle.staffMembers.length + 1) * 10,
    });
    setStaffModalOpen(true);
  };

  const openEditStaffModal = (s: StaffMember) => {
    setEditingStaff(s);
    setStaffForm({
      surname: s.surname,
      fullName: s.fullName,
      displayTitle: s.displayTitle || '',
      department: s.department || '',
      subjectsText: (s.subjects || []).join(', '),
      qualifications: s.qualifications || '',
      bio: s.bio || '',
      image: s.image || '',
      status: s.status,
      sortOrder: s.sortOrder,
    });
    setStaffModalOpen(true);
  };

  const openUnifiedProfileEditor = (entry: UnifiedProfileEntry) => {
    if (entry.kind === 'staff_member' && entry.rawStaff) {
      openEditStaffModal(entry.rawStaff);
      return;
    }
    setEditingUnified(entry);
    setUnifiedForm({
      name: entry.name,
      role: entry.role,
      qualifications:
        entry.rawTeacher?.qualifications ||
        entry.rawDept?.headOfDepartment?.qualifications ||
        entry.rawLeader?.qualifications ||
        '',
      bio:
        entry.rawTeacher?.bio ||
        entry.rawDept?.headOfDepartment?.bio ||
        entry.rawLeader?.bio ||
        entry.rawHostel?.quote ||
        '',
      image: entry.image,
      status: entry.status,
    });
  };

  const handleSaveUnifiedProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUnified) return;
    setSavingUnified(true);
    setError(null);
    try {
      const cleanName = unifiedForm.name.trim();
      const cleanRole = unifiedForm.role.trim();
      const cleanQuals = unifiedForm.qualifications.trim();
      const cleanBio = unifiedForm.bio.trim();
      const cleanImage = unifiedForm.image.trim();

      if (editingUnified.kind === 'teacher' && editingUnified.rawTeacher) {
        const nextTeachers = teachers.map((t) =>
          t.id === editingUnified.sourceId
            ? {
                ...t,
                name: cleanName || t.name,
                role: cleanRole || t.role,
                qualifications: cleanQuals || undefined,
                bio: cleanBio,
                image: cleanImage || undefined,
                status: unifiedForm.status,
              }
            : t
        );
        await updateSectionData('teachers', nextTeachers);
        await assignPortraitToUnifiedProfile(editingUnified, cleanImage || null);
      } else if (editingUnified.kind === 'hod' && editingUnified.rawDept) {
        const nextDepts = departments.map((d) =>
          d.id === editingUnified.sourceId
            ? {
                ...d,
                headOfDepartment: {
                  ...d.headOfDepartment,
                  name: cleanName || d.headOfDepartment.name,
                  title: cleanRole || d.headOfDepartment.title,
                  qualifications: cleanQuals || undefined,
                  bio: cleanBio || undefined,
                  image: cleanImage || undefined,
                  status: unifiedForm.status,
                },
              }
            : d
        );
        await updateSectionData('departments', nextDepts);
        await assignPortraitToUnifiedProfile(editingUnified, cleanImage || null);
      } else if (editingUnified.kind === 'smt') {
        const nextLeadership = (about.leadership || []).map((l) =>
          (l.id || l.name) === editingUnified.sourceId
            ? {
                ...l,
                name: cleanName || l.name,
                role: cleanRole || l.role,
                title: cleanRole || l.title,
                qualifications: cleanQuals || undefined,
                bio: cleanBio,
                image: cleanImage || undefined,
                status: unifiedForm.status,
              }
            : l
        );
        await updateSectionData('about', { ...about, leadership: nextLeadership });
      } else if (editingUnified.kind === 'director') {
        const nextDirectors = (about.directors || []).map((d) =>
          (d.id || d.name) === editingUnified.sourceId
            ? {
                ...d,
                name: cleanName || d.name,
                role: cleanRole || d.role,
                title: cleanRole || d.title,
                qualifications: cleanQuals || undefined,
                bio: cleanBio,
                image: cleanImage || undefined,
                status: unifiedForm.status,
              }
            : d
        );
        await updateSectionData('about', { ...about, directors: nextDirectors });
      } else if (editingUnified.kind === 'boarding') {
        const nextHostels = (boarding.hostels || []).map((h) =>
          h.id === editingUnified.sourceId
            ? {
                ...h,
                leaderName: cleanName || h.leaderName,
                leaderRole: cleanRole || h.leaderRole,
                leaderImage: cleanImage || undefined,
                quote: cleanBio || h.quote,
              }
            : h
        );
        await updateSectionData('boarding', { ...boarding, hostels: nextHostels });
      }

      onNotify(`Saved profile & portrait changes for ${cleanName || editingUnified.name}.`);
      setEditingUnified(null);
      if (onRefreshSections) {
        await onRefreshSections();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save profile changes.');
    } finally {
      setSavingUnified(false);
    }
  };

  const handleSaveStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const payload = {
        surname: staffForm.surname.trim(),
        fullName: staffForm.fullName.trim(),
        displayTitle: staffForm.displayTitle.trim() || undefined,
        department: staffForm.department.trim() || undefined,
        subjects: staffForm.subjectsText
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
        qualifications: staffForm.qualifications.trim() || undefined,
        bio: staffForm.bio.trim() || undefined,
        image: staffForm.image.trim() || null,
        status: staffForm.status,
        sortOrder: Number(staffForm.sortOrder) || 0,
      };
      if (editingStaff) {
        await updateStaffMember(editingStaff.id, payload);
        onNotify(`Updated staff profile for ${payload.fullName}.`);
      } else {
        await createStaffMember(payload);
        onNotify(`Added staff profile for ${payload.fullName}.`);
      }
      setStaffModalOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save staff profile.');
    }
  };

  const handleDeleteStaff = async (s: StaffMember) => {
    setError(null);
    try {
      await deleteStaffMemberById(s.id, false);
      onNotify(`Removed staff profile '${s.fullName}'.`);
    } catch (err) {
      const apiErr = err as ApiError;
      if (apiErr.status === 409 && apiErr.assignmentCount) {
        setForceDeleteStaffTarget({ staff: s, assignmentCount: apiErr.assignmentCount });
        return;
      }
      setError(err instanceof Error ? err.message : 'Failed to delete staff profile.');
    }
  };

  const confirmForceDeleteStaff = async () => {
    if (!forceDeleteStaffTarget) return;
    const target = forceDeleteStaffTarget.staff;
    setError(null);
    try {
      await deleteStaffMemberById(target.id, true);
      onNotify(`Removed '${target.fullName}' and linked assignments.`);
    } catch (innerErr) {
      setError(innerErr instanceof Error ? innerErr.message : 'Failed to force-delete staff.');
    } finally {
      setForceDeleteStaffTarget(null);
    }
  };

  const filteredAssignments = bundle.assignments.filter((a) => {
    if (typeFilter !== 'all' && a.assignmentType !== typeFilter) return false;
    if (statusFilter !== 'all' && a.status !== statusFilter) return false;
    if (assignmentSearch.trim()) {
      return matchesSearchTokens(assignmentSearch, [
        a.staff?.fullName,
        a.staff?.surname,
        a.staff?.department,
        a.roleTitle,
        a.yearGroup,
        a.summary,
      ]);
    }
    return true;
  });

  const filteredProfiles = allProfiles.filter((entry) => {
    if (profileKindFilter !== 'all' && entry.kind !== profileKindFilter) return false;
    if (incompleteOnly && !entry.missingPortrait) return false;
    return matchesSearchTokens(staffSearch, [
      entry.name,
      entry.surname,
      entry.role,
      entry.department,
      entry.kindLabel,
      ...entry.searchFields,
    ]);
  });

  const totalStaffPages = Math.max(1, Math.ceil(filteredProfiles.length / STAFF_PER_PAGE));
  const safeStaffPage = Math.min(staffPage, totalStaffPages);
  const pagedProfiles = filteredProfiles.slice(
    (safeStaffPage - 1) * STAFF_PER_PAGE,
    safeStaffPage * STAFF_PER_PAGE
  );

  const incompleteCount = allProfiles.filter((entry) => entry.missingPortrait).length;

  return (
    <div className="space-y-6 text-[15px] text-[#0c1a40]">
      {/* Header & Sub-View Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h3 className="font-serif font-bold text-2xl flex items-center gap-2.5 text-[#0c1a40]">
            <GraduationCap className="w-6 h-6 text-amber-600" />
            <span>Heads of Year, A-Level Coordinator, Pastoral Care & Staff</span>
          </h3>
          <p className="text-[15px] text-slate-600 mt-1">
            Assign Heads of Year, search any staff, teacher, HOD, SMT, Director, or Boarding profile, and upload or assign portraits.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setSubView('assignments')}
            className={`px-4 py-2.5 rounded-xl text-[15px] font-bold cursor-pointer tabular-nums ${
              subView === 'assignments'
                ? 'bg-[#0c1a40] text-white'
                : 'bg-slate-100 hover:bg-slate-200 text-[#0c1a40]'
            }`}
          >
            Role Assignments ({bundle.assignments.length})
          </button>
          <button
            type="button"
            onClick={() => setSubView('staff')}
            className={`px-4 py-2.5 rounded-xl text-[15px] font-bold cursor-pointer flex items-center gap-2 tabular-nums ${
              subView === 'staff'
                ? 'bg-[#0c1a40] text-white'
                : 'bg-slate-100 hover:bg-slate-200 text-[#0c1a40]'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Staff Profiles ({allProfiles.length})</span>
            {incompleteCount > 0 && (
              <span className="text-amber-500 font-semibold">· {incompleteCount} Missing Photo</span>
            )}
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-[15px] text-red-800">
          {error}
        </div>
      )}

      {loading && bundle.assignments.length === 0 && (
        <div className="py-8 text-center text-[15px] text-slate-600">
          Syncing academic & pastoral leadership from SQLite...
        </div>
      )}

      {/* SUB-VIEW 1: ACADEMIC & PASTORAL ASSIGNMENTS */}
      {subView === 'assignments' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1">
              <div className="relative min-w-[220px] flex-1 max-w-xs">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={assignmentSearch}
                  onChange={(e) => setAssignmentSearch(e.target.value)}
                  placeholder="Search assignments by name, role or year..."
                  className="w-full pl-10 pr-8 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px]"
                />
                {assignmentSearch && (
                  <button
                    type="button"
                    onClick={() => setAssignmentSearch('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0c1a40] cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value as 'all' | AcademicAssignmentType)}
                className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px] font-semibold"
              >
                <option value="all">All Role Types ({bundle.assignments.length})</option>
                <option value="head_of_year">Heads of Year</option>
                <option value="a_level_coordinator">A-Level Coordinator</option>
                <option value="pastoral_care">Pastoral Care & Counselling</option>
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as 'all' | PublishStatus)}
                className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px] font-semibold"
              >
                <option value="all">All Statuses</option>
                <option value="published">Published</option>
                <option value="unpublished">Unpublished</option>
                <option value="draft">Draft</option>
                <option value="archived">Archived</option>
              </select>
            </div>

            <button
              type="button"
              onClick={() => openNewAssignmentModal('head_of_year', 'Form 1')}
              className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4 text-amber-400" />
              <span>Assign Head of Year / Role</span>
            </button>
          </div>

          {/* Assignment Cards */}
          <div className="space-y-3">
            {filteredAssignments.length === 0 ? (
              <div className="p-8 rounded-xl bg-slate-50 border border-slate-200 text-center text-[15px] text-slate-600 space-y-2">
                <p>No academic leadership assignments match the current filter.</p>
                {(assignmentSearch || typeFilter !== 'all' || statusFilter !== 'all') && (
                  <button
                    type="button"
                    onClick={() => {
                      setAssignmentSearch('');
                      setTypeFilter('all');
                      setStatusFilter('all');
                    }}
                    className="px-4 py-2 rounded-lg bg-[#0c1a40] text-white text-sm font-semibold cursor-pointer"
                  >
                    Reset Filters
                  </button>
                )}
              </div>
            ) : (
              filteredAssignments.map((a) => {
                const staff = a.staff;
                return (
                  <div
                    key={a.id}
                    className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-4 min-w-0">
                      {staff?.image ? (
                        <img
                          src={staff.image}
                          alt={staff.fullName}
                          onClick={() =>
                            openImageViewer({
                              src: staff.image!,
                              title: staff.fullName,
                              subtitle: a.roleTitle,
                            })
                          }
                          className="w-16 h-16 rounded-xl object-cover object-top border border-amber-400 shrink-0 cursor-zoom-in"
                        />
                      ) : (
                        <div className="w-16 h-16 rounded-xl bg-slate-100 border border-slate-200 flex flex-col items-center justify-center shrink-0 text-center px-1">
                          <span className="font-serif font-bold text-base text-[#0c1a40]">
                            {(staff?.surname || '?').slice(0, 2).toUpperCase()}
                          </span>
                          <span className="text-sm text-amber-700 font-medium leading-none mt-0.5">
                            No Photo
                          </span>
                        </div>
                      )}

                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2 text-sm text-slate-600 mb-1">
                          <span className="font-semibold text-[#0c1a40]">
                            {ASSIGNMENT_TYPE_LABELS[a.assignmentType]}
                          </span>
                          {a.yearGroup && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="font-semibold text-amber-700">{a.yearGroup}</span>
                            </>
                          )}
                          <span aria-hidden="true">·</span>
                          <span
                            className={`font-semibold capitalize ${
                              a.status === 'published'
                                ? 'text-emerald-700'
                                : a.status === 'archived'
                                ? 'text-slate-500'
                                : 'text-amber-700'
                            }`}
                          >
                            {a.status}
                          </span>
                          {staff?.isIncomplete && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-amber-700 font-semibold inline-flex items-center gap-1">
                                <AlertTriangle className="w-3.5 h-3.5" /> Portrait Pending
                              </span>
                            </>
                          )}
                        </div>

                        <div className="font-serif font-bold text-lg text-[#0c1a40]">
                          {staff?.fullName || 'Unassigned Staff'}
                        </div>
                        <div className="text-[15px] font-semibold text-slate-700">
                          {a.roleTitle}
                          {a.yearGroup && a.assignmentType === 'head_of_year' ? ` — ${a.yearGroup}` : ''}
                        </div>
                        {a.summary && (
                          <p className="text-sm text-slate-600 mt-1 line-clamp-2">{a.summary}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setPreviewAssignment(a)}
                        className="px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Eye className="w-4 h-4" /> Preview
                      </button>

                      <button
                        type="button"
                        onClick={() => openEditAssignmentModal(a)}
                        className="px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Edit3 className="w-4 h-4" /> Edit / Reassign
                      </button>

                      {isPublisher && (
                        <>
                          {a.status !== 'published' ? (
                            <button
                              type="button"
                              onClick={() => void handleAssignmentStatus(a, 'published')}
                              className="px-3.5 py-2 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                            >
                              {a.status === 'archived' ? (
                                <>
                                  <RotateCcw className="w-4 h-4 text-amber-400" /> Restore & Publish
                                </>
                              ) : (
                                <>
                                  <CheckCircle2 className="w-4 h-4 text-amber-400" /> Publish
                                </>
                              )}
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => void handleAssignmentStatus(a, 'unpublished')}
                              className="px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                            >
                              <EyeOff className="w-4 h-4" /> Unpublish
                            </button>
                          )}

                          {a.status !== 'archived' && (
                            <button
                              type="button"
                              onClick={() => void handleAssignmentStatus(a, 'archived')}
                              className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                              title="Archive assignment"
                            >
                              <Archive className="w-4 h-4" />
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => setDeleteAssignmentTarget(a)}
                            className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                            title="Delete assignment"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: UNIFIED STAFF PROFILES & PORTRAITS DIRECTORY */}
      {subView === 'staff' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1">
              <div className="relative min-w-[240px] flex-1 max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={staffSearch}
                  onChange={(e) => {
                    setStaffSearch(e.target.value);
                    setStaffPage(1);
                  }}
                  placeholder="Search any staff, teacher, HOD, SMT or boarding..."
                  className="w-full pl-10 pr-8 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px]"
                />
                {staffSearch && (
                  <button
                    type="button"
                    onClick={() => {
                      setStaffSearch('');
                      setStaffPage(1);
                    }}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0c1a40] cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              <select
                value={profileKindFilter}
                onChange={(e) => {
                  setProfileKindFilter(e.target.value as 'all' | UnifiedProfileKind);
                  setStaffPage(1);
                }}
                className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px] font-semibold"
              >
                <option value="all">All Profiles ({allProfiles.length})</option>
                <option value="teacher">Teachers ({teachers.length})</option>
                <option value="hod">Heads of Department ({departments.length})</option>
                <option value="smt">SMT Leaders ({about.leadership?.length || 0})</option>
                <option value="director">College Directors ({about.directors?.length || 0})</option>
                <option value="staff_member">Year-Group / Pastoral ({bundle.staffMembers.length})</option>
                <option value="boarding">Boarding Staff ({boarding.hostels?.length || 0})</option>
              </select>

              <label className="flex items-center gap-2 font-semibold text-sm cursor-pointer px-3.5 py-2.5 rounded-xl bg-amber-50 border border-amber-200">
                <input
                  type="checkbox"
                  className="w-4 h-4 accent-[#0c1a40]"
                  checked={incompleteOnly}
                  onChange={(e) => {
                    setIncompleteOnly(e.target.checked);
                    setStaffPage(1);
                  }}
                />
                <span className="tabular-nums">
                  Missing Portrait Only ({incompleteCount})
                </span>
              </label>
            </div>

            <button
              type="button"
              onClick={openNewStaffModal}
              className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4 text-amber-400" />
              <span>Add Year-Group Staff</span>
            </button>
          </div>

          {pagedProfiles.length === 0 ? (
            <div className="p-10 rounded-xl bg-slate-50 border border-slate-200 text-center space-y-2">
              <p className="font-semibold text-[#0c1a40]">
                No profiles match "{staffSearch}" with current filters.
              </p>
              <button
                type="button"
                onClick={() => {
                  setStaffSearch('');
                  setProfileKindFilter('all');
                  setIncompleteOnly(false);
                  setStaffPage(1);
                }}
                className="px-4 py-2 rounded-lg bg-[#0c1a40] text-white text-sm font-semibold cursor-pointer"
              >
                Reset Search & Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pagedProfiles.map((entry) => {
                const linkedAssignments =
                  entry.kind === 'staff_member'
                    ? bundle.assignments.filter((a) => a.staffId === entry.sourceId)
                    : [];
                return (
                  <div
                    key={entry.uid}
                    className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 flex items-start justify-between gap-3"
                  >
                    <div className="flex items-start gap-3.5 min-w-0">
                      {!entry.missingPortrait ? (
                        <img
                          src={entry.image}
                          alt={entry.name}
                          onClick={() =>
                            openImageViewer({
                              src: entry.image,
                              title: entry.name,
                              subtitle: `${entry.kindLabel} · ${entry.department}`,
                            })
                          }
                          className="w-16 h-20 rounded-xl object-cover object-top border border-amber-400 shrink-0 cursor-zoom-in"
                        />
                      ) : (
                        <div className="w-16 h-20 rounded-xl bg-slate-100 border border-slate-200 flex flex-col items-center justify-center shrink-0 text-center px-1">
                          <span className="font-serif font-bold text-base text-[#0c1a40]">
                            {entry.surname.slice(0, 2).toUpperCase()}
                          </span>
                          <span className="text-xs text-amber-700 leading-tight">No Photo</span>
                        </div>
                      )}

                      <div className="min-w-0 space-y-1">
                        <div className="inline-flex items-center px-2 py-0.5 rounded bg-blue-50 text-[#0c1a40] text-xs font-bold">
                          {entry.kindLabel}
                        </div>
                        <div className="font-serif font-bold text-[17px] text-[#0c1a40] truncate">
                          {entry.name}
                        </div>
                        <div className="text-sm text-slate-600">
                          {entry.department} · {entry.role}
                          {entry.missingPortrait && (
                            <span className="text-amber-700 font-semibold"> · Portrait Missing</span>
                          )}
                        </div>
                        {linkedAssignments.length > 0 && (
                          <div className="text-sm font-medium text-[#0c1a40] pt-0.5">
                            {linkedAssignments
                              .map((la) =>
                                `${la.roleTitle}${la.yearGroup ? ` (${la.yearGroup})` : ''}`
                              )
                              .join(' · ')}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => openUnifiedProfileEditor(entry)}
                        className="px-3 py-2 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Edit3 className="w-4 h-4 text-amber-400" /> Edit / Photo
                      </button>
                      {isPublisher && entry.kind === 'staff_member' && entry.rawStaff && (
                        <button
                          type="button"
                          onClick={() => void handleDeleteStaff(entry.rawStaff!)}
                          className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                          title="Delete staff profile"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {totalStaffPages > 1 && (
            <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-sm">
              <span className="text-slate-600 tabular-nums">
                Page {safeStaffPage} of {totalStaffPages} · {filteredProfiles.length} profiles
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={safeStaffPage <= 1}
                  onClick={() => setStaffPage((p) => Math.max(1, p - 1))}
                  className="px-3.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer font-semibold"
                >
                  Previous
                </button>
                <button
                  type="button"
                  disabled={safeStaffPage >= totalStaffPages}
                  onClick={() => setStaffPage((p) => Math.min(totalStaffPages, p + 1))}
                  className="px-3.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer font-semibold"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* CREATE / EDIT ASSIGNMENT MODAL */}
      {assignmentModalOpen && (
        <div
          className="fixed inset-0 z-[70] bg-[#081226]/80 flex items-center justify-center p-4"
          onClick={() => setAssignmentModalOpen(false)}
        >
          <form
            onSubmit={handleSaveAssignment}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl max-w-xl w-full p-6 border border-slate-200 shadow-2xl space-y-4 text-[15px] text-[#0c1a40]"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h4 className="font-serif font-bold text-xl">
                {editingAssignment
                  ? 'Edit / Reassign Academic Role'
                  : 'Create Academic / Pastoral Assignment'}
              </h4>
              <button
                type="button"
                onClick={() => setAssignmentModalOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-semibold text-[15px] mb-1.5">
                  Assigned Staff / Faculty Member *
                </label>
                <select
                  required
                  value={assignForm.staffId}
                  onChange={(e) => setAssignForm({ ...assignForm, staffId: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                >
                  <optgroup label="Academic & Pastoral Staff">
                    {bundle.staffMembers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.fullName} ({s.surname}){s.isIncomplete ? ' — Photo Pending' : ''}
                      </option>
                    ))}
                  </optgroup>
                  {assignableTeacherOptions.length > 0 && (
                    <optgroup label="Assign Any Faculty Teacher">
                      {assignableTeacherOptions.map((t) => (
                        <option key={t.id} value={`teacher-import:${t.id}`}>
                          {t.name} ({t.departmentName})
                        </option>
                      ))}
                    </optgroup>
                  )}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[15px] mb-1.5">
                  Assignment Category *
                </label>
                <select
                  value={assignForm.assignmentType}
                  onChange={(e) => {
                    const nextType = e.target.value as AcademicAssignmentType;
                    setAssignForm({
                      ...assignForm,
                      assignmentType: nextType,
                      roleTitle:
                        nextType === 'head_of_year'
                          ? 'Head of Year'
                          : nextType === 'a_level_coordinator'
                          ? 'A-Level Coordinator'
                          : 'Pastoral Care, Guidance and Counselling – A Level',
                      yearGroup:
                        nextType === 'head_of_year' ? assignForm.yearGroup || 'Form 1' : 'A Level',
                    });
                  }}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                >
                  <option value="head_of_year">Head of Year</option>
                  <option value="a_level_coordinator">A-Level Coordinator</option>
                  <option value="pastoral_care">Pastoral Care, Guidance & Counselling</option>
                </select>
              </div>

              {assignForm.assignmentType === 'head_of_year' && (
                <div>
                  <label className="block font-semibold text-[15px] mb-1.5">Year Group *</label>
                  <select
                    value={assignForm.yearGroup}
                    onChange={(e) =>
                      setAssignForm({ ...assignForm, yearGroup: e.target.value as YearGroupKey })
                    }
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                  >
                    {YEAR_GROUPS.map((yg) => (
                      <option key={yg} value={yg}>
                        {yg}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block font-semibold text-[15px] mb-1.5">
                  Official Role Title *
                </label>
                <input
                  type="text"
                  required
                  value={assignForm.roleTitle}
                  onChange={(e) => setAssignForm({ ...assignForm, roleTitle: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[15px] mb-1.5">Status</label>
                <select
                  value={assignForm.status}
                  onChange={(e) =>
                    setAssignForm({ ...assignForm, status: e.target.value as PublishStatus })
                  }
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                >
                  <option value="published">Published (Live)</option>
                  <option value="unpublished">Unpublished (Hidden)</option>
                  <option value="draft">Draft</option>
                  <option value="archived">Archived</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[15px] mb-1.5">Display Order</label>
                <input
                  type="number"
                  value={assignForm.sortOrder}
                  onChange={(e) =>
                    setAssignForm({ ...assignForm, sortOrder: Number(e.target.value) || 0 })
                  }
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px] tabular-nums"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-[15px] mb-1.5">Role Summary</label>
              <textarea
                rows={2}
                value={assignForm.summary}
                onChange={(e) => setAssignForm({ ...assignForm, summary: e.target.value })}
                placeholder="Brief verified summary of pastoral or academic coordination duties..."
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
              />
            </div>

            <div>
              <label className="block font-semibold text-[15px] mb-1.5">
                Key Responsibilities (optional)
              </label>
              <textarea
                rows={2}
                value={assignForm.responsibilities}
                onChange={(e) => setAssignForm({ ...assignForm, responsibilities: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setAssignmentModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[15px] font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold cursor-pointer"
              >
                {editingAssignment ? 'Save Assignment' : 'Create Assignment'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* UNIFIED PROFILE & PORTRAIT EDITOR MODAL (Teachers, HODs, SMT, Directors, Boarding) */}
      {editingUnified && (
        <div
          className="fixed inset-0 z-[70] bg-[#081226]/80 flex items-center justify-center p-4"
          onClick={() => setEditingUnified(null)}
        >
          <form
            onSubmit={handleSaveUnifiedProfile}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 border border-slate-200 shadow-2xl space-y-4 text-[15px] text-[#0c1a40]"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <span className="text-xs font-bold uppercase text-amber-700">
                  {editingUnified.kindLabel} · {editingUnified.department}
                </span>
                <h4 className="font-serif font-bold text-xl">
                  Edit Profile: {editingUnified.name}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setEditingUnified(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <PhotoUploadField
              value={unifiedForm.image}
              onChange={(url) => setUnifiedForm({ ...unifiedForm, image: url })}
              label="Portrait Photograph (Upload or Pick from Media Library)"
              category="Academics"
              placeholderLabel="Photo Pending"
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-semibold text-[15px] mb-1.5">Display Name *</label>
                <input
                  type="text"
                  required
                  value={unifiedForm.name}
                  onChange={(e) => setUnifiedForm({ ...unifiedForm, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
                />
              </div>
              <div>
                <label className="block font-semibold text-[15px] mb-1.5">Role / Designation</label>
                <input
                  type="text"
                  value={unifiedForm.role}
                  onChange={(e) => setUnifiedForm({ ...unifiedForm, role: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
                />
              </div>
              {editingUnified.kind !== 'boarding' && (
                <div>
                  <label className="block font-semibold text-[15px] mb-1.5">Visibility</label>
                  <select
                    value={unifiedForm.status}
                    onChange={(e) =>
                      setUnifiedForm({ ...unifiedForm, status: e.target.value as PublishStatus })
                    }
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                  >
                    <option value="published">Published (Live)</option>
                    <option value="unpublished">Unpublished (Hidden)</option>
                    <option value="archived">Archived</option>
                  </select>
                </div>
              )}
              <div>
                <label className="block font-semibold text-[15px] mb-1.5">Qualifications</label>
                <input
                  type="text"
                  value={unifiedForm.qualifications}
                  onChange={(e) =>
                    setUnifiedForm({ ...unifiedForm, qualifications: e.target.value })
                  }
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-[15px] mb-1.5">Biography / Statement</label>
              <textarea
                rows={3}
                value={unifiedForm.bio}
                onChange={(e) => setUnifiedForm({ ...unifiedForm, bio: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setEditingUnified(null)}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[15px] font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingUnified}
                className="px-5 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold cursor-pointer disabled:opacity-50"
              >
                {savingUnified ? 'Saving...' : 'Save Profile Live'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* CREATE / EDIT RELATIONAL STAFF PROFILE MODAL */}
      {staffModalOpen && (
        <div
          className="fixed inset-0 z-[70] bg-[#081226]/80 flex items-center justify-center p-4"
          onClick={() => setStaffModalOpen(false)}
        >
          <form
            onSubmit={handleSaveStaff}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 border border-slate-200 shadow-2xl space-y-4 text-[15px] text-[#0c1a40]"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h4 className="font-serif font-bold text-xl">
                {editingStaff
                  ? `Edit Staff Profile: ${editingStaff.fullName}`
                  : 'Add Staff Member Profile'}
              </h4>
              <button
                type="button"
                onClick={() => setStaffModalOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <PhotoUploadField
              value={staffForm.image}
              onChange={(url) => setStaffForm({ ...staffForm, image: url })}
              label="Staff Portrait (Upload or Pick from Media Library)"
              category="Boarding & Staff"
              placeholderLabel="Photo Pending"
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-semibold text-[15px] mb-1.5">
                  Full Display Name *
                </label>
                <input
                  type="text"
                  required
                  value={staffForm.fullName}
                  onChange={(e) => setStaffForm({ ...staffForm, fullName: e.target.value })}
                  placeholder="e.g. Ms Evelyn Mpofu"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
                />
              </div>
              <div>
                <label className="block font-semibold text-[15px] mb-1.5">
                  Surname / Reference *
                </label>
                <input
                  type="text"
                  required
                  value={staffForm.surname}
                  onChange={(e) => setStaffForm({ ...staffForm, surname: e.target.value })}
                  placeholder="e.g. Mpofu"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
                />
              </div>
              <div>
                <label className="block font-semibold text-[15px] mb-1.5">
                  Academic Department
                </label>
                <input
                  type="text"
                  value={staffForm.department}
                  onChange={(e) => setStaffForm({ ...staffForm, department: e.target.value })}
                  placeholder="e.g. Science, Languages, Humanities"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
                />
              </div>
              <div>
                <label className="block font-semibold text-[15px] mb-1.5">
                  Subjects (comma separated)
                </label>
                <input
                  type="text"
                  value={staffForm.subjectsText}
                  onChange={(e) => setStaffForm({ ...staffForm, subjectsText: e.target.value })}
                  placeholder="e.g. Biology, Combined Science"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
                />
              </div>
              <div>
                <label className="block font-semibold text-[15px] mb-1.5">Status</label>
                <select
                  value={staffForm.status}
                  onChange={(e) =>
                    setStaffForm({ ...staffForm, status: e.target.value as PublishStatus })
                  }
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
                >
                  <option value="published">Published</option>
                  <option value="unpublished">Unpublished</option>
                  <option value="archived">Archived</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold text-[15px] mb-1.5">Sort Order</label>
                <input
                  type="number"
                  value={staffForm.sortOrder}
                  onChange={(e) =>
                    setStaffForm({ ...staffForm, sortOrder: Number(e.target.value) || 0 })
                  }
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px] tabular-nums"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-[15px] mb-1.5">
                Qualifications (optional — do not fabricate)
              </label>
              <input
                type="text"
                value={staffForm.qualifications}
                onChange={(e) => setStaffForm({ ...staffForm, qualifications: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
              />
            </div>

            <div>
              <label className="block font-semibold text-[15px] mb-1.5">
                Brief Bio / Note (optional)
              </label>
              <textarea
                rows={2}
                value={staffForm.bio}
                onChange={(e) => setStaffForm({ ...staffForm, bio: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-[15px]"
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setStaffModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[15px] font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold cursor-pointer"
              >
                {editingStaff ? 'Save Staff Profile' : 'Create Staff Profile'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* PREVIEW PUBLIC CARD MODAL */}
      {previewAssignment && (
        <div
          className="fixed inset-0 z-[70] bg-[#081226]/80 flex items-center justify-center p-4"
          onClick={() => setPreviewAssignment(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-lg w-full p-6 border border-slate-200 shadow-2xl space-y-4 text-[15px] text-[#0c1a40]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-amber-700 flex items-center gap-1.5">
                {previewAssignment.assignmentType === 'pastoral_care' ? (
                  <HeartHandshake className="w-4 h-4" />
                ) : (
                  <Award className="w-4 h-4" />
                )}
                Public Website Preview ({previewAssignment.status})
              </span>
              <button
                type="button"
                onClick={() => setPreviewAssignment(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer"
                aria-label="Close preview"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 rounded-xl bg-slate-50 border border-slate-200 text-center space-y-3">
              {previewAssignment.staff?.image ? (
                <img
                  src={previewAssignment.staff.image}
                  alt={previewAssignment.staff.fullName}
                  onClick={() =>
                    openImageViewer({
                      src: previewAssignment.staff!.image!,
                      title: previewAssignment.staff!.fullName,
                      subtitle: previewAssignment.roleTitle,
                    })
                  }
                  className="w-40 h-48 rounded-2xl object-cover object-top mx-auto border-2 border-amber-400 shadow-sm cursor-zoom-in"
                />
              ) : (
                <div className="w-36 h-44 rounded-2xl bg-[#0c1a40] text-amber-400 flex flex-col items-center justify-center mx-auto border-2 border-amber-400/50">
                  <span className="font-serif font-bold text-3xl">
                    {(previewAssignment.staff?.surname || 'LKC').slice(0, 2).toUpperCase()}
                  </span>
                  <span className="text-sm text-blue-200 mt-1">Pending</span>
                </div>
              )}

              <div>
                {previewAssignment.yearGroup && (
                  <div className="text-sm font-bold text-amber-700">
                    {previewAssignment.yearGroup}
                  </div>
                )}
                <h5 className="font-serif font-bold text-xl text-[#0c1a40]">
                  {previewAssignment.staff?.fullName || 'Staff Member'}
                </h5>
                <div className="text-[15px] font-semibold text-slate-700">
                  {previewAssignment.roleTitle}
                </div>
              </div>

              {previewAssignment.summary && (
                <p className="text-[15px] text-slate-600 leading-relaxed">
                  {previewAssignment.summary}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modals */}
      <CmsConfirmModal
        open={Boolean(deleteAssignmentTarget)}
        title="Delete Leadership Assignment"
        message={
          deleteAssignmentTarget
            ? `Delete assignment "${deleteAssignmentTarget.roleTitle}${
                deleteAssignmentTarget.yearGroup ? ` (${deleteAssignmentTarget.yearGroup})` : ''
              }"?`
            : ''
        }
        confirmLabel="Delete Assignment"
        onConfirm={() => void confirmDeleteAssignment()}
        onCancel={() => setDeleteAssignmentTarget(null)}
      />

      <CmsConfirmModal
        open={Boolean(forceDeleteStaffTarget)}
        title="Staff Member Holds Active Roles"
        message={
          forceDeleteStaffTarget
            ? `${forceDeleteStaffTarget.staff.fullName} currently holds ${forceDeleteStaffTarget.assignmentCount} academic/pastoral assignment(s). Deleting this staff profile will also delete those linked assignments. Proceed?`
            : ''
        }
        confirmLabel="Delete Profile & Assignments"
        onConfirm={() => void confirmForceDeleteStaff()}
        onCancel={() => setForceDeleteStaffTarget(null)}
      />
    </div>
  );
};
