import React, { useEffect, useState } from 'react';
import { Save, Plus, Trash2, Timer, RotateCcw } from 'lucide-react';
import type { AthleticsData } from '../../types';
import { CmsPhotoGalleryEditor, type GalleryPhotoEntry } from './CmsPhotoGalleryEditor';
import { CmsConfirmModal } from './CmsConfirmModal';

interface CmsAthleticsTabProps {
  athletics: AthleticsData;
  onSave: (next: AthleticsData) => Promise<void>;
}

export const CmsAthleticsTab: React.FC<CmsAthleticsTabProps> = ({ athletics, onSave }) => {
  const [state, setState] = useState<AthleticsData>(() => JSON.parse(JSON.stringify(athletics)));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setState(JSON.parse(JSON.stringify(athletics)));
  }, [athletics]);

  const [newComp, setNewComp] = useState({
    name: '',
    date: '',
    venue: 'LKC Block 8 Athletics Track',
    highlights: '',
    status: 'Scheduled',
  });

  const [newRecord, setNewRecord] = useState({
    event: '',
    athlete: '',
    mark: '',
    year: '2026',
    category: 'U19 Boys / Girls',
  });

  const [confirmDelete, setConfirmDelete] = useState<{
    type: 'comp' | 'record';
    index: number;
    label: string;
  } | null>(null);

  const isDirty = JSON.stringify(state) !== JSON.stringify(athletics);

  const handleSaveAll = async () => {
    setSaving(true);
    try {
      await onSave(state);
    } finally {
      setSaving(false);
    }
  };

  const handleDiscard = () => {
    setState(JSON.parse(JSON.stringify(athletics)));
  };

  const executeConfirmDelete = () => {
    if (!confirmDelete) return;
    if (confirmDelete.type === 'comp') {
      setState((prev) => ({
        ...prev,
        competitions: prev.competitions.filter((_, i) => i !== confirmDelete.index),
      }));
    } else {
      setState((prev) => ({
        ...prev,
        records: prev.records.filter((_, i) => i !== confirmDelete.index),
      }));
    }
    setConfirmDelete(null);
  };

  return (
    <div className="space-y-6 text-[15px] text-[#0c1a40]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h3 className="font-serif font-bold text-2xl flex items-center gap-2.5 text-[#0c1a40]">
            <Timer className="w-6 h-6 text-amber-600" />
            <span>Athletics Page Manager (Track & Field)</span>
          </h3>
          <p className="text-[15px] text-slate-600 mt-1">
            Manage dedicated Athletics headlines, gallery photos, track meets, and verified school records.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          {isDirty && (
            <button
              type="button"
              onClick={handleDiscard}
              className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-[15px] font-semibold flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Discard Changes</span>
            </button>
          )}
          <button
            type="button"
            disabled={saving}
            onClick={() => void handleSaveAll()}
            className="px-5 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold flex items-center gap-2 cursor-pointer disabled:opacity-60"
          >
            <Save className="w-4 h-4 text-amber-400" />
            <span>{saving ? 'Saving...' : 'Save Athletics Page'}</span>
          </button>
        </div>
      </div>

      {/* Overview Copy */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
        <h4 className="font-serif font-bold text-lg text-[#0c1a40]">
          Page Headline & Season Overview
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
              Headline
            </label>
            <input
              type="text"
              value={state.headline}
              onChange={(e) => setState({ ...state, headline: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
            />
          </div>
          <div>
            <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
              Subheadline
            </label>
            <input
              type="text"
              value={state.subheadline}
              onChange={(e) => setState({ ...state, subheadline: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
            />
          </div>
        </div>
        <div>
          <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
            Overview Description
          </label>
          <textarea
            rows={3}
            value={state.description}
            onChange={(e) => setState({ ...state, description: e.target.value })}
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
          />
        </div>
        <div>
          <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
            Season Summary
          </label>
          <textarea
            rows={2}
            value={state.seasonSummary}
            onChange={(e) => setState({ ...state, seasonSummary: e.target.value })}
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
          />
        </div>
      </div>

      {/* Athletics Photo Gallery */}
      <CmsPhotoGalleryEditor
        title={`Athletics Track & Training Gallery (${(state.photos || []).length})`}
        description="Upload new photos, replace existing images, edit titles/descriptions/categories/locations, reorder items, or publish/unpublish gallery entries."
        category="Sports"
        mode="gallery"
        enableLocationAndStatus
        items={(state.photos || []) as GalleryPhotoEntry[]}
        hasUnsavedChanges={isDirty}
        saving={saving}
        onSaveSection={() => void handleSaveAll()}
        onChange={(next) =>
          setState({
            ...state,
            photos: next.map((item) => ({
              url: item.url,
              title: item.title || '',
              category: item.category || 'Track & Field',
              location: item.location || '',
              status: item.status || 'published',
              caption: item.caption || '',
            })),
          })
        }
      />

      {/* Competitions */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <h4 className="font-serif font-bold text-lg text-[#0c1a40] tabular-nums">
            Track & Field Competitions ({state.competitions.length})
          </h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <input
            type="text"
            placeholder="Competition Name"
            value={newComp.name}
            onChange={(e) => setNewComp({ ...newComp, name: e.target.value })}
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <input
            type="text"
            placeholder="Date"
            value={newComp.date}
            onChange={(e) => setNewComp({ ...newComp, date: e.target.value })}
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <input
            type="text"
            placeholder="Venue"
            value={newComp.venue}
            onChange={(e) => setNewComp({ ...newComp, venue: e.target.value })}
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <button
            type="button"
            onClick={() => {
              if (!newComp.name.trim()) return;
              setState({
                ...state,
                competitions: [...state.competitions, newComp],
              });
              setNewComp({
                name: '',
                date: '',
                venue: 'LKC Block 8 Athletics Track',
                highlights: '',
                status: 'Scheduled',
              });
            }}
            className="px-4 py-2.5 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-semibold flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Add Meet</span>
          </button>
        </div>

        <div className="space-y-2.5">
          {state.competitions.length === 0 ? (
            <div className="p-6 rounded-xl bg-slate-50 border border-slate-200 text-center text-[15px] text-slate-600">
              No competitions scheduled yet.
            </div>
          ) : (
            state.competitions.map((c, idx) => (
              <div
                key={`${c.name}-${idx}`}
                className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
              >
                <div>
                  <div className="font-bold text-base text-[#0c1a40]">{c.name}</div>
                  <div className="text-sm text-slate-600 mt-0.5">
                    {c.date || 'Date TBC'} · {c.venue} · {c.status}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setConfirmDelete({ type: 'comp', index: idx, label: c.name })
                  }
                  className="p-2 text-red-700 hover:bg-red-50 rounded-lg cursor-pointer"
                  title="Remove meet"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Athletics School Records */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
        <h4 className="font-serif font-bold text-lg text-[#0c1a40] tabular-nums">
          Verified School Records ({state.records.length})
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <input
            type="text"
            placeholder="Event (e.g. 100m Boys)"
            value={newRecord.event}
            onChange={(e) => setNewRecord({ ...newRecord, event: e.target.value })}
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <input
            type="text"
            placeholder="Athlete Name"
            value={newRecord.athlete}
            onChange={(e) => setNewRecord({ ...newRecord, athlete: e.target.value })}
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <input
            type="text"
            placeholder="Mark / Time"
            value={newRecord.mark}
            onChange={(e) => setNewRecord({ ...newRecord, mark: e.target.value })}
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <input
            type="text"
            placeholder="Year"
            value={newRecord.year}
            onChange={(e) => setNewRecord({ ...newRecord, year: e.target.value })}
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
          />
          <button
            type="button"
            onClick={() => {
              if (!newRecord.event.trim() || !newRecord.athlete.trim()) return;
              setState({
                ...state,
                records: [...state.records, newRecord],
              });
              setNewRecord({
                event: '',
                athlete: '',
                mark: '',
                year: '2026',
                category: 'U19 Boys / Girls',
              });
            }}
            className="px-4 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Record</span>
          </button>
        </div>

        {state.records.length > 0 && (
          <div className="space-y-2.5">
            {state.records.map((r, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
              >
                <div className="text-[15px]">
                  <strong className="text-[#0c1a40]">{r.event}</strong> — {r.athlete}{' '}
                  <span className="text-slate-600 tabular-nums">
                    ({r.mark}, {r.year})
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setConfirmDelete({ type: 'record', index: idx, label: `${r.event} (${r.athlete})` })
                  }
                  className="p-2 text-red-700 hover:bg-red-50 rounded-lg cursor-pointer"
                  title="Remove record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <CmsConfirmModal
        open={Boolean(confirmDelete)}
        title="Remove Athletics Entry"
        message={
          confirmDelete
            ? `Remove "${confirmDelete.label}"? Save Athletics Page afterwards to apply this update.`
            : ''
        }
        confirmLabel="Remove"
        onConfirm={executeConfirmDelete}
        onCancel={() => setConfirmDelete(null)}
      />
    </div>
  );
};
