import React, { useState, useEffect } from 'react';
import { ShieldCheck, Lock, UserPlus, LogIn, X, AlertCircle, KeyRound, CheckCircle2, ArrowLeft } from 'lucide-react';
import {
  changeCmsPassword,
  getAuthSetupStatus,
  loginCmsAdmin,
  requestPasswordReset,
  resetPasswordWithToken,
  setupInitialSuperAdmin,
} from '../../services/cmsDataService';
import type { CmsUser } from '../../types';

interface CmsAuthGateProps {
  onAuthenticated: (user: CmsUser) => void;
  onClose: () => void;
  initialPendingPasswordUser?: CmsUser | null;
}

export const CmsAuthGate: React.FC<CmsAuthGateProps> = ({
  onAuthenticated,
  onClose,
  initialPendingPasswordUser = null,
}) => {
  const [loadingStatus, setLoadingStatus] = useState(!initialPendingPasswordUser);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [forceLoginForm, setForceLoginForm] = useState(false);

  const [mode, setMode] = useState<'login' | 'force_change' | 'recovery'>(
    initialPendingPasswordUser ? 'force_change' : 'login'
  );
  const [pendingUser, setPendingUser] = useState<CmsUser | null>(initialPendingPasswordUser);

  const isSetupView = needsSetup && !forceLoginForm;

  const [fullName, setFullName] = useState('');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [currentPassInput, setCurrentPassInput] = useState('');
  const [newPassInput, setNewPassInput] = useState('');
  const [confirmNewPassInput, setConfirmNewPassInput] = useState('');

  const [resetRequested, setResetRequested] = useState(false);
  const [resetTokenInput, setResetTokenInput] = useState('');
  const [resetSuccessMsg, setResetSuccessMsg] = useState<string | null>(null);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (initialPendingPasswordUser) {
      setPendingUser(initialPendingPasswordUser);
      setMode('force_change');
      setLoadingStatus(false);
      return;
    }
    let active = true;
    (async () => {
      try {
        const res = await getAuthSetupStatus();
        if (active) setNeedsSetup(res.needsInitialSetup);
      } catch (err) {
        if (active) {
          setError(
            err instanceof Error
              ? err.message
              : 'Unable to reach CMS authentication service.'
          );
        }
      } finally {
        if (active) setLoadingStatus(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [initialPendingPasswordUser]);

  const handleLoginOrSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (isSetupView) {
      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        return;
      }
      if (password.length < 8) {
        setError('Administrator password must be at least 8 characters long.');
        return;
      }
    }

    setSubmitting(true);
    try {
      const user = isSetupView
        ? await setupInitialSuperAdmin({
            email: identifier.trim(),
            fullName: fullName.trim(),
            password,
          })
        : await loginCmsAdmin(identifier.trim(), password);

      if (user.mustChangePassword) {
        setPendingUser(user);
        setCurrentPassInput(password);
        setNewPassInput('');
        setConfirmNewPassInput('');
        setMode('force_change');
        return;
      }
      onAuthenticated(user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleForceChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (newPassInput.length < 10) {
      setError('New password must be at least 10 characters long.');
      return;
    }
    if (newPassInput !== confirmNewPassInput) {
      setError('New passwords do not match.');
      return;
    }
    if (newPassInput === currentPassInput) {
      setError('Your new password must be different from your temporary password.');
      return;
    }

    setSubmitting(true);
    try {
      const updatedUser = await changeCmsPassword(currentPassInput, newPassInput);
      onAuthenticated(updatedUser);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Password update failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRequestReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setResetSuccessMsg(null);
    setSubmitting(true);
    try {
      const res = await requestPasswordReset(identifier.trim());
      setResetRequested(true);
      setResetSuccessMsg(res.message);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not initiate password recovery.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCompleteRecovery = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (newPassInput.length < 10) {
      setError('New password must be at least 10 characters long.');
      return;
    }
    if (newPassInput !== confirmNewPassInput) {
      setError('New passwords do not match.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await resetPasswordWithToken(identifier.trim(), resetTokenInput.trim(), newPassInput);
      setResetSuccessMsg(res.message || 'Password reset complete. You may now sign in.');
      setMode('login');
      setPassword('');
      setResetTokenInput('');
      setNewPassInput('');
      setConfirmNewPassInput('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reset password with token.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#081226]/90 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden text-[#0c1a40]">
        <div className="bg-[#0c1a40] text-white px-6 py-5 border-b border-blue-900 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-400 shrink-0">
              {isSetupView ? (
                <UserPlus className="w-6 h-6" />
              ) : mode === 'force_change' || mode === 'recovery' ? (
                <KeyRound className="w-6 h-6" />
              ) : (
                <Lock className="w-6 h-6" />
              )}
            </div>
            <div>
              <h2 className="font-serif font-bold text-[22px] text-white leading-tight">
                {isSetupView
                  ? 'Initial Super Admin Setup'
                  : mode === 'force_change'
                  ? 'Required Password Update'
                  : mode === 'recovery'
                  ? 'Account Recovery'
                  : 'LKC CMS Administration'}
              </h2>
              <p className="text-sm text-amber-300 font-medium mt-0.5">
                {isSetupView
                  ? 'First-Time Database Initialization'
                  : mode === 'force_change'
                  ? 'Security Policy · Change Temporary Password'
                  : mode === 'recovery'
                  ? 'Out-of-Band Institutional Recovery'
                  : 'Restricted Staff Sign-In'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-blue-200 hover:text-white hover:bg-white/10 cursor-pointer"
            aria-label="Close CMS login"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 sm:p-7">
          {loadingStatus ? (
            <div className="py-10 text-center text-[15px] text-slate-600">
              Verifying CMS session and database status...
            </div>
          ) : mode === 'force_change' ? (
            <form onSubmit={handleForceChangePassword} className="space-y-4">
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-[15px] text-[#0c1a40] leading-relaxed">
                Signed in as <strong>{pendingUser?.fullName || pendingUser?.username || 'Administrator'}</strong>. For institutional security, please replace your temporary password with a private password (minimum 10 characters).
              </div>

              {error && (
                <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-[15px] text-red-800 flex items-start gap-2.5">
                  <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                  Temporary / Current Password *
                </label>
                <input
                  type="password"
                  required
                  value={currentPassInput}
                  onChange={(e) => setCurrentPassInput(e.target.value)}
                  placeholder="Enter temporary password"
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base focus:outline-hidden focus:border-[#0c1a40]"
                />
              </div>

              <div>
                <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                  New Private Password (min. 10 characters) *
                </label>
                <input
                  type="password"
                  required
                  minLength={10}
                  autoComplete="new-password"
                  value={newPassInput}
                  onChange={(e) => setNewPassInput(e.target.value)}
                  placeholder="Minimum 10 characters"
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base focus:outline-hidden focus:border-[#0c1a40]"
                />
              </div>

              <div>
                <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                  Confirm New Password *
                </label>
                <input
                  type="password"
                  required
                  minLength={10}
                  autoComplete="new-password"
                  value={confirmNewPassInput}
                  onChange={(e) => setConfirmNewPassInput(e.target.value)}
                  placeholder="Re-enter new password"
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base focus:outline-hidden focus:border-[#0c1a40]"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-base font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors disabled:opacity-60"
              >
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                <span>{submitting ? 'Updating Password...' : 'Save Private Password & Enter CMS'}</span>
              </button>
            </form>
          ) : mode === 'recovery' ? (
            <div className="space-y-4">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                  setResetSuccessMsg(null);
                }}
                className="text-[15px] font-semibold text-[#0c1a40] hover:underline flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Sign-In
              </button>

              {error && (
                <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-[15px] text-red-800 flex items-start gap-2.5">
                  <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              {resetSuccessMsg && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-[15px] text-emerald-800 flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{resetSuccessMsg}</span>
                </div>
              )}

              {!resetRequested ? (
                <form onSubmit={handleRequestReset} className="space-y-4">
                  <p className="text-[15px] text-slate-700 leading-relaxed">
                    Enter your administrator username or institutional email. A time-limited one-time recovery token will be dispatched via the server’s protected administration channel.
                  </p>
                  <div>
                    <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                      Username or Email *
                    </label>
                    <input
                      type="text"
                      required
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      placeholder="e.g. makoni or makoni@lkc.ac.bw"
                      className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-3 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-base font-bold cursor-pointer disabled:opacity-60"
                  >
                    {submitting ? 'Dispatching Token...' : 'Request Recovery Token'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setResetRequested(true)}
                    className="w-full text-[15px] text-amber-700 font-semibold hover:underline cursor-pointer"
                  >
                    Already have a recovery token? Enter it here
                  </button>
                </form>
              ) : (
                <form onSubmit={handleCompleteRecovery} className="space-y-4">
                  <div>
                    <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                      Username or Email *
                    </label>
                    <input
                      type="text"
                      required
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base"
                    />
                  </div>
                  <div>
                    <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                      One-Time Recovery Token *
                    </label>
                    <input
                      type="text"
                      required
                      value={resetTokenInput}
                      onChange={(e) => setResetTokenInput(e.target.value)}
                      placeholder="Paste recovery token"
                      className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                      New Password (min. 10 characters) *
                    </label>
                    <input
                      type="password"
                      required
                      minLength={10}
                      value={newPassInput}
                      onChange={(e) => setNewPassInput(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base"
                    />
                  </div>
                  <div>
                    <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                      Confirm New Password *
                    </label>
                    <input
                      type="password"
                      required
                      minLength={10}
                      value={confirmNewPassInput}
                      onChange={(e) => setConfirmNewPassInput(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-3 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-base font-bold cursor-pointer disabled:opacity-60"
                  >
                    {submitting ? 'Resetting Password...' : 'Reset Password'}
                  </button>
                </form>
              )}
            </div>
          ) : (
            <form onSubmit={handleLoginOrSetup} className="space-y-4">
              {isSetupView && (
                <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-[15px] text-[#0c1a40] leading-relaxed space-y-2">
                  <div>
                    <strong>First-Time Setup on This Server:</strong> No Super Administrator exists yet in this environment&apos;s database. Create your primary <strong>Super Administrator</strong> account below, or switch to Sign In if using a seeded staff account.
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setError(null);
                      setForceLoginForm(true);
                    }}
                    className="text-sm font-bold text-[#162a6b] hover:underline cursor-pointer"
                  >
                    Already have a CMS account? Sign In →
                  </button>
                </div>
              )}

              {needsSetup && forceLoginForm && (
                <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 text-sm text-[#0c1a40] flex items-center justify-between gap-2">
                  <span>Sign in with an existing staff username or email.</span>
                  <button
                    type="button"
                    onClick={() => {
                      setError(null);
                      setForceLoginForm(false);
                    }}
                    className="text-sm font-bold text-amber-700 hover:underline shrink-0 cursor-pointer"
                  >
                    Create Super Admin
                  </button>
                </div>
              )}

              {resetSuccessMsg && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-[15px] text-emerald-800 flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{resetSuccessMsg}</span>
                </div>
              )}

              {error && (
                <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-[15px] text-red-800 flex items-start gap-2.5">
                  <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              {isSetupView && (
                <div>
                  <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. College Principal / Registrar"
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base focus:outline-hidden focus:border-[#0c1a40]"
                  />
                </div>
              )}

              <div>
                <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                  {isSetupView ? 'Super Administrator Email *' : 'Username or Email *'}
                </label>
                <input
                  type={isSetupView ? 'email' : 'text'}
                  required
                  autoComplete="username"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={isSetupView ? 'admin@lkc.ac.bw' : 'e.g. makoni or your email address'}
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base focus:outline-hidden focus:border-[#0c1a40]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-[15px] font-semibold text-[#0c1a40]">
                    Password {isSetupView ? '(min. 8 characters)' : '*'}
                  </label>
                  {!isSetupView && (
                    <button
                      type="button"
                      onClick={() => {
                        setError(null);
                        setResetRequested(false);
                        setMode('recovery');
                      }}
                      className="text-sm font-semibold text-amber-700 hover:underline cursor-pointer"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <input
                  type="password"
                  required
                  autoComplete={isSetupView ? 'new-password' : 'current-password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base focus:outline-hidden focus:border-[#0c1a40]"
                />
              </div>

              {isSetupView && (
                <div>
                  <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                    Confirm Password *
                  </label>
                  <input
                    type="password"
                    required
                    autoComplete="new-password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base focus:outline-hidden focus:border-[#0c1a40]"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-base font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors disabled:opacity-60"
              >
                {isSetupView ? (
                  <>
                    <ShieldCheck className="w-5 h-5 text-amber-400" />
                    <span>{submitting ? 'Creating Super Admin...' : 'Initialize Super Admin & Sign In'}</span>
                  </>
                ) : (
                  <>
                    <LogIn className="w-5 h-5 text-amber-400" />
                    <span>{submitting ? 'Authenticating...' : 'Sign In to LKC CMS'}</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
