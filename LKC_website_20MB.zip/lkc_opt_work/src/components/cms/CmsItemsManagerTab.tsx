import React, { useState } from 'react';
import {
  Plus,
  Star,
  Eye,
  Trash2,
  Edit3,
  CheckCircle2,
  Archive,
  X,
  Send,
  EyeOff,
  Search,
  ChevronLeft,
  ChevronRight,
  FileText,
  Upload,
} from 'lucide-react';
import {
  createCmsItem,
  updateCmsItem,
  toggleFeatureOnHomepage,
  changeItemStatus,
  deleteCmsItem,
  uploadMediaFile,
} from '../../services/cmsDataService';
import type { CmsItem, CmsUser, PageKey, PublishStatus } from '../../types';
import { PhotoUploadField } from './PhotoUploadField';
import { CmsConfirmModal } from './CmsConfirmModal';

interface CmsItemsManagerTabProps {
  items: CmsItem[];
  currentUser: CmsUser;
  onRefresh: () => Promise<void>;
  onNotify: (msg: string) => void;
}

const PAGE_OPTIONS: { key: PageKey; label: string }[] = [
  { key: 'news', label: 'News & Bulletins' },
  { key: 'events', label: 'Events Calendar' },
  { key: 'campus', label: 'Campus & Facilities' },
  { key: 'achievers', label: 'Top Achievers' },
  { key: 'sports', label: 'Sports' },
  { key: 'athletics', label: 'Athletics (Track & Field)' },
  { key: 'jaguars', label: 'The Jaguars (Rugby)' },
  { key: 'boarding', label: 'Boarding Houses' },
  { key: 'excursions', label: 'Educational Excursions' },
  { key: 'departments', label: 'Academic Departments' },
  { key: 'curriculum', label: 'Curriculum' },
];

const ITEMS_PER_PAGE = 8;

export const CmsItemsManagerTab: React.FC<CmsItemsManagerTabProps> = ({
  items,
  currentUser,
  onRefresh,
  onNotify,
}) => {
  const isPublisher = currentUser.role === 'super_admin' || currentUser.role === 'admin';

  const allowedPages =
    currentUser.role === 'content_editor'
      ? PAGE_OPTIONS.filter((p) => currentUser.assignedPages.includes(p.key))
      : PAGE_OPTIONS;

  const [filterPage, setFilterPage] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [previewItem, setPreviewItem] = useState<CmsItem | null>(null);
  const [confirmDeleteItem, setConfirmDeleteItem] = useState<CmsItem | null>(null);
  const [saving, setSaving] = useState(false);
  const [docUploading, setDocUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState<{
    pageKey: PageKey;
    category: string;
    academicYear: string;
    title: string;
    excerpt: string;
    body: string;
    thumbnailUrl: string;
    mediaUrl: string;
    publishAt: string;
    eventDate: string;
    eventTime: string;
    eventLocation: string;
    eventCompleted: boolean;
    status: PublishStatus;
    featureOnHomepage: boolean;
  }>({
    pageKey: (allowedPages[0]?.key as PageKey) || 'news',
    category: 'Admissions Bulletin',
    academicYear: '2026',
    title: '',
    excerpt: '',
    body: '',
    thumbnailUrl: '',
    mediaUrl: '',
    publishAt: new Date().toISOString().split('T')[0],
    eventDate: '',
    eventTime: '',
    eventLocation: '',
    eventCompleted: false,
    status: isPublisher ? 'published' : 'draft',
    featureOnHomepage: false,
  });

  const resetForm = () => {
    setEditingId(null);
    setForm({
      pageKey: (allowedPages[0]?.key as PageKey) || 'news',
      category: 'Admissions Bulletin',
      academicYear: '2026',
      title: '',
      excerpt: '',
      body: '',
      thumbnailUrl: '',
      mediaUrl: '',
      publishAt: new Date().toISOString().split('T')[0],
      eventDate: '',
      eventTime: '',
      eventLocation: '',
      eventCompleted: false,
      status: isPublisher ? 'published' : 'draft',
      featureOnHomepage: false,
    });
  };

  const handleEdit = (item: CmsItem) => {
    setEditingId(item.id);
    setForm({
      pageKey: item.pageKey,
      category: item.category,
      academicYear: item.academicYear || '2026',
      title: item.title,
      excerpt: item.excerpt,
      body: typeof item.content?.body === 'string' ? item.content.body : '',
      thumbnailUrl: item.thumbnailUrl || '',
      mediaUrl: item.mediaUrl || '',
      publishAt: item.publishAt || '',
      eventDate: item.eventDate || '',
      eventTime: item.eventTime || '',
      eventLocation: item.eventLocation || '',
      eventCompleted: Boolean(item.eventCompleted),
      status: item.status,
      featureOnHomepage: item.featureOnHomepage,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      const cleanThumb = form.thumbnailUrl.trim();
      const cleanMedia = form.mediaUrl.trim();
      const basePayload = {
        pageKey: form.pageKey,
        category: form.category,
        academicYear: form.academicYear || undefined,
        title: form.title.trim(),
        excerpt: form.excerpt.trim(),
        content: { body: form.body.trim(), author: currentUser.fullName },
        publishAt: form.publishAt || undefined,
        eventDate: form.eventDate || undefined,
        eventTime: form.eventTime || undefined,
        eventLocation: form.eventLocation || undefined,
        eventCompleted: form.eventCompleted,
        status: isPublisher ? form.status : form.status === 'pending' ? 'pending' : 'draft',
        featureOnHomepage: isPublisher ? form.featureOnHomepage : false,
      };
      if (editingId) {
        await updateCmsItem(editingId, {
          ...basePayload,
          thumbnailUrl: cleanThumb || null,
          mediaUrl: cleanMedia || null,
        });
        onNotify('Updated article / event & media changes saved.');
      } else {
        await createCmsItem({
          ...basePayload,
          thumbnailUrl: cleanThumb || undefined,
          mediaUrl: cleanMedia || undefined,
        });
        onNotify('Created new article / event in SQLite database.');
      }
      resetForm();
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save item.');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleFeature = async (item: CmsItem) => {
    setError(null);
    try {
      await toggleFeatureOnHomepage(item.id, !item.featureOnHomepage);
      onNotify(
        !item.featureOnHomepage
          ? `Featured '${item.title}' on Homepage.`
          : `Removed '${item.title}' from Homepage only — preserved on '${item.pageKey}' page.`
      );
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to toggle homepage feature.');
    }
  };

  const handleStatusChange = async (item: CmsItem, nextStatus: PublishStatus) => {
    setError(null);
    try {
      await changeItemStatus(item.id, nextStatus);
      onNotify(`Changed '${item.title}' status to '${nextStatus}'.`);
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to change publish status.');
    }
  };

  const handleDelete = async (item: CmsItem) => {
    setError(null);
    try {
      await deleteCmsItem(item.id);
      setConfirmDeleteItem(null);
      onNotify(`Deleted '${item.title}' from CMS database.`);
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete item.');
    }
  };

  const visibleItems = items.filter((item) => {
    if (filterPage !== 'all' && item.pageKey !== filterPage) return false;
    if (filterStatus !== 'all' && item.status !== filterStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.title.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.excerpt.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalPages = Math.max(1, Math.ceil(visibleItems.length / ITEMS_PER_PAGE));
  const safePage = Math.min(currentPage, totalPages);
  const paginatedItems = visibleItems.slice(
    (safePage - 1) * ITEMS_PER_PAGE,
    safePage * ITEMS_PER_PAGE
  );

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-200">
        <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
          News, Events & Homepage Featured Content
        </h3>
        <p className="text-[15px] text-slate-600 mt-1">
          Create or edit articles, upload/replace poster thumbnails directly, and toggle Homepage featuring independently without deleting page items.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-[15px] text-red-800">
          {error}
        </div>
      )}

      {/* Create / Edit Item Form */}
      <form
        onSubmit={handleSubmit}
        className="bg-slate-50 rounded-xl border border-slate-200 p-6 space-y-5"
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="text-base font-bold text-[#0c1a40]">
            {editingId ? 'Edit Existing Article / Event' : 'Add New Page Article or Event'}
          </div>
          {editingId && (
            <button
              type="button"
              onClick={resetForm}
              className="px-3.5 py-2 rounded-lg bg-white border border-slate-300 text-[15px] font-semibold text-[#0c1a40] hover:bg-slate-100 cursor-pointer"
            >
              Discard Edit
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
              Target Page *
            </label>
            <select
              value={form.pageKey}
              onChange={(e) => setForm({ ...form, pageKey: e.target.value as PageKey })}
              className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
            >
              {allowedPages.map((p) => (
                <option key={p.key} value={p.key}>
                  {p.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
              Category *
            </label>
            <input
              type="text"
              required
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
              placeholder="e.g. Academic Distinction"
              className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
            />
          </div>

          <div>
            <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
              Publish Date
            </label>
            <input
              type="date"
              value={form.publishAt}
              onChange={(e) => setForm({ ...form, publishAt: e.target.value })}
              className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
            />
          </div>

          <div>
            <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
              Workflow Status
            </label>
            <select
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value as PublishStatus })}
              className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
            >
              <option value="draft">Draft</option>
              <option value="pending">Pending Review</option>
              {isPublisher && (
                <>
                  <option value="published">Published (Live)</option>
                  <option value="unpublished">Unpublished (Hidden)</option>
                  <option value="archived">Archived</option>
                </>
              )}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
          <div>
            <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
              Headline / Title *
            </label>
            <input
              type="text"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Enter article or event headline..."
              className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
            />
          </div>

          <div>
            <PhotoUploadField
              value={form.thumbnailUrl}
              onChange={(url) => setForm({ ...form, thumbnailUrl: url })}
              label="Thumbnail / Poster Image"
              category="News & Events"
              placeholderLabel="Optional"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
              Short Summary / Excerpt *
            </label>
            <textarea
              required
              rows={3}
              value={form.excerpt}
              onChange={(e) => setForm({ ...form, excerpt: e.target.value })}
              placeholder="Concise summary displayed on preview cards..."
              className="w-full p-3 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
            />
          </div>
          <div>
            <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
              Full Article / Event Details
            </label>
            <textarea
              rows={3}
              value={form.body}
              onChange={(e) => setForm({ ...form, body: e.target.value })}
              placeholder="Detailed announcement or event programme notes..."
              className="w-full p-3 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="block text-[15px] font-semibold text-[#0c1a40]">
            Attached Document / Circular PDF / Video URL (Optional)
          </label>
          <div className="flex flex-wrap items-center gap-2.5">
            <input
              type="text"
              value={form.mediaUrl}
              onChange={(e) => setForm({ ...form, mediaUrl: e.target.value })}
              placeholder="Optional PDF, DOCX, or video link..."
              className="flex-1 min-w-[220px] p-2.5 rounded-lg border border-slate-300 bg-white text-sm font-mono text-[#0c1a40]"
            />
            <label className="px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-[#0c1a40] text-[15px] font-semibold flex items-center gap-2 cursor-pointer">
              <Upload className="w-4 h-4 text-amber-600" />
              <span>{docUploading ? 'Uploading...' : 'Attach PDF / Doc'}</span>
              <input
                type="file"
                accept=".pdf,.doc,.docx,.mp4,.webm"
                className="hidden"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  setDocUploading(true);
                  setError(null);
                  try {
                    const asset = await uploadMediaFile(file, {
                      name: file.name.replace(/\.[^.]+$/, ''),
                      category: 'News & Events',
                    });
                    setForm((prev) => ({ ...prev, mediaUrl: asset.url }));
                    onNotify('Attachment uploaded and linked to item form.');
                  } catch (err) {
                    setError(err instanceof Error ? err.message : 'Failed to upload attachment.');
                  } finally {
                    setDocUploading(false);
                    e.target.value = '';
                  }
                }}
              />
            </label>
            {form.mediaUrl && (
              <button
                type="button"
                onClick={() => setForm({ ...form, mediaUrl: '' })}
                className="px-3 py-2.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 text-sm font-semibold cursor-pointer"
              >
                Remove File
              </button>
            )}
          </div>
          {form.mediaUrl && (
            <div className="text-sm text-slate-600 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-amber-600" />
              <span className="font-mono truncate">{form.mediaUrl}</span>
            </div>
          )}
        </div>

        {form.pageKey === 'events' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-3 border-t border-slate-200">
            <div>
              <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                Event Date
              </label>
              <input
                type="date"
                value={form.eventDate}
                onChange={(e) => setForm({ ...form, eventDate: e.target.value })}
                className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
              />
            </div>
            <div>
              <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                Event Time
              </label>
              <input
                type="text"
                value={form.eventTime}
                onChange={(e) => setForm({ ...form, eventTime: e.target.value })}
                placeholder="e.g. 09:00 – 12:30 CAT"
                className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
              />
            </div>
            <div>
              <label className="block text-[15px] font-semibold text-[#0c1a40] mb-1.5">
                Location
              </label>
              <input
                type="text"
                value={form.eventLocation}
                onChange={(e) => setForm({ ...form, eventLocation: e.target.value })}
                placeholder="e.g. Sechele Hall"
                className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
              />
            </div>
            <div className="flex items-end pb-2.5">
              <label className="flex items-center gap-2 cursor-pointer text-[15px] font-semibold text-[#0c1a40]">
                <input
                  type="checkbox"
                  checked={form.eventCompleted}
                  onChange={(e) => setForm({ ...form, eventCompleted: e.target.checked })}
                  className="w-4 h-4"
                />
                <span>Mark Event Completed</span>
              </label>
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          {isPublisher ? (
            <label className="flex items-center gap-2.5 text-[15px] font-semibold text-[#0c1a40] cursor-pointer">
              <input
                type="checkbox"
                checked={form.featureOnHomepage}
                onChange={(e) => setForm({ ...form, featureOnHomepage: e.target.checked })}
                className="w-4 h-4"
              />
              <span>Feature on Homepage Spotlight</span>
            </label>
          ) : (
            <div className="text-sm text-slate-600">
              Content Editors submit updates as Draft or Pending Review for Administrator publishing.
            </div>
          )}

          <div className="flex items-center gap-3">
            {editingId && (
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2.5 rounded-xl bg-white border border-slate-300 text-[#0c1a40] text-[15px] font-semibold cursor-pointer"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold flex items-center gap-2 cursor-pointer disabled:opacity-60"
            >
              <Plus className="w-4 h-4 text-amber-400" />
              <span>{saving ? 'Saving...' : editingId ? 'Save Changes' : 'Save Page Content'}</span>
            </button>
          </div>
        </div>
      </form>

      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search articles, events, or categories..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
          />
        </div>

        <select
          value={filterPage}
          onChange={(e) => {
            setFilterPage(e.target.value);
            setCurrentPage(1);
          }}
          className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px] font-medium text-[#0c1a40]"
        >
          <option value="all">All Pages ({items.length})</option>
          {PAGE_OPTIONS.map((p) => (
            <option key={p.key} value={p.key}>
              {p.label}
            </option>
          ))}
        </select>

        <select
          value={filterStatus}
          onChange={(e) => {
            setFilterStatus(e.target.value);
            setCurrentPage(1);
          }}
          className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px] font-medium text-[#0c1a40]"
        >
          <option value="all">All Statuses</option>
          <option value="published">Published</option>
          <option value="draft">Draft</option>
          <option value="pending">Pending Review</option>
          <option value="unpublished">Unpublished</option>
          <option value="archived">Archived</option>
        </select>
      </div>

      {/* Items List */}
      <div className="space-y-3">
        {paginatedItems.length === 0 ? (
          <div className="p-8 rounded-xl bg-slate-50 border border-slate-200 text-center text-[15px] text-slate-600">
            No articles or events match the selected filters.
          </div>
        ) : (
          paginatedItems.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-xl border border-slate-200 p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-4 min-w-0">
                {item.thumbnailUrl ? (
                  <img
                    src={item.thumbnailUrl}
                    alt={item.title}
                    className="w-20 h-16 rounded-lg object-cover border border-slate-200 shrink-0"
                  />
                ) : (
                  <div className="w-20 h-16 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center text-sm text-slate-400 shrink-0">
                    No Img
                  </div>
                )}
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-sm mb-1">
                    <span className="font-mono font-semibold text-slate-600">
                      /{item.pageKey}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span
                      className={`font-semibold capitalize ${
                        item.status === 'published'
                          ? 'text-emerald-700'
                          : item.status === 'pending'
                          ? 'text-amber-700'
                          : 'text-slate-600'
                      }`}
                    >
                      {item.status}
                    </span>
                    {item.featureOnHomepage && (
                      <>
                        <span className="text-slate-300">·</span>
                        <span className="inline-flex items-center gap-1 font-semibold text-amber-700">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" /> Homepage Featured
                        </span>
                      </>
                    )}
                  </div>
                  <h4 className="font-serif font-bold text-base text-[#0c1a40] truncate">
                    {item.title}
                  </h4>
                  <p className="text-[15px] text-slate-600 line-clamp-1 mt-0.5">{item.excerpt}</p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setPreviewItem(item)}
                  className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Eye className="w-4 h-4" /> Preview
                </button>

                <button
                  type="button"
                  onClick={() => handleEdit(item)}
                  className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Edit3 className="w-4 h-4" /> Edit
                </button>

                {isPublisher && (
                  <>
                    <button
                      type="button"
                      onClick={() => void handleToggleFeature(item)}
                      className={`px-3 py-2 rounded-lg text-sm font-semibold flex items-center gap-1.5 cursor-pointer ${
                        item.featureOnHomepage
                          ? 'bg-amber-400 text-[#081226]'
                          : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
                      }`}
                    >
                      <Star className="w-4 h-4" />
                      <span>{item.featureOnHomepage ? 'Unfeature Home' : 'Feature Home'}</span>
                    </button>

                    {item.status !== 'published' ? (
                      <button
                        type="button"
                        onClick={() => void handleStatusChange(item, 'published')}
                        className="px-3 py-2 rounded-lg bg-[#0c1a40] text-white text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4 text-amber-400" /> Publish
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => void handleStatusChange(item, 'unpublished')}
                        className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                      >
                        <EyeOff className="w-4 h-4" /> Unpublish
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => void handleStatusChange(item, 'archived')}
                      className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                      title="Archive item"
                    >
                      <Archive className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setConfirmDeleteItem(item)}
                      className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                      title="Delete item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </>
                )}

                {!isPublisher && item.status === 'draft' && (
                  <button
                    type="button"
                    onClick={() => void handleStatusChange(item, 'pending')}
                    className="px-3 py-2 rounded-lg bg-amber-400 text-[#081226] text-sm font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-4 h-4" /> Submit Review
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-[15px]">
          <span className="text-slate-600 tabular-nums">
            Showing {(safePage - 1) * ITEMS_PER_PAGE + 1}–{Math.min(safePage * ITEMS_PER_PAGE, visibleItems.length)} of {visibleItems.length}
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={safePage <= 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-[#0c1a40] font-semibold flex items-center gap-1 disabled:opacity-40 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" /> Prev
            </button>
            <span className="font-semibold text-[#0c1a40] px-2 tabular-nums">
              {safePage} / {totalPages}
            </span>
            <button
              type="button"
              disabled={safePage >= totalPages}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-[#0c1a40] font-semibold flex items-center gap-1 disabled:opacity-40 cursor-pointer"
            >
              Next <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Preview Modal */}
      {previewItem && (
        <div
          className="fixed inset-0 z-[75] bg-[#081226]/80 flex items-center justify-center p-4"
          onClick={() => setPreviewItem(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 relative text-[#0c1a40]"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setPreviewItem(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="text-sm font-mono uppercase text-amber-700 font-bold mb-2">
              CMS PREVIEW ({previewItem.status}) · /{previewItem.pageKey}
            </div>
            {previewItem.thumbnailUrl && (
              <img
                src={previewItem.thumbnailUrl}
                alt={previewItem.title}
                className="w-full h-56 object-cover rounded-xl mb-4 border border-slate-200"
              />
            )}
            <h3 className="font-serif font-bold text-2xl mb-2">{previewItem.title}</h3>
            <p className="text-base font-medium text-slate-800 mb-3">{previewItem.excerpt}</p>
            {typeof previewItem.content?.body === 'string' && (
              <p className="text-[15px] text-slate-700 whitespace-pre-line leading-relaxed">
                {previewItem.content.body}
              </p>
            )}
          </div>
        </div>
      )}

      <CmsConfirmModal
        open={Boolean(confirmDeleteItem)}
        title="Delete Article or Event?"
        message={
          confirmDeleteItem
            ? `Permanently delete "${confirmDeleteItem.title}" from /${confirmDeleteItem.pageKey}? This action cannot be undone.`
            : ''
        }
        confirmLabel="Delete Item"
        onConfirm={() => {
          if (confirmDeleteItem) void handleDelete(confirmDeleteItem);
        }}
        onCancel={() => setConfirmDeleteItem(null)}
      />
    </div>
  );
};
