import React, { useMemo, useState } from 'react';
import {
  Upload,
  Trash2,
  Copy,
  Check,
  Search,
  Video,
  FileText,
  Image as ImageIcon,
  Eye,
  X,
  UserCheck,
  ZoomIn,
  ZoomOut,
  RotateCcw,
} from 'lucide-react';
import {
  uploadMediaFile,
  addMediaEmbed,
  updateMediaAsset,
  deleteMediaAssetById,
  useAcademicLeadership,
  useCmsSection,
  type ApiError,
} from '../../services/cmsDataService';
import type { CmsUser, MediaAsset } from '../../types';
import { CmsConfirmModal } from './CmsConfirmModal';
import { matchesSearchTokens } from '../../utils/profileSearch';
import {
  assignPortraitToUnifiedProfile,
  buildUnifiedProfileDirectory,
  type UnifiedProfileEntry,
} from '../../utils/profileDirectory';

interface CmsMediaLibraryTabProps {
  media: MediaAsset[];
  currentUser: CmsUser;
  onRefresh: () => Promise<void>;
  onNotify: (msg: string) => void;
}

export const CmsMediaLibraryTab: React.FC<CmsMediaLibraryTabProps> = ({
  media,
  currentUser,
  onRefresh,
  onNotify,
}) => {
  const canDelete = currentUser.role === 'super_admin' || currentUser.role === 'admin';

  const academicLeadership = useAcademicLeadership();
  const teachers = useCmsSection('teachers');
  const departments = useCmsSection('departments');
  const about = useCmsSection('about');
  const boarding = useCmsSection('boarding');

  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [uploading, setUploading] = useState(false);
  const [uploadName, setUploadName] = useState('');
  const [uploadCategory, setUploadCategory] = useState('Academics');
  const [uploadDesc, setUploadDesc] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [lastUploadedAsset, setLastUploadedAsset] = useState<MediaAsset | null>(null);

  const [embedName, setEmbedName] = useState('');
  const [embedUrl, setEmbedUrl] = useState('');
  const [embedCategory, setEmbedCategory] = useState('Video & Embeds');

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [previewAsset, setPreviewAsset] = useState<MediaAsset | null>(null);
  const [previewZoom, setPreviewZoom] = useState<number>(1);
  const [editingAsset, setEditingAsset] = useState<MediaAsset | null>(null);

  const [assignAsset, setAssignAsset] = useState<MediaAsset | null>(null);
  const [profileSearch, setProfileSearch] = useState('');
  const [missingPortraitOnly, setMissingPortraitOnly] = useState(false);
  const [assigningUid, setAssigningUid] = useState<string | null>(null);

  const [confirmForceDelete, setConfirmForceDelete] = useState<{
    asset: MediaAsset;
    usedIn: string[];
  } | null>(null);
  const [confirmDeleteAsset, setConfirmDeleteAsset] = useState<MediaAsset | null>(null);
  const [error, setError] = useState<string | null>(null);

  const allProfiles = useMemo(
    () =>
      buildUnifiedProfileDirectory({
        academicLeadership,
        teachers,
        departments,
        about,
        boarding,
      }),
    [academicLeadership, teachers, departments, about, boarding]
  );

  const filteredProfiles = useMemo(
    () =>
      allProfiles.filter((entry) => {
        if (missingPortraitOnly && !entry.missingPortrait) return false;
        return matchesSearchTokens(profileSearch, [
          entry.name,
          entry.surname,
          entry.role,
          entry.department,
          entry.kindLabel,
          ...entry.searchFields,
        ]);
      }),
    [allProfiles, missingPortraitOnly, profileSearch]
  );

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;
    setUploading(true);
    setError(null);
    try {
      const asset = await uploadMediaFile(selectedFile, {
        name: uploadName.trim() || selectedFile.name,
        category: uploadCategory,
        description: uploadDesc.trim(),
      });
      setSelectedFile(null);
      setUploadName('');
      setUploadDesc('');
      setLastUploadedAsset(asset);
      onNotify('Media file uploaded to persistent server disk storage.');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const handleAssignPortrait = async (entry: UnifiedProfileEntry) => {
    if (!assignAsset) return;
    setAssigningUid(entry.uid);
    setError(null);
    try {
      const targets = await assignPortraitToUnifiedProfile(entry, assignAsset.url);
      onNotify(`Assigned "${assignAsset.name}" portrait to ${targets.join(' & ')}.`);
      setAssignAsset(null);
      setProfileSearch('');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to assign portrait to profile.');
    } finally {
      setAssigningUid(null);
    }
  };

  const handleAddEmbed = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!embedName.trim() || !embedUrl.trim()) return;
    setError(null);
    try {
      await addMediaEmbed({
        name: embedName.trim(),
        url: embedUrl.trim(),
        category: embedCategory,
        mediaType: 'embed',
      });
      setEmbedName('');
      setEmbedUrl('');
      onNotify('Video / external media link added to Media Library.');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add embed.');
    }
  };

  const handleSaveMeta = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAsset) return;
    try {
      await updateMediaAsset(editingAsset.id, {
        name: editingAsset.name,
        category: editingAsset.category,
        description: editingAsset.description,
      });
      setEditingAsset(null);
      onNotify('Media metadata updated.');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update media metadata.');
    }
  };

  const executeDelete = async (asset: MediaAsset, force = false) => {
    setError(null);
    try {
      await deleteMediaAssetById(asset.id, force);
      setConfirmDeleteAsset(null);
      setConfirmForceDelete(null);
      onNotify(`Removed '${asset.name}' from Media Library.`);
      await onRefresh();
    } catch (err) {
      const apiErr = err as ApiError;
      if (!force && apiErr.status === 409 && apiErr.usedIn && apiErr.usedIn.length > 0) {
        setConfirmDeleteAsset(null);
        setConfirmForceDelete({ asset, usedIn: apiErr.usedIn });
        return;
      }
      setConfirmDeleteAsset(null);
      setError(err instanceof Error ? err.message : 'Failed to delete asset.');
    }
  };

  const handleCopy = (asset: MediaAsset) => {
    navigator.clipboard.writeText(asset.url);
    setCopiedId(asset.id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const categories = Array.from(new Set(media.map((m) => m.category)));
  const filtered = media.filter((m) => {
    const matchesCat = categoryFilter === 'all' || m.category === categoryFilter;
    const matchesQuery = matchesSearchTokens(search, [
      m.name,
      m.description,
      m.category,
      m.filename,
      m.url,
      m.usedIn,
    ]);
    return matchesCat && matchesQuery;
  });

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-200">
        <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
          Media Library & Portrait Assignments
        </h3>
        <p className="text-[15px] text-slate-600 mt-1">
          Upload images, videos, or documents to persistent storage and assign uploaded portraits directly to any Teacher, HOD, SMT Leader, Director, or Year-Group Staff profile.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-[15px] text-red-800">
          {error}
        </div>
      )}

      {lastUploadedAsset && (!lastUploadedAsset.mediaType || lastUploadedAsset.mediaType === 'image') && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src={lastUploadedAsset.url}
              alt={lastUploadedAsset.name}
              className="w-12 h-14 rounded-lg object-cover object-top border border-amber-400 shrink-0"
            />
            <div>
              <div className="font-bold text-[#0c1a40] text-[15px]">
                Uploaded: {lastUploadedAsset.name}
              </div>
              <div className="text-sm text-slate-700">
                Assign this portrait directly to any staff or faculty profile now.
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setAssignAsset(lastUploadedAsset);
                setProfileSearch('');
              }}
              className="px-4 py-2 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <UserCheck className="w-4 h-4 text-amber-400" />
              <span>Assign to Staff / Teacher Profile</span>
            </button>
            <button
              type="button"
              onClick={() => setLastUploadedAsset(null)}
              className="p-2 rounded-lg text-slate-600 hover:bg-amber-100 cursor-pointer"
              aria-label="Dismiss upload banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <form
          onSubmit={handleUpload}
          className="bg-slate-50 rounded-xl border border-slate-200 p-5 space-y-3.5 text-[15px]"
        >
          <div className="font-bold text-[#0c1a40] text-base flex items-center gap-2">
            <Upload className="w-4 h-4 text-amber-600" />
            <span>Upload File / Portrait to Server Storage</span>
          </div>
          <input
            type="file"
            accept=".jpg,.jpeg,.png,.webp,.gif,.mp4,.webm,.mov,.pdf,.doc,.docx"
            onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
            className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              value={uploadName}
              onChange={(e) => setUploadName(e.target.value)}
              placeholder="Staff / image title (e.g. Mrs Tsetse)"
              className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
            />
            <select
              value={uploadCategory}
              onChange={(e) => setUploadCategory(e.target.value)}
              className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
            >
              <option value="Academics">Academics & Teachers</option>
              <option value="Boarding & Staff">Boarding & Leadership</option>
              <option value="Campus">Campus</option>
              <option value="Sports">Sports & Athletics</option>
              <option value="Achievers">Top Achievers</option>
              <option value="Fees">Fees & Policy</option>
              <option value="News & Events">News & Events</option>
            </select>
          </div>
          <input
            type="text"
            value={uploadDesc}
            onChange={(e) => setUploadDesc(e.target.value)}
            placeholder="Brief description or department note..."
            className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <button
            type="submit"
            disabled={!selectedFile || uploading}
            className="px-5 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-semibold disabled:opacity-50 cursor-pointer"
          >
            {uploading ? 'Uploading...' : 'Upload & Save to Library'}
          </button>
        </form>

        <form
          onSubmit={handleAddEmbed}
          className="bg-slate-50 rounded-xl border border-slate-200 p-5 space-y-3.5 text-[15px]"
        >
          <div className="font-bold text-[#0c1a40] text-base flex items-center gap-2">
            <Video className="w-4 h-4 text-amber-600" />
            <span>Register External Video / Document Link</span>
          </div>
          <input
            type="text"
            required
            value={embedName}
            onChange={(e) => setEmbedName(e.target.value)}
            placeholder="Media / Video Title"
            className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <input
            type="url"
            required
            value={embedUrl}
            onChange={(e) => setEmbedUrl(e.target.value)}
            placeholder="https://youtube.com/... or https://..."
            className="w-full p-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <div className="flex flex-wrap items-center justify-between gap-3">
            <select
              value={embedCategory}
              onChange={(e) => setEmbedCategory(e.target.value)}
              className="p-2.5 rounded-lg border border-slate-300 bg-white flex-1 text-[15px]"
            >
              <option value="Video & Embeds">Video & Embeds</option>
              <option value="Campus">Campus</option>
              <option value="Sports">Sports</option>
            </select>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold cursor-pointer"
            >
              Add Video Link
            </button>
          </div>
        </form>
      </div>

      {/* Filter */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search uploaded files by name, surname, category, filename..."
            className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px]"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0c1a40] cursor-pointer"
              aria-label="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="px-4 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px] font-medium"
        >
          <option value="all">All Categories ({media.length})</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="p-10 text-center rounded-xl bg-slate-50 border border-slate-200 space-y-2">
          <p className="font-semibold text-[#0c1a40]">
            No media assets match "{search}" {categoryFilter !== 'all' ? `in ${categoryFilter}` : ''}.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearch('');
              setCategoryFilter('all');
            }}
            className="px-4 py-2 rounded-lg bg-[#0c1a40] text-white text-sm font-semibold cursor-pointer"
          >
            Reset Media Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((asset) => {
            const isImg = asset.mediaType === 'image' || !asset.mediaType;
            return (
              <div
                key={asset.id}
                className="bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col justify-between"
              >
                <div>
                  <div
                    onClick={() => {
                      setPreviewAsset(asset);
                      setPreviewZoom(1);
                    }}
                    className="h-52 bg-[#081226] flex items-center justify-center overflow-hidden relative cursor-zoom-in group"
                  >
                    {isImg ? (
                      <img
                        src={asset.url}
                        alt={asset.name}
                        className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : asset.mediaType === 'video' ? (
                      <Video className="w-10 h-10 text-amber-400" />
                    ) : (
                      <FileText className="w-10 h-10 text-amber-300" />
                    )}
                    <span className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded bg-[#0c1a40]/90 text-amber-300 text-xs font-mono font-bold uppercase">
                      {asset.mediaType || 'image'}
                    </span>
                  </div>
                  <div className="p-4 text-[15px]">
                    <div className="text-sm font-semibold text-amber-700">
                      {asset.category} · {asset.uploadedAt}
                    </div>
                    <h4 className="font-serif font-bold text-[17px] text-[#0c1a40] truncate mt-1">
                      {asset.name}
                    </h4>
                    {asset.description && (
                      <p className="text-sm text-slate-600 line-clamp-2 mt-1">
                        {asset.description}
                      </p>
                    )}
                    <div className="mt-2.5 font-mono text-xs text-slate-700 truncate bg-slate-100 px-2.5 py-1.5 rounded-lg">
                      {asset.url}
                    </div>
                    {asset.usedIn && asset.usedIn.length > 0 && (
                      <div className="mt-2 text-sm text-amber-800 font-medium">
                        Used in {asset.usedIn.length}: {asset.usedIn.slice(0, 2).join(', ')}
                        {asset.usedIn.length > 2 ? ` +${asset.usedIn.length - 2}` : ''}
                      </div>
                    )}
                  </div>
                </div>

                <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-sm">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {isImg && (
                      <button
                        type="button"
                        onClick={() => {
                          setAssignAsset(asset);
                          setProfileSearch('');
                        }}
                        className="px-2.5 py-1.5 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white font-semibold flex items-center gap-1.5 cursor-pointer"
                        title="Assign this image to any Teacher, HOD, SMT, Director or Staff profile"
                      >
                        <UserCheck className="w-3.5 h-3.5 text-amber-400" /> Assign Profile
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleCopy(asset)}
                      className="px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 text-[#0c1a40] font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      {copiedId === asset.id ? (
                        <>
                          <Check className="w-4 h-4 text-emerald-600" /> Copied
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" /> URL
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPreviewAsset(asset);
                        setPreviewZoom(1);
                      }}
                      className="p-1.5 rounded-lg bg-white border border-slate-300 text-[#0c1a40] cursor-pointer"
                      title="Open large preview"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingAsset({ ...asset })}
                      className="px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 text-[#0c1a40] font-semibold cursor-pointer"
                    >
                      Edit
                    </button>
                  </div>

                  {canDelete && (
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteAsset(asset)}
                      className="p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                      title="Delete asset"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Large Preview Modal */}
      {previewAsset && (
        <div
          className="fixed inset-0 z-[75] bg-[#081226]/92 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4"
          onClick={() => setPreviewAsset(null)}
        >
          <div
            className="bg-[#0c1a40] rounded-2xl max-w-[96vw] sm:max-w-[92vw] w-full h-[92vh] max-h-[92vh] shadow-2xl border border-blue-800 overflow-hidden flex flex-col text-white"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 sm:px-6 py-3 bg-[#081226] border-b border-blue-900 flex flex-wrap items-center justify-between gap-3 shrink-0">
              <div className="min-w-0">
                <div className="text-xs font-mono text-amber-400 uppercase">{previewAsset.category}</div>
                <h4 className="font-serif font-bold text-lg sm:text-xl text-white truncate">
                  {previewAsset.name}
                </h4>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {(!previewAsset.mediaType || previewAsset.mediaType === 'image') && (
                  <>
                    <div className="flex items-center bg-[#0c1a40] border border-blue-800 rounded-lg p-1 gap-1">
                      <button
                        type="button"
                        onClick={() => setPreviewZoom((z) => Math.max(0.5, Number((z - 0.25).toFixed(2))))}
                        className="p-1.5 rounded text-blue-200 hover:text-white cursor-pointer"
                        title="Zoom Out"
                      >
                        <ZoomOut className="w-4 h-4" />
                      </button>
                      <span className="text-xs font-mono font-bold text-amber-300 px-1.5 min-w-[46px] text-center">
                        {Math.round(previewZoom * 100)}%
                      </span>
                      <button
                        type="button"
                        onClick={() => setPreviewZoom((z) => Math.min(4, Number((z + 0.25).toFixed(2))))}
                        className="p-1.5 rounded text-blue-200 hover:text-white cursor-pointer"
                        title="Zoom In"
                      >
                        <ZoomIn className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setPreviewZoom(1)}
                        className="p-1.5 rounded text-blue-200 hover:text-white cursor-pointer"
                        title="Reset Zoom"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const target = previewAsset;
                        setPreviewAsset(null);
                        setAssignAsset(target);
                        setProfileSearch('');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-[#081226] text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <UserCheck className="w-3.5 h-3.5" /> Assign to Profile
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => setPreviewAsset(null)}
                  className="p-1.5 rounded-lg bg-blue-900/60 hover:bg-blue-800 text-blue-200 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 min-h-0 overflow-auto bg-[#060f21] flex items-center justify-center p-4">
              {previewAsset.mediaType === 'image' || !previewAsset.mediaType ? (
                <img
                  src={previewAsset.url}
                  alt={previewAsset.name}
                  style={{
                    transform: `scale(${previewZoom})`,
                    transformOrigin: 'center center',
                  }}
                  className="h-[74vh] w-auto max-w-[88vw] object-contain rounded-xl shadow-2xl transition-transform duration-150"
                />
              ) : previewAsset.mediaType === 'video' ? (
                <video src={previewAsset.url} controls className="w-full h-[74vh] max-w-5xl rounded-xl" />
              ) : (
                <div className="p-8 bg-white text-[#0c1a40] rounded-xl text-center space-y-3 text-[15px] max-w-lg">
                  <ImageIcon className="w-10 h-10 text-[#0c1a40] mx-auto" />
                  <div>Asset URL: <code className="break-all">{previewAsset.url}</code></div>
                  <a
                    href={previewAsset.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block px-4 py-2.5 bg-[#0c1a40] text-white rounded-xl font-semibold"
                  >
                    Open Document / Media in New Tab ↗
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Assign Portrait to Searched Profile Modal */}
      {assignAsset && (
        <div
          className="fixed inset-0 z-[80] bg-[#081226]/85 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setAssignAsset(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-4xl w-full max-h-[88vh] flex flex-col overflow-hidden border border-slate-200 shadow-2xl text-[#0c1a40]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 bg-[#0c1a40] text-white flex items-center justify-between gap-4">
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={assignAsset.url}
                  alt={assignAsset.name}
                  className="w-12 h-14 rounded-lg object-cover object-top border border-amber-400 shrink-0"
                />
                <div className="min-w-0">
                  <h4 className="font-serif font-bold text-xl truncate">
                    Assign Portrait: {assignAsset.name}
                  </h4>
                  <p className="text-sm text-amber-300">
                    Search any Teacher, HOD, SMT Leader, Director, Boarding, or Year-Group Staff profile ({allProfiles.length} total)
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setAssignAsset(null)}
                className="p-2 rounded-lg hover:bg-white/10 text-white cursor-pointer"
                aria-label="Close assign modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="px-6 py-3.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center gap-3">
              <div className="relative flex-1 min-w-[240px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  autoFocus
                  value={profileSearch}
                  onChange={(e) => setProfileSearch(e.target.value)}
                  placeholder="Search profile by name, surname, role, or department (e.g. Tsetse, Otimile, Matlotse)..."
                  className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
                />
                {profileSearch && (
                  <button
                    type="button"
                    onClick={() => setProfileSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0c1a40] cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              <label className="flex items-center gap-2 font-semibold text-sm cursor-pointer px-3.5 py-2.5 rounded-xl bg-amber-50 border border-amber-200">
                <input
                  type="checkbox"
                  checked={missingPortraitOnly}
                  onChange={(e) => setMissingPortraitOnly(e.target.checked)}
                  className="w-4 h-4 accent-[#0c1a40]"
                />
                <span>Missing Portrait Only ({allProfiles.filter((p) => p.missingPortrait).length})</span>
              </label>
            </div>

            <div className="p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {filteredProfiles.length === 0 ? (
                <div className="col-span-full py-10 text-center space-y-2 text-[15px] text-slate-600">
                  <p>No profiles match "{profileSearch}".</p>
                  {missingPortraitOnly && (
                    <button
                      type="button"
                      onClick={() => setMissingPortraitOnly(false)}
                      className="px-4 py-2 rounded-lg bg-[#0c1a40] text-white text-sm font-semibold cursor-pointer"
                    >
                      Show All Profiles (Including Existing Portraits)
                    </button>
                  )}
                </div>
              ) : (
                filteredProfiles.map((entry) => (
                  <div
                    key={entry.uid}
                    className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-[#0c1a40] flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {!entry.missingPortrait ? (
                        <img
                          src={entry.image}
                          alt={entry.name}
                          className="w-12 h-14 rounded-lg object-cover object-top border border-amber-400 shrink-0"
                        />
                      ) : (
                        <div className="w-12 h-14 rounded-lg bg-slate-100 border border-slate-300 flex items-center justify-center font-serif font-bold text-[#0c1a40] shrink-0">
                          {entry.surname.slice(0, 2).toUpperCase()}
                        </div>
                      )}
                      <div className="min-w-0">
                        <div className="font-serif font-bold text-base text-[#0c1a40] truncate">
                          {entry.name}
                        </div>
                        <div className="text-xs font-semibold text-amber-700 truncate">
                          {entry.kindLabel} · {entry.department}
                        </div>
                        <div className="text-xs text-slate-600 truncate">{entry.role}</div>
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={assigningUid === entry.uid}
                      onClick={() => void handleAssignPortrait(entry)}
                      className="px-3.5 py-2 rounded-lg bg-[#0c1a40] hover:bg-[#162a6b] text-white text-sm font-semibold shrink-0 cursor-pointer disabled:opacity-50"
                    >
                      {assigningUid === entry.uid ? 'Saving...' : 'Assign'}
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Edit Metadata Modal */}
      {editingAsset && (
        <div
          className="fixed inset-0 z-[75] bg-[#081226]/80 flex items-center justify-center p-4"
          onClick={() => setEditingAsset(null)}
        >
          <form
            onSubmit={handleSaveMeta}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 text-[15px] text-[#0c1a40]"
          >
            <h4 className="font-serif font-bold text-xl">Edit Media Details</h4>
            <div>
              <label className="block font-semibold mb-1.5">Display Name</label>
              <input
                type="text"
                required
                value={editingAsset.name}
                onChange={(e) => setEditingAsset({ ...editingAsset, name: e.target.value })}
                className="w-full p-2.5 rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1.5">Category</label>
              <input
                type="text"
                required
                value={editingAsset.category}
                onChange={(e) => setEditingAsset({ ...editingAsset, category: e.target.value })}
                className="w-full p-2.5 rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1.5">Description</label>
              <textarea
                rows={2}
                value={editingAsset.description || ''}
                onChange={(e) =>
                  setEditingAsset({ ...editingAsset, description: e.target.value })
                }
                className="w-full p-2.5 rounded-lg border border-slate-300"
              />
            </div>
            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setEditingAsset(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-[#0c1a40] text-white font-semibold cursor-pointer"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}

      <CmsConfirmModal
        open={Boolean(confirmDeleteAsset)}
        title="Delete Media Asset?"
        message={
          confirmDeleteAsset
            ? `Remove "${confirmDeleteAsset.name}" from the LKC Media Library?`
            : ''
        }
        confirmLabel="Delete Asset"
        onConfirm={() => {
          if (confirmDeleteAsset) void executeDelete(confirmDeleteAsset, false);
        }}
        onCancel={() => setConfirmDeleteAsset(null)}
      />

      <CmsConfirmModal
        open={Boolean(confirmForceDelete)}
        title="Asset Currently In Use"
        message={
          confirmForceDelete
            ? `"${confirmForceDelete.asset.name}" is currently referenced in:\n• ${confirmForceDelete.usedIn.join('\n• ')}\n\nDelete this asset anyway?`
            : ''
        }
        confirmLabel="Force Delete Asset"
        onConfirm={() => {
          if (confirmForceDelete) void executeDelete(confirmForceDelete.asset, true);
        }}
        onCancel={() => setConfirmForceDelete(null)}
      />
    </div>
  );
};
