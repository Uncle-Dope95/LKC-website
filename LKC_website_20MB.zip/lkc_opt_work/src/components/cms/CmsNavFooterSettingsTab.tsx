import React, { useEffect, useState } from 'react';
import { Save, ArrowUp, ArrowDown, Globe, Menu, RotateCcw } from 'lucide-react';
import type { CmsDatabase } from '../../services/cmsDataService';
import type { FooterConfig, NavigationItemConfig, WebsiteSettingsConfig } from '../../types';

interface CmsNavFooterSettingsTabProps {
  navigation: NavigationItemConfig[];
  footer: FooterConfig;
  settings: WebsiteSettingsConfig;
  onSaveSection: <K extends keyof CmsDatabase>(section: K, data: CmsDatabase[K], label: string) => Promise<void>;
}

export const CmsNavFooterSettingsTab: React.FC<CmsNavFooterSettingsTabProps> = ({
  navigation,
  footer,
  settings,
  onSaveSection,
}) => {
  const [navState, setNavState] = useState<NavigationItemConfig[]>(() =>
    [...navigation].sort((a, b) => a.order - b.order)
  );
  const [footerState, setFooterState] = useState<FooterConfig>({ ...footer });
  const [settingsState, setSettingsState] = useState<WebsiteSettingsConfig>({ ...settings });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setNavState([...navigation].sort((a, b) => a.order - b.order));
    setFooterState({ ...footer });
    setSettingsState({ ...settings });
  }, [navigation, footer, settings]);

  const isDirty =
    JSON.stringify(navState) !== JSON.stringify([...navigation].sort((a, b) => a.order - b.order)) ||
    JSON.stringify(footerState) !== JSON.stringify(footer) ||
    JSON.stringify(settingsState) !== JSON.stringify(settings);

  const handleDiscard = () => {
    setNavState([...navigation].sort((a, b) => a.order - b.order));
    setFooterState({ ...footer });
    setSettingsState({ ...settings });
  };

  const moveNav = (idx: number, dir: -1 | 1) => {
    const target = idx + dir;
    if (target < 0 || target >= navState.length) return;
    const copy = [...navState];
    const tmp = copy[idx];
    copy[idx] = copy[target];
    copy[target] = tmp;
    const reordered = copy.map((item, i) => ({ ...item, order: i + 1 }));
    setNavState(reordered);
  };

  const handleSaveAll = async () => {
    setSaving(true);
    try {
      await onSaveSection('navigation', navState, 'Navigation Menu');
      await onSaveSection('footer', footerState, 'Footer Configuration');
      await onSaveSection('settings', settingsState, 'Website Settings');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 text-[15px] text-[#0c1a40]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
            Navigation Menu, Footer & Global Settings
          </h3>
          <p className="text-[15px] text-slate-600 mt-1">
            Control top header labels, visibility and ordering, footer copy, admissions status, and active achievers academic year.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          {isDirty && (
            <button
              type="button"
              onClick={handleDiscard}
              className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-[15px] font-semibold flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Discard Changes</span>
            </button>
          )}
          <button
            type="button"
            disabled={saving}
            onClick={() => void handleSaveAll()}
            className="px-5 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold flex items-center gap-2 cursor-pointer disabled:opacity-60"
          >
            <Save className="w-4 h-4 text-amber-400" />
            <span>{saving ? 'Saving...' : 'Save Navigation & Settings'}</span>
          </button>
        </div>
      </div>

      {/* Website Settings */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
        <div className="flex items-center gap-2 font-serif text-lg font-bold text-[#0c1a40]">
          <Globe className="w-5 h-5 text-amber-600" />
          <span>Global Website Settings</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
              Website HTML Title
            </label>
            <input
              type="text"
              value={settingsState.siteTitle}
              onChange={(e) => setSettingsState({ ...settingsState, siteTitle: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
            />
          </div>
          <div>
            <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
              Active Achievers Showcase Year
            </label>
            <input
              type="text"
              value={settingsState.activeAchieversYear}
              onChange={(e) =>
                setSettingsState({ ...settingsState, activeAchieversYear: e.target.value })
              }
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center pt-1">
          <div>
            <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
              Max Homepage Featured Cards
            </label>
            <input
              type="number"
              min={1}
              max={12}
              value={settingsState.homepageMaxFeaturedItems}
              onChange={(e) =>
                setSettingsState({
                  ...settingsState,
                  homepageMaxFeaturedItems: Number(e.target.value || 6),
                })
              }
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] tabular-nums"
            />
          </div>
          <label className="flex items-center gap-2.5 font-semibold text-[15px] cursor-pointer md:pt-6">
            <input
              type="checkbox"
              className="w-4 h-4 accent-[#0c1a40]"
              checked={settingsState.admissionsOpen}
              onChange={(e) =>
                setSettingsState({ ...settingsState, admissionsOpen: e.target.checked })
              }
            />
            <span>Admissions Open Banner Active</span>
          </label>
          <label className="flex items-center gap-2.5 font-semibold text-[15px] cursor-pointer md:pt-6">
            <input
              type="checkbox"
              className="w-4 h-4 accent-[#0c1a40]"
              checked={settingsState.allowPublicAlumniRegistration}
              onChange={(e) =>
                setSettingsState({
                  ...settingsState,
                  allowPublicAlumniRegistration: e.target.checked,
                })
              }
            />
            <span>Allow Public Alumni Registration</span>
          </label>
        </div>
      </div>

      {/* Navigation Items Editor */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
        <div className="flex items-center gap-2 font-serif text-lg font-bold text-[#0c1a40]">
          <Menu className="w-5 h-5 text-amber-600" />
          <span>Header Navigation Manager</span>
        </div>

        <div className="space-y-2.5">
          {navState.map((item, idx) => (
            <div
              key={item.id}
              className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center p-3.5 rounded-xl bg-slate-50 border border-slate-200"
            >
              <div className="sm:col-span-3 font-mono font-semibold text-sm text-[#0c1a40]">
                /{item.pageKey}
              </div>
              <div className="sm:col-span-3">
                <input
                  type="text"
                  value={item.label}
                  onChange={(e) =>
                    setNavState((prev) =>
                      prev.map((n, i) => (i === idx ? { ...n, label: e.target.value } : n))
                    )
                  }
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-[15px]"
                />
              </div>
              <div className="sm:col-span-2">
                <input
                  type="text"
                  value={item.sublabel}
                  onChange={(e) =>
                    setNavState((prev) =>
                      prev.map((n, i) => (i === idx ? { ...n, sublabel: e.target.value } : n))
                    )
                  }
                  placeholder="Sublabel"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-[15px]"
                />
              </div>
              <div className="sm:col-span-2">
                <input
                  type="text"
                  value={item.badge || ''}
                  onChange={(e) =>
                    setNavState((prev) =>
                      prev.map((n, i) => (i === idx ? { ...n, badge: e.target.value } : n))
                    )
                  }
                  placeholder="Badge (optional)"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-[15px]"
                />
              </div>
              <div className="sm:col-span-2 flex items-center justify-end gap-2">
                <label className="flex items-center gap-1.5 text-sm font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-4 h-4 accent-[#0c1a40]"
                    checked={item.visible}
                    onChange={(e) =>
                      setNavState((prev) =>
                        prev.map((n, i) => (i === idx ? { ...n, visible: e.target.checked } : n))
                      )
                    }
                  />
                  <span>Show</span>
                </label>
                <button
                  type="button"
                  onClick={() => moveNav(idx, -1)}
                  className="p-2 rounded-lg bg-white hover:bg-slate-100 border border-slate-300 cursor-pointer"
                  aria-label="Move up"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => moveNav(idx, 1)}
                  className="p-2 rounded-lg bg-white hover:bg-slate-100 border border-slate-300 cursor-pointer"
                  aria-label="Move down"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer Config */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
        <div className="font-serif text-lg font-bold text-[#0c1a40]">
          Footer Manager
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
              Copyright Text
            </label>
            <input
              type="text"
              value={footerState.copyrightText}
              onChange={(e) =>
                setFooterState({ ...footerState, copyrightText: e.target.value })
              }
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
            />
          </div>
          <div>
            <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
              Bottom Notice
            </label>
            <input
              type="text"
              value={footerState.bottomNotice}
              onChange={(e) =>
                setFooterState({ ...footerState, bottomNotice: e.target.value })
              }
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
            />
          </div>
        </div>
        <div>
          <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
            Footer Mission / Tagline
          </label>
          <textarea
            rows={2}
            value={footerState.tagline}
            onChange={(e) => setFooterState({ ...footerState, tagline: e.target.value })}
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
        </div>
        <label className="flex items-center gap-2.5 font-semibold text-[15px] cursor-pointer">
          <input
            type="checkbox"
            className="w-4 h-4 accent-[#0c1a40]"
            checked={footerState.showSocialLinks}
            onChange={(e) =>
              setFooterState({ ...footerState, showSocialLinks: e.target.checked })
            }
          />
          <span>Display Social Media Channels in Footer</span>
        </label>
      </div>
    </div>
  );
};
