import React, { useState, useEffect } from 'react';
import {
  FileText,
  Sparkles,
  Users,
  GraduationCap,
  Image as ImageIcon,
  Mail,
  Calendar,
  Activity,
  RefreshCw,
  Award,
  Layers,
} from 'lucide-react';
import { fetchAdminOverview, fetchEnquiriesAndTours } from '../../services/cmsDataService';
import type { AuditLogEntry, CmsUser } from '../../types';

interface CmsOverviewTabProps {
  currentUser: CmsUser;
  onSelectTab: (tab: string) => void;
}

export const CmsOverviewTab: React.FC<CmsOverviewTabProps> = ({
  currentUser,
  onSelectTab,
}) => {
  const [loading, setLoading] = useState(true);
  const [counts, setCounts] = useState<{
    totalItems: number;
    publishedItems: number;
    draftItems: number;
    pendingItems: number;
    unpublishedItems: number;
    archivedItems: number;
    featuredOnHomepage: number;
    upcomingEventsCount: number;
    announcementsCount: number;
    departments: number;
    teachers: number;
    staffCount: number;
    incompleteStaffCount: number;
    headsOfYearCount: number;
    coordinatorsCount: number;
    pastoralCount: number;
    usersCount: number;
    alumniPending: number;
    alumniApproved: number;
    mediaCount: number;
    enquiriesCount: number;
    toursCount: number;
  } | null>(null);
  const [recentLogs, setRecentLogs] = useState<AuditLogEntry[]>([]);
  const [enquiries, setEnquiries] = useState<
    { id: string; type: string; payload: Record<string, unknown>; status: string; createdAt: string }[]
  >([]);

  const loadOverview = async () => {
    setLoading(true);
    try {
      const ov = await fetchAdminOverview();
      setCounts(ov.counts);
      setRecentLogs(ov.recentAuditLogs || []);
      if (currentUser.role === 'super_admin' || currentUser.role === 'admin') {
        const sub = await fetchEnquiriesAndTours();
        setEnquiries(sub.enquiries.slice(0, 10));
      }
    } catch {
      // Handled gracefully
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadOverview();
  }, []);

  if (loading || !counts) {
    return (
      <div className="p-12 text-center text-base text-slate-600">
        Loading live CMS database overview...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
            School Administration Dashboard Overview
          </h3>
          <p className="text-[15px] text-slate-600 mt-1">
            Signed in as <strong className="text-[#0c1a40]">{currentUser.fullName}</strong> (
            {currentUser.username ? `@${currentUser.username} · ` : ''}
            {currentUser.role.replace('_', ' ').toUpperCase()})
          </p>
        </div>
        <button
          type="button"
          onClick={() => void loadOverview()}
          className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-[15px] font-semibold flex items-center gap-2 border border-slate-200 cursor-pointer shrink-0"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Refresh Stats</span>
        </button>
      </div>

      {/* Stat Cards (Max 4 metrics, crisp tabular numerals) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <button
          type="button"
          onClick={() => onSelectTab('items')}
          className="p-5 rounded-xl bg-white border border-slate-200 text-left hover:border-amber-400 transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between text-[15px] font-semibold text-slate-600 mb-2">
            <span>Published Articles & Events</span>
            <FileText className="w-5 h-5 text-[#0c1a40]" />
          </div>
          <div className="text-3xl font-serif font-bold text-[#0c1a40] tabular-nums">
            {counts.publishedItems}
          </div>
          <div className="text-sm text-slate-600 mt-1.5 tabular-nums">
            {counts.draftItems} draft · {counts.pendingItems} pending review
          </div>
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('items')}
          className="p-5 rounded-xl bg-amber-50/70 border border-amber-200 text-left hover:border-[#0c1a40] transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between text-[15px] font-semibold text-amber-900 mb-2">
            <span>Featured on Homepage</span>
            <Sparkles className="w-5 h-5 text-amber-600" />
          </div>
          <div className="text-3xl font-serif font-bold text-[#0c1a40] tabular-nums">
            {counts.featuredOnHomepage}
          </div>
          <div className="text-sm text-amber-900 mt-1.5 tabular-nums">
            {counts.announcementsCount} active campus notices
          </div>
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('academic_leadership')}
          className="p-5 rounded-xl bg-white border border-slate-200 text-left hover:border-amber-400 transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between text-[15px] font-semibold text-slate-600 mb-2">
            <span>Academic & Pastoral</span>
            <Award className="w-5 h-5 text-[#0c1a40]" />
          </div>
          <div className="text-3xl font-serif font-bold text-[#0c1a40] tabular-nums">
            {counts.headsOfYearCount + counts.coordinatorsCount + counts.pastoralCount}
          </div>
          <div className="text-sm text-slate-600 mt-1.5 tabular-nums">
            {counts.headsOfYearCount} HOYs · {counts.staffCount} staff ({counts.incompleteStaffCount} pending photo)
          </div>
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('media')}
          className="p-5 rounded-xl bg-white border border-slate-200 text-left hover:border-amber-400 transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between text-[15px] font-semibold text-slate-600 mb-2">
            <span>Media Library Assets</span>
            <ImageIcon className="w-5 h-5 text-[#0c1a40]" />
          </div>
          <div className="text-3xl font-serif font-bold text-[#0c1a40] tabular-nums">
            {counts.mediaCount}
          </div>
          <div className="text-sm text-slate-600 mt-1.5 tabular-nums">
            {counts.departments} departments · {counts.teachers} teachers
          </div>
        </button>
      </div>

      {/* Quick Action Bar */}
      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={() => onSelectTab('academic_leadership')}
          className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-semibold flex items-center gap-2 cursor-pointer"
        >
          <Award className="w-4 h-4 text-amber-400" />
          <span>Manage Heads of Year & Staff</span>
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('departments')}
          className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-[#0c1a40] border border-slate-200 text-[15px] font-semibold flex items-center gap-2 cursor-pointer"
        >
          <Layers className="w-4 h-4 text-amber-600" />
          <span>Edit 8 Departments & HODs</span>
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('alumni')}
          className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-[#0c1a40] border border-slate-200 text-[15px] font-semibold flex items-center gap-2 cursor-pointer"
        >
          <GraduationCap className="w-4 h-4 text-amber-600" />
          <span>
            Alumni Registry ({counts.alumniApproved} approved · {counts.alumniPending} pending)
          </span>
        </button>
        {currentUser.role === 'super_admin' && (
          <button
            type="button"
            onClick={() => onSelectTab('governance')}
            className="px-4 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-[#0c1a40] border border-amber-300 text-[15px] font-semibold flex items-center gap-2 cursor-pointer"
          >
            <Users className="w-4 h-4 text-amber-700" />
            <span>Users ({counts.usersCount}) & Static Site Export</span>
          </button>
        )}
      </div>

      {/* Enquiries & Campus Tour Submissions */}
      {(currentUser.role === 'super_admin' || currentUser.role === 'admin') && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-base font-bold text-[#0c1a40]">
              <Mail className="w-5 h-5 text-amber-600" />
              <span>Recent Website Enquiries & Boarding Applications ({counts.enquiriesCount})</span>
            </div>
            <span className="text-[15px] font-medium text-slate-600 flex items-center gap-1.5 tabular-nums">
              <Calendar className="w-4 h-4 text-amber-600" />
              {counts.toursCount} Tour Bookings
            </span>
          </div>

          {enquiries.length === 0 ? (
            <div className="text-[15px] text-slate-500 py-4">
              No website contact, boarding, or admission enquiries logged yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[15px] border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-600 text-sm font-semibold uppercase tracking-wide">
                    <th className="py-3 pr-4">Date</th>
                    <th className="py-3 pr-4">Type</th>
                    <th className="py-3 pr-4">Submitted By</th>
                    <th className="py-3">Summary</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {enquiries.map((e) => (
                    <tr key={e.id}>
                      <td className="py-3 pr-4 font-mono text-sm text-slate-600 tabular-nums whitespace-nowrap">
                        {e.createdAt.slice(0, 10)}
                      </td>
                      <td className="py-3 pr-4 font-semibold uppercase text-sm">
                        <span className="px-2.5 py-1 rounded-md bg-slate-100 border border-slate-200 text-[#0c1a40]">
                          {e.type}
                        </span>
                      </td>
                      <td className="py-3 pr-4 font-semibold text-[#0c1a40]">
                        {String(e.payload.name || e.payload.parentName || 'Visitor')}
                      </td>
                      <td className="py-3 text-slate-700 truncate max-w-md">
                        {String(
                          e.payload.subject ||
                            e.payload.gradeApplying ||
                            e.payload.boardingHouse ||
                            e.payload.message ||
                            ''
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Recent Audit Activity */}
      {(currentUser.role === 'super_admin' || currentUser.role === 'admin') && recentLogs.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-base font-bold text-[#0c1a40]">
              <Activity className="w-5 h-5 text-amber-600" />
              <span>Latest CMS Audit Activity</span>
            </div>
            {currentUser.role === 'super_admin' && (
              <button
                type="button"
                onClick={() => onSelectTab('governance')}
                className="text-[15px] font-semibold text-amber-700 hover:underline cursor-pointer flex items-center gap-1.5"
              >
                <Users className="w-4 h-4" />
                <span>View Full Audit Trail</span>
              </button>
            )}
          </div>
          <div className="divide-y divide-slate-100 text-[15px]">
            {recentLogs.slice(0, 6).map((log) => (
              <div
                key={log.id}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 py-2.5"
              >
                <div>
                  <span className="font-semibold text-[#0c1a40]">{log.userEmail}</span>{' '}
                  <span className="text-slate-600">— {log.summary}</span>
                </div>
                <span className="text-sm font-mono text-slate-500 shrink-0 tabular-nums">
                  {log.createdAt.slice(0, 16).replace('T', ' ')}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
