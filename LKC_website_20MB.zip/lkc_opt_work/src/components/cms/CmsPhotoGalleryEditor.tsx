import React, { useState } from 'react';
import { Plus, Trash2, Images, ChevronUp, ChevronDown, Save } from 'lucide-react';
import type { PublishStatus } from '../../types';
import { PhotoUploadField } from './PhotoUploadField';
import { CmsConfirmModal } from './CmsConfirmModal';

export interface GalleryPhotoEntry {
  url: string;
  title?: string;
  category?: string;
  location?: string;
  status?: PublishStatus;
  tag?: string;
  caption: string;
}

interface CmsPhotoGalleryEditorProps {
  title: string;
  description?: string;
  category: string;
  mode: 'building' | 'gallery';
  enableLocationAndStatus?: boolean;
  items: GalleryPhotoEntry[];
  defaultItems?: GalleryPhotoEntry[];
  onChange: (next: GalleryPhotoEntry[]) => void;
  hasUnsavedChanges?: boolean;
  saving?: boolean;
  onSaveSection?: () => void;
}

export const CmsPhotoGalleryEditor: React.FC<CmsPhotoGalleryEditorProps> = ({
  title,
  description,
  category,
  mode,
  enableLocationAndStatus = false,
  items,
  defaultItems = [],
  onChange,
  hasUnsavedChanges = false,
  saving = false,
  onSaveSection,
}) => {
  const effectiveItems = items.length > 0 ? items : defaultItems;
  const usingDefaults = items.length === 0 && defaultItems.length > 0;
  const [removeIdx, setRemoveIdx] = useState<number | null>(null);

  const commitList = (next: GalleryPhotoEntry[]) => {
    onChange(next);
  };

  const handleAddPhoto = () => {
    const base = [...effectiveItems];
    const newEntry: GalleryPhotoEntry =
      mode === 'building'
        ? { url: '', tag: 'Campus Facility', caption: '' }
        : {
            url: '',
            title: '',
            category,
            ...(enableLocationAndStatus ? { location: '', status: 'published' as PublishStatus } : {}),
            caption: '',
          };
    commitList([...base, newEntry]);
  };

  const handleUpdate = (idx: number, patch: Partial<GalleryPhotoEntry>) => {
    const next = effectiveItems.map((item, i) => (i === idx ? { ...item, ...patch } : item));
    commitList(next);
  };

  const handleMove = (idx: number, direction: -1 | 1) => {
    const targetIdx = idx + direction;
    if (targetIdx < 0 || targetIdx >= effectiveItems.length) return;
    const next = [...effectiveItems];
    const [moved] = next.splice(idx, 1);
    next.splice(targetIdx, 0, moved);
    commitList(next);
  };

  const confirmRemove = () => {
    if (removeIdx === null) return;
    const next = effectiveItems.filter((_, i) => i !== removeIdx);
    commitList(next);
    setRemoveIdx(null);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <h4 className="font-serif font-bold text-lg text-[#0c1a40] flex items-center gap-2">
            <Images className="w-5 h-5 text-amber-600" />
            <span>{title}</span>
          </h4>
          {description && (
            <p className="text-[15px] text-slate-600 mt-0.5">{description}</p>
          )}
          {usingDefaults && (
            <p className="text-sm text-amber-700 font-medium mt-1">
              Showing default showcase photos. Replace, add, reorder, or remove any photo and save to customize.
            </p>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onSaveSection && hasUnsavedChanges && (
            <button
              type="button"
              disabled={saving}
              onClick={onSaveSection}
              className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold flex items-center gap-2 cursor-pointer whitespace-nowrap disabled:opacity-60 shadow-xs"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Publishing...' : 'Save & Publish Gallery Live'}</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleAddPhoto}
            className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-semibold flex items-center gap-2 cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Add Photo</span>
          </button>
        </div>
      </div>

      {hasUnsavedChanges && onSaveSection && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm font-medium text-amber-950">
            Uploaded or edited gallery photos are staged in this draft. Click{' '}
            <strong>Save &amp; Publish Gallery Live</strong> so they appear on the public website.
          </p>
        </div>
      )}

      {effectiveItems.length === 0 ? (
        <div className="p-8 rounded-xl bg-slate-50 border border-slate-200 text-center text-[15px] text-slate-600">
          No photos added yet. Click <strong>Add Photo</strong> to upload or select an image from the Media Library.
        </div>
      ) : (
        <div className="space-y-4">
          {effectiveItems.map((entry, idx) => {
            const isHidden = entry.status === 'unpublished' || entry.status === 'archived';
            return (
              <div
                key={idx}
                className={`p-4 rounded-xl border space-y-4 ${
                  isHidden
                    ? 'bg-amber-50/40 border-amber-200'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold text-base text-[#0c1a40] tabular-nums">
                      Photo #{idx + 1}
                      {entry.title ? ` — ${entry.title}` : entry.tag ? ` — ${entry.tag}` : ''}
                    </span>
                    {enableLocationAndStatus && (
                      <span
                        className={`text-xs font-semibold px-2.5 py-0.5 rounded-md border ${
                          isHidden
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        }`}
                      >
                        {isHidden ? 'Unpublished (Hidden)' : 'Published (Live)'}
                      </span>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => handleMove(idx, -1)}
                      className="p-2 rounded-lg bg-white hover:bg-slate-100 border border-slate-300 text-[#0c1a40] disabled:opacity-40 cursor-pointer"
                      title="Move photo up"
                      aria-label={`Move photo ${idx + 1} up`}
                    >
                      <ChevronUp className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      disabled={idx === effectiveItems.length - 1}
                      onClick={() => handleMove(idx, 1)}
                      className="p-2 rounded-lg bg-white hover:bg-slate-100 border border-slate-300 text-[#0c1a40] disabled:opacity-40 cursor-pointer"
                      title="Move photo down"
                      aria-label={`Move photo ${idx + 1} down`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setRemoveIdx(idx)}
                      className="px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Delete Photo</span>
                    </button>
                  </div>
                </div>

                <PhotoUploadField
                  aspect="banner"
                  value={entry.url}
                  onChange={(url) => handleUpdate(idx, { url })}
                  label="Gallery Image"
                  category={category}
                  placeholderLabel="No Photo"
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {mode === 'building' ? (
                    <div>
                      <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1">
                        Badge / Tag Label
                      </label>
                      <input
                        type="text"
                        value={entry.tag || ''}
                        onChange={(e) => handleUpdate(idx, { tag: e.target.value })}
                        placeholder="e.g. Architectural Wing"
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
                      />
                    </div>
                  ) : (
                    <>
                      <div>
                        <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1">
                          Photo Title
                        </label>
                        <input
                          type="text"
                          value={entry.title || ''}
                          onChange={(e) => handleUpdate(idx, { title: e.target.value })}
                          placeholder="Photo headline"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1">
                          Category
                        </label>
                        <input
                          type="text"
                          value={entry.category || ''}
                          onChange={(e) => handleUpdate(idx, { category: e.target.value })}
                          placeholder="e.g. Track & Field"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
                        />
                      </div>
                      {enableLocationAndStatus && (
                        <>
                          <div>
                            <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1">
                              Location
                            </label>
                            <input
                              type="text"
                              value={entry.location || ''}
                              onChange={(e) => handleUpdate(idx, { location: e.target.value })}
                              placeholder="e.g. Block 8 Campus Athletics Precinct"
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
                            />
                          </div>
                          <div>
                            <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1">
                              Visibility Status
                            </label>
                            <select
                              value={entry.status || 'published'}
                              onChange={(e) =>
                                handleUpdate(idx, { status: e.target.value as PublishStatus })
                              }
                              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
                            >
                              <option value="published">Published (Visible on Website)</option>
                              <option value="unpublished">Unpublished (Hidden from Public)</option>
                            </select>
                          </div>
                        </>
                      )}
                    </>
                  )}
                  <div className={mode === 'building' ? '' : 'md:col-span-2'}>
                    <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1">
                      Description / Caption
                    </label>
                    <input
                      type="text"
                      value={entry.caption}
                      onChange={(e) => handleUpdate(idx, { caption: e.target.value })}
                      placeholder="Brief description shown beneath the photo"
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <CmsConfirmModal
        open={removeIdx !== null}
        title="Remove Gallery Photo"
        message="Remove this photo from the gallery? Save section changes afterwards to update the live website."
        confirmLabel="Remove Photo"
        onConfirm={confirmRemove}
        onCancel={() => setRemoveIdx(null)}
      />
    </div>
  );
};

