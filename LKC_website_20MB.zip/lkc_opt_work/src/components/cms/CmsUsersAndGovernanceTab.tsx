import React, { useState, useEffect } from 'react';
import {
  Users,
  UserPlus,
  Trash2,
  Shield,
  Download,
  Upload,
  Activity,
  CheckCircle2,
  Ban,
  KeyRound,
  LogOut,
  FileArchive,
  Lock,
  Search,
  X,
} from 'lucide-react';
import {
  fetchUsers,
  createCmsUser,
  updateCmsUser,
  deleteCmsUser,
  fetchAuditLogs,
  exportFullBackupSnapshot,
  restoreFullBackupSnapshot,
  resetCmsUserPassword,
  revokeCmsUserSessions,
  downloadStaticWebsiteZip,
} from '../../services/cmsDataService';
import type { AuditLogEntry, CmsUser, PageKey, UserRole } from '../../types';
import { CmsConfirmModal } from './CmsConfirmModal';

interface CmsUsersAndGovernanceTabProps {
  currentUser: CmsUser;
  onRefreshAll: () => Promise<void>;
  onNotify: (msg: string) => void;
}

const ALL_ASSIGNABLE_PAGES: { key: PageKey; label: string }[] = [
  { key: 'home', label: 'Home' },
  { key: 'campus', label: 'Campus & Facilities' },
  { key: 'departments', label: 'Departments & Faculty' },
  { key: 'curriculum', label: 'Curriculum' },
  { key: 'boarding', label: 'Boarding' },
  { key: 'excursions', label: 'Excursions' },
  { key: 'achievers', label: 'Top Achievers' },
  { key: 'sports', label: 'Sports' },
  { key: 'athletics', label: 'Athletics' },
  { key: 'jaguars', label: 'The Jaguars' },
  { key: 'news', label: 'News' },
  { key: 'events', label: 'Events' },
  { key: 'contact', label: 'Contact & FAQ' },
];

const LOGS_PER_PAGE = 15;

export const CmsUsersAndGovernanceTab: React.FC<CmsUsersAndGovernanceTabProps> = ({
  currentUser,
  onRefreshAll,
  onNotify,
}) => {
  const [users, setUsers] = useState<CmsUser[]>([]);
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [exportingStatic, setExportingStatic] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [logSearch, setLogSearch] = useState('');
  const [logPage, setLogPage] = useState(1);

  const [deleteTarget, setDeleteTarget] = useState<CmsUser | null>(null);
  const [pwResetUser, setPwResetUser] = useState<CmsUser | null>(null);
  const [pwResetInput, setPwResetInput] = useState('');
  const [pwResetSaving, setPwResetSaving] = useState(false);

  const [newUser, setNewUser] = useState<{
    fullName: string;
    username: string;
    email: string;
    password: string;
    role: UserRole;
    assignedPages: PageKey[];
    mustChangePassword: boolean;
  }>({
    fullName: '',
    username: '',
    email: '',
    password: '',
    role: 'content_editor',
    assignedPages: ['news', 'events', 'sports'],
    mustChangePassword: true,
  });

  const loadGovernanceData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [uList, aLogs] = await Promise.all([fetchUsers(), fetchAuditLogs(150)]);
      setUsers(uList);
      setLogs(aLogs);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load governance records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadGovernanceData();
  }, []);

  if (currentUser.role !== 'super_admin') {
    return (
      <div className="p-8 bg-amber-50 border border-amber-200 rounded-xl text-[15px] text-[#0c1a40]">
        Only a <strong>Super Administrator</strong> may access User Role Management, Audit Logs, and Database Backups.
      </div>
    );
  }

  const toggleNewUserPage = (key: PageKey) => {
    setNewUser((prev) => ({
      ...prev,
      assignedPages: prev.assignedPages.includes(key)
        ? prev.assignedPages.filter((p) => p !== key)
        : [...prev.assignedPages, key],
    }));
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await createCmsUser({
        ...newUser,
        username: newUser.username.trim() || undefined,
      });
      setNewUser({
        fullName: '',
        username: '',
        email: '',
        password: '',
        role: 'content_editor',
        assignedPages: ['news', 'events', 'sports'],
        mustChangePassword: true,
      });
      onNotify('Created new CMS user account.');
      await loadGovernanceData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create user.');
    }
  };

  const handleToggleActive = async (user: CmsUser) => {
    setError(null);
    try {
      await updateCmsUser(user.id, { active: !user.active });
      onNotify(`${user.active ? 'Deactivated' : 'Activated'} account for ${user.username || user.email}.`);
      await loadGovernanceData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update user status.');
    }
  };

  const handleChangeRole = async (user: CmsUser, role: UserRole) => {
    setError(null);
    try {
      await updateCmsUser(user.id, { role });
      onNotify(`Updated ${user.username || user.email} role to ${role}.`);
      await loadGovernanceData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update role.');
    }
  };

  const submitPasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pwResetUser) return;
    if (pwResetInput.length < 8) {
      setError('Temporary password must be at least 8 characters long.');
      return;
    }
    setPwResetSaving(true);
    setError(null);
    try {
      await resetCmsUserPassword(pwResetUser.id, pwResetInput);
      onNotify(
        `Temporary password set & active sessions revoked for '${pwResetUser.username || pwResetUser.email}'.`
      );
      setPwResetUser(null);
      setPwResetInput('');
      await loadGovernanceData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Password reset failed.');
    } finally {
      setPwResetSaving(false);
    }
  };

  const handleRevokeSessions = async (user: CmsUser) => {
    setError(null);
    try {
      const res = await revokeCmsUserSessions(user.id);
      onNotify(`Revoked ${res.revokedCount} active session(s) for ${user.username || user.email}.`);
      await loadGovernanceData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Session revocation failed.');
    }
  };

  const confirmDeleteUser = async () => {
    if (!deleteTarget) return;
    setError(null);
    try {
      await deleteCmsUser(deleteTarget.id);
      onNotify(`Deleted account ${deleteTarget.email}.`);
      setDeleteTarget(null);
      await loadGovernanceData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete user.');
      setDeleteTarget(null);
    }
  };

  const handleExportBackup = async () => {
    setError(null);
    try {
      const snapshot = await exportFullBackupSnapshot();
      const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `LKC-CMS-SQLite-Backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      onNotify('Full SQLite database backup downloaded cleanly.');
      await loadGovernanceData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Backup export failed.');
    }
  };

  const handleDownloadStaticZip = async () => {
    setError(null);
    setExportingStatic(true);
    try {
      await downloadStaticWebsiteZip();
      onNotify('Static public website ZIP archive exported with zero CMS secrets.');
      await loadGovernanceData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Static website ZIP export failed.');
    } finally {
      setExportingStatic(false);
    }
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    try {
      const raw = await file.text();
      const parsed = JSON.parse(raw);
      await restoreFullBackupSnapshot(parsed);
      await onRefreshAll();
      await loadGovernanceData();
      onNotify('CMS database restored cleanly from backup snapshot.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid backup snapshot file.');
    }
    e.target.value = '';
  };

  const filteredLogs = logs.filter((l) => {
    if (!logSearch.trim()) return true;
    const q = logSearch.toLowerCase();
    return (
      l.userEmail.toLowerCase().includes(q) ||
      l.action.toLowerCase().includes(q) ||
      l.summary.toLowerCase().includes(q)
    );
  });

  const totalLogPages = Math.max(1, Math.ceil(filteredLogs.length / LOGS_PER_PAGE));
  const safeLogPage = Math.min(logPage, totalLogPages);
  const pagedLogs = filteredLogs.slice(
    (safeLogPage - 1) * LOGS_PER_PAGE,
    safeLogPage * LOGS_PER_PAGE
  );

  return (
    <div className="space-y-6 text-[15px] text-[#0c1a40]">
      <div className="border-b border-slate-200 pb-4">
        <h3 className="font-serif font-bold text-2xl text-[#0c1a40]">
          Users, Governance, Audit Logs & Backups
        </h3>
        <p className="text-[15px] text-slate-600 mt-1">
          Manage school administrator permissions, security logs, JSON backups, and static website deployments.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-[15px] text-red-800">
          {error}
        </div>
      )}

      {/* Database Backup, Recovery & Static Deployment Export */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h4 className="font-serif font-bold text-lg text-[#0c1a40] mb-1">
            Database Backup, Disaster Recovery & Static Public Export
          </h4>
          <p className="text-[15px] text-slate-600 max-w-2xl">
            Export a full JSON snapshot of SQLite data, restore from backup, or download a self-contained static public website archive (.zip) sanitized of all admin accounts and credentials. Extract the full ZIP folder so local images and uploads sit beside <code className="font-mono text-sm">index.html</code>.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            disabled={exportingStatic}
            onClick={() => void handleDownloadStaticZip()}
            className="px-4 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold flex items-center gap-2 cursor-pointer disabled:opacity-60"
          >
            <FileArchive className="w-4 h-4 text-amber-400" />
            <span>{exportingStatic ? 'Packaging ZIP...' : 'Download Static Website (.zip)'}</span>
          </button>

          <button
            type="button"
            onClick={() => void handleExportBackup()}
            className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-[#0c1a40] border border-slate-300 text-[15px] font-semibold flex items-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4 text-amber-600" />
            <span>Export JSON Backup</span>
          </button>

          <label className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-[15px] font-bold flex items-center gap-2 cursor-pointer">
            <Upload className="w-4 h-4" />
            <span>Restore Snapshot</span>
            <input
              type="file"
              accept=".json"
              onChange={(e) => void handleRestoreFile(e)}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Create Staff User */}
      <form
        onSubmit={handleCreateUser}
        className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4"
      >
        <div className="flex items-center gap-2 font-serif text-lg font-bold text-[#0c1a40]">
          <UserPlus className="w-5 h-5 text-amber-600" />
          <span>Create CMS Administrator / Content Editor Account</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <input
            type="text"
            required
            value={newUser.fullName}
            onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })}
            placeholder="Staff Full Name *"
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <input
            type="text"
            required
            value={newUser.username}
            onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
            placeholder="Username (e.g. makoni) *"
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white font-mono text-[15px]"
          />
          <input
            type="email"
            required
            value={newUser.email}
            onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
            placeholder="staff@lkc.ac.bw *"
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <input
            type="password"
            required
            minLength={8}
            value={newUser.password}
            onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
            placeholder="Temp Password (min 8) *"
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          />
          <select
            value={newUser.role}
            onChange={(e) => setNewUser({ ...newUser, role: e.target.value as UserRole })}
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
          >
            <option value="content_editor">Content Editor (Assigned Pages)</option>
            <option value="admin">Admin (Manage Content & Publish)</option>
            <option value="super_admin">Super Admin (Full Governance)</option>
          </select>
        </div>

        <label className="flex items-center gap-2.5 font-semibold text-[15px] text-[#0c1a40] cursor-pointer">
          <input
            type="checkbox"
            className="w-4 h-4 accent-[#0c1a40]"
            checked={newUser.mustChangePassword}
            onChange={(e) => setNewUser({ ...newUser, mustChangePassword: e.target.checked })}
          />
          <span>Require user to change temporary password on first sign-in</span>
        </label>

        {newUser.role === 'content_editor' && (
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div className="font-semibold text-[15px] text-[#0c1a40] mb-2.5">
              Assign Permitted Pages for this Content Editor:
            </div>
            <div className="flex flex-wrap gap-2">
              {ALL_ASSIGNABLE_PAGES.map((pg) => (
                <label
                  key={pg.key}
                  className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-sm font-medium flex items-center gap-2 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    className="w-4 h-4 accent-[#0c1a40]"
                    checked={newUser.assignedPages.includes(pg.key)}
                    onChange={() => toggleNewUserPage(pg.key)}
                  />
                  <span>{pg.label}</span>
                </label>
              ))}
            </div>
          </div>
        )}

        <button
          type="submit"
          className="px-5 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold cursor-pointer"
        >
          Create CMS Account
        </button>
      </form>

      {/* Users Table */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
        <div className="flex items-center gap-2 font-serif text-lg font-bold text-[#0c1a40] tabular-nums">
          <Users className="w-5 h-5 text-amber-600" />
          <span>CMS Administrator & Editor Accounts ({users.length})</span>
        </div>

        {loading ? (
          <div className="py-6 text-[15px] text-slate-600">Loading user directory...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-600 text-sm font-semibold">
                  <th className="py-3 pr-4">Name</th>
                  <th className="py-3 pr-4">Username & Email</th>
                  <th className="py-3 pr-4">Role</th>
                  <th className="py-3 pr-4">Scope</th>
                  <th className="py-3 pr-4">Security / Status</th>
                  <th className="py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-[15px]">
                {users.map((u) => {
                  const isLocked = u.lockedUntil && new Date(u.lockedUntil).getTime() > Date.now();
                  return (
                    <tr key={u.id} className="hover:bg-slate-50/70">
                      <td className="py-3 pr-4 font-semibold">{u.fullName}</td>
                      <td className="py-3 pr-4">
                        {u.username && (
                          <div className="font-mono font-bold text-sm text-[#0c1a40]">
                            @{u.username}
                          </div>
                        )}
                        <div className="text-sm text-slate-600">{u.email}</div>
                      </td>
                      <td className="py-3 pr-4">
                        <select
                          value={u.role}
                          disabled={u.id === currentUser.id}
                          onChange={(e) => void handleChangeRole(u, e.target.value as UserRole)}
                          className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-sm font-medium"
                        >
                          <option value="super_admin">Super Admin</option>
                          <option value="admin">Admin</option>
                          <option value="content_editor">Content Editor</option>
                        </select>
                      </td>
                      <td className="py-3 pr-4 text-sm text-slate-600">
                        {u.role === 'content_editor'
                          ? u.assignedPages.join(', ') || 'None'
                          : 'All Content Sections'}
                      </td>
                      <td className="py-3 pr-4 space-y-1 text-sm">
                        <div className="flex items-center gap-1.5 font-semibold">
                          {u.active ? (
                            <span className="inline-flex items-center gap-1.5 text-emerald-700">
                              <CheckCircle2 className="w-4 h-4" /> Active
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 text-red-700">
                              <Ban className="w-4 h-4" /> Disabled
                            </span>
                          )}
                        </div>
                        {u.mustChangePassword && (
                          <div className="text-amber-700 font-medium">Temp Password Pending</div>
                        )}
                        {isLocked && (
                          <div className="inline-flex items-center gap-1 text-red-700 font-semibold">
                            <Lock className="w-3.5 h-3.5" /> Account Locked
                          </div>
                        )}
                      </td>
                      <td className="py-3">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              setPwResetUser(u);
                              setPwResetInput('');
                            }}
                            className="px-3 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                            title="Issue temporary password reset"
                          >
                            <KeyRound className="w-3.5 h-3.5" />
                            <span>Reset PW</span>
                          </button>

                          {u.id !== currentUser.id && (
                            <>
                              <button
                                type="button"
                                onClick={() => void handleRevokeSessions(u)}
                                className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] cursor-pointer"
                                title="Revoke active sessions"
                              >
                                <LogOut className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => void handleToggleActive(u)}
                                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-sm font-semibold cursor-pointer"
                              >
                                {u.active ? 'Disable' : 'Enable'}
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTarget(u)}
                                className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer"
                                title="Delete user"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          {u.id === currentUser.id && (
                            <span className="text-sm font-semibold text-amber-700 flex items-center gap-1 ml-1">
                              <Shield className="w-4 h-4" /> Current Session
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Audit Logs */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 font-serif text-lg font-bold text-[#0c1a40] tabular-nums">
            <Activity className="w-5 h-5 text-amber-600" />
            <span>Security & Content Audit Logs ({filteredLogs.length})</span>
          </div>

          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={logSearch}
              onChange={(e) => {
                setLogSearch(e.target.value);
                setLogPage(1);
              }}
              placeholder="Filter audit logs..."
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-slate-600 text-sm font-semibold">
                <th className="py-2.5 pr-4">Timestamp</th>
                <th className="py-2.5 pr-4">Actor</th>
                <th className="py-2.5 pr-4">Action</th>
                <th className="py-2.5">Summary</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {pagedLogs.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-6 text-center text-slate-500 text-[15px]">
                    No audit log entries match the search query.
                  </td>
                </tr>
              ) : (
                pagedLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/70">
                    <td className="py-2.5 pr-4 font-mono tabular-nums text-slate-600 whitespace-nowrap">
                      {log.createdAt.slice(0, 19).replace('T', ' ')}
                    </td>
                    <td className="py-2.5 pr-4 font-medium">
                      {log.userEmail} <span className="text-amber-700">({log.userRole})</span>
                    </td>
                    <td className="py-2.5 pr-4 font-mono font-bold text-[#0c1a40]">
                      {log.action}
                    </td>
                    <td className="py-2.5 text-slate-700">{log.summary}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalLogPages > 1 && (
          <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-sm">
            <span className="text-slate-600 tabular-nums">
              Page {safeLogPage} of {totalLogPages}
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={safeLogPage <= 1}
                onClick={() => setLogPage((p) => Math.max(1, p - 1))}
                className="px-3.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer font-semibold"
              >
                Previous
              </button>
              <button
                type="button"
                disabled={safeLogPage >= totalLogPages}
                onClick={() => setLogPage((p) => Math.min(totalLogPages, p + 1))}
                className="px-3.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer font-semibold"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Temporary Password Reset Modal */}
      {pwResetUser && (
        <div
          className="fixed inset-0 z-[90] bg-[#081226]/80 flex items-center justify-center p-4"
          onClick={() => setPwResetUser(null)}
        >
          <form
            onSubmit={submitPasswordReset}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-2xl space-y-4 text-[#0c1a40]"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h4 className="font-serif font-bold text-xl text-[#0c1a40]">
                Reset Temporary Password
              </h4>
              <button
                type="button"
                onClick={() => setPwResetUser(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600 cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-[15px] text-slate-700 leading-relaxed">
              Enter a temporary password (minimum 8 characters) for{' '}
              <strong>{pwResetUser.fullName}</strong> ({pwResetUser.username || pwResetUser.email}).
              Active sessions will be revoked and they will be prompted to set a new password upon signing in.
            </p>

            <div>
              <label className="block font-semibold text-[15px] text-[#0c1a40] mb-1.5">
                Temporary Password *
              </label>
              <input
                type="password"
                required
                minLength={8}
                autoFocus
                value={pwResetInput}
                onChange={(e) => setPwResetInput(e.target.value)}
                placeholder="Minimum 8 characters"
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-[15px]"
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setPwResetUser(null)}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0c1a40] text-[15px] font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={pwResetSaving}
                className="px-5 py-2.5 rounded-xl bg-[#0c1a40] hover:bg-[#162a6b] text-white text-[15px] font-bold cursor-pointer disabled:opacity-60"
              >
                {pwResetSaving ? 'Resetting...' : 'Set Temporary Password'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete Administrator Confirm Modal */}
      <CmsConfirmModal
        open={Boolean(deleteTarget)}
        title="Delete Administrator Account"
        message={
          deleteTarget
            ? `Permanently delete administrator account "${deleteTarget.fullName}" (${deleteTarget.email})? This action cannot be undone.`
            : ''
        }
        confirmLabel="Delete Account"
        onConfirm={() => void confirmDeleteUser()}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
