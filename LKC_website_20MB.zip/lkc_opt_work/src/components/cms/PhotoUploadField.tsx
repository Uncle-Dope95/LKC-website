import React, { useRef, useState } from 'react';
import { Upload, Image as ImageIcon, Trash2, FolderOpen, X, Check, Search, ZoomIn } from 'lucide-react';
import { uploadMediaFile, useCmsSection } from '../../services/cmsDataService';
import { matchesSearchTokens } from '../../utils/profileSearch';
import { openImageViewer } from '../ImageLightboxModal';

interface PhotoUploadFieldProps {
  value?: string | null;
  onChange: (url: string) => void;
  label?: string;
  category?: string;
  placeholderLabel?: string;
  dark?: boolean;
  aspect?: 'square' | 'banner';
}

const ACCEPTED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'image/gif',
]);

export const PhotoUploadField: React.FC<PhotoUploadFieldProps> = ({
  value,
  onChange,
  label = 'Portrait / Image',
  category = 'Boarding & Staff',
  placeholderLabel = 'No Image',
  dark = false,
  aspect = 'square',
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const pickerFileInputRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerSearch, setPickerSearch] = useState('');

  const mediaAssets = useCmsSection('media');
  const imageAssets = (mediaAssets || []).filter(
    (m) => !m.mediaType || m.mediaType === 'image'
  );

  const filteredAssets = imageAssets.filter((asset) =>
    matchesSearchTokens(pickerSearch, [
      asset.name,
      asset.category,
      asset.description,
      asset.filename,
      asset.url,
      asset.usedIn,
    ])
  );

  const uploadSelectedImage = async (file: File, closePickerAfter = false) => {
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    const allowedExts = new Set(['jpg', 'jpeg', 'png', 'webp', 'gif']);
    if (!ACCEPTED_MIME_TYPES.has(file.type) && !allowedExts.has(ext)) {
      setError('Please select a valid image file (JPG, JPEG, PNG, or WebP).');
      return;
    }

    setUploading(true);
    setError(null);
    setStatusMessage(null);
    try {
      const asset = await uploadMediaFile(file, {
        name: file.name.replace(/\.[^.]+$/, ''),
        category,
      });
      onChange(asset.url);
      if (closePickerAfter) setPickerOpen(false);
      setStatusMessage('Image uploaded and attached. Save changes to publish.');
      setTimeout(() => setStatusMessage(null), 4000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload image.');
    } finally {
      setUploading(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, closePickerAfter = false) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await uploadSelectedImage(file, closePickerAfter);
    e.target.value = '';
  };

  return (
    <div className="space-y-2 text-[15px]">
      {label && (
        <label
          className={`block font-semibold text-[15px] ${dark ? 'text-amber-300' : 'text-[#0c1a40]'}`}
        >
          {label}
        </label>
      )}

      <div
        className={`flex flex-wrap items-center gap-4 p-3.5 rounded-xl border ${
          dark
            ? 'bg-[#081226]/70 border-blue-800 text-white'
            : 'bg-slate-50 border-slate-200 text-[#0c1a40]'
        }`}
      >
        {/* Preview Thumbnail or Clean Placeholder */}
        <div
          className={`${
            aspect === 'banner' ? 'w-40 h-28' : 'w-24 h-28'
          } rounded-xl overflow-hidden shrink-0 border flex items-center justify-center relative group ${
            dark ? 'bg-blue-950 border-blue-700' : 'bg-white border-slate-200'
          }`}
        >
          {value ? (
            <>
              <img
                src={value}
                alt={label}
                onClick={() => openImageViewer({ src: value, title: label, subtitle: category })}
                className="w-full h-full object-cover object-top cursor-zoom-in"
              />
              <button
                type="button"
                onClick={() => openImageViewer({ src: value, title: label, subtitle: category })}
                className="absolute bottom-1 right-1 p-1 rounded bg-[#081226]/80 text-amber-300 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                title="View full image"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center text-center px-2">
              <ImageIcon
                className={`w-6 h-6 ${dark ? 'text-amber-400/70' : 'text-slate-400'}`}
              />
              <span
                className={`text-sm leading-tight mt-1 font-medium ${
                  dark ? 'text-blue-200' : 'text-slate-500'
                }`}
              >
                {placeholderLabel}
              </span>
            </div>
          )}
        </div>

        <div className="flex-1 min-w-[220px] space-y-2.5">
          <div className="flex flex-wrap items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept=".jpg,.jpeg,.png,.webp,.gif,image/jpeg,image/png,image/webp"
              onChange={(e) => void handleFileChange(e, false)}
              className="hidden"
            />
            <button
              type="button"
              disabled={uploading}
              onClick={() => fileInputRef.current?.click()}
              className={`px-3.5 py-2 rounded-lg text-[15px] font-semibold flex items-center gap-2 cursor-pointer transition-colors disabled:opacity-50 whitespace-nowrap ${
                dark
                  ? 'bg-amber-400 hover:bg-amber-300 text-[#081226]'
                  : 'bg-[#0c1a40] hover:bg-[#162a6b] text-white'
              }`}
            >
              <Upload className="w-4 h-4 shrink-0" />
              <span>{uploading ? 'Uploading...' : value ? 'Replace Photo' : 'Upload Photo'}</span>
            </button>

            <button
              type="button"
              onClick={() => setPickerOpen(true)}
              className={`px-3.5 py-2 rounded-lg text-[15px] font-semibold flex items-center gap-2 cursor-pointer border whitespace-nowrap ${
                dark
                  ? 'bg-blue-950 hover:bg-blue-900 border-blue-700 text-blue-100'
                  : 'bg-white hover:bg-slate-100 border-slate-300 text-[#0c1a40]'
              }`}
            >
              <FolderOpen className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Media Library</span>
            </button>

            {value && (
              <button
                type="button"
                onClick={() => {
                  onChange('');
                  setStatusMessage('Image removed. Save changes to update the live page.');
                  setTimeout(() => setStatusMessage(null), 4000);
                }}
                className={`px-3.5 py-2 rounded-lg text-[15px] font-semibold flex items-center gap-2 cursor-pointer whitespace-nowrap ${
                  dark
                    ? 'bg-red-950/70 hover:bg-red-900 text-red-200 border border-red-800'
                    : 'bg-red-50 hover:bg-red-100 text-red-700 border border-red-200'
                }`}
                title="Remove image"
              >
                <Trash2 className="w-4 h-4 shrink-0" />
                <span>Remove Image</span>
              </button>
            )}
          </div>

          <input
            type="text"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Image path or URL (e.g. /uploads/... or ./assets/...)"
            className={`w-full px-3 py-2 rounded-lg text-sm font-mono border ${
              dark
                ? 'bg-[#0c1a40] border-blue-800 text-blue-100'
                : 'bg-white border-slate-300 text-[#0c1a40]'
            }`}
          />
        </div>
      </div>

      {statusMessage && (
        <div className="text-sm text-emerald-700 font-medium">{statusMessage}</div>
      )}
      {error && <div className="text-sm text-red-600 font-medium">{error}</div>}

      {/* Media Library Picker Modal */}
      {pickerOpen && (
        <div
          className="fixed inset-0 z-[80] bg-[#081226]/80 flex items-center justify-center p-4"
          onClick={() => setPickerOpen(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-5xl w-full max-h-[88vh] flex flex-col overflow-hidden border border-slate-200 shadow-2xl text-[#0c1a40]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 bg-[#0c1a40] text-white flex flex-wrap items-center justify-between gap-4">
              <div>
                <h4 className="font-serif font-bold text-xl">
                  Select Image from LKC Media Library
                </h4>
                <p className="text-sm text-amber-300">
                  {imageAssets.length} verified image assets available (JPG, PNG, WebP)
                </p>
              </div>
              <div className="flex items-center gap-2">
                <input
                  ref={pickerFileInputRef}
                  type="file"
                  accept=".jpg,.jpeg,.png,.webp,.gif,image/jpeg,image/png,image/webp"
                  onChange={(e) => void handleFileChange(e, true)}
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={uploading}
                  onClick={() => pickerFileInputRef.current?.click()}
                  className="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#081226] text-sm font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Upload className="w-4 h-4" />
                  <span>{uploading ? 'Uploading...' : 'Upload New Image'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPickerOpen(false)}
                  className="p-2 rounded-lg hover:bg-white/10 text-white cursor-pointer"
                  aria-label="Close media library picker"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="px-6 py-3.5 bg-slate-50 border-b border-slate-200">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  autoFocus
                  value={pickerSearch}
                  onChange={(e) => setPickerSearch(e.target.value)}
                  placeholder="Search images by title, surname, category, or filename..."
                  className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-slate-300 bg-white text-[15px] text-[#0c1a40]"
                />
                {pickerSearch && (
                  <button
                    type="button"
                    onClick={() => setPickerSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0c1a40] cursor-pointer"
                    aria-label="Clear search"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            <div className="p-6 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {filteredAssets.length === 0 ? (
                <div className="col-span-full py-10 text-center text-[15px] text-slate-500 space-y-2">
                  <p>No images match "{pickerSearch}".</p>
                  {pickerSearch && (
                    <button
                      type="button"
                      onClick={() => setPickerSearch('')}
                      className="px-4 py-2 rounded-lg bg-[#0c1a40] text-white text-sm font-semibold cursor-pointer"
                    >
                      Show All Images
                    </button>
                  )}
                </div>
              ) : (
                filteredAssets.map((asset) => {
                  const selected = value === asset.url;
                  return (
                    <button
                      key={asset.id}
                      type="button"
                      onClick={() => {
                        onChange(asset.url);
                        setPickerOpen(false);
                      }}
                      className={`rounded-xl overflow-hidden border text-left transition-all cursor-pointer bg-white ${
                        selected
                          ? 'border-amber-500 ring-2 ring-amber-400'
                          : 'border-slate-200 hover:border-[#0c1a40]'
                      }`}
                    >
                      <div className="h-36 bg-[#081226] relative">
                        <img
                          src={asset.url}
                          alt={asset.name}
                          className="w-full h-full object-cover object-top"
                        />
                        {selected && (
                          <span className="absolute top-2 right-2 w-6 h-6 rounded-full bg-amber-400 text-[#081226] flex items-center justify-center shadow-sm">
                            <Check className="w-4 h-4" />
                          </span>
                        )}
                      </div>
                      <div className="p-3 bg-white">
                        <div className="font-semibold text-sm truncate text-[#0c1a40]">
                          {asset.name}
                        </div>
                        <div className="text-sm text-amber-700 truncate">
                          {asset.category}
                        </div>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
