import type { HouseInfo, SubjectInfo, TermDate, AchievementItem, DepartmentInfo, LeadershipMember, ExcursionItem, AlumniProfile, CambridgeLearnerAward, AchieverItem, TeacherProfile } from '../types/index.ts';

export const COLLEGE_INFO = {
  name: "Livingstone Kolobeng College",
  shortName: "LKC",
  motto: "Thuto Ke Botshelo",
  mottoEnglish: "Education is Life",
  cambridgeCentreNo: "Cambridge International Centre",
  established: "2008",
  logoUrl: "./assets/aistudio/logo_33a39ff7.png",
  historicalRoots: "Named in honor of the historic Kolobeng mission established in 1847 by Dr. David Livingstone and Kgosi Sechele I.",
  mascot: "The Kolobeng Jaguars",
  admissionsPortalUrl: "https://lkcportal.com/?form=apply",
  parentsPortalUrl: "https://lkcportal.com/?portal=parent",
  teachersPortalUrl: "https://lkcportal.com/",
  portalHomeUrl: "https://lkcportal.com",
  googleMapsDirectionsUrl: "https://www.google.com/maps/dir/?api=1&destination=Livingstone%20Kolobeng%20College%2C%20Plot%2037225%20Extension%2038%2C%20Block%208%2C%20Gaborone%2C%20Botswana&destination_place_id=ChIJ8_bX5EwD-BURp8s3e2L2-H0&travelmode=driving",
  socials: {
    tiktok: "https://www.tiktok.com/@lkc_college",
    tiktokHandle: "@lkc_college",
    instagram: "https://www.instagram.com/lkc_livingstonekolobeng",
    instagramHandle: "@lkc_livingstonekolobeng",
    facebook: "https://www.facebook.com/LivingstoneKolobengCollege",
    facebookHandle: "Livingstone Kolobeng College",
    whatsapp: "https://wa.me/26778465196",
    whatsappNumber: "+267 78 465 196",
  },
  address: {
    plot: "Plot 37225, Kgame Road, Block 8, Extension 38",
    area: "Gaborone West",
    city: "Gaborone",
    country: "Botswana",
    postalBox: "P.O. Box 403388, Gaborone, Botswana",
    gps: "-24.619000, 25.909500 (Plot 37225, Extension 38)",
  },
  contacts: {
    phone: "+267 316 1140",
    phoneSecondary: "+267 316 2208",
    phoneAlternate: "+267 31 611 39",
    fax: "+267 316 1139",
    mobile: "+267 75 474 970",
    whatsapp: "+267 78 465 196",
    bursarWhatsapp: "+267 72 820 327",
    bursarWhatsappLink: "https://wa.me/26772820327",
    principalEmail: "principal@lkc.ac.bw",
    admissionsEmail: "admissions@livingstonekolobeng.ac.bw",
    admissionsAltEmail: "admissions@lkc.ac.bw",
    accountsEmail: "accountslkc@yahoo.com",
    feePolicyPdfUrl: "./assets/aistudio/School_Fees_Policy_2026_IGCSE_f50e8781.pdf",
    officeHours: "Monday – Friday: 07:30 – 16:30",
  },
  leadership: [
    {
      id: "lead-md",
      order: 1,
      status: "published",
      name: "Mrs Nilima Bakaya",
      role: "Managing Director",
      title: "Managing Director & Executive Governance",
      image: "./assets/aistudio/managing_director_nilima_bakaya_e0a81873.jpg",
      bio: "Oversees the strategic vision, institutional governance, infrastructural development, and international accreditations of Livingstone Kolobeng College.",
      message: "Welcome to Livingstone Kolobeng College. Since our inception in 2008, our mission has been clear: to provide learners in Botswana with a world-class Cambridge education grounded in character, ambition, and cultural heritage. We have invested substantially in specialized science laboratories, digital learning spaces, modern residential boarding hostels, and passionate master teachers. At LKC, our vision is to equip every child with the intellectual competence and moral fortitude required to thrive in a rapidly changing global society. We welcome you to experience education where excellence is a lived reality."
    },
    {
      id: "lead-principal",
      order: 2,
      status: "published",
      name: "Dr Jeff Ramsay",
      role: "Principal",
      title: "Principal & Senior Academician",
      image: "./assets/aistudio/principal_dr_jeff_ramsay_a61fcb25.jpg",
      bio: "Renowned historian, educationalist, and author. Directs academic rigour, Cambridge UCLES curriculum standards, and holistic student mentorship.",
      message: "It is an honor to guide the academic destiny of Livingstone Kolobeng College. As a premier Cambridge International Examination Centre, we hold ourselves and our students to uncompromising standards of intellectual inquiry. Our educational philosophy blends British Cambridge curricular rigor with the cherished Setswana principle of Botho—fostering mutual respect, resilience, and civic integrity. From Preschool to Cambridge A-Levels, we nurture curious minds, critical thinkers, and leaders ready to excel in top global universities."
    },
    {
      id: "lead-adu",
      order: 3,
      status: "published",
      name: "Mr K Adu",
      role: "Director of A-Levels",
      title: "Director of Cambridge AS & A-Levels (Sixth Form)",
      image: "./assets/aistudio/Mr_K_Adu_portrait_c3a680c6.jpg",
      department: "Sixth Form & University Placement",
      isSMT: true,
      bio: "Directs the Cambridge International AS and A-Level Sixth Form program, pre-university specialization, academic tutoring, and Ivy League & Russell Group university applications."
    },
    {
      id: "lead-mutenheri",
      order: 4,
      status: "published",
      name: "Dr Fedious Mutenheri",
      role: "Vice Principal of All School Affairs",
      title: "Vice Principal (Academic Standards & Student Affairs)",
      image: "./assets/aistudio/vp_dr_fedious_mutenheri_e1569921.jpg",
      department: "Academic Standards & Student Affairs",
      isSMT: true,
      bio: "Coordinates academic curriculum delivery, Cambridge examination compliance, departmental quality audits, student discipline, and comprehensive pastoral care."
    },
    {
      id: "lead-nyika",
      order: 5,
      status: "published",
      name: "Mr R Nyika",
      role: "Vice Principal Administration",
      title: "Vice Principal (Administration & Operations)",
      image: "./assets/aistudio/vp_mr_r_nyika_88c39b96.jpg",
      department: "College Operations & Hostels",
      isSMT: true,
      bio: "Directs campus operational logistics, residential boarding hostels (Sir Ketumile and Lady Olebile Masire dormitories), institutional safety, health services, and bursary coordination."
    },
    {
      id: "lead-murombedzi",
      order: 6,
      status: "published",
      name: "Mr K Murombedzi",
      role: "Vice Principal Examinations",
      title: "Vice Principal (Examinations & Assessment Standards)",
      image: "./assets/aistudio/Murombedzi_b26ea474.jpg",
      department: "Cambridge Examinations & Assessment",
      isSMT: true,
      bio: "Directs Cambridge IGCSE, AS, and A-Level examination administration, candidate entries, invigilation compliance, and assessment standards across the college."
    },
    {
      id: "lead-munodawafa",
      order: 7,
      status: "published",
      name: "Ms Tracey Munodawafa",
      role: "Deputy Vice Principal Administration",
      title: "Deputy Vice Principal (Administration & Institutional Liaison)",
      image: "./assets/aistudio/Ms_Tracey_Munodawafa_portrait_311fd817.jpg",
      department: "Administrative Services & Public Liaison",
      isSMT: true,
      bio: "Assists the Vice Principal Administration in operational oversight, staff coordination, parent communications, academic timetabling, and regulatory compliance."
    }
  ] as LeadershipMember[],
  statistics: [
    { label: "Cambridge Pass Rate", value: "98.4%", detail: "A* to C grades across IGCSE & A-Levels" },
    { label: "Boarding Capacity", value: "100 Beds", detail: "39 currently enrolled · 61 spaces open" },
    { label: "Certified Faculty", value: "80", detail: "Specialized Cambridge subject masters" },
    { label: "Student-Faculty Ratio", value: "10:1", detail: "Personalized academic mentoring and pastoral care" },
    { label: "University Placement", value: "100%", detail: "Direct progression to premier global universities" },
    { label: "Active Co-Curriculars", value: "24+", detail: "Jaguars athletics, rugby, robotics, MUN, marimba" }
  ]
};

export const DEPARTMENTS: DepartmentInfo[] = [
  {
    id: "dept-maths",
    name: "Mathematics Department",
    slug: "mathematics",
    headOfDepartment: {
      name: "Mrs Charity Dewah",
      title: "Head of Mathematics",
      image: "./assets/aistudio/Dewah_0cc021bf.jpg",
      qualifications: "BEd Mathematics Education",
      status: "published"
    },
    shortDescription: "The Mathematics Department builds strong numerical fluency, logical reasoning, algebraic proficiency and analytical problem-solving skills that underpin academic achievement across all disciplines.",
    curriculum: "Progressive Cambridge Mathematics pathway from Form 1 through IGCSE, AS and A2 Level (including Additional, Extended, Statistics, Mechanics and Further Mathematics where offered).",
    subjects: [
      "Mathematics – Form 1–A2",
      "Additional Mathematics – Form 4–5",
      "Extended Mathematics – Form 4–5 (where offered)",
      "Statistics – AS–A2 (where offered)",
      "Mechanics – AS–A2 (where offered)",
      "Further Mathematics – AS–A2 (where offered)"
    ],
    keyAreas: [
      "Number systems, algebra and functions",
      "Geometry, trigonometry and mensuration",
      "Calculus and mathematical analysis",
      "Probability and statistics",
      "Applied mechanics and mathematical modelling",
      "Logical deduction and multi-step problem solving"
    ],
    activities: [
      "Mathematics Olympiad / Problem-Solving Competitions",
      "Mathematics Support and Enrichment Clinics",
      "Chess and Logical Thinking Club",
      "STEM Quantitative Problem-Solving Challenges"
    ],
    facilities: [
      "Structured seminar classrooms for guided analytical problem-solving",
      "Mathematics support clinics and diagnostic examination archives",
      "Statistical modelling, graphing and Olympiad training resources"
    ],
    features: [
      "Mathematics Olympiad / Problem-Solving Competitions",
      "Mathematics Support and Enrichment Clinics",
      "Chess and Logical Thinking Club",
      "STEM Quantitative Problem-Solving Challenges"
    ],
    icon: "Calculator"
  },
  {
    id: "dept-science",
    name: "Science Department",
    slug: "science",
    headOfDepartment: {
      name: "Mr Daniel Kadembo",
      title: "Head of Science",
      image: "./assets/aistudio/Kadembo_34520bae.jpeg",
      qualifications: "BSc Applied Physics",
      status: "published"
    },
    shortDescription: "The Science Department fosters scientific inquiry, experimentation, analytical reasoning and a deeper understanding of the natural and physical world. Students engage in both theoretical study and hands-on laboratory investigations.",
    curriculum: "Combined Science (Form 1–3), Biology, Chemistry & Physics (Form 4–A2), and Agriculture (Form 1–5) aligned with Cambridge International examinations.",
    subjects: [
      "Combined Science – Form 1–3",
      "Biology – Form 4–A2",
      "Chemistry – Form 4–A2",
      "Physics – Form 4–A2",
      "Agriculture – Form 1–5"
    ],
    keyAreas: [
      "Scientific method and experimental investigation",
      "Cellular biology, genetics, ecology and human systems",
      "Chemical reactions, atomic structure and organic chemistry",
      "Mechanics, electricity, waves, energy and physical systems",
      "Agricultural science, soil management and sustainable food production",
      "Laboratory safety and practical scientific skills",
      "Environmental stewardship and conservation"
    ],
    activities: [
      "Science Club / STEM Club",
      "Science Fair and Innovation Exhibitions",
      "Environmental and Conservation Club",
      "Agriculture / Young Farmers Club",
      "Laboratory and Practical Science Workshops"
    ],
    facilities: [
      "Dedicated Biology, Chemistry and Physics laboratories for practical investigations",
      "Agricultural plots and sustainable food production demonstration areas",
      "Microscopy, titration stations, optics and electrical measurement equipment"
    ],
    features: [
      "Science Club / STEM Club",
      "Science Fair and Innovation Exhibitions",
      "Environmental and Conservation Club",
      "Agriculture / Young Farmers Club"
    ],
    icon: "FlaskConical"
  },
  {
    id: "dept-creatives",
    name: "Creatives Department",
    slug: "creatives",
    headOfDepartment: {
      name: "Mr Jones",
      title: "Head of Creatives",
      image: "./assets/aistudio/jones_e7c56bef.jpeg",
      qualifications: "BSc Industrial Design & Tech",
      status: "published"
    },
    shortDescription: "The Creatives Department nurtures imagination, artistic expression, technical design skills and practical craftsmanship, enabling students to transform ideas into tangible creative and functional works.",
    curriculum: "Art and Design (Form 1–A2, where offered) and Design and Technology (where offered) supporting studio portfolios and practical manufacturing skills.",
    subjects: [
      "Art and Design – Form 1–A2 (where offered)",
      "Design and Technology (where offered)"
    ],
    keyAreas: [
      "Drawing, painting, sculpture and mixed media",
      "Graphic design and visual communication",
      "Product design, prototyping and problem solving",
      "Material properties, workshop tools and manufacturing processes",
      "Design thinking and iterative development",
      "Portfolio development and creative presentation",
      "Cultural and contemporary art appreciation"
    ],
    activities: [
      "Art and Craft Club",
      "Design, Makerspace and Prototyping Club",
      "Photography and Digital Media Club",
      "Annual Art Exhibition and Design Showcase",
      "School Stage Set Design and Creative Production Support"
    ],
    facilities: [
      "Visual art studio equipped for drawing, painting, sculpture and mixed media",
      "Design and Technology workshop for prototyping and material fabrication",
      "Exhibition and portfolio curation spaces for annual showcases"
    ],
    features: [
      "Art and Craft Club",
      "Design, Makerspace and Prototyping Club",
      "Annual Art Exhibition and Design Showcase",
      "Photography, Digital Media & Stage Design"
    ],
    icon: "Palette"
  },
  {
    id: "dept-pe",
    name: "Physical Education Department",
    slug: "physical-education",
    headOfDepartment: {
      name: "Mr Singh Dhaliwal",
      title: "Head of Physical Education",
      image: "./assets/aistudio/Dhaliwal_6434853f.jpg",
      qualifications: "MSc Physical Education & Sports Coaching",
      status: "published"
    },
    shortDescription: "The Physical Education Department promotes physical fitness, teamwork, sportsmanship, discipline and healthy lifestyles while supporting both recreational participation and competitive school sport.",
    curriculum: "Physical Education alongside structured inter-house sports competitions, inter-school leagues and Kolobeng Jaguars athletic development.",
    subjects: [
      "Physical Education",
      "Athletics",
      "Football",
      "Basketball",
      "Volleyball",
      "Netball",
      "Rugby",
      "Tennis",
      "Swimming",
      "Cross-country",
      "Badminton",
      "Other sporting activities offered by the college"
    ],
    keyAreas: [
      "Inter-house sports competitions",
      "Inter-school leagues and tournaments",
      "Athletics development programme",
      "Team sports training and conditioning",
      "Health, fitness and wellness education",
      "Sportsmanship and athletic leadership development"
    ],
    activities: [
      "Athletics",
      "Football",
      "Basketball",
      "Volleyball",
      "Netball",
      "Rugby",
      "Tennis",
      "Swimming",
      "Cross-country",
      "Badminton",
      "Other sporting activities offered by the college"
    ],
    facilities: [
      "Athletics track, rugby & football pitches and multi-sport courts",
      "Swimming pool and inter-house aquatic competition facilities",
      "Sports conditioning, coaching and athletic leadership support"
    ],
    features: [
      "Inter-house sports competitions",
      "Inter-school leagues and tournaments",
      "Athletics development programme",
      "Sportsmanship and athletic leadership development"
    ],
    icon: "Trophy"
  },
  {
    id: "dept-humanities",
    name: "Humanities Department",
    slug: "humanities",
    headOfDepartment: {
      name: "Mr P Muzeza",
      title: "Head of Humanities",
      image: "./assets/aistudio/Muzeza_9d32f7a2.jpg",
      qualifications: "BA History & Political Science",
      status: "published"
    },
    shortDescription: "The Humanities Department encourages students to understand human societies, historical developments, geographical systems, global challenges and human behaviour, cultivating informed and responsible global citizens.",
    curriculum: "History (Form 4–A2, where offered), Geography (Form 1–A2, where offered), Travel and Tourism, Global Perspectives (where offered) and Psychology (AS–A2, where offered).",
    subjects: [
      "History – Form 4–A2 (where offered)",
      "Geography – Form 1–A2 (where offered)",
      "Travel and Tourism (where offered)",
      "Global Perspectives (where offered)",
      "Psychology – AS–A2 (where offered)"
    ],
    keyAreas: [
      "Historical inquiry, evidence evaluation and global events",
      "Physical and human geography, climate and environmental systems",
      "Sustainable tourism, hospitality and cultural heritage",
      "Global issues, research methodology and critical perspectives",
      "Human behaviour, cognition and psychological research methods",
      "Social responsibility, ethics and global citizenship",
      "Map reading, fieldwork and data interpretation"
    ],
    activities: [
      "Model United Nations (MUN)",
      "Current Affairs and Global Issues Club",
      "History and Heritage Society",
      "Geography and Environmental Field Trips",
      "Tourism and Cultural Heritage Excursions",
      "Community Service and Civic Engagement Club"
    ],
    facilities: [
      "Cartography, map reading and environmental fieldwork resources",
      "Historical archives and Kolobeng cultural heritage learning materials",
      "Model United Nations and global research seminar rooms"
    ],
    features: [
      "Model United Nations (MUN)",
      "Current Affairs and Global Issues Club",
      "Geography and Environmental Field Trips",
      "History and Heritage Society"
    ],
    icon: "Globe"
  },
  {
    id: "dept-languages",
    name: "Languages Department",
    slug: "languages",
    headOfDepartment: {
      name: "Mrs Tsetse",
      title: "Head of Languages",
      image: "./assets/aistudio/tsetse_de6b2999.jpeg",
      qualifications: "BEd English Education",
      status: "published"
    },
    shortDescription: "The Languages Department strengthens students' communication skills, reading comprehension, writing proficiency, literary appreciation and cultural awareness in both local and international languages.",
    curriculum: "English as a First Language, English as a Second Language, French, Setswana, Chinese (where offered) and Literature in English (Form 4–A2, where offered).",
    subjects: [
      "English as a First Language",
      "English as a Second Language",
      "French (where offered)",
      "Setswana (where offered)",
      "Chinese (where offered)",
      "Literature in English – Form 4–A2 (where offered)"
    ],
    keyAreas: [
      "Reading comprehension and critical analysis",
      "Essay, creative and academic writing",
      "Oral communication, listening and presentation skills",
      "Grammar, vocabulary and linguistic accuracy",
      "Literary analysis of prose, poetry and drama",
      "Multilingual competence and intercultural understanding",
      "Research and referencing skills"
    ],
    activities: [
      "Debate Club",
      "Public Speaking and Toastmasters-style Activities",
      "Drama and Theatre Arts Club",
      "Creative Writing and School Magazine / Journalism Club",
      "Cultural and Language Exchange Days",
      "Spelling Bee and Reading / Book Club"
    ],
    facilities: [
      "Oral communication and listening comprehension learning spaces",
      "College library collections spanning English, Setswana, French & Chinese",
      "Debate chambers and drama performance spaces"
    ],
    features: [
      "Debate Club & Public Speaking",
      "Drama and Theatre Arts Club",
      "Creative Writing & Journalism Club",
      "Cultural and Language Exchange Days"
    ],
    icon: "Languages"
  },
  {
    id: "dept-commercials",
    name: "Commercials Department",
    slug: "commercials",
    headOfDepartment: {
      name: "Mrs M Katai",
      title: "Head of Commercials",
      image: "./assets/aistudio/Katai_6d0dcd93.jpg",
      qualifications: "MSc Accounting & Finance",
      status: "published"
    },
    shortDescription: "The Commercials Department develops students' financial literacy, business acumen, economic understanding and entrepreneurial thinking, preparing them for careers in commerce, finance, management and enterprise.",
    curriculum: "Business Studies, Accounting and Economics (Form 4–A2, where offered) alongside Enterprise (where offered).",
    subjects: [
      "Business Studies – Form 4–A2 (where offered)",
      "Accounting – Form 4–A2 (where offered)",
      "Enterprise (where offered)",
      "Economics – Form 4–A2 (where offered)"
    ],
    keyAreas: [
      "Business organisation, management, marketing and operations",
      "Financial accounting, bookkeeping, budgeting and financial statements",
      "Entrepreneurship, business planning and venture creation",
      "Microeconomics and macroeconomics",
      "Financial decision-making and resource allocation",
      "Business ethics and corporate social responsibility",
      "Case study analysis and commercial problem solving"
    ],
    activities: [
      "Young Entrepreneurs / Junior Achievement Club",
      "Business Innovation and Pitch Competitions",
      "Investment and Financial Literacy Club",
      "School Market Days and Enterprise Projects",
      "Industry Visits and Guest Speaker Sessions"
    ],
    facilities: [
      "Financial accounting, bookkeeping and spreadsheet analysis workspaces",
      "Business case study and enterprise pitch preparation rooms",
      "Current economic, commercial and market research materials"
    ],
    features: [
      "Young Entrepreneurs / Junior Achievement Club",
      "Business Innovation and Pitch Competitions",
      "Investment and Financial Literacy Club",
      "School Market Days and Enterprise Projects"
    ],
    icon: "Briefcase"
  },
  {
    id: "dept-ict",
    name: "ICT Department",
    slug: "ict",
    headOfDepartment: {
      name: "Mr Tapiwa Norman Chivorese",
      title: "Head of ICT",
      image: "./assets/aistudio/Chivorese_92d20e94.jpg",
      qualifications: "BSc Computer Science, Cambridge Certified Teacher",
      status: "published"
    },
    shortDescription: "The ICT Department develops students' digital literacy, computational thinking, programming, technological innovation and problem-solving skills. It equips learners with the knowledge and practical skills required to thrive in an increasingly digital world.",
    curriculum: "ICT (Form 1–3) progressing to Computer Science (Form 4–A2) aligned with Cambridge International examinations and practical computing projects.",
    subjects: [
      "ICT – Form 1–3",
      "Computer Science – Form 4–A2"
    ],
    keyAreas: [
      "Programming and software development",
      "Computer systems and architecture",
      "Data representation and management",
      "Computer networks and cybersecurity",
      "Algorithms and computational thinking",
      "Robotics and automation",
      "Artificial Intelligence and emerging technologies",
      "Web design and development"
    ],
    activities: [
      "Robotics Club",
      "Coding and Programming Club",
      "Computer Science Projects",
      "Digital Innovation and Technology Challenges",
      "Cybersecurity Awareness Activities",
      "Artificial Intelligence and Digital Literacy Workshops",
      "Web Design and Development Projects"
    ],
    facilities: [
      "Air-conditioned networked computer laboratories with campus broadband",
      "Robotics kits, microcontrollers and automation prototyping equipment",
      "Programming, database, networking and web design learning suites"
    ],
    features: [
      "Robotics Club",
      "Coding and Programming Club",
      "Cybersecurity Awareness Activities",
      "AI, Web Design & Digital Innovation Workshops"
    ],
    icon: "Cpu"
  }
];

export const HOUSES: HouseInfo[] = [
  {
    id: "house-bathoen",
    name: "Bathoen House",
    colorName: "Red",
    colorHex: "#dc2626",
    color: "#dc2626",
    textColor: "text-red-800",
    bgColor: "bg-red-50 border-red-300",
    patron: "Bathoen I",
    description: "Honouring the resolute statesman and celebrating tenacity, steadfast courage and the spirit of achievement."
  },
  {
    id: "house-khama",
    name: "Khama House",
    colorName: "Green",
    colorHex: "#16a34a",
    color: "#16a34a",
    textColor: "text-emerald-800",
    bgColor: "bg-emerald-50 border-emerald-300",
    patron: "Khama III",
    description: "Honouring the revered statesman and promoting principled leadership, integrity, dignified conduct and athletic excellence."
  },
  {
    id: "house-sechele",
    name: "Sechele House",
    colorName: "Blue",
    colorHex: "#1d4ed8",
    color: "#1d4ed8",
    textColor: "text-blue-900",
    bgColor: "bg-blue-50 border-blue-300",
    patron: "Sechele I",
    description: "Named in honour of the pioneer of literacy and scholarship, representing intellectual curiosity, courage and commitment to learning."
  },
  {
    id: "house-moremi",
    name: "Moremi House",
    colorName: "Yellow",
    colorHex: "#eab308",
    color: "#eab308",
    textColor: "text-yellow-900",
    bgColor: "bg-yellow-50 border-yellow-300",
    patron: "Moremi",
    description: "Celebrating exploratory ambition, environmental stewardship, intellectual curiosity and cultural heritage."
  }
];

export const BOARDING_INFO = {
  capacity: 100,
  currentResidents: 39,
  spacesOpen: 61,
  headline: "Campus Residential Community · Capacity: 100 Students",
  subheadline: "A Home Away from Home",
  leadParagraph: "At Livingstone Kolobeng College, our state-of-the-art boarding facilities provide students with a safe, comfortable, and supportive environment in which to live, learn, and grow. Designed to promote academic excellence, personal development, and a strong sense of community, our boarding houses offer students a home away from home.",
  capacityNotice: "Our boarding facilities accommodate up to 100 students (with 39 students currently in residence across both wings), with dedicated residences for boys and girls: the Lady Olebile Masire Boarding House (up to 50 girls) and the Sir Ketumile Masire Boarding House (up to 50 boys).",
  entranceBanner: "Sir Ketumile Masire & Lady Olebile Masire Boarding Houses Entrance",
  officialTitle: "Official Campus Residences",
  housesSubhead: "Two Historic Houses Honoring Botswana's Leadership",
  housesLead: "Purpose-built separate wings ensuring complete privacy, structured pastoral supervision, and an empowering atmosphere for both young women and young men.",
  hostels: [
    {
      id: "girls-house",
      name: "Lady Olebile Masire Boarding House – Girls",
      wing: "Girls Residence",
      capacityBadge: "Girls Residence · 50 Beds Capacity",
      capacity: 50,
      description: "Accommodates up to 50 girls. Named in honour of Lady Olebile Masire, wife of Botswana's former President, Sir Ketumile Masire. It provides a welcoming and supportive environment where girls can thrive academically, build confidence, develop essential life skills, and form lasting friendships.",
      leaderName: "Ms T Tumotumo",
      leaderRole: "Boarding Mistress",
      leaderTitle: "Boarding Mistress & Senior English Teacher – Girls Residence",
      leaderImage: "./assets/aistudio/Tumotumo_dbbe66dc.jpg",
      quoteTitle: "Pastoral Care",
      quote: "Welcome to the Lady Olebile Masire Boarding House. Our girls’ residence is more than just accommodation—it is a warm, sisterly community where young women thrive academically, develop self-discipline, build lasting friendships, and are nurtured with dignified pastoral care in a secure home away from home.",
      features: [
        "Safe, secure biometric-monitored dormitories",
        "Quiet study suites & high-speed academic internet",
        "Resident female boarding mistress & pastoral nursing support"
      ],
      applyCta: "Apply for Girls Boarding"
    },
    {
      id: "boys-house",
      name: "Sir Ketumile Masire Boarding House – Boys",
      wing: "Boys Residence",
      capacityBadge: "Boys Residence · 50 Beds Capacity",
      capacity: 50,
      description: "Accommodates up to 50 boys. Named in honour of Sir Ketumile Masire, Botswana's former President, who worked as a teacher before entering national leadership. The residence encourages boys to develop independence, take responsibility, build lasting friendships, and pursue academic excellence.",
      leaderName: "Mr Anderson Dube",
      leaderRole: "Boarding Master",
      leaderTitle: "Boarding Master & Senior Geography Master – Boys Residence",
      leaderImage: "./assets/aistudio/Dube_f9988e37.jpg",
      quoteTitle: "House Leadership",
      quote: "Welcome to the Sir Ketumile Masire Boarding House. Carrying forward the educational and leadership legacy of Botswana’s former President, our residence fosters brotherhood, integrity, and disciplined study habits. Here, young men cultivate the self-reliance and academic focus essential for university and life beyond.",
      features: [
        "Air-cooled study dorms & recreational student commons",
        "High-speed campus fiber for academic research",
        "Direct access to rugby, football & basketball sports facilities"
      ],
      applyCta: "Apply for Boys Boarding"
    }
  ],
  morningRoutine: [
    { time: "05:30 – 06:15", activity: "Wake-Up, Morning Ablutions & Inspection", notes: "Rooms tidied and inspected by prefects" },
    { time: "06:15 – 06:30", activity: "Nutritious Dining Hall Breakfast", notes: "Hot breakfast served at the Cafeteria" },
    { time: "06:30 – 07:00", activity: "Morning Reflection & Campus Transit", notes: "Short walk to academic main building" },
    { time: "07:00 – 16:30", activity: "Main Academic Schedule & Activities", notes: "Full Cambridge school day & clubs" }
  ],
  eveningRoutine: [
    { time: "16:30 – 17:30", activity: "Sports, Co-Curriculars & Downtime", notes: "Outdoor sports, library or leisure" },
    { time: "17:30 – 18:00", activity: "Evening Bath & Grooming", notes: "Return to residential wings" },
    { time: "18:00 – 18:30", activity: "Wholesome Dinner", notes: "Hot dinner served in dining hall" },
    { time: "18:30 – 20:30", activity: "Supervised Evening Study (Prep)", notes: "Monitored silent academic study" },
    { time: "20:30 – 21:30", activity: "Staggered Lights-Out by Year Group", notes: "Restful sleep ensured for all students" }
  ],
  lightsOutSchedule: [
    { group: "Lower School", grades: "Forms 1–2 (Ages 12–14)", time: "20:30", rationale: "Adequate rest essential for cognitive growth" },
    { group: "High School", grades: "Forms 3–5 (IGCSE Candidates)", time: "21:00", rationale: "Balanced study habits & wellness" },
    { group: "Upper School", grades: "Cambridge AS & A-Levels", time: "21:30", rationale: "Extended private study allowance" }
  ],
  cafeteria: {
    title: "Our Cafeteria & Dining Pavilion",
    headline: "Nutritious Dining · 3 Hot Meals Daily",
    subheadline: "Fueling Academic Focus & Wholesome Living",
    description: "Our dedicated campus culinary team serves balanced, freshly prepared meals 7 days a week, accommodating diverse dietary requirements and fostering family-style table culture.",
    meals: [
      { meal: "Breakfast", time: "06:15 – 06:30", details: "Cereals, hot porridge, eggs, fresh toast, tea, milk and seasonal fruit" },
      { meal: "Lunch", time: "13:00 – 14:00", details: "Warm balanced main meals, proteins, fresh greens, rice or pap" },
      { meal: "Dinner", time: "18:00 – 18:30", details: "Hearty dinner including stews, roasted chicken, vegetables and warm soup" }
    ]
  },
  communityPillars: [
    {
      title: "Pastoral Mentorship",
      desc: "Resident house mistresses, house masters, and matrons on hand 24/7 providing emotional support, life guidance, and spiritual wellbeing."
    },
    {
      title: "Academic Evening Prep",
      desc: "Structured, silent study hours supported by rotating Cambridge subject teachers for one-on-one homework and examination tutoring."
    },
    {
      title: "Weekend Recreation & Leisure",
      desc: "Organized sports tournaments, debate evenings, campus movie nights, board games, and supervised weekend shopping shuttles."
    },
    {
      title: "Health & Medical Oversight",
      desc: "On-campus sickbay overseen by a registered school nurse with direct priority referral protocols to Gaborone private hospitals."
    }
  ]
};

export const CURRICULUM_DATA: Record<string, { title: string; subtitle: string; description: string; subjects: SubjectInfo[] }> = {
  "preschool": {
    title: "Preschool & Early Childhood Development (Ages 3–5)",
    subtitle: "Foundational Inquiry & Sensory Development",
    description: "A nurturing, vibrant early years environment fostering foundational literacy, numeracy discovery, motor coordination, creative arts, and social empathy in small supportive classes.",
    subjects: [
      { code: "PRE-LIT", name: "Early Phonemic Literacy & Storytelling", stream: "Early Years", description: "Letter-sound relationships, vocabulary immersion, interactive story circles.", isCore: true },
      { code: "PRE-NUM", name: "Foundational Numeracy & Spatial Discovery", stream: "Early Years", description: "Counting games, patterns, shapes, spatial relationships, hands-on sensory math.", isCore: true },
      { code: "PRE-SCI", name: "Early World Exploration & Nature Play", stream: "Early Years", description: "Plants, seasons, animal life, tactile sensory outdoor learning gardens.", isCore: true },
      { code: "PRE-ART", name: "Creative Expression, Music & Movement", stream: "Early Years", description: "Finger painting, rhythmic marimba rhythms, singing, roleplay.", isCore: true },
      { code: "PRE-MOT", name: "Physical Motor Skills & Coordination", stream: "Early Years", description: "Gross & fine motor agility, balance games, playground team play.", isCore: true }
    ]
  },
  "lower-secondary": {
    title: "Lower Secondary (Forms 1 & 2)",
    subtitle: "Cambridge Lower Secondary Framework (11 Broad Subjects)",
    description: "A comprehensive, rigorous foundational curriculum preparing students aged 12–14 with critical enquiry, mathematical mastery, experimental sciences, linguistic fluency, and ICT proficiency.",
    subjects: [
      { code: "ENG-01", name: "English First Language", stream: "Languages", description: "Analytical reading, composition, rhetoric, and literary appreciation.", isCore: true },
      { code: "MAT-01", name: "Mathematics", stream: "Sciences", description: "Algebraic structures, Euclidean geometry, probability, and spatial reasoning.", isCore: true },
      { code: "SCI-01", name: "Integrated General Sciences", stream: "Sciences", description: "Foundational physics, chemistry, and biology with mandatory weekly laboratory practicals.", isCore: true },
      { code: "SET-01", name: "Setswana Language & Culture", stream: "Languages", description: "Grammar, national literature, cultural traditions, and oral rhetoric.", isCore: true },
      { code: "FRE-01", name: "French Foreign Language", stream: "Languages", description: "Conversational fluency, grammar, comprehension, and Francophone studies." },
      { code: "ICT-01", name: "Information & Communication Technology", stream: "Creative & Tech", description: "Digital literacy, introductory programming, spreadsheets, and database basics." },
      { code: "GEO-01", name: "Geography & Environmental Studies", stream: "Humanities", description: "Physical geography, geomorphology, climate change, and human settlements." },
      { code: "HIS-01", name: "History of Botswana & World History", stream: "Humanities", description: "SADC regional history, colonial eras, democratic evolution, and 20th-century world shifts." },
      { code: "BUS-01", name: "Introduction to Commerce & Accounting", stream: "Commercial", description: "Foundations of enterprise, financial ledgers, trade principles, and budgeting." },
      { code: "ART-01", name: "Art & Design", stream: "Creative & Tech", description: "Fine art techniques, observational drawing, painting, ceramics, and art history." },
      { code: "MUS-01", name: "Music & Performing Arts", stream: "Creative & Tech", description: "Music theory, traditional African marimba, choral performance, and ensemble." },
      { code: "PHE-01", name: "Physical Education & Jaguars Athletics", stream: "Creative & Tech", description: "Athletics, competitive team sports, fitness physiology, and sportsmanship.", isCore: true },
    ]
  },
  "pre-igcse": {
    title: "Pre-IGCSE Transition (Form 3)",
    subtitle: "Cambridge Pre-IGCSE Gateway (10 Structured Subjects)",
    description: "An intensive bridge year refining subject specialization and laboratory research in preparation for the two-year Cambridge IGCSE examination syllabus.",
    subjects: [
      { code: "F3-ENG", name: "Advanced English Comprehension & Composition", stream: "Languages", description: "Critical essay structure, rhetorical analysis, and literary texts.", isCore: true },
      { code: "F3-MAT", name: "Pre-IGCSE Extended Mathematics", stream: "Sciences", description: "Quadratic equations, coordinate geometry, trigonometry, vectors.", isCore: true },
      { code: "F3-PHY", name: "Physics & Mechanics Foundations", stream: "Sciences", description: "Experimental mechanics, kinematics, electricity fundamentals.", isCore: true },
      { code: "F3-CHM", name: "Chemistry Foundations & Stoichiometry", stream: "Sciences", description: "Atomic structure, chemical equations, acids and bases laboratory work.", isCore: true },
      { code: "F3-BIO", name: "Cellular Biology & Ecology", stream: "Sciences", description: "Cell structure, genetics overview, human circulatory systems.", isCore: true },
      { code: "F3-ACC", name: "Foundations of Accounting & Bookkeeping", stream: "Commercial", description: "Ledger entries, balancing accounts, profit and loss calculations." },
      { code: "F3-ECO", name: "Introductory Economics & Enterprise", stream: "Commercial", description: "Supply, demand, markets, global trade introduction." },
      { code: "F3-CS", name: "Computer Science & Python Coding", stream: "Creative & Tech", description: "Computational logic, control structures, and algorithms." },
      { code: "F3-HIS", name: "Modern World & African History", stream: "Humanities", description: "20th-century global diplomacy and southern African history." },
      { code: "F3-FRE", name: "Intermediate French Language", stream: "Languages", description: "Intermediate communicative competence and listening comprehension." }
    ]
  },
  "igcse": {
    title: "Upper Secondary (Forms 4 – 5) — Cambridge IGCSE",
    subtitle: "International General Certificate of Secondary Education (UCLES)",
    description: "Two-year international qualification culminating in externally assessed Cambridge IGCSE examinations. Students select 8 to 9 subjects structured into balanced academic pathways.",
    subjects: [
      { code: "IG-0500", name: "Cambridge IGCSE First Language English", stream: "Languages", description: "Advanced textual analysis, argumentative synthesis, style commentary.", cambridgeCode: "0500", isCore: true },
      { code: "IG-0580", name: "Cambridge IGCSE Mathematics (Extended)", stream: "Sciences", description: "Pure mathematics, calculus foundations, trigonometry, vectors, probability.", cambridgeCode: "0580", isCore: true },
      { code: "IG-0625", name: "Cambridge IGCSE Physics", stream: "Sciences", description: "Mechanics, thermal physics, waves, electromagnetism, atomic and nuclear physics.", cambridgeCode: "0625" },
      { code: "IG-0620", name: "Cambridge IGCSE Chemistry", stream: "Sciences", description: "Stoichiometry, organic chemistry, periodic trends, electrochemistry, and wet chemistry lab exam.", cambridgeCode: "0620" },
      { code: "IG-0610", name: "Cambridge IGCSE Biology", stream: "Sciences", description: "Cellular biology, genetics, human physiology, biotechnology, and ecology.", cambridgeCode: "0610" },
      { code: "IG-0452", name: "Cambridge IGCSE Accounting", stream: "Commercial", description: "Double-entry bookkeeping, trial balance adjustments, partnership & company financial statements.", cambridgeCode: "0452" },
      { code: "IG-0450", name: "Cambridge IGCSE Business Studies", stream: "Commercial", description: "Marketing strategies, organizational behavior, financial management, operations.", cambridgeCode: "0450" },
      { code: "IG-0455", name: "Cambridge IGCSE Economics", stream: "Commercial", description: "Microeconomics, macroeconomic government objectives, international monetary systems.", cambridgeCode: "0455" },
      { code: "IG-0478", name: "Cambridge IGCSE Computer Science", stream: "Creative & Tech", description: "Python algorithm design, data representation, logic gates, cybersecurity, computer architecture.", cambridgeCode: "0478" },
      { code: "IG-0460", name: "Cambridge IGCSE Geography", stream: "Humanities", description: "Hydrology, plate tectonics, population demographics, environmental resource management.", cambridgeCode: "0460" },
      { code: "IG-0470", name: "Cambridge IGCSE History", stream: "Humanities", description: "International relations in the 20th century, League of Nations, Cold War, Southern African liberation.", cambridgeCode: "0470" },
      { code: "IG-0400", name: "Cambridge IGCSE Art & Design", stream: "Creative & Tech", description: "Studio portfolio submission, observational studies, experimental media.", cambridgeCode: "0400" },
      { code: "IG-0520", name: "Cambridge IGCSE French Foreign Language", stream: "Languages", description: "Oral examination, authentic listening analysis, reading comprehension, French correspondence.", cambridgeCode: "0520" }
    ]
  },
  "a-levels": {
    title: "Sixth Form — Cambridge International AS & A Levels",
    subtitle: "Advanced Level Pre-University Excellence (Forms 6.1 & 6.2)",
    description: "The gold-standard university entrance qualification accepted worldwide by Ivy League, Russell Group, and prestigious African universities. Students specialize in 3 to 4 subjects.",
    subjects: [
      { code: "AL-9709", name: "Cambridge International A-Level Mathematics", stream: "Sciences", description: "Pure Mathematics (P1, P3) combined with Mechanics (M1) or Probability & Statistics (S1).", cambridgeCode: "9709" },
      { code: "AL-9702", name: "Cambridge International A-Level Physics", stream: "Sciences", description: "Advanced quantum mechanics, thermodynamics, gravitational fields, operational amplifiers, experimental lab paper.", cambridgeCode: "9702" },
      { code: "AL-9701", name: "Cambridge International A-Level Chemistry", stream: "Sciences", description: "Physical chemistry thermodynamics, advanced organic reaction mechanisms, transition metals, spectroscopy.", cambridgeCode: "9701" },
      { code: "AL-9700", name: "Cambridge International A-Level Biology", stream: "Sciences", description: "Molecular genetics, recombinant DNA technology, mammalian nervous coordination, bioinformatics.", cambridgeCode: "9700" },
      { code: "AL-9618", name: "Cambridge International A-Level Computer Science", stream: "Creative & Tech", description: "Object-oriented software engineering in Python, complex data structures, computational theory, systems design.", cambridgeCode: "9618" },
      { code: "AL-9708", name: "Cambridge International A-Level Economics", stream: "Commercial", description: "Price mechanism market failures, macroeconomic policies, international trade equilibria, economic development.", cambridgeCode: "9708" },
      { code: "AL-9706", name: "Cambridge International A-Level Accounting", stream: "Commercial", description: "Cost & management accounting, variance analysis, auditing standards, published company reports.", cambridgeCode: "9706" },
      { code: "AL-9609", name: "Cambridge International A-Level Business", stream: "Commercial", description: "Strategic corporate decision making, financial forecasting, change management, business leadership.", cambridgeCode: "9609" },
      { code: "AL-9093", name: "Cambridge International A-Level English Language", stream: "Languages", description: "Language change over time, child language acquisition, sociolinguistics, discourse analysis.", cambridgeCode: "9093" },
      { code: "AL-9696", name: "Cambridge International A-Level Geography", stream: "Humanities", description: "Hydrology and fluvial geomorphology, atmospheric circulation, global migration, hazardous environments.", cambridgeCode: "9696" },
    ]
  }
};

export const BANK_ACCOUNTS = [
  {
    bankName: "Stanbic Bank",
    accountName: "Lavender Projects",
    accountNumber: "9060003561815",
    branch: "Fairgrounds",
    branchCode: "064967",
    swiftCode: "SBICBWGX",
  },
  {
    bankName: "First Capital Bank",
    accountName: "Lavender Projects",
    accountNumber: "0004704076626",
    branch: "Broadhurst",
    branchCode: "800467",
    swiftCode: "FRCGBWGA",
  },
  {
    bankName: "Bank of Baroda",
    accountName: "Lavender Projects",
    accountNumber: "5210200002480",
    branch: "Main Mall",
    branchCode: "110167",
    swiftCode: "BARBBWGXXXX",
  },
];

export const FEE_POLICY_RULES = [
  "The 1st fees installment must be paid by the end of the preceding term, and the 2nd fees installment must be paid by the end of the first month of the current term. All fees must be fully paid by the end of the first month of each term.",
  "Development fees must be paid in full together with the first installment of school fees prior to attendance.",
  "All Form 5 examination fees must be paid by 31 July 2026 to ensure confirmation of examination entry.",
  "If fees are not paid by the due dates, a written letter of the outstanding balance will be issued. The letter will state that your child/children will not be permitted to return to school until all outstanding fees have been settled.",
  "If the parent or guardian does not pay the full fees within 30 days from the date of the letter and provides no communication, the account will be handed over to the school’s attorneys. The parent or guardian will be liable for all costs, fees, disbursements, and legal charges reasonably incurred by the school in recovering any unpaid fees.",
  "The finance officer reserves the right to exclude from school, students whose fees are unpaid at the beginning of the term.",
  "Sibling discount: The eldest child pays in full as per the due dates, 2nd child and subsequent children 5% discount on tuition fees only. Any siblings should be notified to the accounts office in writing.",
  "Annual discount: If the full year's fees for 2026 are paid before the first day of Term 1, a 2.5% discount will be offered.",
  "Trust funds: No discounts shall be granted on any fees paid through trust funds. All payments made using trust funds are subject to the full applicable fee amounts, without exception.",
  "Remittance verification: Kindly reference all payments with student's full name. Email proof of payment to the bursar on accountslkc@yahoo.com or WhatsApp +267 72 820 327."
];

export const FEE_STRUCTURE = {
  currency: "BWP (Botswana Pula)",
  academicYear: "2026 Academic Year",
  pdfDocumentUrl: "./assets/aistudio/School_Fees_Policy_2026_IGCSE_f50e8781.pdf",
  oneOffFees: {
    entranceAssessment: 300,
    registrationEnrollment: 500,
    developmentLevyForms1to5: 10000,
    developmentLevyALevel: 5000,
  },
  tuitionPerTerm: {
    "preschool": {
      term: 12500,
      annual: 37500,
      termsCount: 3,
      label: "Preschool (Ages 3–5 Early Years)",
      installments: [
        { termName: "Term 1", pay1: 6250, due1: "30 NOV 2025", pay2: 6250, due2: "31 JAN 2026" },
        { termName: "Term 2", pay1: 6250, due1: "31 MAR 2026", pay2: 6250, due2: "30 APR 2026" },
        { termName: "Term 3", pay1: 6250, due1: "30 JUNE 2026", pay2: 6250, due2: "31 JULY 2026" },
      ]
    },
    "form-1": {
      term: 20000,
      annual: 60000,
      termsCount: 3,
      label: "Form 1 (Lower Secondary Entry)",
      installments: [
        { termName: "Term 1", pay1: 10000, due1: "30 NOV 2025", pay2: 10000, due2: "31 JAN 2026" },
        { termName: "Term 2", pay1: 10000, due1: "31 MAR 2026", pay2: 10000, due2: "30 APR 2026" },
        { termName: "Term 3", pay1: 10000, due1: "30 JUNE 2026", pay2: 10000, due2: "31 JULY 2026" },
      ]
    },
    "form-2-3": {
      term: 22000,
      annual: 66000,
      termsCount: 3,
      label: "Form 2 & 3 (Lower Secondary & Pre-IGCSE)",
      installments: [
        { termName: "Term 1", pay1: 11000, due1: "30 NOV 2025", pay2: 11000, due2: "31 JAN 2026" },
        { termName: "Term 2", pay1: 11000, due1: "31 MAR 2026", pay2: 11000, due2: "30 APR 2026" },
        { termName: "Term 3", pay1: 11000, due1: "30 JUNE 2026", pay2: 11000, due2: "31 JULY 2026" },
      ]
    },
    "form-4": {
      term: 24000,
      annual: 72000,
      termsCount: 3,
      label: "Form 4 (Cambridge IGCSE Year 1)",
      installments: [
        { termName: "Term 1", pay1: 12000, due1: "30 NOV 2025", pay2: 12000, due2: "31 JAN 2026" },
        { termName: "Term 2", pay1: 12000, due1: "31 MAR 2026", pay2: 12000, due2: "30 APR 2026" },
        { termName: "Term 3", pay1: 12000, due1: "30 JUNE 2026", pay2: 12000, due2: "31 JULY 2026" },
      ]
    },
    "form-5": {
      term: 36000,
      annual: 72000,
      termsCount: 2,
      label: "Form 5 (Cambridge IGCSE Final Year - 2 Terms)",
      installments: [
        { termName: "Term 1", pay1: 18000, due1: "30 NOV 2025", pay2: 18000, due2: "31 JAN 2026" },
        { termName: "Term 2", pay1: 18000, due1: "31 MAR 2026", pay2: 18000, due2: "30 JUNE 2026" },
      ]
    },
    "a-levels": {
      term: 26667,
      annual: 80000,
      termsCount: 3,
      label: "Cambridge AS & A2 Levels (Sixth Form)",
      installments: [
        { termName: "Term 1", pay1: 13333, due1: "30 NOV 2025", pay2: 13334, due2: "31 JAN 2026" },
        { termName: "Term 2", pay1: 13333, due1: "31 MAR 2026", pay2: 13334, due2: "30 APR 2026" },
        { termName: "Term 3", pay1: 13333, due1: "30 JUNE 2026", pay2: 13334, due2: "31 JULY 2026" },
      ]
    },
  },
  boardingSchedule: {
    annual: 70000,
    term1: 24000,
    term2: 24000,
    term3: 22000,
    description: "Annual Fees: P 70,000.00 (Term 1: P 24,000 | Term 2: P 24,000 | Term 3: P 22,000)"
  },
  boardingPerTerm: 24000, // Term 1 & 2 baseline
  annualDiscountPercentage: 2.5, // 2.5% discount if full year paid before Term 1
  siblingDiscountPercentage: 5, // 5% discount on tuition for 2nd and subsequent children
  transportRoutes: [
    { zone: "Zone A: Block 8, Block 6, Block 10, Gaborone West", costPerTerm: 3200 },
    { zone: "Zone B: Broadhurst, Extension 8, CBD, Tsholofelo", costPerTerm: 3800 },
    { zone: "Zone C: Phakalane, Mogoditshane, Tlokweng", costPerTerm: 4500 },
  ],
  optionalServices: [
    { id: "lunch", name: "Full Term Nutritious Hot Lunch Program", costPerTerm: 3500 },
    { id: "instrument", name: "Individual Classical/Marimba Instrument Tuition", costPerTerm: 1800 },
    { id: "robotics", name: "VEX Robotics & STEM Academy Pass", costPerTerm: 1200 },
  ]
};

export const TERM_DATES_2026: TermDate[] = [
  {
    term: "Term 1 (Autumn)",
    title: "Opening Term & Orientation",
    start: "13 January 2026",
    end: "10 April 2026",
    midTermBreak: "19 – 23 February 2026",
    milestones: ["New Students Orientation", "Inter-House Swimming Gala", "Form 5 Cambridge Diagnostic Tests", "Term 1 Academic Reports"]
  },
  {
    term: "Term 2 (Winter)",
    title: "Athletics & Cambridge Mid-Years",
    start: "5 May 2026",
    end: "7 August 2026",
    midTermBreak: "18 – 22 June 2026",
    milestones: ["Inter-House Track & Field Gala", "President's Day Holiday Observance", "Cambridge Mock Examinations", "Parent-Teacher Conferences"]
  },
  {
    term: "Term 3 (Spring)",
    title: "Examination Season & Valedictory",
    start: "8 September 2026",
    end: "4 December 2026",
    midTermBreak: "15 – 19 October 2026",
    milestones: ["Botswana Independence Day Celebration", "Cambridge IGCSE & A-Level External Examinations", "Annual Speech & Prize Giving Day", "Valedictory Banquet"]
  }
];

export const NOTABLE_ALUMNI: AchievementItem[] = [];

export const FAQS = [
  {
    q: "What curriculum does Livingstone Kolobeng College offer?",
    a: "Livingstone Kolobeng College is an officially accredited Cambridge Assessment International Education Examination Centre. We offer the complete Cambridge pathway from Preschool (ages 3–5), Lower Secondary (Forms 1–2), Pre-IGCSE (Form 3), to Cambridge IGCSE (Forms 4–5), and Cambridge International AS & A2 Levels."
  },
  {
    q: "Who leads the academic and institutional governance at LKC?",
    a: "LKC is led by Managing Director Mrs Nilima Bakaya and Principal Dr Jeff Ramsay (distinguished historian and senior academician), supported by Vice Principal of All Affairs Dr Fedious Mutenheri and Vice Principal of Administration Mr R Nyika."
  },
  {
    q: "What is the admissions procedure for new students?",
    a: "Prospective students can apply directly online via our School Management Admissions Portal (https://lkcportal.com/?form=apply) or through our website application form. Candidates sit for our diagnostic assessment in Mathematics and English Language and submit previous academic term reports."
  },
  {
    q: "Does LKC provide boarding facilities?",
    a: "Yes. LKC accommodates up to 100 resident boarders (with 39 currently enrolled and 61 spaces open for admission) in dedicated residences: the Lady Olebile Masire Boarding House (up to 50 girls) and the Sir Ketumile Masire Boarding House (up to 50 boys). Boarding features 24/7 pastoral oversight, House Mistress & House Master leadership, 3 daily hot cafeteria meals, and supervised evening study."
  },
  {
    q: "What sports and extra-curricular activities are available?",
    a: "Home of the Kolobeng Jaguars! Students compete in rugby, basketball, football, swimming, athletics, and tennis in the BISA inter-school leagues. Non-sporting societies include SADC champion Debating, VEX Robotics, Marimba ensemble, Model United Nations, and the Duke of Edinburgh International Award."
  },
  {
    q: "Where is the college physically located and how do I contact the office?",
    a: "LKC is situated at Plot 37225, Block 8, Extension 38, Gaborone West, Botswana. You can telephone us at +267 316 1140 or +267 316 2208, message us via official WhatsApp at +267 78 465 196, or email principal@lkc.ac.bw / admissions@livingstonekolobeng.ac.bw."
  }
];

export const EXCURSIONS_DATA: ExcursionItem[] = [
  {
    id: "excursion-france-2025",
    title: "France Educational & Cultural Tour (2025)",
    category: "International",
    year: "2025",
    destination: "Paris & Regional Cultural Sites, France",
    targetForms: "French Language, Humanities & Art Students",
    duration: "International Study Tour (2025)",
    description: "An enriching European educational tour to France celebrating French linguistic immersion, historical architecture, fine arts museums, and international cultural exchange.",
    curriculumLink: "Cambridge French (0520), History (0470) & Art & Design (0400)",
    highlights: [
      "French language immersion in authentic European settings",
      "Visits to historic Parisian landmarks and world-renowned museums",
      "Exposure to European arts, architecture, and civic heritage",
      "Cross-cultural global citizenship workshops"
    ]
  },
  {
    id: "excursion-singapore-2026",
    title: "Singapore Educational & STEM Innovation Tour (2026)",
    category: "International",
    year: "2026",
    destination: "Singapore",
    targetForms: "Science, ICT & Commercials Scholars",
    duration: "International Study Tour (2026)",
    description: "A forward-looking international academic excursion to Singapore focused on world-class urban sustainability, scientific innovation, computing technology, and global commerce.",
    curriculumLink: "Cambridge Computer Science (0478), Sciences & Economics (0455)",
    highlights: [
      "Exploration of Singapore's smart-city planning and green architecture",
      "Visits to premier science, robotics, and innovation hubs",
      "Insights into global maritime trade and Asian economic growth",
      "Academic exchange and leadership seminars"
    ]
  },
  {
    id: "excursion-south-africa-2026",
    title: "South Africa Educational & Academic Tour (2026)",
    category: "Regional",
    year: "2026",
    destination: "South Africa",
    targetForms: "Middle & Senior School Cohorts",
    duration: "Regional Study Tour (2026)",
    description: "A comprehensive regional study tour to South Africa connecting classroom learning with university campuses, scientific institutions, historical heritage sites, and regional sporting culture.",
    curriculumLink: "Cambridge Humanities, Sciences & Physical Education",
    highlights: [
      "Visits to leading Southern African academic and scientific institutions",
      "Historical and cultural heritage site exploration",
      "Leadership, teamwork, and regional exchange activities",
      "Pre-university exposure for senior Cambridge learners"
    ]
  },
  {
    id: "excursion-kasane",
    title: "Kasane & Chobe Ecological Study Excursion",
    category: "National",
    destination: "Kasane, Chobe District, Botswana",
    targetForms: "Biology, Geography & Environmental Studies Cohorts",
    duration: "National Residential Field Trip",
    description: "A domestic field study tour to Kasane along the Chobe Riverfront where learners investigate Botswana's wildlife conservation ecosystems, river hydrology, and sustainable ecotourism.",
    curriculumLink: "Cambridge IGCSE Biology (0610) & Geography (0460)",
    highlights: [
      "Chobe River basin ecological and hydrological observation",
      "Botswana wildlife conservation and habitat management studies",
      "Field data collection and geographical sketching",
      "Responsible eco-tourism case studies"
    ]
  },
  {
    id: "excursion-vic-falls-2024",
    title: "Victoria Falls Educational Tour (2024)",
    category: "Regional",
    year: "2024",
    destination: "Victoria Falls (Cross-Border Regional Tour)",
    targetForms: "Geography, History & Senior Forms",
    duration: "Regional Study Tour (2024)",
    description: "Our 2024 regional educational excursion to Victoria Falls offering firsthand geological, geographical, and historical study of the Zambezi River gorge, Kazungula corridor, and rainforest microclimate.",
    curriculumLink: "Cambridge Geography (0460 / 9696) & History (0470)",
    highlights: [
      "Geological study of basalt gorges and waterfall formation",
      "Rainforest microclimate botanical observation",
      "Exploration of Southern African regional heritage & trade corridors",
      "Guided cross-border educational reflections"
    ]
  }
];

export const ALUMNI_PROFILES_DATA: AlumniProfile[] = [];

export const CAMBRIDGE_RESULTS_SUMMARY_2025 = {
  headline: "LKC Does It Again! 2025 Cambridge Results",
  subheadline: "Excellence Recognized · Futures Inspired · Thuto Ke Botshelo",
  anniversary: "20 Years of Academic Excellence (2006 – 2026)",
  igcsePassRate: "99.4%",
  igcseCreditPassRate: "93.1%",
  aLevelPassRate: "100%",
  description: "The Livingstone Kolobeng College community celebrates another landmark year of outstanding Cambridge International Examination results. For all 23 IGCSE subjects, students achieved a 99.4% pass rate with 93.1% credit passes, and 100% pass rate in all subjects across A-Level A2 examinations. LKC alumni continue to secure placements at Ivy League, Russell Group, and leading universities globally.",
  bannerImages: {
    igcseHero: "./assets/aistudio/615794404_1512789714189193_846853645169836317_n_07c7598e.jpg",
    newspaperSpread: "./assets/aistudio/615904833_1517048187096679_2318444802684389687_n_df924cf1.jpg",
    dozenAchievers: "./assets/aistudio/774672545_1076377798282870_1247591611568933828_n_b7303c76.jpg"
  }
};

export const CAMBRIDGE_LEARNER_AWARDS_2025: CambridgeLearnerAward[] = [
  {
    id: "award-miranda-gaoage",
    studentName: "Miranda L. Gaoage",
    awardType: "Top in the World",
    level: "Cambridge IGCSE",
    subject: "Agriculture",
    image: "./assets/aistudio/754057978_2309343803202553_8740330693992551202_n_5f51a62c.jpg",
    year: "2025",
    grades: "7A*, 2B",
    highlightNote: "Top in the World across all Cambridge Assessment International Education global entries"
  },
  {
    id: "award-katlo-kgosiyang",
    studentName: "Katlo J. Kgosiyang",
    awardType: "Top in Botswana",
    level: "Cambridge AS Level",
    subject: "Mathematics & Further Maths",
    image: "./assets/aistudio/753192905_1023477903882905_4748542171726446134_n_5db9ca82.jpg",
    year: "2025",
    grades: "4A (AS), 3A (A2)",
    highlightNote: "Top in Botswana in Mathematics and High Achievement in Further Mathematics"
  },
  {
    id: "award-refilwe-mosekiemang",
    studentName: "Refilwe Mosekiemang",
    awardType: "Top in Botswana",
    level: "Cambridge AS Level",
    subject: "Chemistry",
    image: "./assets/aistudio/753887017_1075469354836706_178420611231454073_n_fb9767a7.jpg",
    year: "2025",
    grades: "4A*, A (A2)",
    highlightNote: "Top in Botswana in Chemistry across all Cambridge AS candidates nationwide"
  },
  {
    id: "award-lame-keakopa",
    studentName: "Lame Keakopa",
    awardType: "Top in Botswana",
    level: "Cambridge AS Level",
    subject: "Business",
    image: "./assets/aistudio/753707379_1015564457889098_6362331850025913152_n_6d880f6d.jpg",
    year: "2025",
    grades: "1A, 3B (AS)",
    highlightNote: "Top in Botswana in Cambridge AS Level Business studies"
  },
  {
    id: "award-thabang-ntshwarang",
    studentName: "Thabang Ntshwarang",
    awardType: "Top in Botswana",
    level: "Cambridge IGCSE",
    subject: "Mathematics",
    image: "./assets/aistudio/751752190_1354067536930441_4315025905510657305_n_04fcce91.jpg",
    year: "2025",
    grades: "6A*, 2A",
    highlightNote: "Top in Botswana in Cambridge IGCSE Mathematics"
  },
  {
    id: "award-mophato-makgadi",
    studentName: "Mophato Makgadi",
    awardType: "Top in Botswana",
    level: "Cambridge IGCSE",
    subject: "Business Studies",
    image: "./assets/aistudio/753647331_1758853285269545_431464464616465705_n_9e1eff3a.jpg",
    year: "2025",
    grades: "5A*, 2A, 1B",
    highlightNote: "Top in Botswana in Cambridge IGCSE Business Studies"
  },
  {
    id: "award-aone-mpoeleng",
    studentName: "Aone Mpoeleng",
    awardType: "Top in Botswana",
    level: "Cambridge IGCSE",
    subject: "Travel & Tourism",
    image: "./assets/aistudio/754960821_1798340494881389_6783855974128912569_n_96989caa.jpg",
    year: "2025",
    grades: "5A*, 3A, 1B",
    highlightNote: "Top in Botswana in Cambridge IGCSE Travel & Tourism"
  },
  {
    id: "award-lore-matt-kennedy",
    studentName: "Lore Matt Kennedy",
    awardType: "Top in Botswana",
    level: "Cambridge IGCSE",
    subject: "Physical Education",
    image: "./assets/aistudio/753288007_2330965551038396_3375065588724189450_n_e65d0c70.jpg",
    year: "2025",
    grades: "5A*, 3A, 1B",
    highlightNote: "Top in Botswana in Cambridge IGCSE Physical Education"
  },
  {
    id: "award-janna-grubber",
    studentName: "Janna R. Grubber",
    awardType: "High Achievement",
    level: "Cambridge AS Level",
    subject: "Accounting & Economics",
    image: "./assets/aistudio/754678035_1092249013343086_6625259594083886379_n_8cc909f0.jpg",
    year: "2025",
    grades: "2A, 1B (A2)",
    highlightNote: "Dual High Achievement in Cambridge AS Accounting and Economics"
  },
  {
    id: "award-phenyo-radipodi",
    studentName: "Phenyo Radipodi",
    awardType: "High Achievement",
    level: "Cambridge AS Level",
    subject: "Economics",
    image: "./assets/aistudio/753694860_3423141577846535_4531046626714548677_n_0c1e9fd0.jpg",
    year: "2025",
    grades: "2A, A (A2)",
    highlightNote: "Cambridge AS Level High Achievement in Economics"
  },
  {
    id: "award-kopano-matlhadisa",
    studentName: "Kopano Lobone Matlhadisa",
    awardType: "High Achievement",
    level: "Cambridge AS Level",
    subject: "History",
    image: "./assets/aistudio/754884679_1685815093544868_6033546716009080197_n_76e0d0c7.jpg",
    year: "2025",
    grades: "2A*, A (A2)",
    highlightNote: "Cambridge AS Level High Achievement in History"
  },
  {
    id: "award-tshiamo-gontse",
    studentName: "Tshiamo Patience Gontse",
    awardType: "High Achievement",
    level: "Cambridge AS Level",
    subject: "Geography",
    image: "./assets/aistudio/756338778_1079892261368663_1328769952349398368_n_4660ca89.jpg",
    year: "2025",
    grades: "4A (AS)",
    highlightNote: "Cambridge AS Level High Achievement in Geography"
  },
  {
    id: "award-oratile-mapitse",
    studentName: "Oratile P. Mapitse",
    awardType: "High Achievement",
    level: "Cambridge AS Level",
    subject: "Psychology",
    image: "./assets/aistudio/753557016_1786595129181414_4007349221263326150_n_a2ed851d.jpg",
    year: "2025",
    grades: "3A, 1B (AS)",
    highlightNote: "Cambridge AS Level High Achievement in Psychology"
  },
  {
    id: "award-leago-malope",
    studentName: "Leago Leroy Malope",
    awardType: "High Achievement",
    level: "Cambridge AS Level",
    subject: "Literature in English",
    image: "./assets/aistudio/753557057_1757580505396357_1814884563392275030_n_aaa3ffa0.jpg",
    year: "2025",
    grades: "3A (AS)",
    highlightNote: "Cambridge AS Level High Achievement in Literature in English"
  },
  {
    id: "award-legae-kgabi",
    studentName: "Legae Glen Kgabi",
    awardType: "High Achievement",
    level: "Cambridge AS Level",
    subject: "Computer Science",
    image: "./assets/aistudio/754648484_1782847262900230_7699909938535378958_n_6444b35e.jpg",
    year: "2025",
    grades: "3A (AS)",
    highlightNote: "Cambridge AS Level High Achievement in Computer Science"
  }
];

export const HONOR_ROLL_ACHIEVERS_2025: AchieverItem[] = [
  // IGCSE Top Achievers with 4+ A*s
  { id: "hr-1", studentName: "Gaoage Miranda Lulu", level: "Cambridge IGCSE", grades: "7A*, 2B", starCount: 7, featuredAward: "Top in the World: Agriculture" },
  { id: "hr-2", studentName: "Montebatsi Faith M. H. R", level: "Cambridge IGCSE", grades: "6A*, 2A", starCount: 6 },
  { id: "hr-3", studentName: "Ntshwarang Thabang B.", level: "Cambridge IGCSE", grades: "6A*, 2A", starCount: 6, featuredAward: "Top in Botswana: Mathematics" },
  { id: "hr-4", studentName: "Busang Setso Selemo", level: "Cambridge IGCSE", grades: "6A*, 1A, 1B", starCount: 6 },
  { id: "hr-5", studentName: "Gobagoba Phazha T.", level: "Cambridge IGCSE", grades: "5A*, 3A, 1B", starCount: 5 },
  { id: "hr-6", studentName: "Mpoeleng Aone", level: "Cambridge IGCSE", grades: "5A*, 3A, 1B", starCount: 5, featuredAward: "Top in Botswana: Travel & Tourism" },
  { id: "hr-7", studentName: "Sekalaba Yame Nikita", level: "Cambridge IGCSE", grades: "5A*, 3A", starCount: 5 },
  { id: "hr-8", studentName: "Mokgadi Mophato T.", level: "Cambridge IGCSE", grades: "5A*, 2A, 1B", starCount: 5, featuredAward: "Top in Botswana: Business Studies" },
  { id: "hr-9", studentName: "Kennedy Lore Matt", level: "Cambridge IGCSE", grades: "5A*, 3A, 1B", starCount: 5, featuredAward: "Top in Botswana: Physical Education" },
  { id: "hr-10", studentName: "Motlhaleemang Atlile E.", level: "Cambridge IGCSE", grades: "4A*, 3A, 1B", starCount: 4 },
  { id: "hr-11", studentName: "Raesima Tlhompho K.", level: "Cambridge IGCSE", grades: "4A*, 3A, 1B", starCount: 4 },
  { id: "hr-12", studentName: "Chiseki Kudah Dudu", level: "Cambridge IGCSE", grades: "3A*, 4A, 1B", starCount: 3 },
  { id: "hr-13", studentName: "Segobye Kgotla Poelo", level: "Cambridge IGCSE", grades: "3A*, 4A", starCount: 3 },
  { id: "hr-14", studentName: "Motshedi Boipelo M.", level: "Cambridge IGCSE", grades: "1A*, 5A, 2B", starCount: 1 },
  { id: "hr-15", studentName: "Chimutengwende Mufaro B.", level: "Cambridge IGCSE", grades: "1A*, 5A, 2B", starCount: 1 },
  { id: "hr-16", studentName: "Mokenti Katlo Maatla", level: "Cambridge IGCSE", grades: "2A*, 3A, 2B", starCount: 2 },
  { id: "hr-17", studentName: "Tsamaase Arona K.", level: "Cambridge IGCSE", grades: "2A*, 3A, 5B", starCount: 2 },

  // Cambridge AS & A2 Sixth Form Top Achievers
  { id: "hr-18", studentName: "Ali Mallikgingwa", level: "Cambridge A2 Level", grades: "4A*, A (A2)", starCount: 4, featuredAward: "Elite Sixth Form Honor Roll" },
  { id: "hr-19", studentName: "Refilwe Mosekiemang", level: "Cambridge A2 Level", grades: "4A*, A (A2)", starCount: 4, featuredAward: "Top in Botswana: Chemistry" },
  { id: "hr-20", studentName: "Kopano Lobone Matlhadisa", level: "Cambridge A2 Level", grades: "2A*, A (A2)", starCount: 2, featuredAward: "High Achievement: History" },
  { id: "hr-21", studentName: "Katlo J. Kgosiyang", level: "Cambridge A2 Level", grades: "4A, 3A (A2)", featuredAward: "Top in Botswana: Mathematics" },
  { id: "hr-22", studentName: "Kinisego Tsemang", level: "Cambridge A2 Level", grades: "3A (A2)" },
  { id: "hr-23", studentName: "Phenyo Radipodi", level: "Cambridge A2 Level", grades: "2A, A (A2)", featuredAward: "High Achievement: Economics" },
  { id: "hr-24", studentName: "One Makhalo", level: "Cambridge A2 Level", grades: "4A (A2)" },
  { id: "hr-25", studentName: "Tinelo Thekiso", level: "Cambridge A2 Level", grades: "4A (A2)" },
  { id: "hr-26", studentName: "Kennedy Shalom Tankiso", level: "Cambridge AS Level", grades: "4A (AS)" },
  { id: "hr-27", studentName: "Modise Leruo Letsholo", level: "Cambridge AS Level", grades: "4A (AS)" },
  { id: "hr-28", studentName: "Mutamba Bill Tatenda", level: "Cambridge AS Level", grades: "4A (AS)" },
  { id: "hr-29", studentName: "Tshiamo Patience Gontse", level: "Cambridge AS Level", grades: "4A (AS)", featuredAward: "High Achievement: Geography" },
  { id: "hr-30", studentName: "Chamo Katso Kago", level: "Cambridge AS Level", grades: "3A, 1B (AS)" },
  { id: "hr-31", studentName: "Gagoitsiwe Larona A.", level: "Cambridge AS Level", grades: "3A, 1B (AS)" },
  { id: "hr-32", studentName: "Mapitse Oratile Precious", level: "Cambridge AS Level", grades: "3A, 1B (AS)", featuredAward: "High Achievement: Psychology" },
  { id: "hr-33", studentName: "Nchalupi Koketso M.", level: "Cambridge AS Level", grades: "3A, 1B (AS)" },
  { id: "hr-34", studentName: "Aina Bamidele Temidayo J.", level: "Cambridge AS Level", grades: "3A (AS)" },
  { id: "hr-35", studentName: "Salani Andile Gorata", level: "Cambridge AS Level", grades: "3A (AS)" },
  { id: "hr-36", studentName: "Leago Leroy Malope", level: "Cambridge AS Level", grades: "3A (AS)", featuredAward: "High Achievement: Literature in English" },
  { id: "hr-37", studentName: "Legae Glen Kgabi", level: "Cambridge AS Level", grades: "3A (AS)", featuredAward: "High Achievement: Computer Science" },
  { id: "hr-38", studentName: "Janna R. Grubber", level: "Cambridge A2 Level", grades: "2A, 1B (A2)", featuredAward: "Dual High Achievement: Accounting & Economics" }
];

export const NEW_BUILDING_PROJECT_2027 = {
  title: "NEW FORMS 1 & 2 CLASSROOMS AT LKC FOR 2027!",
  subtitle: "Exciting Campus Expansion & Modernization in Block 8, Gaborone",
  tagline: "At LKC, we continue to build not just classrooms, but opportunities, innovation and a future of excellence for generations to come.",
  signature: "Livingstone Kolobeng College – Inspiring Excellence Since 2006.",
  status: "Now Under Construction for 2027",
  timeline: {
    start: "November 2026 Foundation",
    completion: "April 2027 Grand Opening"
  },
  keyMetrics: [
    { label: "Modern Classrooms", value: "12", detail: "Dedicated specifically to Forms 1 & 2" },
    { label: "Smart LED Technology", value: "100%", detail: "Interactive touchscreens in every room" },
    { label: "New Computing Lab", value: "1 Lab", detail: "High-spec programming & ICT workstations" },
    { label: "Staff & Admin Offices", value: "Full Suite", detail: "Academic operations & pastoral support" }
  ],
  images: [
    {
      url: "./assets/aistudio/image_1f1ba5b3.png",
      caption: "Architectural elevation and aerial masterplan showing solar-paneled double-storey Lower School classroom wing.",
      tag: "Now Under Construction for 2027"
    },
    {
      url: "./assets/aistudio/image_bdd8b05f.png",
      caption: "November 2026 ground foundation progress transitioning to April 2027 completed Lower Secondary complex.",
      tag: "November 2026 – April 2027 Milestone"
    },
    {
      url: "./assets/aistudio/image_a26b2465.png",
      caption: "Student walkway perspective and north-facing double-storey modern academic suites.",
      tag: "Future-Ready Learning Spaces"
    }
  ],
  story: `Exciting developments are underway at Livingstone Kolobeng College (LKC) in Block 8, Gaborone, as the school continues to expand its campus infrastructure in response to the growing demand for places in the Lower School.

Currently under construction is a brand-new, purpose-built classroom wing that will introduce 12 additional modern classrooms, alongside new administrative offices and state-of-the-art learning facilities dedicated to Forms 1 and 2. This development will further enhance the school's existing academic infrastructure, complementing the classrooms, computer laboratories and library facilities housed in Sechele Hall.

The new wing is being designed with the future of education in mind. All classrooms will be equipped with cutting-edge educational technology, including interactive LED smart screens, creating dynamic, technology-enabled learning environments that encourage collaboration, creativity and greater student engagement. The development will also feature a brand-new, state-of-the-art computer laboratory, providing learners with access to modern computing facilities to strengthen their digital literacy, ICT and programming skills. Additional staff and administrative offices will further support the effective delivery of academic programmes and day-to-day school operations.

Since opening its doors in 2006, LKC has maintained a strong commitment to continuous investment in educational excellence, with its directors and management consistently prioritising the development of world-class teaching, learning and boarding facilities. Over the years, this vision has transformed the school's campus through the addition of modern classrooms, a well-resourced library, specialist science and computer laboratories, and an impressive range of sporting and recreational facilities.

Today, the LKC campus boasts a swimming pool, a fully equipped gymnasium, a 1,000-seat school hall, extensive sports facilities and modern on-campus boarding accommodation, providing a comprehensive environment in which learners can excel academically, socially and beyond the classroom.

The 2027 classroom expansion represents another significant milestone in LKC's ongoing journey of growth and innovation. More than simply adding classroom space, this investment reflects the school's commitment to providing an increasingly modern, technology-driven and future-ready learning environment.`,
  features: [
    "12 Brand-New Ergonomic Classrooms designed for active, collaborative learning",
    "Interactive LED Smart Screens in every room for multimedia and digital lessons",
    "Brand-New State-of-the-Art Computer Laboratory with high-speed fiber internet",
    "Rooftop Solar Array promoting green energy efficiency and campus sustainability",
    "Dedicated Administrative & Pastoral Offices for Forms 1 and 2 heads",
    "Direct covered walkways linking to Sechele Hall, science labs and college library"
  ]
};

export const SPORTS_DATA = {
  name: "LKC Sports & Athletics",
  motto: "Excellence, Discipline & Sportsmanship",
  identity: "Livingstone Kolobeng College Sports & Athletics Directorate",
  colors: ["Royal Navy (#0c1a40)", "Amber Gold (#f59e0b)", "Pure White (#ffffff)"],
  intro: "Sports and physical education are fundamental to life at Livingstone Kolobeng College. Competing vigorously in inter-school leagues and invitationals, our athletes demonstrate tactical excellence, sportsmanship, and character.",
  facilities: [
    {
      name: "Swimming Pool Complex",
      description: "Dedicated on-campus swimming pool hosting our annual Inter-House Swimming Gala, morning swim squad conditioning, and water safety training.",
      icon: "Waves"
    },
    {
      name: "Fully Equipped Gymnasium",
      description: "Modern strength and cardiovascular conditioning gym supervised by certified physical education trainers for varsity athletes and boarders.",
      icon: "Dumbbell"
    },
    {
      name: "1,000-Seat Multi-purpose School Hall",
      description: "Massive indoor venue accommodating indoor basketball, volleyball championships, table tennis, badminton, and whole-school sports ceremonies.",
      icon: "Building"
    },
    {
      name: "All-Weather Athletics Track & Field",
      description: "Dedicated 400m sprint lanes, long jump pit, high jump mats, and shotput rings where LKC track records are set and shattered.",
      icon: "Timer"
    },
    {
      name: "Championship Rugby Turf & Pavilion",
      description: "Home of the famous Kolobeng Jaguars Rugby Team, with manicured regulation turf hosting competitive fixtures and weekend tournaments.",
      icon: "Shield"
    },
    {
      name: "Outdoor Courts (Basketball, Tennis, Netball)",
      description: "Floodlit multi-sport courts for afternoon house leagues, girls netball tournaments, and open-court tennis matches.",
      icon: "Target"
    }
  ],
  codes: [
    { name: "Track & Field Athletics", division: "All Forms (Junior & Senior)", season: "Term 2 Athletics Season", accolades: "National & Inter-School Track Medalists" },
    { name: "Aquatics (Swimming)", division: "Junior, Intermediate & Open", season: "Term 1 & Term 3", accolades: "Annual Inter-House Gala Champions" },
    { name: "Basketball Varsity", division: "Boys & Girls Squads", season: "All Year Round", accolades: "Inter-School Invitational Trophy Holders" },
    { name: "Football (Soccer)", division: "Under-15 & 1st XI Squads", season: "Term 1 & Term 2", accolades: "Regional Inter-School Contenders" },
    { name: "Netball & Volleyball", division: "Girls Varsity & Mixed", season: "Term 2 & Term 3", accolades: "Inter-School & House Netball & Volleyball Squads" },
    { name: "Tennis & Table Tennis", division: "Singles & Doubles", season: "All Year Round", accolades: "Inter-House & Regional Tournaments" }
  ],
  houseTrophyRace: {
    year: "Four Official Houses",
    trophyName: "The Four College Houses",
    description: "Every student at LKC is inducted into one of four storied houses — Bathoen (Red), Khama (Green), Sechele (Blue) and Moremi (Yellow) — fostering lifelong camaraderie, collegial pride, and spirit across academics, swimming, track and field, debating, and cultural pageantry.",
    standings: [
      { house: "Bathoen House", color: "#dc2626", colorName: "Red", patron: "Bathoen I", highlight: "Red House · Tenacity, Courage & Spirit of Achievement" },
      { house: "Khama House", color: "#16a34a", colorName: "Green", patron: "Khama III", highlight: "Green House · Principled Leadership, Integrity & Excellence" },
      { house: "Sechele House", color: "#1d4ed8", colorName: "Blue", patron: "Sechele I", highlight: "Blue House · Literacy, Intellectual Curiosity & Learning" },
      { house: "Moremi House", color: "#eab308", colorName: "Yellow", patron: "Moremi", highlight: "Yellow House · Exploratory Ambition & Cultural Heritage" }
    ]
  }
};

// Backwards compatibility alias
export const JAGUARS_SPORTS_DATA = SPORTS_DATA;

export const JAGUARS_RUGBY_DATA = {
  name: "The Jaguars",
  clubName: "Livingstone Kolobeng College Jaguars Rugby Football Club",
  shortName: "LKC Jaguars Rugby",
  motto: "Pride · Power · Brotherhood",
  mottoLatin: "In Unitatem Fortitudo",
  tagline: "Fearless on the Pitch, Respected Everywhere",
  identity: "Livingstone Kolobeng College 1st XV & Junior Rugby Football Club",
  established: "2008",
  headCoach: "Coach T. 'Scrum-Master' Moyo",
  forwardsCoach: "Coach B. Khumalo",
  backsCoach: "Coach K. Tshenolo",
  homeGround: "The Jaguars Den (LKC Championship Pitch, Block 8)",
  teamColors: {
    primary: "Royal Navy Blue (#0c1a40)",
    accent: "Amber Gold (#f59e0b)",
    secondary: "Pure White"
  },
  overview: "The Jaguars is the premier standalone rugby team of Livingstone Kolobeng College. Renowned across Botswana for unyielding defensive grit, explosive backline agility, and an uncompromising forward pack, the Jaguars stand as an enduring symbol of courage, discipline, and brotherhood at LKC. From our Under-14 developmental squad to the formidable 1st XV, every player wearing the Jaguar crest learns that victory is forged in the scrum, won through teamwork, and honored with respect.",
  creed: [
    { title: "Uncompromising Brotherhood", desc: "We fight for each other on every blade of grass; the bond of the pack endures beyond the whistle." },
    { title: "Physical & Mental Courage", desc: "Fear has no place in the tackle; we embrace pressure and conquer adversity through relentless discipline." },
    { title: "Honorable Sportsmanship", desc: "Fierce in combat, gracious in triumph, respectful to referees and opponents at the final handshake." },
    { title: "Academic & Athletic Excellence", desc: "A Jaguar leads in the classroom and dominates on the field—scholar-athletes upholding the LKC motto." }
  ],
  squads: [
    {
      name: "The 1st XV (Varsity Jaguars)",
      tier: "Senior Varsity (Forms 4 – A-Levels)",
      captain: "Tau 'The Wall' Molefe (Number 8)",
      viceCaptain: "Kagiso Phiri (Fly-Half)",
      description: "The flagship rugby squad of LKC, competing in premier senior school rugby championships and invitational derbies.",
      record2025: "11 Wins, 2 Losses · Gaborone Zone Champions"
    },
    {
      name: "Under-16 Colts XV",
      tier: "Junior Varsity (Forms 2 – 3)",
      captain: "Tumelo Dube (Scrum-Half)",
      description: "High-tempo, technically disciplined squad developing rugby acumen, set-piece mechanics, and tactical phase play.",
      record2025: "9 Wins, 1 Loss · Interschool Colts Trophy Winners"
    },
    {
      name: "Under-14 Cubs (Junior Jaguars)",
      tier: "Foundational Squad (Form 1)",
      captain: "Kabo Sithole (Flanker)",
      description: "Introducing young scholars to contact rugby, safe tackling mechanics, scrum discipline, and team loyalty.",
      record2025: "Developmental undefeated season"
    },
    {
      name: "Jaguars Sevens Squad",
      tier: "Specialized 7s Circuit",
      captain: "Lesedi Banda (Wing)",
      description: "Blistering pace, spatial exploitation, and endurance contesting national high-school Sevens tournaments.",
      record2025: "National High School 7s Cup Finalists"
    }
  ],
  fixtures2026: [],
  positionsPack: [
    { unit: "Front Row (Props & Hooker)", roles: "Loosehead Prop, Hooker, Tighthead Prop", duty: "Scrum anchor, lineout throwing, collision domination" },
    { unit: "Second Row (Locks)", roles: "Number 4 & 5 Locks", duty: "Lineout jumpers, engine room of the scrum, maul defence" },
    { unit: "Back Row (Loose Forwards)", roles: "Blindside Flanker, Openside Flanker, Number 8", duty: "Breakdown poachers, tackle count leaders, ball-carrying power" },
    { unit: "Halves (Playmakers)", roles: "Scrum-Half (9), Fly-Half (10)", duty: "Tactical kicking, distribution tempo, field marshalling" },
    { unit: "Midfield (Centres)", roles: "Inside Centre (12), Outside Centre (13)", duty: "Crash ball penetration, defensive fortress, line breaks" },
    { unit: "Back Three (Speed & Defence)", roles: "Left Wing (11), Right Wing (14), Fullback (15)", duty: "Finishing tries, counter-attack velocity, high-ball security" }
  ],
  honours: [
    { year: "2024 & 2025", title: "BISA Gaborone Zone Rugby Champions", level: "Senior 1st XV" },
    { year: "2025", title: "National High School 7s Tournament Silver Medalists", level: "Jaguars Sevens" },
    { year: "2024", title: "Colts Rugby Cup Champions", level: "Under-16 Squad" },
    { year: "2023", title: "Southern African Independent Schools Derby Winners", level: "1st XV Varsity" }
  ],
  trainingSchedule: [
    { day: "Monday & Wednesday", time: "15:30 – 17:30", focus: "Field Tactics, Phase Play & Set Pieces", venue: "Jaguars Pitch" },
    { day: "Tuesday & Thursday", time: "06:00 – 07:00", focus: "Gym Strength & Cardiovascular Conditioning", venue: "LKC Gymnasium" },
    { day: "Friday", time: "15:00 – 16:30", focus: "Captain's Run, Video Analysis & Walkthrough", venue: "School Hall / Pitch" },
    { day: "Saturday Matchday", time: "09:00 – 13:00", focus: "Competitive Fixtures & Post-Match Tunnel", venue: "The Jaguars Den / Away" }
  ],
  photos: [] as {
    url: string;
    title: string;
    category: string;
    caption: string;
    location?: string;
    status?: 'draft' | 'pending' | 'published' | 'unpublished' | 'archived';
  }[],
};

export const TEACHERS: TeacherProfile[] = [
  // 1. ICT AND LOGISTICS (5)
  {
    id: "t-ict-1",
    name: "Mr Tapiwa Norman Chivorese",
    departmentId: "dept-ict",
    departmentName: "ICT and Logistics",
    role: "Head of ICT & Computer Science",
    title: "Mr",
    subjects: ["Computer Science (0478)", "Python & Algorithm Design", "A-Level Computer Science (9618)", "VEX Robotics"],
    image: "./assets/aistudio/Chivorese_92d20e94.jpg",
    bio: "Passionate computational educator mentoring students in algorithmic thinking, full-stack software development, and international robotics competitions.",
    qualifications: "BSc Computer Science, Cambridge Certified Teacher"
  },
  {
    id: "t-ict-2",
    name: "Ms Pearl Gaobope",
    departmentId: "dept-ict",
    departmentName: "ICT and Logistics",
    role: "Teacher – Information & Communication Technology",
    title: "Ms",
    subjects: ["ICT (0417)", "Digital Literacy", "Database Systems & Spreadsheets"],
    bio: "Dedicated to building strong foundational digital proficiency, productivity workflows, and data security awareness across Lower Secondary.",
    qualifications: "BEd Educational Technology"
  },
  {
    id: "t-ict-3",
    name: "Ms F. Madzivanyika",
    departmentId: "dept-ict",
    departmentName: "ICT and Logistics",
    role: "Teacher – ICT & Systems Logistics",
    title: "Ms",
    subjects: ["Cambridge IGCSE ICT (0417)", "Applied Systems Logistics", "Web Authoring"],
    image: "./assets/aistudio/Madzivanyika_e4d96c2b.jpg",
    bio: "Specializes in digital media applications, document production, and Cambridge ICT practical examination preparation.",
    qualifications: "BSc Information Technology"
  },
  {
    id: "t-ict-4",
    name: "Mr K T Makoni",
    departmentId: "dept-ict",
    departmentName: "ICT and Logistics",
    role: "Senior Computer Science Master",
    title: "Mr",
    subjects: ["Computer Science (0478)", "Object-Oriented Programming", "Algorithms & Logic"],
    image: "./assets/aistudio/Makoni_4a7d1146.jpg",
    bio: "Guides Upper Secondary students through complex data structures, computer architecture, and software design principles.",
    qualifications: "BSc Computer Science & Mathematics"
  },
  {
    id: "t-ict-5",
    name: "Mr Theo Wame Serefhete",
    departmentId: "dept-ict",
    departmentName: "ICT and Logistics",
    role: "ICT Laboratory & Network Specialist",
    title: "Mr",
    subjects: ["Hardware Architecture", "Networking Essentials", "Digital Tools"],
    bio: "Oversees hands-on systems architecture, campus networking labs, and practical computing problem-solving.",
    qualifications: "Diploma in Network Engineering & ICT"
  },

  // 2. MATHEMATICS (9)
  {
    id: "t-math-1",
    name: "Mr K Adu",
    departmentId: "dept-maths",
    departmentName: "Mathematics",
    role: "Director of A-Levels & Master of Further Mathematics",
    title: "Mr",
    subjects: ["Cambridge A-Level Mathematics (9709)", "Pure Mathematics P1/P3", "Mechanics M1"],
    image: "./assets/aistudio/Mr_K_Adu_portrait_c3a680c6.jpg",
    bio: "Director of Cambridge AS & A-Levels with decades of distinction coaching students into global engineering and mathematics programs.",
    qualifications: "MSc Mathematics, Cambridge Post-Graduate Diploma"
  },
  {
    id: "t-math-2",
    name: "Mrs Komal V. Barot",
    departmentId: "dept-maths",
    departmentName: "Mathematics",
    role: "Senior Mathematics Teacher",
    title: "Mrs",
    subjects: ["IGCSE Mathematics Extended (0580)", "Probability & Statistics", "Algebraic Deductions"],
    image: "./assets/aistudio/Barrot_68d8dbf4.jpeg",
    bio: "Cultivates rigorous mathematical thinking, geometric clarity, and consistent top grades in external Cambridge examinations.",
    qualifications: "MSc Applied Mathematics"
  },
  {
    id: "t-math-3",
    name: "Mr M Chandomba",
    departmentId: "dept-maths",
    departmentName: "Mathematics",
    role: "Senior Mathematics Teacher",
    title: "Mr",
    subjects: ["IGCSE Mathematics (0580)", "Additional Mathematics (0606)", "Trigonometry"],
    image: "./assets/aistudio/Chandomba_42a26815.jpg",
    bio: "Renowned for bridging Lower Secondary foundational algebra into advanced Cambridge Extended Mathematics with exceptional pass rates.",
    qualifications: "BSc Mathematics & Statistics"
  },
  {
    id: "t-math-4",
    name: "Mrs Charity Dewah",
    departmentId: "dept-maths",
    departmentName: "Mathematics",
    role: "Head of Mathematics",
    title: "Mrs",
    subjects: ["Lower Secondary Mathematics (0862)", "IGCSE Mathematics (0580)"],
    image: "./assets/aistudio/Dewah_0cc021bf.jpg",
    bio: "Expert in building mathematical confidence, analytical speed, and clear multi-step reasoning for Lower and Upper Secondary learners.",
    qualifications: "BEd Mathematics Education"
  },
  {
    id: "t-math-5",
    name: "Ms Katlego Mitchele Modimoofile",
    departmentId: "dept-maths",
    departmentName: "Mathematics",
    role: "Mathematics Educator & Olympiad Coach",
    title: "Ms",
    subjects: ["Mathematics (0580)", "Pre-IGCSE Algebra", "Maths Olympiad Prep"],
    image: "./assets/aistudio/Modimofile_e9d13f63.jpeg",
    bio: "Inspires students to discover mathematical beauty through problem-solving tournaments, math puzzles, and structured diagnostics.",
    qualifications: "BSc Pure Mathematics"
  },
  {
    id: "t-math-6",
    name: "Mrs Vijayalakshmi Murugesan",
    departmentId: "dept-maths",
    departmentName: "Mathematics",
    role: "Senior Mathematics Educator",
    title: "Mrs",
    subjects: ["Cambridge IGCSE Mathematics (0580)", "Pure Mathematics", "Coordinate Geometry"],
    image: "./assets/aistudio/Murugesan_42078bae.jpg",
    bio: "Over 15 years of secondary mathematics teaching excellence, focusing on systematic examination practice and individual learning diagnostics.",
    qualifications: "MSc Mathematics, BEd"
  },
  {
    id: "t-math-7",
    name: "Mr R Nyika",
    departmentId: "dept-maths",
    departmentName: "Mathematics",
    role: "Vice Principal of Administration & Senior Mathematics Master",
    title: "Mr",
    subjects: ["IGCSE Mathematics (0580)", "Statistics S1", "Advanced Calculus"],
    image: "./assets/aistudio/vp_mr_r_nyika_88c39b96.jpg",
    bio: "Combines institutional administrative leadership with high-level mathematics teaching, guiding students toward stellar Cambridge academic standing.",
    qualifications: "MSc Educational Leadership, BSc Mathematics"
  },
  {
    id: "t-math-8",
    name: "Mr Kutlwano Othomile",
    departmentId: "dept-maths",
    departmentName: "Mathematics",
    role: "Mathematics Teacher",
    title: "Mr",
    subjects: ["Cambridge Lower Secondary Mathematics", "Geometry & Mensuration"],
    image: "./assets/aistudio/Othimile_2008c070.jpeg",
    bio: "Specializes in interactive mathematical instruction, foundational geometry, and peer problem-solving circles.",
    qualifications: "BSc Mathematics"
  },
  {
    id: "t-math-9",
    name: "Mrs Emely Sorofa",
    departmentId: "dept-maths",
    departmentName: "Mathematics",
    role: "Mathematics Teacher",
    title: "Mrs",
    subjects: ["Mathematics (0580)", "Diagnostic Arithmetic & Algebra"],
    image: "./assets/aistudio/sorofa_dced6e8d.jpeg",
    bio: "Dedicated to remedial mathematical reinforcement, diagnostic tests, and examination technique workshops.",
    qualifications: "BEd Secondary Mathematics"
  },

  // 3. SCIENCE (12)
  {
    id: "t-sci-1",
    name: "Mrs Chandra",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Senior Chemistry Specialist",
    title: "Mrs",
    subjects: ["Cambridge IGCSE Chemistry (0620)", "A-Level Chemistry (9701)", "Organic Synthesis"],
    image: "./assets/aistudio/ff292469-859b-447f-87d1-71b64a57fa64_728a86cc.webp",
    bio: "Leads experimental wet chemistry, stoichiometry laboratory practicals, and external Cambridge laboratory assessments.",
    qualifications: "MSc Chemistry"
  },
  {
    id: "t-sci-2",
    name: "Mr Daniel Kadembo",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Head of Science & Physics Master",
    title: "Mr",
    subjects: ["Cambridge Physics (0625)", "A-Level Physics (9702)", "Mechanics & Electromagnetism"],
    image: "./assets/aistudio/Kadembo_34520bae.jpeg",
    bio: "Demystifies Newtonian mechanics, circuit analysis, and experimental quantum concepts with interactive laboratory demonstrations.",
    qualifications: "BSc Applied Physics"
  },
  {
    id: "t-sci-3",
    name: "Mr P Ketlametswe",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Biological Sciences Teacher",
    title: "Mr",
    subjects: ["IGCSE Biology (0610)", "Ecology & Environmental Biology"],
    image: "./assets/aistudio/image_fe074d05.png",
    bio: "Focuses on biodiversity studies, environmental conservation, and field biology explorations across Botswana.",
    qualifications: "BSc Biological Sciences"
  },
  {
    id: "t-sci-4",
    name: "Ms K Kgosikwena",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Science Educator",
    title: "Ms",
    subjects: ["Combined Science", "Lower Secondary Science (0893)"],
    image: "./assets/aistudio/df962819-6680-4651-beb2-217b2d8f1758_3a298a9e.webp",
    bio: "Inspires early scientific curiosity, scientific enquiry methods, and safe laboratory etiquette for junior forms.",
    qualifications: "BSc Science Education"
  },
  {
    id: "t-sci-5",
    name: "Mr Tinieri Maeresera",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Senior Science Master",
    title: "Mr",
    subjects: ["Cambridge Physics (0625)", "Physical Science", "Laboratory Investigations"],
    image: "./assets/aistudio/Maeresera_179c42dd.jpg",
    bio: "Leads hands-on scientific apparatus calibrations, kinematics, and laboratory safety protocols for Cambridge candidates.",
    qualifications: "BSc Physics & Mathematics"
  },
  {
    id: "t-sci-6",
    name: "Ms Abigail Zephania Mandiudza",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Senior Chemistry & Science Educator",
    title: "Ms",
    subjects: ["Cambridge IGCSE Chemistry (0620)", "Practical Qualitative Analysis", "Equilibrium Chemistry"],
    image: "./assets/aistudio/Mandiudza_df942cde.jpg",
    bio: "Expert mentor in laboratory titrations, qualitative chemical analysis, and Cambridge practical examination mastery.",
    qualifications: "BSc Chemistry & Biochemistry"
  },
  {
    id: "t-sci-7",
    name: "Mr Takudzwa L Mboto",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Physics & Computational Science Master",
    title: "Mr",
    subjects: ["Cambridge IGCSE Physics (0625)", "A-Level Physics (9702)", "Electronics"],
    image: "./assets/aistudio/Mboto_a9a43477.jpg",
    bio: "Connects theoretical physics with modern computational simulations, optics experiments, and electronics prototypes.",
    qualifications: "BSc Physics & Electronics"
  },
  {
    id: "t-sci-8",
    name: "Ms Khumoetsile Gorata Morapedi",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Biology Educator",
    title: "Ms",
    subjects: ["Cambridge Biology (0610)", "Human Anatomy & Physiology"],
    image: "./assets/aistudio/Khumo_1d7ed1f6.jpeg",
    bio: "Specializes in molecular genetics, microscopic cellular preparations, and human biological systems.",
    qualifications: "BSc Biological Sciences"
  },
  {
    id: "t-sci-9",
    name: "Mr K Murombedzi",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Senior Chemistry Master",
    title: "Mr",
    subjects: ["Cambridge Chemistry (0620)", "A-Level Chemistry (9701)", "Thermochemistry"],
    image: "./assets/aistudio/Murombedzi_b26ea474.jpg",
    bio: "Coordinates laboratory safety, Cambridge practical exams, science symposia, and university pre-med pathway preparation.",
    qualifications: "MSc Chemistry, BEd"
  },
  {
    id: "t-sci-10",
    name: "Ms Nomathamsanqa Ncube",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Science Educator",
    title: "Ms",
    subjects: ["Cambridge Biology (0610)", "Plant Physiology & Photosynthesis"],
    image: "./assets/aistudio/Ncube_a80f777a.jpeg",
    bio: "Guides experiential botanical and ecological field work with structured scientific reports and practical evaluations.",
    qualifications: "BSc Life Sciences"
  },
  {
    id: "t-sci-11",
    name: "Mr Samuel Ndebele",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Senior Physics & Laboratory In-charge",
    title: "Mr",
    subjects: ["Physics (0625)", "Wave Motion & Optics", "Advanced Practical Physics"],
    image: "./assets/aistudio/Ndebele_S_d3b46a90.jpeg",
    bio: "Oversees physics apparatus calibration, thermal dynamics, and precision measurement protocols.",
    qualifications: "BSc Physics"
  },
  {
    id: "t-sci-12",
    name: "Mr Nyateka",
    departmentId: "dept-science",
    departmentName: "Science",
    role: "Science Educator",
    title: "Mr",
    subjects: ["General Science", "Physical Sciences Foundations"],
    image: "./assets/aistudio/Nyateka_400b2c05.jpeg",
    bio: "Engages students in the scientific method, observation techniques, and early laboratory safety.",
    qualifications: "BEd Secondary Science"
  },

  // 4. CREATIVES / ARTS (4)
  {
    id: "t-art-1",
    name: "Ms M Gordon",
    departmentId: "dept-creatives",
    departmentName: "Creatives / Arts",
    role: "Senior Art & Design Educator",
    title: "Ms",
    subjects: ["Cambridge IGCSE Art & Design (0400)", "Observational Painting", "Portfolio Curation"],
    image: "./assets/aistudio/Gordon_61c95225.jpg",
    bio: "Acclaimed visual artist curating annual LKC exhibitions and guiding students into premier international art, architecture, and design faculties.",
    qualifications: "BA Fine Art & Design"
  },
  {
    id: "t-art-2",
    name: "Mr Jones",
    departmentId: "dept-creatives",
    departmentName: "Creatives / Arts",
    role: "Head of Creatives & Design Technology",
    title: "Mr",
    subjects: ["Design and Technology (0445)", "Prototyping & CAD", "Wood & Metal Craft"],
    image: "./assets/aistudio/jones_e7c56bef.jpeg",
    bio: "Guides students through the complete product design cycle from conceptual ideation to precision workshop prototyping.",
    qualifications: "BSc Industrial Design & Tech"
  },
  {
    id: "t-art-3",
    name: "Mr A Mathodi",
    departmentId: "dept-creatives",
    departmentName: "Creatives / Arts",
    role: "Fine Art & Ceramics Master",
    title: "Mr",
    subjects: ["Ceramics & Mixed Media", "Sculpture", "Visual Art Foundations"],
    image: "./assets/aistudio/Mathodi_7f51ea9a.jpeg",
    bio: "Specializes in tactile clay modeling, ceramic glaze firing, and 3D artistic composition.",
    qualifications: "Diploma in Fine & Applied Arts"
  },
  {
    id: "t-art-4",
    name: "Mr H Sibanda",
    departmentId: "dept-creatives",
    departmentName: "Creatives / Arts",
    role: "Music & Performing Arts Master",
    title: "Mr",
    subjects: ["African Marimba", "Choral Music & Ensembles", "Dramatic Arts"],
    image: "./assets/aistudio/Sibanda_8fd6dc19.jpg",
    bio: "Directs LKC's award-winning traditional African marimba ensemble and multi-part choral performances at national cultural galas.",
    qualifications: "BA Performing Arts & Musicology"
  },

  // 5. PHYSICAL EDUCATION (2)
  {
    id: "t-pe-1",
    name: "Mr Singh Dhaliwal",
    departmentId: "dept-pe",
    departmentName: "Physical Education",
    role: "Head of Physical Education & Athletics",
    title: "Mr",
    subjects: ["Cambridge Physical Education (0413)", "Athletics Conditioning", "Track & Field"],
    image: "./assets/aistudio/Dhaliwal_6434853f.jpg",
    bio: "Directs comprehensive athletic programs, cardiovascular fitness regimens, and BISA track and field championship preparation.",
    qualifications: "MSc Physical Education & Sports Coaching"
  },
  {
    id: "t-pe-2",
    name: "Mr Mthunyelwa Ndebele",
    departmentId: "dept-pe",
    departmentName: "Physical Education",
    role: "Head Rugby Coach & Sports Master",
    title: "Mr",
    subjects: ["Jaguars Rugby 1st XV", "Competitive Swimming", "Football"],
    image: "./assets/aistudio/Ndebele_M_37d3ca16.jpg",
    bio: "Chief strategist behind The Kolobeng Jaguars Rugby squad, cultivating disciplined tackle mechanics, high-work-rate conditioning, and sportsmanship.",
    qualifications: "BSc Sports Science, World Rugby Certified Coach"
  },

  // 6. HUMANITIES (8)
  {
    id: "t-hum-1",
    name: "Mr Bokamoso Kgosidintsi",
    departmentId: "dept-humanities",
    departmentName: "Humanities",
    role: "Humanities Teacher",
    title: "Mr",
    subjects: ["Social Studies", "Botswana Civics & Governance"],
    image: "./assets/aistudio/image_a734d497.png",
    bio: "Fosters civic responsibility, constitutional understanding, and awareness of southern African socio-economic dynamics.",
    qualifications: "BEd Humanities"
  },
  {
    id: "t-hum-2",
    name: "Mr Anderson Dube",
    departmentId: "dept-humanities",
    departmentName: "Humanities",
    role: "Senior Geography Master",
    title: "Mr",
    subjects: ["Cambridge IGCSE Geography (0460)", "A-Level Geography (9696)", "Cartography & GIS"],
    image: "./assets/aistudio/Dube_f9988e37.jpg",
    bio: "Leads geographical field research, river basin hydrology, urban settlement analysis, and GIS mapping expeditions across Botswana.",
    qualifications: "MSc Environmental Geography"
  },
  {
    id: "t-hum-3",
    name: "Ms S Magadi",
    departmentId: "dept-humanities",
    departmentName: "Humanities",
    role: "Humanities Educator",
    title: "Ms",
    subjects: ["Geography (0460)", "Meteorology & Climate Systems"],
    image: "./assets/aistudio/magadi_cf1feea8.jpg",
    bio: "Connects global climate phenomena and environmental stewardship to local conservation priorities.",
    qualifications: "BSc Environmental Science"
  },
  {
    id: "t-hum-4",
    name: "Mr Motlamedi",
    departmentId: "dept-humanities",
    departmentName: "Humanities",
    role: "Development Studies Master",
    title: "Mr",
    subjects: ["Development Studies (0453)", "Sustainable Resource Economics"],
    bio: "Examines sustainable development models, poverty alleviation strategies, and rural-urban migration patterns.",
    qualifications: "BA Development Studies"
  },
  {
    id: "t-hum-5",
    name: "Ms Evelyn Mpofu",
    departmentId: "dept-humanities",
    departmentName: "Humanities",
    role: "Senior History Teacher",
    title: "Ms",
    subjects: ["Cambridge IGCSE History (0470)", "A-Level History (9489)", "20th Century World Diplomacy"],
    image: "./assets/aistudio/Mpofu_8fe1b917.jpg",
    bio: "Inspires deep historiographical analysis, source evaluation, and thoughtful essays on international relations and the Cold War.",
    qualifications: "MA History & International Relations"
  },
  {
    id: "t-hum-6",
    name: "Dr F Mutenheri",
    departmentId: "dept-humanities",
    departmentName: "Humanities",
    role: "Vice Principal of All Affairs & Senior Academician",
    title: "Dr",
    subjects: ["A-Level History (9489)", "Southern African Historiography", "Academic Mentorship"],
    image: "./assets/aistudio/vp_dr_fedious_mutenheri_e1569921.jpg",
    bio: "Doctorate in Educational Leadership and History. Steers holistic school governance, student welfare, pastoral care, and Cambridge academic discipline.",
    qualifications: "PhD in Education & History"
  },
  {
    id: "t-hum-7",
    name: "Mr P Muzeza",
    departmentId: "dept-humanities",
    departmentName: "Humanities",
    role: "Head of Humanities & History Master",
    title: "Mr",
    subjects: ["Cambridge History (0470)", "African Liberation Movements"],
    image: "./assets/aistudio/Muzeza_9d32f7a2.jpg",
    bio: "Dedicated to preserving primary historical sources and guiding annual student pilgrimages to the historic Kolobeng mission site.",
    qualifications: "BA History & Political Science"
  },
  {
    id: "t-hum-8",
    name: "Dr Jeff Ramsay",
    departmentId: "dept-humanities",
    departmentName: "Humanities",
    role: "Principal & Senior Academician",
    title: "Dr",
    subjects: ["Historiography of Botswana", "Senior Seminars in World History"],
    image: "./assets/aistudio/principal_dr_jeff_ramsay_a61fcb25.jpg",
    bio: "Distinguished historian, scholar, and author. Leads institutional Cambridge academic governance and instills in students a profound reverence for Botho.",
    qualifications: "PhD African History (Boston University)"
  },

  // 7. LANGUAGES (10)
  {
    id: "t-lang-1",
    name: "Ms Alex",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "French Language Teacher",
    title: "Ms",
    subjects: ["Cambridge IGCSE French (0520)", "Conversational French", "Francophone Culture"],
    image: "./assets/aistudio/Alex_310606c2.jpeg",
    bio: "Immerses learners in French oral expression, European DELF standards, and cross-cultural communication.",
    qualifications: "BA French Language & Literature"
  },
  {
    id: "t-lang-2",
    name: "Ms Obakeng Banyatsang",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "Setswana Language & Cultural Teacher",
    title: "Ms",
    subjects: ["Setswana Language & Culture", "Traditional Setswana Idioms & Proverbs", "Literature"],
    image: "./assets/aistudio/Banyatsang_26062116.jpg",
    bio: "Champion of national linguistic heritage, guiding learners through authentic Setswana poetry, cultural ethos, and oral storytelling.",
    qualifications: "BEd Setswana Language & Culture"
  },
  {
    id: "t-lang-3",
    name: "Mrs A Benjamin",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "English Language Teacher",
    title: "Mrs",
    subjects: ["First Language English (0500)", "Argumentative Prose & Speechwriting"],
    image: "./assets/aistudio/image_1e2f1b72.png",
    bio: "Refines rhetorical cadence, critical reading strategies, and persuasive writing techniques.",
    qualifications: "BA English Language & Communication"
  },
  {
    id: "t-lang-4",
    name: "Mr Takudzwa Rodney Chambwera",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "English Language & Debating Teacher",
    title: "Mr",
    subjects: ["English Language (0500)", "Parliamentary Debate", "Public Speaking"],
    image: "./assets/aistudio/image_7dd36b08.png",
    bio: "Coaches LKC's Pan-African Debating League team to national championships with sharp analytical argumentation.",
    qualifications: "BA English & Media Studies"
  },
  {
    id: "t-com-11",
    name: "Mrs Dove",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "Teacher – Languages Department",
    title: "Mrs",
    subjects: ["Languages", "Academic Curriculum Coordination"],
    image: "./assets/aistudio/Dove_794935a1.jpg",
    bio: "Coordinates Languages curriculum standards, examination preparation, and Lower School academic development.",
    qualifications: "MEd Curriculum Design"
  },
  {
    id: "t-lang-5",
    name: "Ms Precious Nozithulele Ngwenya",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "Senior Literature in English Teacher",
    title: "Ms",
    subjects: ["Cambridge IGCSE Literature in English (0475)", "A-Level English (9093)", "Dramatic Poetry"],
    image: "./assets/aistudio/Ngwenya_890cf4cf.jpeg",
    bio: "Inspires students with rigorous Shakespearean textual analysis, modern world poetry, and stylistic prose evaluations.",
    qualifications: "MA English Literature"
  },
  {
    id: "t-lang-matlotse",
    name: "Ms Matlotse",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "Teacher",
    title: "Ms",
    subjects: ["English"],
    image: "./assets/aistudio/Matlotse_059db9aa.webp",
    bio: "",
    leadershipPosition: "teacher",
    status: "published"
  },
  {
    id: "t-lang-6",
    name: "Ms Gorata Shobashoba",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "Setswana & Cultural Studies Teacher",
    title: "Ms",
    subjects: ["Setswana Literature", "Customary Cultural Etiquette", "Grammar"],
    image: "./assets/aistudio/Shobashoba_9783c429.jpeg",
    bio: "Fosters deep student pride in Setswana linguistics and traditional civic values.",
    qualifications: "BA African Languages & Culture"
  },
  {
    id: "t-lang-7",
    name: "Mrs Tsetse",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "Head of Languages & ESL Teacher",
    title: "Mrs",
    subjects: ["Cambridge IGCSE ESL (0510)", "Listening Comprehension & Phonetics"],
    image: "./assets/aistudio/tsetse_de6b2999.jpeg",
    bio: "Supports multinational learners with English fluency, phonetics, and academic writing proficiency.",
    qualifications: "BEd English Education"
  },
  {
    id: "t-lang-8",
    name: "Ms T Tumotumo",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "Senior English Teacher",
    title: "Ms",
    subjects: ["Cambridge IGCSE First Language English (0500)", "Descriptive & Narrative Writing"],
    image: "./assets/aistudio/Tumotumo_dbbe66dc.jpg",
    bio: "Renowned for developing students' distinct authorial voice, evocative vocabulary, and flawless examination composition.",
    qualifications: "BA English Language & Literature"
  },
  {
    id: "t-lang-9",
    name: "Mr Wilson",
    departmentId: "dept-languages",
    departmentName: "Languages Department",
    role: "Senior French & Modern Languages Teacher",
    title: "Mr",
    subjects: ["Cambridge IGCSE French (0520)", "Grammar & Translation", "Diplomatic French"],
    image: "./assets/aistudio/Wilson_1ae6d00b.jpg",
    bio: "Oversees foreign language exchange programs, conversational fluency labs, and bilingual speech contests.",
    qualifications: "MA French Linguistics"
  },

  // 8. COMMERCIALS DEPARTMENT (10)
  {
    id: "t-com-1",
    name: "Ms G Gasha",
    departmentId: "dept-commercials",
    departmentName: "Commercials Department",
    role: "Commerce & Business Teacher",
    title: "Ms",
    subjects: ["Business Studies (0450)", "Commercial Law Basics"],
    image: "./assets/aistudio/Gasha_7a156b12.jpeg",
    bio: "Introduces learners to market dynamics, consumer behavior, and entrepreneurial enterprise principles.",
    qualifications: "BCom Business Management"
  },
  {
    id: "t-com-2",
    name: "Mrs M Katai",
    departmentId: "dept-commercials",
    departmentName: "Commercials Department",
    role: "Head of Business & Accounting",
    title: "Mrs",
    subjects: ["Cambridge IGCSE Accounting (0452)", "Financial Ledgers & Trial Balances"],
    image: "./assets/aistudio/Katai_6d0dcd93.jpg",
    bio: "Master of double-entry ledger mechanics, auditing standards, and balance sheet reconciliation.",
    qualifications: "MSc Accounting & Finance"
  },
  {
    id: "t-com-3",
    name: "Ms D Modimakwane",
    departmentId: "dept-commercials",
    departmentName: "Commercials Department",
    role: "Accounting & Commerce Teacher",
    title: "Ms",
    subjects: ["Accounting (0452)", "Cost & Management Accounting", "Business Studies"],
    image: "./assets/aistudio/Modimakwane_7b55648a.jpg",
    bio: "Guides students through real-world balance sheet analysis and corporate financial statements.",
    qualifications: "BCom Financial Accounting"
  },
  {
    id: "t-com-4",
    name: "Ms L Monyeki",
    departmentId: "dept-commercials",
    departmentName: "Commercials Department",
    role: "Business Studies Teacher",
    title: "Ms",
    subjects: ["Business Studies (0450)", "Marketing & Operations"],
    image: "./assets/aistudio/Monyeki_a7e063be.jpeg",
    bio: "Passionate about startup business models, operational logistics, and marketing campaign strategy.",
    qualifications: "BBA Business Administration"
  },
  {
    id: "t-com-5",
    name: "Mrs Muchedzi Nyambo",
    departmentId: "dept-commercials",
    departmentName: "Commercials Department",
    role: "Senior Economics Teacher",
    title: "Mrs",
    subjects: ["Cambridge IGCSE Economics (0455)", "A-Level Economics (9708)", "Fiscal Policy"],
    image: "./assets/aistudio/Nyambo_1953004a.jpg",
    bio: "Prepares future economists and financial analysts in macroeconomic policy, central bank mechanisms, and international trade.",
    qualifications: "MSc Economics & International Trade"
  },
  {
    id: "t-com-6",
    name: "Ms Tracey Munodawafa",
    departmentId: "dept-commercials",
    departmentName: "Commercials Department",
    role: "Senior Business Studies & Commerce Teacher",
    title: "Ms",
    subjects: ["Cambridge IGCSE Business Studies (0450)", "Enterprise (0454)", "Corporate Strategy"],
    image: "./assets/aistudio/Ms_Tracey_Munodawafa_portrait_311fd817.jpg",
    bio: "Mentors young entrepreneurs in business plan formulation, pitch deck presentations, and Bank of Botswana economic competitions.",
    qualifications: "MCom Strategic Management, BEd"
  },
  {
    id: "t-com-7",
    name: "Mr Takunda Mutero",
    departmentId: "dept-commercials",
    departmentName: "Commercials Department",
    role: "Teacher – Commercials Department",
    title: "Mr",
    subjects: ["Cambridge IGCSE Accounting (0452)", "Financial Reporting", "Auditing Principles"],
    image: "./assets/aistudio/Mutero_768af995.jpeg",
    bio: "Specializes in rigorous accounting practice drills, tax fundamentals, and partnership accounts preparation.",
    qualifications: "BSc Accounting & Finance"
  },
  {
    id: "t-com-8",
    name: "Ms Otimile",
    departmentId: "dept-commercials",
    departmentName: "Commercials Department",
    role: "Business Studies Teacher",
    title: "Ms",
    subjects: ["Business Studies (0450)", "Consumer Rights & Trade"],
    bio: "Focuses on commercial ethics, supply chains, and consumer law within SADC regional markets.",
    qualifications: "BEd Commercial Subjects"
  },
  {
    id: "t-com-9",
    name: "Mr P Sakala",
    departmentId: "dept-commercials",
    departmentName: "Commercials Department",
    role: "Senior Commercials & Economics Teacher",
    title: "Mr",
    subjects: ["Cambridge Economics (0455)", "A-Level Accounting (9706)", "Monetary Theory"],
    image: "./assets/aistudio/Sakala_ee78234a.jpg",
    bio: "Brings extensive commercial industry experience to classroom teaching, mentoring students for professional ACCA and actuarial paths.",
    qualifications: "MSc Finance & Investment, ACCA"
  },
  {
    id: "t-com-10",
    name: "Ms Irene T Tafirei",
    departmentId: "dept-commercials",
    departmentName: "Commercials Department",
    role: "Senior Accounting Teacher",
    title: "Ms",
    subjects: ["Cambridge IGCSE Accounting (0452)", "Financial Ratios & Cashflow Statements"],
    image: "./assets/aistudio/Tafirei_eaaa4222.jpg",
    bio: "Known for meticulous ledger accuracy instruction, financial ratio analysis, and outstanding Cambridge IGCSE examination results.",
    qualifications: "BCom Accounting & Auditing"
  }
];
