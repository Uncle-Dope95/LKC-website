import { createRoot } from 'react-dom/client';
import App, { AppErrorBoundary } from './App.tsx';
import { recordDiagnosticError } from './services/cmsDataService';
import './index.css';

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function renderMountFailure(rootEl: HTMLElement | null, errorMessage: string): void {
  const target = rootEl || document.body;
  if (!target) return;
  document.documentElement.dataset.lkcMounted = 'error';
  target.innerHTML = `
    <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;background:#f8fafc;color:#0c1a40;font-family:system-ui,-apple-system,sans-serif;">
      <div style="max-width:560px;width:100%;background:#ffffff;border:1px solid #bfdbfe;border-radius:16px;padding:32px;text-align:center;box-shadow:0 12px 32px rgba(12,26,64,0.08);">
        <div style="font-size:12px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#b45309;margin-bottom:8px;">
          Livingstone Kolobeng College
        </div>
        <h1 style="font-size:24px;font-weight:700;margin:0 0 12px;color:#0c1a40;">
          Unable to Load Website View
        </h1>
        <p style="font-size:14px;line-height:1.6;color:#1e3a8a;margin:0 0 16px;">
          ${escapeHtml(errorMessage || 'An unexpected startup error prevented the page from rendering.')}
        </p>
        <div style="background:#eff6ff;border:1px solid #dbeafe;border-radius:12px;padding:14px;font-size:13px;color:#0c1a40;margin-bottom:18px;">
          <div style="font-weight:700;margin-bottom:4px;">Contact Admissions &amp; Reception</div>
          <div>
            Telephone:
            <a href="tel:+2673161140" style="color:#0c1a40;font-weight:700;">+267 316 1140</a>
            &middot;
            <a href="tel:+2673162208" style="color:#0c1a40;font-weight:700;">+267 316 2208</a>
          </div>
          <div style="margin-top:4px;">
            WhatsApp:
            <a href="https://wa.me/26778465196" target="_blank" rel="noopener noreferrer" style="color:#b45309;font-weight:700;">+267 78 465 196</a>
          </div>
        </div>
        <div style="display:flex;flex-wrap:wrap;justify-content:center;gap:10px;">
          <button type="button" onclick="window.location.reload()" style="padding:10px 18px;border-radius:10px;border:none;background:#0c1a40;color:#fcd34d;font-weight:700;font-size:13px;cursor:pointer;">
            Reload Website
          </button>
          <button type="button" onclick="window.location.hash='#home';window.location.reload();" style="padding:10px 18px;border-radius:10px;border:1px solid #bfdbfe;background:#ffffff;color:#0c1a40;font-weight:600;font-size:13px;cursor:pointer;">
            Open Homepage
          </button>
        </div>
      </div>
    </div>
  `;
}

if (typeof window !== 'undefined') {
  window.addEventListener('error', (event) => {
    const msg = event.error?.message || event.message || 'Unhandled runtime error';
    recordDiagnosticError(msg);
    if (document.documentElement.dataset.lkcMounted !== 'true') {
      renderMountFailure(document.getElementById('root'), msg);
    }
  });
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const msg = reason instanceof Error ? reason.message : String(reason || 'Unhandled promise rejection');
    recordDiagnosticError(msg);
    if (document.documentElement.dataset.lkcMounted !== 'true') {
      renderMountFailure(document.getElementById('root'), msg);
    }
  });
}

function mountApplication() {
  const rootEl = document.getElementById('root');
  if (!rootEl) {
    renderMountFailure(null, 'Root mount element (#root) was not found in index.html.');
    return;
  }
  try {
    createRoot(rootEl).render(
      <AppErrorBoundary>
        <App />
      </AppErrorBoundary>
    );
    document.documentElement.dataset.lkcMounted = 'true';
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    recordDiagnosticError(`Mount failure: ${message}`);
    renderMountFailure(rootEl, message);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', mountApplication, { once: true });
} else {
  mountApplication();
}
