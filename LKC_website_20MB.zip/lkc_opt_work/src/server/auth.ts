import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { getDb, mapUserRow, recordAuditLog } from './db.ts';
import type { CmsUser, PageKey, UserRole } from '../types/index.ts';

export const SESSION_COOKIE_NAME = 'lkc_cms_session';
const SESSION_TTL_HOURS = 24;
const LOGIN_RATE_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_RATE_MAX_ATTEMPTS = 25;

export interface AuthenticatedRequest extends Request {
  cmsUser?: CmsUser;
  sessionTokenHash?: string;
}

function getSessionSecret(): string {
  return process.env.CMS_SESSION_SECRET || 'lkc-dev-ephemeral-session-secret-change-in-production';
}

export function hashSessionToken(rawToken: string): string {
  return crypto.createHmac('sha256', getSessionSecret()).update(rawToken).digest('hex');
}

export function createUserSession(userId: string): { rawToken: string; expiresAt: string } {
  const db = getDb();
  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = hashSessionToken(rawToken);
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_TTL_HOURS * 60 * 60 * 1000);
  const expiresAt = expires.toISOString();

  db.prepare(`
    INSERT INTO sessions (token_hash, user_id, expires_at, created_at)
    VALUES (?, ?, ?, ?)
  `).run(tokenHash, userId, expiresAt, now.toISOString());

  db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(now.toISOString(), userId);

  return { rawToken, expiresAt };
}

export function revokeSession(tokenHash?: string): void {
  if (!tokenHash) return;
  const db = getDb();
  db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
}

export function revokeAllUserSessions(userId: string): number {
  const db = getDb();
  const res = db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
  return Number(res.changes || 0);
}

export function checkLoginRateLimit(clientKey: string): { allowed: boolean; retryAfterSec: number } {
  const db = getDb();
  const now = Date.now();
  const row = db
    .prepare('SELECT count, window_start FROM login_attempts WHERE key = ?')
    .get(clientKey) as { count: number; window_start: string } | undefined;

  if (!row) {
    return { allowed: true, retryAfterSec: 0 };
  }
  const windowStartMs = new Date(row.window_start).getTime();
  if (Number.isNaN(windowStartMs) || now - windowStartMs >= LOGIN_RATE_WINDOW_MS) {
    db.prepare('DELETE FROM login_attempts WHERE key = ?').run(clientKey);
    return { allowed: true, retryAfterSec: 0 };
  }
  if (row.count >= LOGIN_RATE_MAX_ATTEMPTS) {
    const retryAfterSec = Math.ceil((LOGIN_RATE_WINDOW_MS - (now - windowStartMs)) / 1000);
    return { allowed: false, retryAfterSec: Math.max(1, retryAfterSec) };
  }
  return { allowed: true, retryAfterSec: 0 };
}

export function recordLoginRateAttempt(clientKey: string): void {
  const db = getDb();
  const nowIso = new Date().toISOString();
  const nowMs = Date.now();
  const existing = db
    .prepare('SELECT count, window_start FROM login_attempts WHERE key = ?')
    .get(clientKey) as { count: number; window_start: string } | undefined;

  if (!existing) {
    db.prepare('INSERT INTO login_attempts (key, count, window_start) VALUES (?, 1, ?)').run(
      clientKey,
      nowIso
    );
    return;
  }
  const windowStartMs = new Date(existing.window_start).getTime();
  if (Number.isNaN(windowStartMs) || nowMs - windowStartMs >= LOGIN_RATE_WINDOW_MS) {
    db.prepare('UPDATE login_attempts SET count = 1, window_start = ? WHERE key = ?').run(
      nowIso,
      clientKey
    );
    return;
  }
  db.prepare('UPDATE login_attempts SET count = count + 1 WHERE key = ?').run(clientKey);
}

export function clearLoginRateAttempts(clientKey: string): void {
  const db = getDb();
  db.prepare('DELETE FROM login_attempts WHERE key = ?').run(clientKey);
}

export function extractSessionToken(req: Request): string | null {
  const cookieToken = req.cookies?.[SESSION_COOKIE_NAME];
  if (typeof cookieToken === 'string' && cookieToken.length > 0) {
    return cookieToken;
  }
  const authHeader = req.headers.authorization;
  if (typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
    const bearer = authHeader.slice(7).trim();
    if (bearer.length > 0) return bearer;
  }
  return null;
}

export function attachAuth(req: AuthenticatedRequest, _res: Response, next: NextFunction): void {
  const rawToken = extractSessionToken(req);
  if (!rawToken) {
    next();
    return;
  }

  const tokenHash = hashSessionToken(rawToken);
  const db = getDb();
  const row = db
    .prepare(`
      SELECT u.*, s.expires_at
      FROM sessions s
      JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = ?
    `)
    .get(tokenHash) as Record<string, unknown> | undefined;

  if (!row) {
    next();
    return;
  }

  const expiresAt = new Date(String(row.expires_at)).getTime();
  if (Number.isNaN(expiresAt) || expiresAt < Date.now() || Number(row.active) !== 1) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
    next();
    return;
  }

  req.cmsUser = mapUserRow(row);
  req.sessionTokenHash = tokenHash;
  next();
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.cmsUser) {
    res.status(401).json({ error: 'Authentication required. Please sign in to the LKC CMS.' });
    return;
  }
  next();
}

export function requirePasswordUpdated(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): void {
  if (!req.cmsUser) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  if (req.cmsUser.mustChangePassword) {
    res.status(403).json({
      error: 'Password change required before accessing CMS management.',
      code: 'PASSWORD_CHANGE_REQUIRED',
    });
    return;
  }
  next();
}

export function requireRole(allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.cmsUser) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    if (!allowedRoles.includes(req.cmsUser.role)) {
      res.status(403).json({
        error: `Access denied. Role '${req.cmsUser.role}' is not permitted to perform this action.`,
      });
      return;
    }
    next();
  };
}

export const EDITOR_RESTRICTED_SECTIONS = new Set<string>([
  'fees',
  'settings',
  'navigation',
  'footer',
  'general',
  'alumni',
]);

export function canUserAccessSection(user: CmsUser, sectionKey: string): boolean {
  if (user.role === 'super_admin' || user.role === 'admin') return true;
  if (EDITOR_RESTRICTED_SECTIONS.has(sectionKey)) return false;
  if (user.assignedPages.length === 0) return false;

  const sectionToPageMap: Record<string, PageKey[]> = {
    hero: ['home'],
    about: ['home', 'campus'],
    building: ['campus'],
    campus: ['campus'],
    departments: ['departments'],
    teachers: ['departments'],
    academic_leadership: ['departments'],
    curriculum: ['curriculum'],
    houses: ['boarding', 'sports'],
    boarding: ['boarding'],
    excursions: ['excursions'],
    achievers: ['achievers'],
    sports: ['sports'],
    athletics: ['athletics'],
    jaguars: ['jaguars'],
    calendar: ['events'],
    faqs: ['contact'],
    announcements: ['news', 'events'],
    media: ['home', 'campus', 'news', 'events'],
  };

  const mappedPages = sectionToPageMap[sectionKey] || [sectionKey as PageKey];
  return mappedPages.some((p) => user.assignedPages.includes(p));
}

export function canUserEditPage(user: CmsUser, pageKey: PageKey): boolean {
  if (user.role === 'super_admin' || user.role === 'admin') return true;
  if (pageKey === 'fees') return false;
  return user.assignedPages.includes(pageKey);
}

export function auditUserAction(
  req: AuthenticatedRequest,
  action: string,
  targetType: string,
  targetId: string,
  summary: string
): void {
  if (!req.cmsUser) return;
  recordAuditLog({
    userId: req.cmsUser.id,
    userEmail: req.cmsUser.email,
    userRole: req.cmsUser.role,
    action,
    targetType,
    targetId,
    summary,
  });
}
