import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import {
  createDefaultCmsDatabase,
  DEFAULT_CMS_ITEMS,
  FIXED_DEPARTMENT_IDS,
  type CmsDatabase,
  type CmsSectionKey,
} from '../data/cmsDefaults.ts';
import type {
  AcademicAssignment,
  AcademicAssignmentType,
  AcademicLeadershipBundle,
  AuditLogEntry,
  CmsItem,
  CmsUser,
  DepartmentInfo,
  HouseInfo,
  LeadershipMember,
  MediaAsset,
  PageKey,
  PublishStatus,
  StaffMember,
  TeacherProfile,
  UserRole,
  YearGroupKey,
} from '../types/index.ts';
import {
  DEFAULT_DIRECTORS,
  getTeacherLeadershipPosition,
  normalizePersonName,
  sortTeachersForDirectory,
} from '../utils/staffHierarchy.ts';

function normalizeSecondarySchoolTitle(text?: string | null): string {
  if (!text) return '';
  return text
    .replace(/\bLecturers\b/g, 'Teachers')
    .replace(/\bLecturer\b/g, 'Teacher')
    .replace(/\bProfessor\b/g, 'Senior Teacher')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

export const STORAGE_DIR = path.resolve(process.cwd(), 'storage');
export const UPLOADS_DIR = path.resolve(STORAGE_DIR, 'uploads');
export const DB_PATH = path.resolve(STORAGE_DIR, 'lkc_cms.db');
export const INITIAL_CREDENTIALS_FILE = path.resolve(STORAGE_DIR, '.initial_admin_credentials.txt');
export const PASSWORD_RESET_TOKENS_FILE = path.resolve(STORAGE_DIR, '.password_reset_tokens.json');

const FAKE_ALUMNI_IDS = new Set([
  'alumni-1',
  'alumni-2',
  'alumni-3',
  'alumni-4',
  'alumni-5',
  'alumni-6',
]);

const FAKE_EXCURSION_IDS = new Set([
  'excursion-kolobeng',
  'excursion-okavango',
  'excursion-makgadikgadi',
  'excursion-civic',
  'excursion-vicfalls',
  'excursion-mun',
]);

const FAKE_FIXTURE_OPPONENTS = new Set([
  'Maru-a-Pula School 1st XV',
  'Westwood International School',
  'Gaborone Rugby Club Invitational',
  'Rainbow High School 1st XV',
]);

export const OFFICIAL_FOUR_HOUSES: Array<{
  id: string;
  name: string;
  colorName: string;
  colorHex: string;
  textColor: string;
  bgColor: string;
  defaultPatron: string;
  defaultDescription: string;
}> = [
  {
    id: 'house-bathoen',
    name: 'Bathoen House',
    colorName: 'Red',
    colorHex: '#dc2626',
    textColor: 'text-red-800',
    bgColor: 'bg-red-50 border-red-300',
    defaultPatron: 'Bathoen I',
    defaultDescription:
      'Honouring the resolute statesman and celebrating tenacity, steadfast courage and the spirit of achievement.',
  },
  {
    id: 'house-khama',
    name: 'Khama House',
    colorName: 'Green',
    colorHex: '#16a34a',
    textColor: 'text-emerald-800',
    bgColor: 'bg-emerald-50 border-emerald-300',
    defaultPatron: 'Khama III',
    defaultDescription:
      'Honouring the revered statesman and promoting principled leadership, integrity, dignified conduct and athletic excellence.',
  },
  {
    id: 'house-sechele',
    name: 'Sechele House',
    colorName: 'Blue',
    colorHex: '#1d4ed8',
    textColor: 'text-blue-900',
    bgColor: 'bg-blue-50 border-blue-300',
    defaultPatron: 'Sechele I',
    defaultDescription:
      'Named in honour of the pioneer of literacy and scholarship, representing intellectual curiosity, courage and commitment to learning.',
  },
  {
    id: 'house-moremi',
    name: 'Moremi House',
    colorName: 'Yellow',
    colorHex: '#eab308',
    textColor: 'text-yellow-900',
    bgColor: 'bg-yellow-50 border-yellow-300',
    defaultPatron: 'Moremi',
    defaultDescription:
      'Celebrating exploratory ambition, environmental stewardship, intellectual curiosity and cultural heritage.',
  },
];

const INITIAL_ADMIN_ACCOUNTS = [
  { username: 'makoni', email: 'makoni@lkc.ac.bw', fullName: 'Mr K T Makoni' },
  { username: 'serefethe', email: 'serefethe@lkc.ac.bw', fullName: 'Mr Theo Wame Serefhete' },
  { username: 'mutenheri', email: 'mutenheri@lkc.ac.bw', fullName: 'Dr Fedious Mutenheri' },
  { username: 'chambwera', email: 'chambwera@lkc.ac.bw', fullName: 'Mr Takudzwa Rodney Chambwera' },
  { username: 'madzivanyika', email: 'madzivanyika@lkc.ac.bw', fullName: 'Ms F. Madzivanyika' },
] as const;

function generateTemporaryPassword(length = 16): string {
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const lower = 'abcdefghijkmnopqrstuvwxyz';
  const digits = '23456789';
  const symbols = '!@#$%&*';
  const all = upper + lower + digits + symbols;
  const pick = (charset: string) => charset[crypto.randomInt(0, charset.length)];
  const chars = [pick(upper), pick(lower), pick(digits), pick(symbols)];
  while (chars.length < length) {
    chars.push(pick(all));
  }
  for (let i = chars.length - 1; i > 0; i--) {
    const j = crypto.randomInt(0, i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join('');
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const [, salt, originalHex] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const original = Buffer.from(originalHex, 'hex');
  if (derived.length !== original.length) return false;
  return crypto.timingSafeEqual(derived, original);
}

let dbInstance: DatabaseSync | null = null;

function ensureDirs(): void {
  fs.mkdirSync(STORAGE_DIR, { recursive: true });
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

function ensureUsersColumns(db: DatabaseSync): void {
  const cols = db.prepare('PRAGMA table_info(users)').all() as { name: string }[];
  const existing = new Set(cols.map((c) => c.name));

  const migrations: [string, string][] = [
    ['username', 'ALTER TABLE users ADD COLUMN username TEXT'],
    ['must_change_password', 'ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0'],
    ['failed_login_attempts', 'ALTER TABLE users ADD COLUMN failed_login_attempts INTEGER NOT NULL DEFAULT 0'],
    ['locked_until', 'ALTER TABLE users ADD COLUMN locked_until TEXT'],
    ['password_reset_token_hash', 'ALTER TABLE users ADD COLUMN password_reset_token_hash TEXT'],
    ['password_reset_expires', 'ALTER TABLE users ADD COLUMN password_reset_expires TEXT'],
  ];

  for (const [colName, ddl] of migrations) {
    if (!existing.has(colName)) {
      db.exec(ddl);
    }
  }
  db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username) WHERE username IS NOT NULL;');
}

export function getDb(): DatabaseSync {
  if (dbInstance) return dbInstance;
  ensureDirs();
  const db = new DatabaseSync(DB_PATH);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT,
      email TEXT NOT NULL UNIQUE,
      full_name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL,
      assigned_pages_json TEXT NOT NULL DEFAULT '[]',
      active INTEGER NOT NULL DEFAULT 1,
      must_change_password INTEGER NOT NULL DEFAULT 0,
      failed_login_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      password_reset_token_hash TEXT,
      password_reset_expires TEXT,
      created_at TEXT NOT NULL,
      last_login_at TEXT
    );

    CREATE TABLE IF NOT EXISTS login_attempts (
      key TEXT PRIMARY KEY,
      count INTEGER NOT NULL DEFAULT 0,
      window_start TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS cms_sections (
      section_key TEXT PRIMARY KEY,
      data_json TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      updated_by TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS cms_items (
      id TEXT PRIMARY KEY,
      page_key TEXT NOT NULL,
      category TEXT NOT NULL,
      academic_year TEXT,
      title TEXT NOT NULL,
      slug TEXT NOT NULL,
      excerpt TEXT NOT NULL,
      content_json TEXT NOT NULL,
      thumbnail_url TEXT,
      media_url TEXT,
      status TEXT NOT NULL DEFAULT 'draft',
      feature_on_homepage INTEGER NOT NULL DEFAULT 0,
      publish_at TEXT,
      event_date TEXT,
      event_time TEXT,
      event_location TEXT,
      event_completed INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_by TEXT NOT NULL,
      updated_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_cms_items_page_status ON cms_items(page_key, status);
    CREATE INDEX IF NOT EXISTS idx_cms_items_featured ON cms_items(feature_on_homepage, status);

    CREATE TABLE IF NOT EXISTS media_assets (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      filename TEXT,
      url TEXT NOT NULL,
      category TEXT NOT NULL,
      media_type TEXT NOT NULL DEFAULT 'image',
      mime_type TEXT,
      size_bytes INTEGER,
      description TEXT,
      uploaded_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS staff_members (
      id TEXT PRIMARY KEY,
      surname TEXT NOT NULL,
      full_name TEXT NOT NULL,
      display_title TEXT,
      department TEXT,
      subjects_json TEXT NOT NULL DEFAULT '[]',
      image TEXT,
      bio TEXT,
      qualifications TEXT,
      email TEXT,
      status TEXT NOT NULL DEFAULT 'published',
      is_incomplete INTEGER NOT NULL DEFAULT 0,
      incomplete_reason TEXT,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS academic_assignments (
      id TEXT PRIMARY KEY,
      staff_id TEXT NOT NULL,
      assignment_type TEXT NOT NULL,
      role_title TEXT NOT NULL,
      year_group TEXT,
      summary TEXT,
      responsibilities TEXT,
      welcome_message TEXT,
      status TEXT NOT NULL DEFAULT 'published',
      sort_order INTEGER NOT NULL DEFAULT 0,
      archived_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (staff_id) REFERENCES staff_members(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_assignments_type_status ON academic_assignments(assignment_type, status);
    CREATE INDEX IF NOT EXISTS idx_assignments_year_group ON academic_assignments(year_group, status);

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      user_email TEXT NOT NULL,
      user_role TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT NOT NULL,
      summary TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS enquiries (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'new',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS tour_bookings (
      id TEXT PRIMARY KEY,
      payload_json TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'requested',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS cms_migrations (
      id TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL
    );
  `);

  ensureUsersColumns(db);
  dbInstance = db;
  seedDatabaseIfNeeded(db);
  return db;
}

export function enforceFixedDepartments(
  incoming: DepartmentInfo[],
  defaults: DepartmentInfo[]
): DepartmentInfo[] {
  const incomingById = new Map<string, DepartmentInfo>();
  for (const d of incoming) {
    if (d && typeof d.id === 'string') {
      incomingById.set(d.id, d);
    }
  }
  return FIXED_DEPARTMENT_IDS.map((fixedId) => {
    const fallback = defaults.find((d) => d.id === fixedId)!;
    const candidate = incomingById.get(fixedId);
    if (!candidate) return fallback;
    return {
      ...fallback,
      ...candidate,
      id: fixedId,
      headOfDepartment: {
        ...fallback.headOfDepartment,
        ...(candidate.headOfDepartment || {}),
      },
      subjects: Array.isArray(candidate.subjects) ? candidate.subjects : fallback.subjects,
      keyAreas: Array.isArray(candidate.keyAreas) ? candidate.keyAreas : fallback.keyAreas,
      features: Array.isArray(candidate.features) ? candidate.features : fallback.features,
      facilities: Array.isArray(candidate.facilities) ? candidate.facilities : fallback.facilities,
      achievements: Array.isArray(candidate.achievements) ? candidate.achievements : fallback.achievements,
      activities: Array.isArray(candidate.activities)
        ? candidate.activities
        : Array.isArray(fallback.activities)
        ? fallback.activities
        : Array.isArray(candidate.features)
        ? candidate.features
        : [],
      news: Array.isArray(candidate.news) ? candidate.news : fallback.news || [],
    };
  });
}

function sanitizeOfficialHouses(incoming: unknown): HouseInfo[] {
  const rawList = Array.isArray(incoming) ? incoming : [];
  const byName = new Map<string, Record<string, unknown>>();
  for (const item of rawList) {
    if (item && typeof item === 'object') {
      const rec = item as Record<string, unknown>;
      const key = String(rec.id || rec.name || '').toLowerCase();
      if (key.includes('bathoen')) byName.set('house-bathoen', rec);
      else if (key.includes('khama')) byName.set('house-khama', rec);
      else if (key.includes('sechele')) byName.set('house-sechele', rec);
      else if (key.includes('moremi')) byName.set('house-moremi', rec);
    }
  }

  return OFFICIAL_FOUR_HOUSES.map((official) => {
    const existing = byName.get(official.id);
    const patronRaw = existing?.patron ? String(existing.patron).trim() : '';
    const descRaw = existing?.description ? String(existing.description).trim() : '';
    // Ensure old Livingstone/Moffat copy never persists in a matched bucket
    const cleanPatron =
      patronRaw && !/livingstone|moffat|cock house/i.test(patronRaw)
        ? patronRaw
        : official.defaultPatron;
    const cleanDesc =
      descRaw && !/livingstone|moffat|cock house/i.test(descRaw)
        ? descRaw
        : official.defaultDescription;

    return {
      id: official.id,
      name: official.name,
      colorName: official.colorName,
      colorHex: official.colorHex,
      color: official.colorHex,
      textColor: official.textColor,
      bgColor: official.bgColor,
      patron: cleanPatron,
      description: cleanDesc,
      badgeUrl: existing?.badgeUrl ? String(existing.badgeUrl) : undefined,
      photoUrl: existing?.photoUrl ? String(existing.photoUrl) : undefined,
    };
  });
}

export function sanitizeSectionValue<K extends CmsSectionKey>(
  key: K,
  value: CmsDatabase[K],
  defaults = createDefaultCmsDatabase()
): CmsDatabase[K] {
  if (key === 'departments' && Array.isArray(value)) {
    return enforceFixedDepartments(
      value as DepartmentInfo[],
      defaults.departments
    ) as CmsDatabase[K];
  }
  if (key === 'about' && value && typeof value === 'object') {
    const a = value as CmsDatabase['about'];
    const leadership: LeadershipMember[] = Array.isArray(a.leadership)
      ? a.leadership.map((m, idx) => ({
          ...m,
          id: m.id || `lead-${idx + 1}`,
          order: typeof m.order === 'number' ? m.order : idx + 1,
          status: m.status || 'published',
        }))
      : defaults.about.leadership;
    const directors: LeadershipMember[] = Array.isArray(a.directors)
      ? a.directors.map((d, idx) => ({
          ...d,
          id: d.id || `dir-${idx + 1}`,
          order: typeof d.order === 'number' ? d.order : idx + 1,
          status: d.status || 'published',
        }))
      : defaults.about.directors || DEFAULT_DIRECTORS;
    return {
      ...defaults.about,
      ...a,
      leadership,
      directors,
    } as CmsDatabase[K];
  }
  if (key === 'houses') {
    return sanitizeOfficialHouses(value) as CmsDatabase[K];
  }
  if (key === 'sports' && value && typeof value === 'object') {
    const s = value as CmsDatabase['sports'];
    const rawStandings = Array.isArray(s.houseTrophyRace?.standings)
      ? s.houseTrophyRace.standings
      : [];
    const byHouse = new Map<string, Record<string, unknown>>();
    for (const st of rawStandings) {
      if (st && typeof st === 'object') {
        const nm = String((st as Record<string, unknown>).house || '').toLowerCase();
        if (nm.includes('bathoen')) byHouse.set('house-bathoen', st as Record<string, unknown>);
        else if (nm.includes('khama')) byHouse.set('house-khama', st as Record<string, unknown>);
        else if (nm.includes('sechele')) byHouse.set('house-sechele', st as Record<string, unknown>);
        else if (nm.includes('moremi')) byHouse.set('house-moremi', st as Record<string, unknown>);
      }
    }
    const cleanStandings = OFFICIAL_FOUR_HOUSES.map((h) => {
      const existing = byHouse.get(h.id);
      const rawHighlight = existing?.highlight ? String(existing.highlight).trim() : '';
      const highlight =
        rawHighlight && !/cock house|livingstone|moffat|points|champion|tied/i.test(rawHighlight)
          ? rawHighlight
          : h.defaultDescription;
      return {
        house: h.name,
        color: h.colorHex,
        colorName: h.colorName,
        patron: h.defaultPatron,
        highlight,
      };
    });

    const rawTrophyName = String(s.houseTrophyRace?.trophyName || '');
    const cleanTrophyName =
      rawTrophyName && !/cock house|standings|leaderboard/i.test(rawTrophyName)
        ? rawTrophyName
        : defaults.sports.houseTrophyRace.trophyName;

    const rawDesc = String(s.houseTrophyRace?.description || '');
    const cleanRaceDesc =
      rawDesc && !/cock house|livingstone|moffat/i.test(rawDesc)
        ? rawDesc
        : defaults.sports.houseTrophyRace.description;

    return {
      ...defaults.sports,
      ...s,
      photos: Array.isArray(s.photos)
        ? s.photos.map((p) => ({
            ...p,
            location: p.location ? String(p.location) : undefined,
            status:
              p.status === 'unpublished' || p.status === 'archived'
                ? p.status
                : ('published' as const),
          }))
        : defaults.sports.photos,
      houseTrophyRace: {
        year: String(s.houseTrophyRace?.year || defaults.sports.houseTrophyRace.year),
        trophyName: cleanTrophyName,
        description: cleanRaceDesc,
        standings: cleanStandings,
      },
    } as CmsDatabase[K];
  }
  if (key === 'athletics' && value && typeof value === 'object') {
    const ath = value as CmsDatabase['athletics'];
    const cleanText = (str: string | undefined, fallback: string): string =>
      str && !/livingstone house|moffat house|cock house/i.test(str) ? str : fallback;
    return {
      ...defaults.athletics,
      ...ath,
      seasonSummary: cleanText(ath.seasonSummary, defaults.athletics.seasonSummary),
      events: Array.isArray(ath.events)
        ? ath.events.map((ev) => ({
            ...ev,
            records: /livingstone|moffat/i.test(ev.records || '')
              ? 'Bathoen, Khama, Sechele & Moremi'
              : ev.records,
          }))
        : defaults.athletics.events,
      competitions: Array.isArray(ath.competitions)
        ? ath.competitions.map((comp) => ({
            ...comp,
            highlights: /cock house|livingstone|moffat/i.test(comp.highlights || '')
              ? 'Full-school inter-house track and field championship uniting Bathoen, Khama, Sechele, and Moremi Houses.'
              : comp.highlights,
          }))
        : defaults.athletics.competitions,
      photos: Array.isArray(ath.photos)
        ? ath.photos.map((p) => ({
            ...p,
            location: p.location ? String(p.location) : undefined,
            status:
              p.status === 'unpublished' || p.status === 'archived'
                ? p.status
                : ('published' as const),
          }))
        : defaults.athletics.photos,
    } as CmsDatabase[K];
  }
  if (key === 'general' && value && typeof value === 'object') {
    const g = value as CmsDatabase['general'];
    return {
      ...defaults.general,
      ...g,
      cambridgeCentreNo:
        (g.cambridgeCentreNo || '').replace(/\s*BW812\s*/gi, '').trim() ||
        defaults.general.cambridgeCentreNo,
      socials: { ...defaults.general.socials, ...(g.socials || {}) },
      address: { ...defaults.general.address, ...(g.address || {}) },
      contacts: { ...defaults.general.contacts, ...(g.contacts || {}) },
    } as CmsDatabase[K];
  }
  if (key === 'alumni' && Array.isArray(value)) {
    return (value as CmsDatabase['alumni'])
      .filter((a) => a && !FAKE_ALUMNI_IDS.has(a.id))
      .map((a) => ({ ...a, status: a.status || 'pending' })) as CmsDatabase[K];
  }
  if (key === 'excursions' && Array.isArray(value)) {
    return (value as CmsDatabase['excursions']).filter(
      (e) => e && !FAKE_EXCURSION_IDS.has(e.id)
    ) as CmsDatabase[K];
  }
  if (key === 'jaguars' && value && typeof value === 'object') {
    const j = value as CmsDatabase['jaguars'];
    return {
      ...defaults.jaguars,
      ...j,
      photos: Array.isArray(j.photos)
        ? j.photos.map((p) => ({
            ...p,
            location: p.location ? String(p.location) : undefined,
            status:
              p.status === 'unpublished' || p.status === 'archived'
                ? p.status
                : ('published' as const),
          }))
        : defaults.jaguars.photos,
      fixtures2026: Array.isArray(j.fixtures2026)
        ? j.fixtures2026.filter((f) => f && !FAKE_FIXTURE_OPPONENTS.has(f.opponent))
        : [],
    } as CmsDatabase[K];
  }
  if (key === 'boarding' && value && typeof value === 'object') {
    const b = value as CmsDatabase['boarding'];
    const hostels = Array.isArray(b.hostels)
      ? b.hostels.map((h) => {
          const normalizedTitle = normalizeSecondarySchoolTitle(h.leaderTitle);
          if (h.id === 'girls-house') {
            return {
              ...h,
              leaderName: h.leaderName || 'Ms T Tumotumo',
              leaderRole:
                h.leaderRole === 'House Mistress'
                  ? 'Boarding Mistress'
                  : normalizeSecondarySchoolTitle(h.leaderRole) || 'Boarding Mistress',
              leaderTitle: normalizedTitle || h.leaderTitle,
              leaderImage: h.leaderImage || './assets/aistudio/Tumotumo_dbbe66dc.jpg',
            };
          }
          if (h.id === 'boys-house') {
            return {
              ...h,
              leaderName: h.leaderName || 'Mr Anderson Dube',
              leaderRole:
                h.leaderRole === 'House Master'
                  ? 'Boarding Master'
                  : normalizeSecondarySchoolTitle(h.leaderRole) || 'Boarding Master',
              leaderTitle: normalizedTitle || h.leaderTitle,
              leaderImage: h.leaderImage || './assets/aistudio/Dube_f9988e37.jpg',
            };
          }
          return {
            ...h,
            leaderRole: normalizeSecondarySchoolTitle(h.leaderRole) || h.leaderRole,
            leaderTitle: normalizedTitle || h.leaderTitle,
          };
        })
      : defaults.boarding.hostels;
    return {
      ...defaults.boarding,
      ...b,
      bannerImage: b.bannerImage ?? defaults.boarding.bannerImage,
      hostels,
    } as CmsDatabase[K];
  }
  if (key === 'teachers' && Array.isArray(value)) {
    return (value as TeacherProfile[]).map((t) => ({
      ...t,
      role: t.role ? normalizeSecondarySchoolTitle(t.role) : t.role,
      leadershipPosition:
        t.leadershipPosition &&
        ['hod', 'deputy_hod', 'teacher', 'support'].includes(t.leadershipPosition)
          ? t.leadershipPosition
          : undefined,
      order: typeof t.order === 'number' && Number.isFinite(t.order) ? t.order : undefined,
    })) as CmsDatabase[K];
  }
  if (key === 'achievers' && value && typeof value === 'object') {
    const a = value as CmsDatabase['achievers'];
    const years = Array.isArray(a.availableYears) && a.availableYears.length > 0 ? a.availableYears : ['2025'];
    return {
      ...defaults.achievers,
      ...a,
      availableYears: years,
      activeYear: a.activeYear || years[0],
      yearlySummaries: a.yearlySummaries || { [years[0]]: a.summary || defaults.achievers.summary },
      awards: Array.isArray(a.awards) ? a.awards : defaults.achievers.awards,
      honorRoll: Array.isArray(a.honorRoll) ? a.honorRoll : defaults.achievers.honorRoll,
    } as CmsDatabase[K];
  }
  return value;
}

const HOY_DEFAULT_RESPONSIBILITIES = [
  'Academic progress monitoring',
  'Student attendance and discipline',
  'Student development',
  'Communication with parents and guardians',
  'Student welfare and pastoral support',
  'Identification of students requiring additional assistance',
  'Coordination with teachers and school management',
].join('\n');

const COORDINATOR_DEFAULT_RESPONSIBILITIES = [
  'Coordination of A-Level academic programmes',
  'Monitoring academic progress',
  'Supporting subject departments and teachers',
  'Coordinating academic planning',
  'Monitoring assessment and examination preparation',
  'Supporting consistency in academic standards',
  'Liaising with school leadership on A-Level academic matters',
].join('\n');

const PASTORAL_DEFAULT_RESPONSIBILITIES = [
  'Student wellbeing and welfare',
  'Guidance and counselling support',
  'Supporting students facing personal or academic difficulties',
  'Promoting positive behaviour and responsible decision-making',
  'Supporting student adjustment and development',
  'Referring students to appropriate additional support where necessary',
  'Promoting a safe, supportive and respectful learning environment',
  'Liaising with relevant staff and school leadership where appropriate',
].join('\n');

function seedDatabaseIfNeeded(db: DatabaseSync): void {
  const defaults = createDefaultCmsDatabase();
  const now = new Date().toISOString();

  const existingCountRow = db
    .prepare('SELECT COUNT(*) as cnt FROM cms_sections')
    .get() as { cnt: number };

  const upsertSectionStmt = db.prepare(`
    INSERT INTO cms_sections (section_key, data_json, updated_at, updated_by)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(section_key) DO NOTHING
  `);

  for (const key of Object.keys(defaults) as CmsSectionKey[]) {
    if (key === 'media') continue;
    upsertSectionStmt.run(key, JSON.stringify(defaults[key]), now, 'system');
  }

  // Normalize houses/sports/athletics in DB if legacy values remain from prior version
  for (const cleanKey of ['houses', 'sports', 'athletics'] as CmsSectionKey[]) {
    const existingRow = db
      .prepare('SELECT data_json FROM cms_sections WHERE section_key = ?')
      .get(cleanKey) as { data_json: string } | undefined;
    if (existingRow) {
      const rawJson = existingRow.data_json;
      if (/livingstone house|moffat house|cock house|fortis in fide/i.test(rawJson)) {
        const parsed = JSON.parse(rawJson);
        const cleaned = sanitizeSectionValue(cleanKey, parsed, defaults);
        db.prepare('UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = ?').run(
          JSON.stringify(cleaned),
          now,
          cleanKey
        );
      }
    }
  }

  // Ensure media assets exist when fresh DB
  const mediaCnt = (db.prepare('SELECT COUNT(*) as cnt FROM media_assets').get() as { cnt: number }).cnt;
  if (mediaCnt === 0 || existingCountRow.cnt === 0) {
    const insertMedia = db.prepare(`
      INSERT OR IGNORE INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const m of defaults.media) {
      insertMedia.run(
        m.id,
        m.name,
        m.filename ?? null,
        m.url,
        m.category,
        m.mediaType || 'image',
        m.mimeType ?? null,
        m.sizeBytes ?? null,
        m.description ?? null,
        m.uploadedAt
      );
    }
  }

  // Seed default featured page items when fresh DB
  const itemsCnt = (db.prepare('SELECT COUNT(*) as cnt FROM cms_items').get() as { cnt: number }).cnt;
  if (itemsCnt === 0) {
    const insertItem = db.prepare(`
      INSERT OR IGNORE INTO cms_items (
        id, page_key, category, academic_year, title, slug, excerpt, content_json,
        thumbnail_url, media_url, status, feature_on_homepage, publish_at,
        event_date, event_time, event_location, event_completed, sort_order,
        created_by, updated_by, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const item of DEFAULT_CMS_ITEMS) {
      insertItem.run(
        item.id,
        item.pageKey,
        item.category,
        item.academicYear ?? null,
        item.title,
        item.slug,
        item.excerpt,
        JSON.stringify(item.content || {}),
        item.thumbnailUrl ?? null,
        item.mediaUrl ?? null,
        item.status,
        item.featureOnHomepage ? 1 : 0,
        item.publishAt ?? null,
        item.eventDate ?? null,
        item.eventTime ?? null,
        item.eventLocation ?? null,
        item.eventCompleted ? 1 : 0,
        item.sortOrder,
        item.createdBy ?? 'system',
        item.updatedBy ?? 'system',
        item.createdAt,
        item.updatedAt
      );
    }
  }

  // Seed initial 5 CMS Administrator accounts idempotently (unique per-user CSPRNG or env passwords)
  const newlyProvisioned: Array<{ username: string; email: string; tempPassword: string; source: string }> = [];
  for (const acct of INITIAL_ADMIN_ACCOUNTS) {
    const existing = db
      .prepare('SELECT id FROM users WHERE LOWER(username) = ? OR LOWER(email) = ?')
      .get(acct.username, acct.email) as { id: string } | undefined;
    if (existing) continue;

    const envKey = `CMS_SEED_PASSWORD_${acct.username.toUpperCase()}`;
    const envPass = process.env[envKey]?.trim();
    const useEnv = Boolean(envPass && envPass.length >= 8);
    const tempPassword = useEnv ? envPass! : generateTemporaryPassword(16);

    const id = `usr-seed-${acct.username}-${crypto.randomBytes(4).toString('hex')}`;
    db.prepare(`
      INSERT INTO users (
        id, username, email, full_name, password_hash, role, assigned_pages_json,
        active, must_change_password, failed_login_attempts, created_at
      ) VALUES (?, ?, ?, ?, ?, 'admin', '[]', 1, 1, 0, ?)
    `).run(id, acct.username, acct.email, acct.fullName, hashPassword(tempPassword), now);

    newlyProvisioned.push({
      username: acct.username,
      email: acct.email,
      tempPassword,
      source: useEnv ? `env:${envKey}` : 'csprng',
    });
  }

  if (newlyProvisioned.length > 0) {
    const generatedLines = [
      '# LKC CMS Initial Administrator Temporary Passwords (0600 Protected — Rotate Immediately on First Login)',
      `# Provisioned: ${now}`,
      '# Delete or move to your institution password manager once distributed securely.',
      '',
      ...newlyProvisioned.map(
        (p) => `username=${p.username}  email=${p.email}  temporary_password=${p.tempPassword}  source=${p.source}`
      ),
      '',
    ].join('\n');

    const appendMode = fs.existsSync(INITIAL_CREDENTIALS_FILE);
    fs.writeFileSync(
      INITIAL_CREDENTIALS_FILE,
      appendMode ? `\n${generatedLines}` : generatedLines,
      { mode: 0o600, flag: appendMode ? 'a' : 'w' }
    );
    try {
      fs.chmodSync(INITIAL_CREDENTIALS_FILE, 0o600);
    } catch {
      // Ignore chmod failures on non-POSIX filesystems
    }
  }

  // Optional environment-based initial Super Administrator bootstrap (checks super_admin count only)
  const bootstrapEmail = process.env.CMS_BOOTSTRAP_ADMIN_EMAIL?.trim().toLowerCase();
  const bootstrapPassword = process.env.CMS_BOOTSTRAP_ADMIN_PASSWORD?.trim();
  const superAdminCnt = (
    db.prepare("SELECT COUNT(*) as cnt FROM users WHERE role = 'super_admin' AND active = 1").get() as {
      cnt: number;
    }
  ).cnt;
  if (superAdminCnt === 0 && bootstrapEmail && bootstrapPassword && bootstrapPassword.length >= 8) {
    const existingByEmail = db
      .prepare('SELECT id FROM users WHERE LOWER(email) = ?')
      .get(bootstrapEmail);
    if (!existingByEmail) {
      const id = `usr-${crypto.randomUUID()}`;
      db.prepare(`
        INSERT INTO users (
          id, username, email, full_name, password_hash, role, assigned_pages_json,
          active, must_change_password, failed_login_attempts, created_at
        ) VALUES (?, ?, ?, ?, ?, 'super_admin', '[]', 1, 0, 0, ?)
      `).run(
        id,
        bootstrapEmail.split('@')[0],
        bootstrapEmail,
        'Initial Super Administrator',
        hashPassword(bootstrapPassword),
        now
      );
    }
  }

  // Seed relational staff_members and academic_assignments when fresh (non-clobbering)
  const staffCnt = (db.prepare('SELECT COUNT(*) as cnt FROM staff_members').get() as { cnt: number }).cnt;
  const assignCnt = (db.prepare('SELECT COUNT(*) as cnt FROM academic_assignments').get() as { cnt: number }).cnt;

  if (staffCnt === 0 && assignCnt === 0) {
    const initialStaff: Array<{
      id: string;
      surname: string;
      fullName: string;
      displayTitle: string;
      department: string;
      subjects: string[];
      image: string | null;
      isIncomplete: boolean;
      incompleteReason?: string;
      sortOrder: number;
    }> = [
      {
        id: 'staff-benjamin',
        surname: 'Benjamin',
        fullName: 'Mrs A Benjamin',
        displayTitle: 'Mrs',
        department: 'Languages',
        subjects: ['First Language English (0500)', 'Argumentative Prose & Speechwriting'],
        image: './assets/aistudio/image_1e2f1b72.png',
        isIncomplete: false,
        sortOrder: 1,
      },
      {
        id: 'staff-mboto',
        surname: 'Mboto',
        fullName: 'Mr Takudzwa L Mboto',
        displayTitle: 'Mr',
        department: 'Commercials',
        subjects: ['Cambridge Accounting (0452)', 'Business Studies (0450)'],
        image: './assets/aistudio/Mboto_a9a43477.jpg',
        isIncomplete: false,
        sortOrder: 2,
      },
      {
        id: 'staff-mpofu',
        surname: 'Mpofu',
        fullName: 'Ms Evelyn Mpofu',
        displayTitle: 'Ms',
        department: 'Humanities',
        subjects: ['Cambridge Geography (0460)', 'Development Studies'],
        image: './assets/aistudio/Mpofu_8fe1b917.jpg',
        isIncomplete: false,
        sortOrder: 3,
      },
      {
        id: 'staff-ndebele-m',
        surname: 'Ndebele M',
        fullName: 'Mr Mthunyelwa Ndebele',
        displayTitle: 'Mr',
        department: 'Physical Education & Sports',
        subjects: ['Cambridge Physical Education (0413)', 'Athletics & Coaching'],
        image: './assets/aistudio/Ndebele_M_37d3ca16.jpg',
        isIncomplete: false,
        sortOrder: 4,
      },
      {
        id: 'staff-mutero',
        surname: 'Mutero',
        fullName: 'Mr Takunda Mutero',
        displayTitle: 'Mr',
        department: 'Commercials',
        subjects: ['Cambridge Economics (0455 / 9708)', 'Business Studies'],
        image: './assets/aistudio/Mutero_768af995.jpeg',
        isIncomplete: false,
        sortOrder: 5,
      },
      {
        id: 'staff-mandiudza',
        surname: 'Mandiudza',
        fullName: 'Ms Abigail Zephania Mandiudza',
        displayTitle: 'Ms',
        department: 'Science',
        subjects: ['Cambridge Chemistry (0620 / 9701)', 'Combined Science'],
        image: './assets/aistudio/Mandiudza_df942cde.jpg',
        isIncomplete: false,
        sortOrder: 6,
      },
      {
        id: 'staff-chambwera',
        surname: 'Chambwera',
        fullName: 'Mr Takudzwa Rodney Chambwera',
        displayTitle: 'Mr',
        department: 'Languages',
        subjects: ['English Language (0500)', 'Parliamentary Debate', 'Public Speaking'],
        image: './assets/aistudio/image_7dd36b08.png',
        isIncomplete: false,
        sortOrder: 7,
      },
      {
        id: 'staff-madzivanyika',
        surname: 'Madzivanyika',
        fullName: 'Ms F. Madzivanyika',
        displayTitle: 'Ms',
        department: 'ICT and Logistics',
        subjects: ['Cambridge ICT (0417)', 'Digital Literacy'],
        image: './assets/aistudio/Madzivanyika_e4d96c2b.jpg',
        isIncomplete: false,
        sortOrder: 8,
      },
    ];

    const insertStaffStmt = db.prepare(`
      INSERT OR IGNORE INTO staff_members (
        id, surname, full_name, display_title, department, subjects_json,
        image, bio, qualifications, email, status, is_incomplete, incomplete_reason,
        sort_order, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'published', ?, ?, ?, ?, ?)
    `);

    for (const s of initialStaff) {
      insertStaffStmt.run(
        s.id,
        s.surname,
        s.fullName,
        s.displayTitle,
        s.department,
        JSON.stringify(s.subjects),
        s.image,
        null,
        null,
        null,
        s.isIncomplete ? 1 : 0,
        s.incompleteReason ?? null,
        s.sortOrder,
        now,
        now
      );
    }

    const initialAssignments: Array<{
      id: string;
      staffId: string;
      assignmentType: AcademicAssignmentType;
      roleTitle: string;
      yearGroup: YearGroupKey | null;
      summary: string;
      responsibilities: string;
      sortOrder: number;
    }> = [
      {
        id: 'assign-hoy-form1',
        staffId: 'staff-benjamin',
        assignmentType: 'head_of_year',
        roleTitle: 'Head of Year – Form 1',
        yearGroup: 'Form 1',
        summary: 'Year-group academic progress oversight and pastoral induction for Form 1 students.',
        responsibilities: HOY_DEFAULT_RESPONSIBILITIES,
        sortOrder: 1,
      },
      {
        id: 'assign-hoy-form2',
        staffId: 'staff-mboto',
        assignmentType: 'head_of_year',
        roleTitle: 'Head of Year – Form 2',
        yearGroup: 'Form 2',
        summary: 'Academic tracking and Lower Secondary progression support for Form 2 cohorts.',
        responsibilities: HOY_DEFAULT_RESPONSIBILITIES,
        sortOrder: 2,
      },
      {
        id: 'assign-hoy-form3',
        staffId: 'staff-mpofu',
        assignmentType: 'head_of_year',
        roleTitle: 'Head of Year – Form 3',
        yearGroup: 'Form 3',
        summary: 'IGCSE foundation guidance, attendance monitoring, and student welfare for Form 3.',
        responsibilities: HOY_DEFAULT_RESPONSIBILITIES,
        sortOrder: 3,
      },
      {
        id: 'assign-hoy-form4',
        staffId: 'staff-ndebele-m',
        assignmentType: 'head_of_year',
        roleTitle: 'Head of Year – Form 4',
        yearGroup: 'Form 4',
        summary: 'IGCSE coursework diligence, pastoral care, and Form 4 academic monitoring.',
        responsibilities: HOY_DEFAULT_RESPONSIBILITIES,
        sortOrder: 4,
      },
      {
        id: 'assign-hoy-form5',
        staffId: 'staff-mutero',
        assignmentType: 'head_of_year',
        roleTitle: 'Head of Year – Form 5',
        yearGroup: 'Form 5',
        summary: 'Senior IGCSE examination readiness, discipline, and sixth-form transition support.',
        responsibilities: HOY_DEFAULT_RESPONSIBILITIES,
        sortOrder: 5,
      },
      {
        id: 'assign-hoy-alevel',
        staffId: 'staff-mandiudza',
        assignmentType: 'head_of_year',
        roleTitle: 'Head of Year – A Level',
        yearGroup: 'A Level',
        summary: 'Sixth Form year-group supervision, attendance, and student welfare for A-Level learners.',
        responsibilities: HOY_DEFAULT_RESPONSIBILITIES,
        sortOrder: 6,
      },
      {
        id: 'assign-alevel-coordinator',
        staffId: 'staff-chambwera',
        assignmentType: 'a_level_coordinator',
        roleTitle: 'A-Level Coordinator',
        yearGroup: 'A Level',
        summary: 'Academic coordination of Cambridge AS & A-Level programmes across departments.',
        responsibilities: COORDINATOR_DEFAULT_RESPONSIBILITIES,
        sortOrder: 1,
      },
      {
        id: 'assign-pastoral-alevel',
        staffId: 'staff-madzivanyika',
        assignmentType: 'pastoral_care',
        roleTitle: 'Pastoral Care, Guidance and Counselling – A Level',
        yearGroup: 'A Level',
        summary: 'Dedicated Sixth Form student wellbeing, guidance, and counselling support.',
        responsibilities: PASTORAL_DEFAULT_RESPONSIBILITIES,
        sortOrder: 1,
      },
    ];

    const insertAssignStmt = db.prepare(`
      INSERT OR IGNORE INTO academic_assignments (
        id, staff_id, assignment_type, role_title, year_group, summary,
        responsibilities, welcome_message, status, sort_order, archived_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'published', ?, NULL, ?, ?)
    `);

    for (const a of initialAssignments) {
      insertAssignStmt.run(
        a.id,
        a.staffId,
        a.assignmentType,
        a.roleTitle,
        a.yearGroup,
        a.summary,
        a.responsibilities,
        '',
        a.sortOrder,
        now,
        now
      );
    }
  }

  // One-shot non-clobbering migration: apply updated photography, HODs, and faculty roles
  const migrationId = 'migration_2026_11_13_images_hods_v1';
  const applied = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationId) as { id: string } | undefined;

  if (!applied) {
    // 1. Update homepage hero background image
    const heroRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'hero'")
      .get() as { data_json: string } | undefined;
    if (heroRow) {
      const heroObj = JSON.parse(heroRow.data_json);
      heroObj.heroImage = './assets/aistudio/image_efcc4027.png';
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'hero'").run(
        JSON.stringify(heroObj),
        now
      );
    }

    // 2. Register new photography assets in Media Library
    const insertMedia = db.prepare(`
      INSERT OR IGNORE INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const m of defaults.media) {
      insertMedia.run(
        m.id,
        m.name,
        m.filename ?? null,
        m.url,
        m.category,
        m.mediaType || 'image',
        m.mimeType ?? null,
        m.sizeBytes ?? null,
        m.description ?? null,
        m.uploadedAt
      );
    }

    // 3. Update featured CMS item thumbnails
    const itemThumbs: Record<string, string> = {
      'item-news-admissions-2026': './assets/aistudio/image_64191a25.png',
      'item-news-cambridge-honors': './assets/aistudio/image_92072db7.png',
      'item-news-masire-boarding': './assets/aistudio/image_06ec6396.png',
      'item-event-open-day': './assets/aistudio/image_75acd27b.png',
    };
    const updateItemThumbStmt = db.prepare(
      'UPDATE cms_items SET thumbnail_url = ?, updated_at = ? WHERE id = ?'
    );
    for (const [itemId, thumbUrl] of Object.entries(itemThumbs)) {
      updateItemThumbStmt.run(thumbUrl, now, itemId);
    }

    // 4. Update the 8 Departments' Head of Department records
    const deptRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'departments'")
      .get() as { data_json: string } | undefined;
    if (deptRow) {
      const existingDepts = JSON.parse(deptRow.data_json) as DepartmentInfo[];
      const defaultHodById = new Map(
        defaults.departments.map((d) => [d.id, d.headOfDepartment])
      );
      const updatedDepts = existingDepts.map((d) => {
        const nextHod = defaultHodById.get(d.id);
        return nextHod
          ? {
              ...d,
              headOfDepartment: {
                ...d.headOfDepartment,
                ...nextHod,
              },
            }
          : d;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'departments'").run(
        JSON.stringify(updatedDepts),
        now
      );
    }

    // 5. Sync updated HOD faculty roles in teachers section
    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as Array<{ id: string; role?: string }>;
      const defaultRoleById = new Map(defaults.teachers.map((t) => [t.id, t.role]));
      const roleUpdatedIds = new Set([
        't-ict-1',
        't-math-4',
        't-sci-2',
        't-sci-9',
        't-art-1',
        't-art-2',
        't-pe-1',
        't-hum-7',
        't-lang-7',
        't-com-2',
      ]);
      const updatedTeachers = existingTeachers.map((t) =>
        roleUpdatedIds.has(t.id) && defaultRoleById.has(t.id)
          ? { ...t, role: defaultRoleById.get(t.id) }
          : t
      );
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(updatedTeachers),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationId, now);
  }

  // One-shot non-clobbering migration v2: Mrs Dove -> Languages, Mr Mutero -> Commercials Teacher, eliminate Lecturer/Professor
  const migrationV2Id = 'migration_2026_11_13_dove_mutero_terminology_v2';
  const appliedV2 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV2Id) as { id: string } | undefined;

  if (!appliedV2) {
    // 1. Update teachers section
    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];
      const migratedTeachers = existingTeachers.map((t) => {
        if (t.id === 't-com-11' || /\bdove\b/i.test(t.name)) {
          return {
            ...t,
            departmentId: 'dept-languages',
            departmentName: 'Languages Department',
            role: 'Teacher – Languages Department',
            subjects:
              t.subjects && t.subjects.length > 0 && !t.subjects.includes('Commercial Studies')
                ? t.subjects
                : ['Languages', 'Academic Curriculum Coordination'],
            bio:
              t.bio && !/commercial studies/i.test(t.bio)
                ? t.bio
                : 'Coordinates Languages curriculum standards, examination preparation, and Lower School academic development.',
          };
        }
        if (t.id === 't-com-7' || /\bmutero\b/i.test(t.name)) {
          return {
            ...t,
            departmentId: 'dept-commercials',
            departmentName: 'Commercials Department',
            role: 'Teacher – Commercials Department',
          };
        }
        return {
          ...t,
          role: t.role ? normalizeSecondarySchoolTitle(t.role) : t.role,
        };
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(migratedTeachers),
        now
      );
    }

    // 2. Update boarding section (girls-house leaderTitle)
    const boardingRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'boarding'")
      .get() as { data_json: string } | undefined;
    if (boardingRow) {
      const parsedBoarding = JSON.parse(boardingRow.data_json) as CmsDatabase['boarding'];
      const cleanedBoarding = sanitizeSectionValue('boarding', parsedBoarding, defaults);
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'boarding'").run(
        JSON.stringify(cleanedBoarding),
        now
      );
    }

    // 3. Ensure relational staff_members has no Lecturer/Professor labels
    const staffRows = db
      .prepare('SELECT id, display_title, bio FROM staff_members')
      .all() as { id: string; display_title: string | null; bio: string | null }[];
    const updateStaffStmt = db.prepare(
      'UPDATE staff_members SET display_title = ?, bio = ?, updated_at = ? WHERE id = ?'
    );
    for (const s of staffRows) {
      const nextTitle = s.display_title ? normalizeSecondarySchoolTitle(s.display_title) : null;
      const nextBio = s.bio ? normalizeSecondarySchoolTitle(s.bio) : null;
      if (nextTitle !== s.display_title || nextBio !== s.bio) {
        updateStaffStmt.run(nextTitle, nextBio, now, s.id);
      }
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV2Id, now);
  }

  // One-shot non-clobbering migration v3: Directors section, Ms Matlotse normalization (no duplicate), and HOD-first hierarchy
  const migrationV3Id = 'migration_2026_11_13_directors_matlotse_hod_hierarchy_v3';
  const appliedV3 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV3Id) as { id: string } | undefined;

  if (!appliedV3) {
    // 1. Add separate Directors records into about.directors without touching about.leadership (SMT)
    const aboutRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'about'")
      .get() as { data_json: string } | undefined;
    if (aboutRow) {
      const parsedAbout = JSON.parse(aboutRow.data_json) as CmsDatabase['about'];
      if (!Array.isArray(parsedAbout.directors) || parsedAbout.directors.length === 0) {
        parsedAbout.directors = DEFAULT_DIRECTORS;
        db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'about'").run(
          JSON.stringify(parsedAbout),
          now
        );
      }
    }

    // 2. Normalize Ms Matlotse (no duplicates) & assign explicit HOD leadershipPosition where already recorded
    const deptRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'departments'")
      .get() as { data_json: string } | undefined;
    const currentDepts: DepartmentInfo[] = deptRow
      ? (JSON.parse(deptRow.data_json) as DepartmentInfo[])
      : defaults.departments;
    const deptById = new Map(currentDepts.map((d) => [d.id, d]));

    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];

      let keptMatlotse = false;
      const updatedTeachers: TeacherProfile[] = [];
      for (const teacher of existingTeachers) {
        if (/\bmatlotse\b/i.test(teacher.name)) {
          if (keptMatlotse) {
            continue;
          }
          keptMatlotse = true;
          updatedTeachers.push({
            ...teacher,
            name: 'Ms Matlotse',
            departmentId: 'dept-languages',
            departmentName: 'Languages Department',
            role: 'Teacher',
            title: 'Ms',
            subjects:
              Array.isArray(teacher.subjects) && teacher.subjects.length > 0
                ? teacher.subjects
                : ['English'],
            bio: teacher.bio || '',
            leadershipPosition: teacher.leadershipPosition || 'teacher',
            status: teacher.status || 'published',
          });
          continue;
        }

        const dept = deptById.get(teacher.departmentId);
        const inferredPos = getTeacherLeadershipPosition(teacher, dept);
        const isRecordedHod =
          Boolean(dept?.headOfDepartment?.name) &&
          normalizePersonName(dept?.headOfDepartment?.name) === normalizePersonName(teacher.name);

        updatedTeachers.push({
          ...teacher,
          leadershipPosition: teacher.leadershipPosition || (isRecordedHod ? 'hod' : inferredPos),
          order:
            typeof teacher.order === 'number'
              ? teacher.order
              : isRecordedHod
              ? 1
              : undefined,
        });
      }

      if (!keptMatlotse) {
        updatedTeachers.push({
          id: 't-lang-matlotse',
          name: 'Ms Matlotse',
          departmentId: 'dept-languages',
          departmentName: 'Languages Department',
          role: 'Teacher',
          title: 'Ms',
          subjects: ['English'],
          bio: '',
          leadershipPosition: 'teacher',
          status: 'published',
        });
      }

      const sortedTeachers = sortTeachersForDirectory(updatedTeachers, currentDepts);
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(sortedTeachers),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV3Id, now);
  }

  // One-shot non-clobbering migration v4: Athletics Track & Training Gallery location, capitalization & status
  const migrationV4Id = 'migration_2026_11_13_athletics_gallery_v4';
  const appliedV4 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV4Id) as { id: string } | undefined;

  if (!appliedV4) {
    const athleticsRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'athletics'")
      .get() as { data_json: string } | undefined;
    if (athleticsRow) {
      const parsedAthletics = JSON.parse(athleticsRow.data_json) as CmsDatabase['athletics'];
      const photos = Array.isArray(parsedAthletics.photos) ? parsedAthletics.photos : defaults.athletics.photos;
      parsedAthletics.photos = photos.map((p) => {
        const next = { ...p, status: p.status || ('published' as const) };
        if (
          next.title === 'LKC Synthetic Running Track & Field Complex' &&
          !next.location
        ) {
          next.location = 'Block 8 Campus Athletics Precinct';
        }
        if (
          next.title === 'Block 8 Campus Athletics Precinct' &&
          typeof next.caption === 'string' &&
          next.caption.startsWith('expansive ')
        ) {
          next.caption = `Expansive ${next.caption.slice('expansive '.length)}`;
        }
        if (next.title === 'Block 8 Campus Athletics Precinct' && !next.location) {
          next.location = 'LKC Block 8 Campus';
        }
        return next;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'athletics'").run(
        JSON.stringify(parsedAthletics),
        now
      );
    }
    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV4Id, now);
  }

  // One-shot non-clobbering migration v5: apply uploaded portraits for Mrs A Benjamin, Mr P Ketlametswe & register media assets
  const migrationV5Id = 'migration_2026_11_15_benjamin_ketlametswe_portraits_v5';
  const appliedV5 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV5Id) as { id: string } | undefined;

  if (!appliedV5) {
    const insertMedia = db.prepare(`
      INSERT OR IGNORE INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const m of defaults.media) {
      if (m.id === 'm-14' || m.id === 'm-15' || m.id === 'm-16') {
        insertMedia.run(
          m.id,
          m.name,
          m.filename ?? null,
          m.url,
          m.category,
          m.mediaType || 'image',
          m.mimeType ?? null,
          m.sizeBytes ?? null,
          m.description ?? null,
          m.uploadedAt
        );
      }
    }

    // Update Mrs A Benjamin in relational staff_members (Form 1 Head of Year)
    db.prepare(`
      UPDATE staff_members
      SET image = ?, is_incomplete = 0, incomplete_reason = NULL, updated_at = ?
      WHERE id = 'staff-benjamin' AND (image IS NULL OR image = '')
    `).run('./assets/aistudio/image_1e2f1b72.png', now);

    // Update Mrs A Benjamin & Mr P Ketlametswe in teachers CMS section
    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];
      const migratedTeachers = existingTeachers.map((t) => {
        if ((t.id === 't-lang-3' || /\bbenjamin\b/i.test(t.name)) && !t.image) {
          return { ...t, image: './assets/aistudio/image_1e2f1b72.png' };
        }
        if ((t.id === 't-sci-3' || /\bketlametswe\b/i.test(t.name)) && !t.image) {
          return { ...t, image: './assets/aistudio/image_fe074d05.png' };
        }
        return t;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(migratedTeachers),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV5Id, now);
  }

  // One-shot non-clobbering migration v6: apply uploaded portrait for Mr Takudzwa Rodney Chambwera & register school video
  const migrationV6Id = 'migration_2026_11_15_chambwera_and_school_video_v6';
  const appliedV6 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV6Id) as { id: string } | undefined;

  if (!appliedV6) {
    const insertMedia = db.prepare(`
      INSERT OR IGNORE INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const m of defaults.media) {
      if (m.id === 'm-17' || m.id === 'm-18') {
        insertMedia.run(
          m.id,
          m.name,
          m.filename ?? null,
          m.url,
          m.category,
          m.mediaType || 'image',
          m.mimeType ?? null,
          m.sizeBytes ?? null,
          m.description ?? null,
          m.uploadedAt
        );
      }
    }

    db.prepare(`
      UPDATE staff_members
      SET image = ?, is_incomplete = 0, incomplete_reason = NULL, updated_at = ?
      WHERE id = 'staff-chambwera' AND (image IS NULL OR image = '')
    `).run('./assets/aistudio/image_7dd36b08.png', now);

    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];
      const migratedTeachers = existingTeachers.map((t) =>
        (t.id === 't-lang-4' || /\bchambwera\b/i.test(t.name)) && !t.image
          ? { ...t, image: './assets/aistudio/image_7dd36b08.png' }
          : t
      );
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(migratedTeachers),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV6Id, now);
  }

  // One-shot migration v7: link Kgosidintsi portrait to Mr Bokamoso Kgosidintsi (t-hum-1),
  // register Chivorese & Makoni portraits in media_assets, and repair any fallback-logo links in ICT/Directors.
  const migrationV7Id = 'migration_2026_11_15_bokamoso_kgosidintsi_and_ict_media_v7';
  const appliedV7 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV7Id) as { id: string } | undefined;

  if (!appliedV7) {
    const insertOrUpdateMedia = db.prepare(`
      INSERT INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        description = excluded.description,
        url = excluded.url
    `);
    for (const m of defaults.media) {
      if (m.id === 'm-15' || m.id === 'm-19' || m.id === 'm-20') {
        insertOrUpdateMedia.run(
          m.id,
          m.name,
          m.filename ?? null,
          m.url,
          m.category,
          m.mediaType || 'image',
          m.mimeType ?? null,
          m.sizeBytes ?? null,
          m.description ?? null,
          m.uploadedAt
        );
      }
    }

    const isLogoOrBlank = (url?: string | null) =>
      !url || !url.trim() || /logo_33a39ff7\.png/i.test(url);

    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];
      const migratedTeachers = existingTeachers.map((t) => {
        if (t.id === 't-hum-1' || /\bbokamoso\b/i.test(t.name)) {
          return {
            ...t,
            name: t.name === 'Mr K Bokamoso' ? 'Mr Bokamoso Kgosidintsi' : t.name,
            image: isLogoOrBlank(t.image) ? './assets/aistudio/image_a734d497.png' : t.image,
          };
        }
        if ((t.id === 't-ict-1' || /\bchivorese\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Chivorese_92d20e94.jpg' };
        }
        if ((t.id === 't-ict-4' || /\bmakoni\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Makoni_4a7d1146.jpg' };
        }
        return t;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(migratedTeachers),
        now
      );
    }

    const deptsRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'departments'")
      .get() as { data_json: string } | undefined;
    if (deptsRow) {
      const existingDepts = JSON.parse(deptsRow.data_json) as DepartmentInfo[];
      const migratedDepts = existingDepts.map((d) => {
        if (
          (d.id === 'dept-ict' || /\bchivorese\b/i.test(d.headOfDepartment?.name || '')) &&
          isLogoOrBlank(d.headOfDepartment?.image)
        ) {
          return {
            ...d,
            headOfDepartment: {
              ...d.headOfDepartment,
              image: './assets/aistudio/Chivorese_92d20e94.jpg',
            },
          };
        }
        return d;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'departments'").run(
        JSON.stringify(migratedDepts),
        now
      );
    }

    const aboutRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'about'")
      .get() as { data_json: string } | undefined;
    if (aboutRow) {
      const existingAbout = JSON.parse(aboutRow.data_json) as CmsDatabase['about'];
      if (Array.isArray(existingAbout.directors)) {
        existingAbout.directors = existingAbout.directors.map((dir) =>
          (dir.id === 'dir-makoni' || /\bmakoni\b/i.test(dir.name)) && isLogoOrBlank(dir.image)
            ? { ...dir, image: './assets/aistudio/Makoni_4a7d1146.jpg' }
            : dir
        );
        db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'about'").run(
          JSON.stringify(existingAbout),
          now
        );
      }
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV7Id, now);
  }

  // One-shot migration v8: restore Mr K Murombedzi (Vice Principal Examinations) to SMT in about.leadership,
  // register Murombedzi portrait m-21 in media_assets, and remove legacy AI-generated placeholder photos
  // from athletics, jaguars, and sports galleries while keeping any admin-uploaded media intact.
  const migrationV8Id = 'migration_2026_11_16_smt_murombedzi_and_sports_cleanup_v8';
  const appliedV8 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV8Id) as { id: string } | undefined;

  if (!appliedV8) {
    const murombedziAsset = defaults.media.find((m) => m.id === 'm-21');
    if (murombedziAsset) {
      db.prepare(`
        INSERT INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          name = excluded.name,
          description = excluded.description,
          url = excluded.url
      `).run(
        murombedziAsset.id,
        murombedziAsset.name,
        murombedziAsset.filename ?? null,
        murombedziAsset.url,
        murombedziAsset.category,
        murombedziAsset.mediaType || 'image',
        murombedziAsset.mimeType ?? null,
        murombedziAsset.sizeBytes ?? null,
        murombedziAsset.description ?? null,
        murombedziAsset.uploadedAt
      );
    }

    const aboutRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'about'")
      .get() as { data_json: string } | undefined;
    if (aboutRow) {
      const existingAbout = JSON.parse(aboutRow.data_json) as CmsDatabase['about'];
      const leadershipList: LeadershipMember[] = Array.isArray(existingAbout.leadership)
        ? [...existingAbout.leadership]
        : [...defaults.about.leadership];

      const hasMurombedzi = leadershipList.some(
        (m) => m.id === 'lead-murombedzi' || /\bmurombedzi\b/i.test(m.name)
      );
      if (!hasMurombedzi) {
        const defaultMurombedzi = defaults.about.leadership.find(
          (m) => m.id === 'lead-murombedzi'
        );
        if (defaultMurombedzi) {
          leadershipList.push(defaultMurombedzi);
        }
      }

      const updatedLeadership = leadershipList.map((m) => {
        if (m.id === 'lead-murombedzi' || /\bmurombedzi\b/i.test(m.name)) {
          return {
            ...m,
            id: m.id || 'lead-murombedzi',
            order: m.order ?? 6,
            status: 'published' as const,
            role: m.role || 'Vice Principal Examinations',
            title: m.title || 'Vice Principal (Examinations & Assessment Standards)',
            image:
              !m.image || /logo_33a39ff7\.png/i.test(m.image)
                ? './assets/aistudio/Murombedzi_b26ea474.jpg'
                : m.image,
            department: m.department || 'Cambridge Examinations & Assessment',
            isSMT: true,
          };
        }
        if (m.id === 'lead-munodawafa' && (m.order === undefined || m.order === 6)) {
          return { ...m, order: 7 };
        }
        return m;
      });

      existingAbout.leadership = updatedLeadership;
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'about'").run(
        JSON.stringify(existingAbout),
        now
      );
    }

    const aiPlaceholderRe =
      /\/assets\/images\/(?:hero_lkc_campus_1792759534281|lkc_library_study_1792759536305|lkc_science_lab_1792759535206|lkc_sports_athletics_1792759535888)\.jpg$/i;

    for (const secKey of ['athletics', 'jaguars', 'sports'] as const) {
      const row = db
        .prepare('SELECT data_json FROM cms_sections WHERE section_key = ?')
        .get(secKey) as { data_json: string } | undefined;
      if (!row) continue;
      const parsed = JSON.parse(row.data_json) as { photos?: { url?: string }[] };
      if (Array.isArray(parsed.photos)) {
        const cleanedPhotos = parsed.photos.filter(
          (p) => p && p.url && !aiPlaceholderRe.test(p.url.trim())
        );
        if (cleanedPhotos.length !== parsed.photos.length) {
          parsed.photos = cleanedPhotos;
          db.prepare('UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = ?').run(
            JSON.stringify(parsed),
            now,
            secKey
          );
        }
      }
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV8Id, now);
  }

  // One-shot migration v9: apply uploaded portraits for Mr Daniel Kadembo, Ms L Monyeki, and Ms Katlego Mitchele Modimoofile
  const migrationV9Id = 'migration_2026_11_16_kadembo_monyeki_modimofile_portraits_v9';
  const appliedV9 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV9Id) as { id: string } | undefined;

  if (!appliedV9) {
    const insertOrUpdateMedia = db.prepare(`
      INSERT INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        description = excluded.description,
        url = excluded.url
    `);
    for (const m of defaults.media) {
      if (m.id === 'm-22' || m.id === 'm-23' || m.id === 'm-24') {
        insertOrUpdateMedia.run(
          m.id,
          m.name,
          m.filename ?? null,
          m.url,
          m.category,
          m.mediaType || 'image',
          m.mimeType ?? null,
          m.sizeBytes ?? null,
          m.description ?? null,
          m.uploadedAt
        );
      }
    }

    const isLogoOrBlank = (url?: string | null) =>
      !url || !url.trim() || /logo_33a39ff7\.png/i.test(url);

    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];
      const migratedTeachers = existingTeachers.map((t) => {
        if ((t.id === 't-sci-2' || /\bka?dembo\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Kadembo_34520bae.jpeg' };
        }
        if ((t.id === 't-com-4' || /\bmonyeki\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Monyeki_a7e063be.jpeg' };
        }
        if ((t.id === 't-math-5' || /\bmodimoo?file\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Modimofile_e9d13f63.jpeg' };
        }
        return t;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(migratedTeachers),
        now
      );
    }

    const deptsRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'departments'")
      .get() as { data_json: string } | undefined;
    if (deptsRow) {
      const existingDepts = JSON.parse(deptsRow.data_json) as DepartmentInfo[];
      const migratedDepts = existingDepts.map((d) => {
        if (
          (d.id === 'dept-science' || /\bka?dembo\b/i.test(d.headOfDepartment?.name || '')) &&
          isLogoOrBlank(d.headOfDepartment?.image)
        ) {
          return {
            ...d,
            headOfDepartment: {
              ...d.headOfDepartment,
              image: './assets/aistudio/Kadembo_34520bae.jpeg',
            },
          };
        }
        return d;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'departments'").run(
        JSON.stringify(migratedDepts),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV9Id, now);
  }

  // One-shot migration v10: apply verified portraits for Mrs Chandra and Ms K Kgosikwena
  const migrationV10Id = 'migration_2026_11_16_kgosikwena_chandra_portraits_v10';
  const appliedV10 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV10Id) as { id: string } | undefined;

  if (!appliedV10) {
    const insertOrUpdateMedia = db.prepare(`
      INSERT INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        description = excluded.description,
        url = excluded.url
    `);
    for (const m of defaults.media) {
      if (m.id === 'm-25' || m.id === 'm-26') {
        insertOrUpdateMedia.run(
          m.id,
          m.name,
          m.filename ?? null,
          m.url,
          m.category,
          m.mediaType || 'image',
          m.mimeType ?? null,
          m.sizeBytes ?? null,
          m.description ?? null,
          m.uploadedAt
        );
      }
    }

    const isLogoOrBlank = (url?: string | null) =>
      !url || !url.trim() || /logo_33a39ff7\.png/i.test(url);

    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];
      const migratedTeachers = existingTeachers.map((t) => {
        if ((t.id === 't-sci-1' || /\bchandra\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/ff292469-859b-447f-87d1-71b64a57fa64_728a86cc.webp' };
        }
        if ((t.id === 't-sci-4' || /\bkgosikwena\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/df962819-6680-4651-beb2-217b2d8f1758_3a298a9e.webp' };
        }
        return t;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(migratedTeachers),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV10Id, now);
  }

  // One-shot migration v11: apply uploaded portraits for Jones, Nyateka, Samuel Ndebele, Ncube, Mathodi, Gasha, Barot, Sorofa & updated Mutero
  const migrationV11Id = 'migration_2026_11_16_remaining_staff_portraits_v11';
  const appliedV11 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV11Id) as { id: string } | undefined;

  if (!appliedV11) {
    const insertOrUpdateMedia = db.prepare(`
      INSERT INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        description = excluded.description,
        url = excluded.url
    `);
    const v11MediaIds = new Set(['m-27', 'm-28', 'm-29', 'm-30', 'm-31', 'm-32', 'm-33', 'm-34', 'm-35']);
    for (const m of defaults.media) {
      if (v11MediaIds.has(m.id)) {
        insertOrUpdateMedia.run(
          m.id,
          m.name,
          m.filename ?? null,
          m.url,
          m.category,
          m.mediaType || 'image',
          m.mimeType ?? null,
          m.sizeBytes ?? null,
          m.description ?? null,
          m.uploadedAt
        );
      }
    }

    const isLogoOrBlank = (url?: string | null) =>
      !url || !url.trim() || /logo_33a39ff7\.png/i.test(url);

    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];
      const migratedTeachers = existingTeachers.map((t) => {
        if ((t.id === 't-art-2' || /\bjones\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/jones_e7c56bef.jpeg' };
        }
        if ((t.id === 't-art-3' || /\bmathodi\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Mathodi_7f51ea9a.jpeg' };
        }
        if ((t.id === 't-sci-12' || /\bnyateka\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Nyateka_400b2c05.jpeg' };
        }
        if ((t.id === 't-sci-11' || /\bsamuel\s+ndebele\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Ndebele_S_d3b46a90.jpeg' };
        }
        if ((t.id === 't-sci-10' || /\bncube\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Ncube_a80f777a.jpeg' };
        }
        if ((t.id === 't-com-1' || /\bgasha\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Gasha_7a156b12.jpeg' };
        }
        if ((t.id === 't-math-2' || /\bbar+ot\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Barrot_68d8dbf4.jpeg' };
        }
        if ((t.id === 't-math-9' || /\bsorofa\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/sorofa_dced6e8d.jpeg' };
        }
        if (
          (t.id === 't-com-7' || /\bmutero\b/i.test(t.name)) &&
          (isLogoOrBlank(t.image) || /Mutero_823ea3f0\.jpg/i.test(t.image || ''))
        ) {
          return { ...t, image: './assets/aistudio/Mutero_768af995.jpeg' };
        }
        return t;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(migratedTeachers),
        now
      );
    }

    const deptsRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'departments'")
      .get() as { data_json: string } | undefined;
    if (deptsRow) {
      const existingDepts = JSON.parse(deptsRow.data_json) as DepartmentInfo[];
      const migratedDepts = existingDepts.map((d) => {
        if (
          (d.id === 'dept-creatives' || /\bjones\b/i.test(d.headOfDepartment?.name || '')) &&
          isLogoOrBlank(d.headOfDepartment?.image)
        ) {
          return {
            ...d,
            headOfDepartment: {
              ...d.headOfDepartment,
              image: './assets/aistudio/jones_e7c56bef.jpeg',
            },
          };
        }
        return d;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'departments'").run(
        JSON.stringify(migratedDepts),
        now
      );
    }

    db.prepare(`
      UPDATE staff_members
      SET image = ?, is_incomplete = 0, incomplete_reason = NULL, updated_at = ?
      WHERE id = 'staff-mutero' AND (image IS NULL OR image = '' OR image LIKE '%Mutero_823ea3f0.jpg%')
    `).run('./assets/aistudio/Mutero_768af995.jpeg', now);

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV11Id, now);
  }

  // One-shot migration v12: apply uploaded portrait for Mrs Tsetse (Languages Department HOD & Teacher)
  const migrationV12Id = 'migration_2026_11_16_tsetse_portrait_v12';
  const appliedV12 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV12Id) as { id: string } | undefined;

  if (!appliedV12) {
    const insertOrUpdateMedia = db.prepare(`
      INSERT INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        description = excluded.description,
        url = excluded.url
    `);
    for (const m of defaults.media) {
      if (m.id === 'm-36') {
        insertOrUpdateMedia.run(
          m.id,
          m.name,
          m.filename ?? null,
          m.url,
          m.category,
          m.mediaType || 'image',
          m.mimeType ?? null,
          m.sizeBytes ?? null,
          m.description ?? null,
          m.uploadedAt
        );
      }
    }

    const isLogoOrBlank = (url?: string | null) =>
      !url || !url.trim() || /logo_33a39ff7\.png/i.test(url);

    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];
      const migratedTeachers = existingTeachers.map((t) => {
        if ((t.id === 't-lang-7' || /\btsetse\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/tsetse_de6b2999.jpeg' };
        }
        return t;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(migratedTeachers),
        now
      );
    }

    const deptsRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'departments'")
      .get() as { data_json: string } | undefined;
    if (deptsRow) {
      const existingDepts = JSON.parse(deptsRow.data_json) as DepartmentInfo[];
      const migratedDepts = existingDepts.map((d) => {
        if (
          (d.id === 'dept-languages' || /\btsetse\b/i.test(d.headOfDepartment?.name || '')) &&
          isLogoOrBlank(d.headOfDepartment?.image)
        ) {
          return {
            ...d,
            headOfDepartment: {
              ...d.headOfDepartment,
              image: './assets/aistudio/tsetse_de6b2999.jpeg',
            },
          };
        }
        return d;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'departments'").run(
        JSON.stringify(migratedDepts),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV12Id, now);
  }

  // One-shot migration v13: apply uploaded portraits for Alex, Ngwenya, Shobashoba, Matlotse (Languages), Magadi (Humanities), and Othomile (Maths)
  const migrationV13Id = 'migration_2026_11_16_faculty_portraits_v13';
  const appliedV13 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV13Id) as { id: string } | undefined;

  if (!appliedV13) {
    const newMediaIds = new Set(['m-37', 'm-38', 'm-39', 'm-40', 'm-41', 'm-42']);
    const insertOrUpdateMedia = db.prepare(`
      INSERT INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        description = excluded.description,
        url = excluded.url
    `);
    for (const m of defaults.media) {
      if (newMediaIds.has(m.id)) {
        insertOrUpdateMedia.run(
          m.id,
          m.name,
          m.filename ?? null,
          m.url,
          m.category,
          m.mediaType || 'image',
          m.mimeType ?? null,
          m.sizeBytes ?? null,
          m.description ?? null,
          m.uploadedAt
        );
      }
    }

    const isLogoOrBlank = (url?: string | null) =>
      !url || !url.trim() || /logo_33a39ff7\.png/i.test(url);

    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];
      const migratedTeachers = existingTeachers.map((t) => {
        if ((t.id === 't-lang-1' || /\balex\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Alex_310606c2.jpeg' };
        }
        if (
          (t.id === 't-lang-5' || /\bngwenya\b/i.test(t.name)) &&
          (isLogoOrBlank(t.image) || /Ngwenya_8691aac9\.jpg/i.test(t.image || ''))
        ) {
          return { ...t, image: './assets/aistudio/Ngwenya_890cf4cf.jpeg' };
        }
        if ((t.id === 't-lang-6' || /\bshobashoba\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Shobashoba_9783c429.jpeg' };
        }
        if ((t.id === 't-lang-matlotse' || /\bmatlotse\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Matlotse_059db9aa.webp' };
        }
        if ((t.id === 't-hum-3' || /\bmagadi\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/magadi_cf1feea8.jpg' };
        }
        if ((t.id === 't-math-8' || /\both[io]mile\b/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Othimile_2008c070.jpeg' };
        }
        return t;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(migratedTeachers),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV13Id, now);
  }

  const migrationV14Id = 'migration_2026_11_16_khumo_science_v14';
  const appliedV14 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV14Id) as { id: string } | undefined;

  if (!appliedV14) {
    const khumoAsset = defaults.media.find((m) => m.id === 'm-43');
    if (khumoAsset) {
      db.prepare(`
        INSERT INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          name = excluded.name,
          description = excluded.description,
          url = excluded.url
      `).run(
        khumoAsset.id,
        khumoAsset.name,
        khumoAsset.filename ?? null,
        khumoAsset.url,
        khumoAsset.category,
        khumoAsset.mediaType || 'image',
        khumoAsset.mimeType ?? null,
        khumoAsset.sizeBytes ?? null,
        khumoAsset.description ?? null,
        khumoAsset.uploadedAt
      );
    }

    const isLogoOrBlank = (url?: string | null) =>
      !url || !url.trim() || /logo_33a39ff7\.png/i.test(url);

    const teachersRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'teachers'")
      .get() as { data_json: string } | undefined;
    if (teachersRow) {
      const existingTeachers = JSON.parse(teachersRow.data_json) as TeacherProfile[];
      const migratedTeachers = existingTeachers.map((t) => {
        if ((t.id === 't-sci-8' || /\bkhumo/i.test(t.name)) && isLogoOrBlank(t.image)) {
          return { ...t, image: './assets/aistudio/Khumo_1d7ed1f6.jpeg' };
        }
        return t;
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'teachers'").run(
        JSON.stringify(migratedTeachers),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV14Id, now);
  }

  // One-shot migration v15: sync all 8 academic departments' subjects, key areas, clubs/activities, and facilities while preserving HOD portraits & profiles
  const migrationV15Id = 'migration_2026_11_16_academic_programmes_v15';
  const appliedV15 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV15Id) as { id: string } | undefined;

  if (!appliedV15) {
    const deptsRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'departments'")
      .get() as { data_json: string } | undefined;
    const defaultsById = new Map(defaults.departments.map((d) => [d.id, d]));

    if (deptsRow) {
      const existingDepts = JSON.parse(deptsRow.data_json) as DepartmentInfo[];
      const existingById = new Map(existingDepts.map((d) => [d.id, d]));
      const migratedDepts = FIXED_DEPARTMENT_IDS.map((id) => {
        const def = defaultsById.get(id)!;
        const cur = existingById.get(id);
        return {
          ...def,
          headOfDepartment: {
            ...def.headOfDepartment,
            ...(cur?.headOfDepartment || {}),
            title: def.headOfDepartment.title,
            image: cur?.headOfDepartment?.image || def.headOfDepartment.image,
          },
          news: Array.isArray(cur?.news) ? cur!.news : def.news || [],
        };
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'departments'").run(
        JSON.stringify(migratedDepts),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV15Id, now);
  }

  // One-shot migration v16: re-apply complete activities arrays & PE department title after cmsDefaults.ts fix
  const migrationV16Id = 'migration_2026_11_16_academic_programmes_v16';
  const appliedV16 = db
    .prepare('SELECT id FROM cms_migrations WHERE id = ?')
    .get(migrationV16Id) as { id: string } | undefined;

  if (!appliedV16) {
    const deptsRow = db
      .prepare("SELECT data_json FROM cms_sections WHERE section_key = 'departments'")
      .get() as { data_json: string } | undefined;
    const defaultsById = new Map(defaults.departments.map((d) => [d.id, d]));

    if (deptsRow) {
      const existingDepts = JSON.parse(deptsRow.data_json) as DepartmentInfo[];
      const existingById = new Map(existingDepts.map((d) => [d.id, d]));
      const migratedDepts = FIXED_DEPARTMENT_IDS.map((id) => {
        const def = defaultsById.get(id)!;
        const cur = existingById.get(id);
        return {
          ...def,
          headOfDepartment: {
            ...def.headOfDepartment,
            ...(cur?.headOfDepartment || {}),
            title: def.headOfDepartment.title,
            image: cur?.headOfDepartment?.image || def.headOfDepartment.image,
          },
          news: Array.isArray(cur?.news) ? cur!.news : def.news || [],
        };
      });
      db.prepare("UPDATE cms_sections SET data_json = ?, updated_at = ? WHERE section_key = 'departments'").run(
        JSON.stringify(migratedDepts),
        now
      );
    }

    db.prepare('INSERT INTO cms_migrations (id, applied_at) VALUES (?, ?)').run(migrationV16Id, now);
  }
}

export function getAllSections(): CmsDatabase {
  const db = getDb();
  const defaults = createDefaultCmsDatabase();
  const rows = db.prepare('SELECT section_key, data_json FROM cms_sections').all() as {
    section_key: string;
    data_json: string;
  }[];

  const result: Record<string, unknown> = { ...defaults };
  for (const row of rows) {
    const key = row.section_key as CmsSectionKey;
    if (key in defaults) {
      try {
        const parsed = JSON.parse(row.data_json);
        result[key] = sanitizeSectionValue(key, parsed, defaults);
      } catch {
        result[key] = defaults[key];
      }
    }
  }
  result.media = listMedia();
  return result as unknown as CmsDatabase;
}

export function getSection<K extends CmsSectionKey>(key: K): CmsDatabase[K] {
  if (key === 'media') {
    return listMedia() as CmsDatabase[K];
  }
  const db = getDb();
  const defaults = createDefaultCmsDatabase();
  const row = db
    .prepare('SELECT data_json FROM cms_sections WHERE section_key = ?')
    .get(key) as { data_json: string } | undefined;
  if (!row) return defaults[key];
  try {
    return sanitizeSectionValue(key, JSON.parse(row.data_json), defaults);
  } catch {
    return defaults[key];
  }
}

export function saveSection<K extends CmsSectionKey>(
  key: K,
  value: CmsDatabase[K],
  updatedBy: string
): CmsDatabase[K] {
  const db = getDb();
  const defaults = createDefaultCmsDatabase();
  const sanitized = sanitizeSectionValue(key, value, defaults);
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO cms_sections (section_key, data_json, updated_at, updated_by)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(section_key) DO UPDATE SET
      data_json = excluded.data_json,
      updated_at = excluded.updated_at,
      updated_by = excluded.updated_by
  `).run(key, JSON.stringify(sanitized), now, updatedBy);
  return sanitized;
}

function mapCmsItemRow(row: Record<string, unknown>): CmsItem {
  let parsedContent: Record<string, unknown> = {};
  try {
    parsedContent = JSON.parse(String(row.content_json || '{}'));
  } catch {
    parsedContent = {};
  }
  return {
    id: String(row.id),
    pageKey: String(row.page_key) as PageKey,
    category: String(row.category),
    academicYear: row.academic_year ? String(row.academic_year) : undefined,
    title: String(row.title),
    slug: String(row.slug),
    excerpt: String(row.excerpt),
    content: parsedContent,
    thumbnailUrl: row.thumbnail_url ? String(row.thumbnail_url) : undefined,
    mediaUrl: row.media_url ? String(row.media_url) : undefined,
    status: String(row.status) as PublishStatus,
    featureOnHomepage: Number(row.feature_on_homepage) === 1,
    publishAt: row.publish_at ? String(row.publish_at) : undefined,
    eventDate: row.event_date ? String(row.event_date) : undefined,
    eventTime: row.event_time ? String(row.event_time) : undefined,
    eventLocation: row.event_location ? String(row.event_location) : undefined,
    eventCompleted: Number(row.event_completed) === 1,
    sortOrder: Number(row.sort_order || 0),
    createdBy: row.created_by ? String(row.created_by) : undefined,
    updatedBy: row.updated_by ? String(row.updated_by) : undefined,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export function listCmsItems(filters?: {
  pageKey?: PageKey;
  status?: PublishStatus | 'all';
  featureOnHomepage?: boolean;
  academicYear?: string;
}): CmsItem[] {
  const db = getDb();
  const where: string[] = [];
  const params: (string | number)[] = [];

  if (filters?.pageKey) {
    where.push('page_key = ?');
    params.push(filters.pageKey);
  }
  if (filters?.status && filters.status !== 'all') {
    where.push('status = ?');
    params.push(filters.status);
  }
  if (typeof filters?.featureOnHomepage === 'boolean') {
    where.push('feature_on_homepage = ?');
    params.push(filters.featureOnHomepage ? 1 : 0);
  }
  if (filters?.academicYear) {
    where.push('academic_year = ?');
    params.push(filters.academicYear);
  }

  const sql = `
    SELECT * FROM cms_items
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY sort_order ASC, updated_at DESC
  `;
  const rows = db.prepare(sql).all(...params) as Record<string, unknown>[];
  return rows.map(mapCmsItemRow);
}

export function getCmsItemById(id: string): CmsItem | null {
  const db = getDb();
  const row = db.prepare('SELECT * FROM cms_items WHERE id = ?').get(id) as
    | Record<string, unknown>
    | undefined;
  return row ? mapCmsItemRow(row) : null;
}

export function saveCmsItem(item: CmsItem): CmsItem {
  const db = getDb();
  db.prepare(`
    INSERT INTO cms_items (
      id, page_key, category, academic_year, title, slug, excerpt, content_json,
      thumbnail_url, media_url, status, feature_on_homepage, publish_at,
      event_date, event_time, event_location, event_completed, sort_order,
      created_by, updated_by, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      page_key = excluded.page_key,
      category = excluded.category,
      academic_year = excluded.academic_year,
      title = excluded.title,
      slug = excluded.slug,
      excerpt = excluded.excerpt,
      content_json = excluded.content_json,
      thumbnail_url = excluded.thumbnail_url,
      media_url = excluded.media_url,
      status = excluded.status,
      feature_on_homepage = excluded.feature_on_homepage,
      publish_at = excluded.publish_at,
      event_date = excluded.event_date,
      event_time = excluded.event_time,
      event_location = excluded.event_location,
      event_completed = excluded.event_completed,
      sort_order = excluded.sort_order,
      updated_by = excluded.updated_by,
      updated_at = excluded.updated_at
  `).run(
    item.id,
    item.pageKey,
    item.category,
    item.academicYear ?? null,
    item.title,
    item.slug,
    item.excerpt,
    JSON.stringify(item.content || {}),
    item.thumbnailUrl ?? null,
    item.mediaUrl ?? null,
    item.status,
    item.featureOnHomepage ? 1 : 0,
    item.publishAt ?? null,
    item.eventDate ?? null,
    item.eventTime ?? null,
    item.eventLocation ?? null,
    item.eventCompleted ? 1 : 0,
    item.sortOrder,
    item.createdBy ?? 'admin',
    item.updatedBy ?? 'admin',
    item.createdAt,
    item.updatedAt
  );
  return getCmsItemById(item.id)!;
}

export function deleteCmsItem(id: string): boolean {
  const db = getDb();
  const res = db.prepare('DELETE FROM cms_items WHERE id = ?').run(id);
  return res.changes > 0;
}

export function listMedia(): MediaAsset[] {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM media_assets ORDER BY uploaded_at DESC, rowid DESC')
    .all() as Record<string, unknown>[];
  return rows.map((r) => ({
    id: String(r.id),
    name: String(r.name),
    filename: r.filename ? String(r.filename) : undefined,
    url: String(r.url),
    category: String(r.category),
    mediaType: (r.media_type ? String(r.media_type) : 'image') as MediaAsset['mediaType'],
    mimeType: r.mime_type ? String(r.mime_type) : undefined,
    sizeBytes: r.size_bytes !== null && r.size_bytes !== undefined ? Number(r.size_bytes) : undefined,
    description: r.description ? String(r.description) : undefined,
    uploadedAt: String(r.uploaded_at),
  }));
}

export function findMediaReferences(url: string): string[] {
  if (!url) return [];
  const db = getDb();
  const refs: string[] = [];

  const sectionRows = db.prepare('SELECT section_key, data_json FROM cms_sections').all() as {
    section_key: string;
    data_json: string;
  }[];
  for (const row of sectionRows) {
    if (row.data_json.includes(url)) {
      refs.push(`Section: ${row.section_key}`);
    }
  }

  const itemRows = db
    .prepare('SELECT page_key, title, thumbnail_url, media_url, content_json FROM cms_items')
    .all() as {
    page_key: string;
    title: string;
    thumbnail_url: string | null;
    media_url: string | null;
    content_json: string;
  }[];
  for (const item of itemRows) {
    if (
      item.thumbnail_url === url ||
      item.media_url === url ||
      (item.content_json && item.content_json.includes(url))
    ) {
      refs.push(`Item (${item.page_key}): ${item.title}`);
    }
  }

  const staffRows = db
    .prepare('SELECT full_name, image FROM staff_members WHERE image = ?')
    .all(url) as { full_name: string }[];
  for (const s of staffRows) {
    refs.push(`Staff Profile: ${s.full_name}`);
  }

  return Array.from(new Set(refs));
}

export function listMediaWithReferences(): MediaAsset[] {
  const assets = listMedia();
  const db = getDb();
  const sectionRows = db.prepare('SELECT section_key, data_json FROM cms_sections').all() as {
    section_key: string;
    data_json: string;
  }[];
  const itemRows = db
    .prepare('SELECT page_key, title, thumbnail_url, media_url, content_json FROM cms_items')
    .all() as {
    page_key: string;
    title: string;
    thumbnail_url: string | null;
    media_url: string | null;
    content_json: string;
  }[];
  const staffRows = db
    .prepare('SELECT full_name, image FROM staff_members WHERE image IS NOT NULL')
    .all() as { full_name: string; image: string }[];

  return assets.map((asset) => {
    const usedIn: string[] = [];
    for (const s of sectionRows) {
      if (s.data_json.includes(asset.url)) usedIn.push(`Section: ${s.section_key}`);
    }
    for (const item of itemRows) {
      if (
        item.thumbnail_url === asset.url ||
        item.media_url === asset.url ||
        (item.content_json && item.content_json.includes(asset.url))
      ) {
        usedIn.push(`Item (${item.page_key}): ${item.title}`);
      }
    }
    for (const st of staffRows) {
      if (st.image === asset.url) usedIn.push(`Staff: ${st.full_name}`);
    }
    return { ...asset, usedIn: Array.from(new Set(usedIn)) };
  });
}

export function getMediaById(id: string): MediaAsset | null {
  const db = getDb();
  const r = db.prepare('SELECT * FROM media_assets WHERE id = ?').get(id) as
    | Record<string, unknown>
    | undefined;
  if (!r) return null;
  return {
    id: String(r.id),
    name: String(r.name),
    filename: r.filename ? String(r.filename) : undefined,
    url: String(r.url),
    category: String(r.category),
    mediaType: (r.media_type ? String(r.media_type) : 'image') as MediaAsset['mediaType'],
    mimeType: r.mime_type ? String(r.mime_type) : undefined,
    sizeBytes: r.size_bytes !== null && r.size_bytes !== undefined ? Number(r.size_bytes) : undefined,
    description: r.description ? String(r.description) : undefined,
    uploadedAt: String(r.uploaded_at),
  };
}

export function saveMediaAsset(asset: MediaAsset): MediaAsset {
  const db = getDb();
  db.prepare(`
    INSERT INTO media_assets (id, name, filename, url, category, media_type, mime_type, size_bytes, description, uploaded_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      filename = excluded.filename,
      url = excluded.url,
      category = excluded.category,
      media_type = excluded.media_type,
      mime_type = excluded.mime_type,
      size_bytes = excluded.size_bytes,
      description = excluded.description,
      uploaded_at = excluded.uploaded_at
  `).run(
    asset.id,
    asset.name,
    asset.filename ?? null,
    asset.url,
    asset.category,
    asset.mediaType || 'image',
    asset.mimeType ?? null,
    asset.sizeBytes ?? null,
    asset.description ?? null,
    asset.uploadedAt
  );
  return getMediaById(asset.id)!;
}

export function deleteMediaAsset(id: string): boolean {
  const db = getDb();
  const existing = getMediaById(id);
  const res = db.prepare('DELETE FROM media_assets WHERE id = ?').run(id);
  if (existing && existing.url.startsWith('/uploads/')) {
    const fileOnDisk = path.resolve(UPLOADS_DIR, path.basename(existing.url));
    if (fileOnDisk.startsWith(UPLOADS_DIR) && fs.existsSync(fileOnDisk)) {
      try {
        fs.unlinkSync(fileOnDisk);
      } catch {
        // Ignore cleanup race errors
      }
    }
  }
  return res.changes > 0;
}

// ────────────────────────────────────────────────────────────
// RELATIONAL STAFF PROFILES & ACADEMIC / PASTORAL ASSIGNMENTS
// ────────────────────────────────────────────────────────────

function mapStaffRow(row: Record<string, unknown>): StaffMember {
  let subjects: string[] = [];
  try {
    subjects = JSON.parse(String(row.subjects_json || '[]'));
  } catch {
    subjects = [];
  }
  return {
    id: String(row.id),
    surname: String(row.surname),
    fullName: String(row.full_name),
    displayTitle: row.display_title ? String(row.display_title) : undefined,
    department: row.department ? String(row.department) : undefined,
    subjects: Array.isArray(subjects) ? subjects : [],
    image: row.image ? String(row.image) : null,
    bio: row.bio ? String(row.bio) : undefined,
    qualifications: row.qualifications ? String(row.qualifications) : undefined,
    email: row.email ? String(row.email) : undefined,
    status: (row.status ? String(row.status) : 'published') as PublishStatus,
    isIncomplete: Number(row.is_incomplete) === 1 || !row.image,
    incompleteReason: row.incomplete_reason ? String(row.incomplete_reason) : undefined,
    sortOrder: Number(row.sort_order || 0),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export function listStaffMembers(publishedOnly = false): StaffMember[] {
  const db = getDb();
  const sql = publishedOnly
    ? "SELECT * FROM staff_members WHERE status = 'published' ORDER BY sort_order ASC, surname ASC"
    : 'SELECT * FROM staff_members ORDER BY sort_order ASC, surname ASC';
  const rows = db.prepare(sql).all() as Record<string, unknown>[];
  return rows.map(mapStaffRow);
}

export function getStaffMemberById(id: string): StaffMember | null {
  const db = getDb();
  const row = db.prepare('SELECT * FROM staff_members WHERE id = ?').get(id) as
    | Record<string, unknown>
    | undefined;
  return row ? mapStaffRow(row) : null;
}

export function saveStaffMember(member: StaffMember): StaffMember {
  const db = getDb();
  const hasPhoto = Boolean(member.image && member.image.trim().length > 0);
  const incomplete = typeof member.isIncomplete === 'boolean' ? member.isIncomplete : !hasPhoto;
  db.prepare(`
    INSERT INTO staff_members (
      id, surname, full_name, display_title, department, subjects_json,
      image, bio, qualifications, email, status, is_incomplete, incomplete_reason,
      sort_order, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      surname = excluded.surname,
      full_name = excluded.full_name,
      display_title = excluded.display_title,
      department = excluded.department,
      subjects_json = excluded.subjects_json,
      image = excluded.image,
      bio = excluded.bio,
      qualifications = excluded.qualifications,
      email = excluded.email,
      status = excluded.status,
      is_incomplete = excluded.is_incomplete,
      incomplete_reason = excluded.incomplete_reason,
      sort_order = excluded.sort_order,
      updated_at = excluded.updated_at
  `).run(
    member.id,
    member.surname,
    member.fullName,
    member.displayTitle ?? null,
    member.department ?? null,
    JSON.stringify(member.subjects || []),
    hasPhoto ? member.image!.trim() : null,
    member.bio ?? null,
    member.qualifications ?? null,
    member.email ?? null,
    member.status || 'published',
    incomplete ? 1 : 0,
    hasPhoto && !member.incompleteReason ? null : member.incompleteReason ?? (hasPhoto ? null : 'Portrait photograph pending upload'),
    member.sortOrder ?? 0,
    member.createdAt,
    member.updatedAt
  );
  return getStaffMemberById(member.id)!;
}

export function countAssignmentsForStaff(staffId: string): number {
  const db = getDb();
  return (
    db.prepare('SELECT COUNT(*) as cnt FROM academic_assignments WHERE staff_id = ?').get(staffId) as {
      cnt: number;
    }
  ).cnt;
}

export function deleteStaffMember(id: string): boolean {
  const db = getDb();
  const res = db.prepare('DELETE FROM staff_members WHERE id = ?').run(id);
  return res.changes > 0;
}

function mapAssignmentRow(row: Record<string, unknown>): AcademicAssignment {
  return {
    id: String(row.id),
    staffId: String(row.staff_id),
    assignmentType: String(row.assignment_type) as AcademicAssignmentType,
    roleTitle: String(row.role_title),
    yearGroup: row.year_group ? (String(row.year_group) as YearGroupKey) : null,
    summary: row.summary ? String(row.summary) : undefined,
    responsibilities: row.responsibilities ? String(row.responsibilities) : undefined,
    welcomeMessage: row.welcome_message ? String(row.welcome_message) : undefined,
    status: (row.status ? String(row.status) : 'published') as PublishStatus,
    sortOrder: Number(row.sort_order || 0),
    archivedAt: row.archived_at ? String(row.archived_at) : null,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export function listAcademicAssignments(publishedOnly = false): AcademicAssignment[] {
  const db = getDb();
  const staffMap = new Map(listStaffMembers(false).map((s) => [s.id, s]));
  const sql = publishedOnly
    ? "SELECT * FROM academic_assignments WHERE status = 'published' ORDER BY sort_order ASC, role_title ASC"
    : 'SELECT * FROM academic_assignments ORDER BY sort_order ASC, role_title ASC';
  const rows = db.prepare(sql).all() as Record<string, unknown>[];
  return rows
    .map((r) => {
      const assign = mapAssignmentRow(r);
      const staff = staffMap.get(assign.staffId) || null;
      return { ...assign, staff };
    })
    .filter((a) => !publishedOnly || (a.staff && a.staff.status === 'published'));
}

export function getAcademicAssignmentById(id: string): AcademicAssignment | null {
  const db = getDb();
  const row = db.prepare('SELECT * FROM academic_assignments WHERE id = ?').get(id) as
    | Record<string, unknown>
    | undefined;
  if (!row) return null;
  const assign = mapAssignmentRow(row);
  return { ...assign, staff: getStaffMemberById(assign.staffId) };
}

export function saveAcademicAssignment(assignment: AcademicAssignment): AcademicAssignment {
  const db = getDb();
  const archivedAt =
    assignment.status === 'archived'
      ? assignment.archivedAt || new Date().toISOString()
      : null;

  db.prepare(`
    INSERT INTO academic_assignments (
      id, staff_id, assignment_type, role_title, year_group, summary,
      responsibilities, welcome_message, status, sort_order, archived_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      staff_id = excluded.staff_id,
      assignment_type = excluded.assignment_type,
      role_title = excluded.role_title,
      year_group = excluded.year_group,
      summary = excluded.summary,
      responsibilities = excluded.responsibilities,
      welcome_message = excluded.welcome_message,
      status = excluded.status,
      sort_order = excluded.sort_order,
      archived_at = excluded.archived_at,
      updated_at = excluded.updated_at
  `).run(
    assignment.id,
    assignment.staffId,
    assignment.assignmentType,
    assignment.roleTitle,
    assignment.yearGroup ?? null,
    assignment.summary ?? null,
    assignment.responsibilities ?? null,
    assignment.welcomeMessage ?? null,
    assignment.status || 'published',
    assignment.sortOrder ?? 0,
    archivedAt,
    assignment.createdAt,
    assignment.updatedAt
  );
  return getAcademicAssignmentById(assignment.id)!;
}

export function deleteAcademicAssignment(id: string): boolean {
  const db = getDb();
  const res = db.prepare('DELETE FROM academic_assignments WHERE id = ?').run(id);
  return res.changes > 0;
}

export function getAcademicLeadershipBundle(publishedOnly = false): AcademicLeadershipBundle {
  return {
    staffMembers: listStaffMembers(publishedOnly),
    assignments: listAcademicAssignments(publishedOnly),
  };
}

export function mapUserRow(row: Record<string, unknown>): CmsUser {
  let pages: PageKey[] = [];
  try {
    pages = JSON.parse(String(row.assigned_pages_json || '[]'));
  } catch {
    pages = [];
  }
  return {
    id: String(row.id),
    username: row.username ? String(row.username) : String(row.email).split('@')[0],
    email: String(row.email),
    fullName: String(row.full_name),
    role: String(row.role) as UserRole,
    assignedPages: pages,
    active: Number(row.active) === 1,
    mustChangePassword: Number(row.must_change_password) === 1,
    failedLoginAttempts: Number(row.failed_login_attempts || 0),
    lockedUntil: row.locked_until ? String(row.locked_until) : null,
    createdAt: String(row.created_at),
    lastLoginAt: row.last_login_at ? String(row.last_login_at) : null,
  };
}

export function recordAuditLog(entry: {
  userId: string;
  userEmail: string;
  userRole: string;
  action: string;
  targetType: string;
  targetId: string;
  summary: string;
}): void {
  const db = getDb();
  db.prepare(`
    INSERT INTO audit_logs (user_id, user_email, user_role, action, target_type, target_id, summary, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    entry.userId,
    entry.userEmail,
    entry.userRole,
    entry.action,
    entry.targetType,
    entry.targetId,
    entry.summary,
    new Date().toISOString()
  );
}

export function listAuditLogs(limit = 150): AuditLogEntry[] {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?')
    .all(limit) as Record<string, unknown>[];
  return rows.map((r) => ({
    id: Number(r.id),
    userId: String(r.user_id),
    userEmail: String(r.user_email),
    userRole: String(r.user_role),
    action: String(r.action),
    targetType: String(r.target_type),
    targetId: String(r.target_id),
    summary: String(r.summary),
    createdAt: String(r.created_at),
  }));
}

export interface BackupSnapshot {
  version: number;
  exportedAt: string;
  exportedBy: string;
  sections: Partial<CmsDatabase>;
  items: CmsItem[];
  media: MediaAsset[];
  staffMembers?: StaffMember[];
  academicAssignments?: AcademicAssignment[];
}

export function exportDatabaseSnapshot(exportedBy: string): BackupSnapshot {
  const sections = getAllSections();
  const items = listCmsItems({ status: 'all' });
  const media = listMedia();
  const staffMembers = listStaffMembers(false);
  const academicAssignments = listAcademicAssignments(false);
  return {
    version: 3,
    exportedAt: new Date().toISOString(),
    exportedBy,
    sections,
    items,
    media,
    staffMembers,
    academicAssignments,
  };
}

export function restoreDatabaseSnapshot(snapshot: Partial<BackupSnapshot>, actorEmail: string): void {
  const db = getDb();
  const defaults = createDefaultCmsDatabase();
  const now = new Date().toISOString();

  if (snapshot.sections && typeof snapshot.sections === 'object') {
    for (const key of Object.keys(defaults) as CmsSectionKey[]) {
      if (key === 'media') continue;
      const incoming = snapshot.sections[key];
      if (incoming !== undefined) {
        saveSection(key, incoming as CmsDatabase[typeof key], actorEmail);
      }
    }
  }

  if (Array.isArray(snapshot.items)) {
    db.prepare('DELETE FROM cms_items').run();
    for (const item of snapshot.items) {
      if (item && item.id && item.pageKey && item.title) {
        saveCmsItem({
          ...item,
          updatedBy: actorEmail,
          updatedAt: item.updatedAt || now,
        });
      }
    }
  }

  if (Array.isArray(snapshot.media)) {
    db.prepare('DELETE FROM media_assets').run();
    for (const m of snapshot.media) {
      if (m && m.id && m.url) {
        saveMediaAsset(m);
      }
    }
  }

  if (Array.isArray(snapshot.staffMembers)) {
    db.prepare('DELETE FROM academic_assignments').run();
    db.prepare('DELETE FROM staff_members').run();
    for (const s of snapshot.staffMembers) {
      if (s && s.id && s.fullName) {
        saveStaffMember(s);
      }
    }
  }

  if (Array.isArray(snapshot.academicAssignments)) {
    db.prepare('DELETE FROM academic_assignments').run();
    for (const a of snapshot.academicAssignments) {
      if (a && a.id && a.staffId && a.roleTitle) {
        saveAcademicAssignment(a);
      }
    }
  }
}
