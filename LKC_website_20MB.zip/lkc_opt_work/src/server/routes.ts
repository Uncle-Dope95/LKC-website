import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import express from 'express';
import multer from 'multer';
import {
  attachAuth,
  auditUserAction,
  canUserAccessSection,
  canUserEditPage,
  checkLoginRateLimit,
  clearLoginRateAttempts,
  createUserSession,
  recordLoginRateAttempt,
  requireAuth,
  requirePasswordUpdated,
  requireRole,
  revokeAllUserSessions,
  revokeSession,
  SESSION_COOKIE_NAME,
  type AuthenticatedRequest,
} from './auth.ts';
import {
  countAssignmentsForStaff,
  deleteAcademicAssignment,
  deleteCmsItem,
  deleteMediaAsset,
  deleteStaffMember,
  exportDatabaseSnapshot,
  findMediaReferences,
  getAcademicAssignmentById,
  getAcademicLeadershipBundle,
  getAllSections,
  getCmsItemById,
  getDb,
  getMediaById,
  getSection,
  getStaffMemberById,
  hashPassword,
  listAcademicAssignments,
  listAuditLogs,
  listCmsItems,
  listMediaWithReferences,
  listStaffMembers,
  mapUserRow,
  PASSWORD_RESET_TOKENS_FILE,
  recordAuditLog,
  restoreDatabaseSnapshot,
  saveAcademicAssignment,
  saveCmsItem,
  saveMediaAsset,
  saveSection,
  saveStaffMember,
  UPLOADS_DIR,
  verifyPassword,
} from './db.ts';
import { createZipBuffer } from './zipUtil.ts';
import {
  createDefaultCmsDatabase,
  FIXED_DEPARTMENT_IDS,
  type CmsSectionKey,
} from '../data/cmsDefaults.ts';
import type {
  AcademicAssignment,
  AcademicAssignmentType,
  AlumniProfile,
  CmsItem,
  MediaAsset,
  PageKey,
  PublishStatus,
  StaffMember,
  UserRole,
  YearGroupKey,
} from '../types/index.ts';
import { sortTeachersForDirectory } from '../utils/staffHierarchy.ts';

const ALLOWED_PAGE_KEYS = new Set<PageKey>([
  'home',
  'campus',
  'boarding',
  'excursions',
  'alumni',
  'achievers',
  'sports',
  'athletics',
  'jaguars',
  'departments',
  'curriculum',
  'fees',
  'contact',
  'news',
  'events',
]);

const ALLOWED_STATUSES = new Set<PublishStatus>([
  'draft',
  'pending',
  'published',
  'unpublished',
  'archived',
]);

const ALLOWED_YEAR_GROUPS = new Set<YearGroupKey>([
  'Form 1',
  'Form 2',
  'Form 3',
  'Form 4',
  'Form 5',
  'A Level',
]);

const ALLOWED_ASSIGNMENT_TYPES = new Set<AcademicAssignmentType>([
  'head_of_year',
  'a_level_coordinator',
  'pastoral_care',
]);

const ALLOWED_UPLOAD_EXTS = new Set([
  '.jpg',
  '.jpeg',
  '.png',
  '.webp',
  '.gif',
  '.mp4',
  '.webm',
  '.mov',
  '.pdf',
  '.doc',
  '.docx',
]);

function inferMediaType(ext: string): MediaAsset['mediaType'] {
  const lower = ext.toLowerCase();
  if (['.jpg', '.jpeg', '.png', '.webp', '.gif'].includes(lower)) return 'image';
  if (['.mp4', '.webm', '.mov'].includes(lower)) return 'video';
  if (lower === '.pdf') return 'pdf';
  return 'document';
}

const uploadStorage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const safeBase = path
      .basename(file.originalname || 'file', ext)
      .replace(/[^a-zA-Z0-9-_]+/g, '_')
      .slice(0, 50);
    const unique = `${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    cb(null, `${safeBase}_${unique}${ext}`);
  },
});

const uploadMiddleware = multer({
  storage: uploadStorage,
  limits: { fileSize: 50 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    if (!ALLOWED_UPLOAD_EXTS.has(ext)) {
      cb(
        new Error(
          `Unsupported file type '${ext}'. Allowed: jpg, jpeg, png, webp, gif, mp4, webm, mov, pdf, doc, docx.`
        )
      );
      return;
    }
    cb(null, true);
  },
});

function setSessionCookie(
  req: express.Request,
  res: express.Response,
  rawToken: string,
  expiresAt: string
): void {
  const forwardedProto = String(req.headers['x-forwarded-proto'] || '').toLowerCase();
  const autoHttps = Boolean(req.secure || forwardedProto.includes('https'));
  const cookieSecureEnv = String(process.env.COOKIE_SECURE || '').trim().toLowerCase();
  const isSecureCookie =
    cookieSecureEnv === 'true'
      ? true
      : cookieSecureEnv === 'false'
      ? false
      : autoHttps;

  res.cookie(SESSION_COOKIE_NAME, rawToken, {
    httpOnly: true,
    sameSite: isSecureCookie ? 'none' : 'lax',
    path: '/',
    expires: new Date(expiresAt),
    secure: isSecureCookie,
  });
}

function slugify(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

function collectFilesRecursively(dir: string, baseDir: string): { name: string; data: Buffer }[] {
  const results: { name: string; data: Buffer }[] = [];
  if (!fs.existsSync(dir)) return results;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...collectFilesRecursively(fullPath, baseDir));
    } else if (entry.isFile()) {
      const rel = path.relative(baseDir, fullPath).replace(/\\/g, '/');
      results.push({ name: rel, data: fs.readFileSync(fullPath) });
    }
  }
  return results;
}

export function createApiRouter(): express.Router {
  const router = express.Router();
  router.use(attachAuth);

  // Health Check
  router.get('/health', (_req, res) => {
    getDb();
    res.json({ ok: true, database: 'connected', timestamp: new Date().toISOString() });
  });

  // ────────────────────────────────────────────────────────────
  // AUTHENTICATION ENDPOINTS
  // ────────────────────────────────────────────────────────────

  router.get('/auth/setup-status', (_req, res) => {
    const db = getDb();
    const cnt = (
      db.prepare("SELECT COUNT(*) as cnt FROM users WHERE role = 'super_admin' AND active = 1").get() as {
        cnt: number;
      }
    ).cnt;
    res.json({ needsInitialSetup: cnt === 0 });
  });

  router.post('/auth/setup-initial-admin', (req, res) => {
    const db = getDb();
    const cnt = (
      db.prepare("SELECT COUNT(*) as cnt FROM users WHERE role = 'super_admin' AND active = 1").get() as {
        cnt: number;
      }
    ).cnt;
    if (cnt > 0) {
      res.status(409).json({
        error: 'Initial Super Administrator has already been configured. Please sign in.',
      });
      return;
    }

    const email = String(req.body?.email || '').trim().toLowerCase();
    const username = String(req.body?.username || email.split('@')[0] || '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9._-]/g, '');
    const fullName = String(req.body?.fullName || '').trim();
    const password = String(req.body?.password || '');

    if (!email || !email.includes('@')) {
      res.status(400).json({ error: 'A valid administrator email address is required.' });
      return;
    }
    if (!fullName || fullName.length < 2) {
      res.status(400).json({ error: 'Full name is required.' });
      return;
    }
    if (!password || password.length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters long.' });
      return;
    }

    const conflict = db
      .prepare('SELECT id FROM users WHERE LOWER(email) = ? OR (username IS NOT NULL AND LOWER(username) = ?)')
      .get(email, username);
    if (conflict) {
      res.status(409).json({ error: 'An administrator record with that email or username already exists.' });
      return;
    }

    const now = new Date().toISOString();
    const userId = `usr-${crypto.randomUUID()}`;
    db.prepare(`
      INSERT INTO users (
        id, username, email, full_name, password_hash, role, assigned_pages_json,
        active, must_change_password, failed_login_attempts, created_at
      ) VALUES (?, ?, ?, ?, ?, 'super_admin', '[]', 1, 0, 0, ?)
    `).run(userId, username || null, email, fullName, hashPassword(password), now);

    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as Record<string, unknown>;
    const user = mapUserRow(row);
    const { rawToken, expiresAt } = createUserSession(user.id);
    setSessionCookie(req, res, rawToken, expiresAt);

    recordAuditLog({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'SETUP_SUPER_ADMIN',
      targetType: 'user',
      targetId: user.id,
      summary: `Configured Super Administrator account '${user.email}'`,
    });

    res.status(201).json({ user, token: rawToken });
  });

  router.post('/auth/login', (req, res) => {
    const identifier = String(req.body?.identifier || req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    const rateKey = `login:${clientIp}:${identifier}`;

    if (!identifier || !password) {
      res.status(400).json({ error: 'Username or email and password are required.' });
      return;
    }

    const rate = checkLoginRateLimit(rateKey);
    if (!rate.allowed) {
      res.status(429).json({
        error: `Too many login attempts. Please wait ${rate.retryAfterSec} seconds and try again.`,
      });
      return;
    }

    const db = getDb();
    const row = db
      .prepare('SELECT * FROM users WHERE LOWER(username) = ? OR LOWER(email) = ?')
      .get(identifier, identifier) as Record<string, unknown> | undefined;

    if (!row) {
      recordLoginRateAttempt(rateKey);
      recordAuditLog({
        userId: 'anonymous',
        userEmail: identifier,
        userRole: 'unknown',
        action: 'LOGIN_FAILED',
        targetType: 'auth',
        targetId: identifier,
        summary: `Failed login attempt for unknown identifier '${identifier}'`,
      });
      res.status(401).json({ error: 'Invalid username/email or password.' });
      return;
    }

    if (row.locked_until) {
      const lockUntilMs = new Date(String(row.locked_until)).getTime();
      if (!Number.isNaN(lockUntilMs) && lockUntilMs > Date.now()) {
        const minsLeft = Math.max(1, Math.ceil((lockUntilMs - Date.now()) / 60000));
        res.status(423).json({
          error: `Account temporarily locked due to repeated failed attempts. Try again in ~${minsLeft} minute(s) or contact a Super Administrator.`,
        });
        return;
      }
      // Lock expired cleanly
      db.prepare('UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?').run(
        String(row.id)
      );
      row.failed_login_attempts = 0;
      row.locked_until = null;
    }

    if (Number(row.active) !== 1) {
      res.status(403).json({ error: 'This administrator account has been deactivated.' });
      return;
    }

    if (!verifyPassword(password, String(row.password_hash))) {
      recordLoginRateAttempt(rateKey);
      const nextFailures = Number(row.failed_login_attempts || 0) + 1;
      if (nextFailures >= 5) {
        const lockUntil = new Date(Date.now() + 15 * 60 * 1000).toISOString();
        db.prepare('UPDATE users SET failed_login_attempts = ?, locked_until = ? WHERE id = ?').run(
          nextFailures,
          lockUntil,
          String(row.id)
        );
        recordAuditLog({
          userId: String(row.id),
          userEmail: String(row.email),
          userRole: String(row.role),
          action: 'ACCOUNT_LOCKED',
          targetType: 'user',
          targetId: String(row.id),
          summary: `Account '${String(row.username || row.email)}' locked for 15 minutes after 5 failed login attempts`,
        });
        res.status(423).json({
          error: 'Account locked for 15 minutes after 5 consecutive failed login attempts.',
        });
        return;
      }

      db.prepare('UPDATE users SET failed_login_attempts = ? WHERE id = ?').run(
        nextFailures,
        String(row.id)
      );
      recordAuditLog({
        userId: String(row.id),
        userEmail: String(row.email),
        userRole: String(row.role),
        action: 'LOGIN_FAILED',
        targetType: 'auth',
        targetId: String(row.id),
        summary: `Failed login attempt #${nextFailures} for '${String(row.username || row.email)}'`,
      });
      res.status(401).json({ error: 'Invalid username/email or password.' });
      return;
    }

    // Success
    clearLoginRateAttempts(rateKey);
    db.prepare('UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?').run(
      String(row.id)
    );
    const updatedRow = db.prepare('SELECT * FROM users WHERE id = ?').get(String(row.id)) as Record<
      string,
      unknown
    >;
    const user = mapUserRow(updatedRow);
    const { rawToken, expiresAt } = createUserSession(user.id);
    setSessionCookie(req, res, rawToken, expiresAt);

    recordAuditLog({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'LOGIN_SUCCESS',
      targetType: 'auth',
      targetId: user.id,
      summary: `Signed in '${user.username || user.email}' (mustChangePassword=${Boolean(
        user.mustChangePassword
      )})`,
    });

    res.json({ user, token: rawToken });
  });

  router.post('/auth/change-password', requireAuth, (req: AuthenticatedRequest, res) => {
    const currentPassword = String(req.body?.currentPassword || '');
    const newPassword = String(req.body?.newPassword || '');
    if (!currentPassword || !newPassword) {
      res.status(400).json({ error: 'Current password and new password are required.' });
      return;
    }
    if (newPassword.length < 10) {
      res.status(400).json({ error: 'New password must be at least 10 characters long.' });
      return;
    }
    if (newPassword === currentPassword) {
      res.status(400).json({ error: 'New password must differ from your temporary/current password.' });
      return;
    }

    const db = getDb();
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.cmsUser!.id) as
      | Record<string, unknown>
      | undefined;
    if (!row || !verifyPassword(currentPassword, String(row.password_hash))) {
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }

    db.prepare(`
      UPDATE users
      SET password_hash = ?, must_change_password = 0, failed_login_attempts = 0, locked_until = NULL
      WHERE id = ?
    `).run(hashPassword(newPassword), req.cmsUser!.id);

    const updated = mapUserRow(
      db.prepare('SELECT * FROM users WHERE id = ?').get(req.cmsUser!.id) as Record<string, unknown>
    );
    auditUserAction(
      req,
      'CHANGE_PASSWORD',
      'user',
      updated.id,
      `Administrator '${updated.username || updated.email}' completed password update`
    );
    res.json({ ok: true, user: updated });
  });

  router.post('/auth/request-reset', (req, res) => {
    const identifier = String(req.body?.identifier || req.body?.email || '').trim().toLowerCase();
    if (!identifier) {
      res.status(400).json({ error: 'Username or email is required.' });
      return;
    }
    const db = getDb();
    const row = db
      .prepare('SELECT id, username, email, active FROM users WHERE LOWER(username) = ? OR LOWER(email) = ?')
      .get(identifier, identifier) as
      | { id: string; username: string | null; email: string; active: number }
      | undefined;

    if (row && Number(row.active) === 1) {
      const rawResetToken = crypto.randomBytes(24).toString('hex');
      const tokenHash = crypto.createHash('sha256').update(rawResetToken).digest('hex');
      const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();

      db.prepare(
        'UPDATE users SET password_reset_token_hash = ?, password_reset_expires = ? WHERE id = ?'
      ).run(tokenHash, expiresAt, row.id);

      // Write reset dispatch payload out-of-band to protected server file (0600); never return token in HTTP response
      let existingDispatches: Record<string, unknown>[] = [];
      if (fs.existsSync(PASSWORD_RESET_TOKENS_FILE)) {
        try {
          const parsed = JSON.parse(fs.readFileSync(PASSWORD_RESET_TOKENS_FILE, 'utf8'));
          if (Array.isArray(parsed)) existingDispatches = parsed.slice(-19);
        } catch {
          existingDispatches = [];
        }
      }
      existingDispatches.push({
        userId: row.id,
        username: row.username,
        email: row.email,
        resetToken: rawResetToken,
        expiresAt,
        issuedAt: new Date().toISOString(),
      });
      fs.writeFileSync(
        PASSWORD_RESET_TOKENS_FILE,
        JSON.stringify(existingDispatches, null, 2),
        { mode: 0o600 }
      );
      try {
        fs.chmodSync(PASSWORD_RESET_TOKENS_FILE, 0o600);
      } catch {
        // Ignore on non-POSIX
      }

      recordAuditLog({
        userId: row.id,
        userEmail: row.email,
        userRole: 'admin',
        action: 'REQUEST_PASSWORD_RESET',
        targetType: 'user',
        targetId: row.id,
        summary: `Password recovery token issued to secure server dispatch file for '${row.username || row.email}'`,
      });
    }

    res.json({
      ok: true,
      message:
        'If an active account matches that identifier, a one-time recovery token has been issued to secure institutional administration channels.',
    });
  });

  router.post('/auth/reset-password', (req, res) => {
    const identifier = String(req.body?.identifier || req.body?.email || '').trim().toLowerCase();
    const token = String(req.body?.token || '').trim();
    const newPassword = String(req.body?.newPassword || '');
    if (!identifier || !token || newPassword.length < 10) {
      res.status(400).json({
        error: 'Identifier, recovery token, and a new password (10+ characters) are required.',
      });
      return;
    }

    const db = getDb();
    const row = db
      .prepare('SELECT * FROM users WHERE LOWER(username) = ? OR LOWER(email) = ?')
      .get(identifier, identifier) as Record<string, unknown> | undefined;

    if (!row || !row.password_reset_token_hash || !row.password_reset_expires) {
      res.status(400).json({ error: 'Invalid or expired recovery token.' });
      return;
    }

    const expMs = new Date(String(row.password_reset_expires)).getTime();
    if (Number.isNaN(expMs) || expMs < Date.now()) {
      res.status(400).json({ error: 'Recovery token has expired. Please request a new reset.' });
      return;
    }

    const incomingHash = crypto.createHash('sha256').update(token).digest('hex');
    if (
      incomingHash.length !== String(row.password_reset_token_hash).length ||
      !crypto.timingSafeEqual(
        Buffer.from(incomingHash, 'hex'),
        Buffer.from(String(row.password_reset_token_hash), 'hex')
      )
    ) {
      res.status(400).json({ error: 'Invalid recovery token.' });
      return;
    }

    db.prepare(`
      UPDATE users
      SET password_hash = ?, must_change_password = 0, failed_login_attempts = 0,
          locked_until = NULL, password_reset_token_hash = NULL, password_reset_expires = NULL
      WHERE id = ?
    `).run(hashPassword(newPassword), String(row.id));

    revokeAllUserSessions(String(row.id));
    recordAuditLog({
      userId: String(row.id),
      userEmail: String(row.email),
      userRole: String(row.role),
      action: 'RESET_PASSWORD_WITH_TOKEN',
      targetType: 'user',
      targetId: String(row.id),
      summary: `Password recovered via one-time token for '${String(row.username || row.email)}'`,
    });

    res.json({ ok: true, message: 'Password updated. Please sign in with your new password.' });
  });

  router.post('/auth/logout', (req: AuthenticatedRequest, res) => {
    if (req.cmsUser) {
      auditUserAction(req, 'LOGOUT', 'auth', req.cmsUser.id, `Signed out '${req.cmsUser.email}'`);
    }
    revokeSession(req.sessionTokenHash);
    res.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
    res.json({ ok: true });
  });

  router.get('/auth/me', (req: AuthenticatedRequest, res) => {
    res.json({ user: req.cmsUser || null });
  });

  // ────────────────────────────────────────────────────────────
  // PUBLIC READ & SUBMISSION ENDPOINTS
  // ────────────────────────────────────────────────────────────

  router.get('/public/bootstrap', (_req, res) => {
    const sections = getAllSections();
    // Filter unpublished leadership & directors profiles on public site
    if (sections.about) {
      sections.about = {
        ...sections.about,
        leadership: Array.isArray(sections.about.leadership)
          ? sections.about.leadership
              .filter((l) => l.status !== 'unpublished' && l.status !== 'archived')
              .sort((a, b) => (a.order ?? 99) - (b.order ?? 99))
          : [],
        directors: Array.isArray(sections.about.directors)
          ? sections.about.directors
              .filter((d) => d.status !== 'unpublished' && d.status !== 'archived')
              .sort((a, b) => (a.order ?? 99) - (b.order ?? 99))
          : [],
      };
    }

    // Strictly filter alumni on public bootstrap to approved profiles only (no private email/phone)
    const publicAlumni = (sections.alumni || [])
      .filter((a) => a.status === 'approved')
      .map(({ email: _e, phone: _p, ...publicSafe }) => publicSafe);

    // Omit qualifications from public teacher profiles, hide unpublished/archived teachers, and enforce HOD-first hierarchy
    const publicTeachers = sortTeachersForDirectory(
      (sections.teachers || [])
        .filter((t) => t.status !== 'unpublished' && t.status !== 'archived')
        .map(({ qualifications: _q, ...publicSafe }) => publicSafe),
      sections.departments || []
    );

    const filterPublicPhotos = <T extends { url?: string; status?: string }>(photos?: T[]) =>
      (photos || []).filter(
        (p) =>
          Boolean(p.url && p.url.trim()) &&
          p.status !== 'unpublished' &&
          p.status !== 'archived'
      );

    const publicAthletics = sections.athletics
      ? {
          ...sections.athletics,
          photos: filterPublicPhotos(sections.athletics.photos),
        }
      : sections.athletics;

    const publicSports = sections.sports
      ? {
          ...sections.sports,
          photos: filterPublicPhotos(sections.sports.photos),
        }
      : sections.sports;

    const publicJaguars = sections.jaguars
      ? {
          ...sections.jaguars,
          photos: filterPublicPhotos(sections.jaguars.photos),
        }
      : sections.jaguars;

    const featuredItems = listCmsItems({
      status: 'published',
      featureOnHomepage: true,
    });
    const publishedItems = listCmsItems({ status: 'published' });
    const academicLeadership = getAcademicLeadershipBundle(true);

    res.json({
      sections: {
        ...sections,
        athletics: publicAthletics,
        sports: publicSports,
        jaguars: publicJaguars,
        teachers: publicTeachers,
        alumni: publicAlumni,
      },
      featuredItems,
      publishedItems,
      academicLeadership,
    });
  });

  router.get('/public/academic-leadership', (_req, res) => {
    res.json(getAcademicLeadershipBundle(true));
  });

  router.get('/public/homepage', (_req, res) => {
    const general = getSection('general');
    const hero = getSection('hero');
    const about = getSection('about');
    const navigation = getSection('navigation');
    const footer = getSection('footer');
    const settings = getSection('settings');
    const maxFeatured = Math.max(1, Number(settings.homepageMaxFeaturedItems || 6));

    const featuredItems = listCmsItems({
      status: 'published',
      featureOnHomepage: true,
    }).slice(0, maxFeatured);

    const leadership = (about.leadership || [])
      .filter((l) => l.status !== 'unpublished' && l.status !== 'archived')
      .sort((a, b) => (a.order ?? 99) - (b.order ?? 99))
      .map(({ bio: _b, message: _m, ...concise }) => concise);

    const directors = (about.directors || [])
      .filter((d) => d.status !== 'unpublished' && d.status !== 'archived')
      .sort((a, b) => (a.order ?? 99) - (b.order ?? 99));

    const featuredNews = featuredItems.filter((i) => i.pageKey === 'news');
    const featuredEvents = featuredItems.filter((i) => i.pageKey === 'events');
    const featuredHighlights = featuredItems.filter(
      (i) => i.pageKey !== 'news' && i.pageKey !== 'events'
    );

    res.json({
      general,
      hero,
      leadership,
      directors,
      navigation,
      footer,
      settings,
      featuredItems,
      featuredNews,
      featuredEvents,
      featuredHighlights,
    });
  });

  router.get('/public/page/:pageKey', (req, res) => {
    const pageKey = req.params.pageKey as PageKey;
    if (!ALLOWED_PAGE_KEYS.has(pageKey)) {
      res.status(404).json({ error: `Unknown page key '${pageKey}'.` });
      return;
    }

    const items = listCmsItems({ pageKey, status: 'published' });
    const yearFilter = typeof req.query.year === 'string' ? req.query.year : undefined;

    let sectionData: unknown = null;
    if (pageKey === 'campus') {
      const about = getSection('about');
      sectionData = {
        about: {
          ...about,
          leadership: (about.leadership || [])
            .filter((l) => l.status !== 'unpublished' && l.status !== 'archived')
            .sort((a, b) => (a.order ?? 99) - (b.order ?? 99)),
          directors: (about.directors || [])
            .filter((d) => d.status !== 'unpublished' && d.status !== 'archived')
            .sort((a, b) => (a.order ?? 99) - (b.order ?? 99)),
        },
        building: getSection('building'),
      };
    } else if (pageKey === 'boarding') {
      sectionData = getSection('boarding');
    } else if (pageKey === 'excursions') {
      sectionData = getSection('excursions');
    } else if (pageKey === 'alumni') {
      sectionData = (getSection('alumni') || [])
        .filter((a) => a.status === 'approved')
        .map(({ email: _e, phone: _p, ...safe }) => safe);
    } else if (pageKey === 'achievers') {
      const achievers = getSection('achievers');
      if (yearFilter) {
        sectionData = {
          ...achievers,
          activeYear: yearFilter,
          summary: achievers.yearlySummaries?.[yearFilter] || achievers.summary,
          awards: achievers.awards.filter((a) => a.year === yearFilter),
          honorRoll: achievers.honorRoll.filter((h) => (h.year || '2025') === yearFilter),
        };
      } else {
        sectionData = achievers;
      }
    } else if (pageKey === 'sports') {
      const sp = getSection('sports');
      sectionData = {
        sports: {
          ...sp,
          photos: (sp.photos || []).filter(
            (p) =>
              Boolean(p.url && p.url.trim()) &&
              p.status !== 'unpublished' &&
              p.status !== 'archived'
          ),
        },
        houses: getSection('houses'),
      };
    } else if (pageKey === 'athletics') {
      const ath = getSection('athletics');
      sectionData = {
        ...ath,
        photos: (ath.photos || []).filter(
          (p) =>
            Boolean(p.url && p.url.trim()) &&
            p.status !== 'unpublished' &&
            p.status !== 'archived'
        ),
      };
    } else if (pageKey === 'jaguars') {
      const jag = getSection('jaguars');
      sectionData = {
        ...jag,
        photos: (jag.photos || []).filter(
          (p) =>
            Boolean(p.url && p.url.trim()) &&
            p.status !== 'unpublished' &&
            p.status !== 'archived'
        ),
      };
    } else if (pageKey === 'departments') {
      const departments = getSection('departments');
      const publicTeachers = sortTeachersForDirectory(
        (getSection('teachers') || [])
          .filter((t) => t.status !== 'unpublished' && t.status !== 'archived')
          .map(({ qualifications: _q, ...publicSafe }) => publicSafe),
        departments
      );
      sectionData = {
        departments,
        teachers: publicTeachers,
        academicLeadership: getAcademicLeadershipBundle(true),
      };
    } else if (pageKey === 'curriculum') {
      sectionData = getSection('curriculum');
    } else if (pageKey === 'fees') {
      sectionData = getSection('fees');
    } else if (pageKey === 'contact') {
      sectionData = {
        general: getSection('general'),
        faqs: getSection('faqs'),
      };
    } else if (pageKey === 'news') {
      sectionData = getSection('announcements').filter(
        (a) => a.active && (!a.status || a.status === 'published')
      );
    } else if (pageKey === 'events') {
      sectionData = {
        calendar: getSection('calendar'),
      };
    }

    res.json({
      pageKey,
      sectionData,
      items,
    });
  });

  router.post('/public/alumni/register', (req, res) => {
    const settings = getSection('settings');
    if (!settings.allowPublicAlumniRegistration) {
      res.status(403).json({ error: 'Public alumni registration is currently closed.' });
      return;
    }
    const body = req.body || {};
    const name = String(body.name || '').trim();
    const gradYear = String(body.gradYear || '').trim();
    if (!name || !gradYear) {
      res.status(400).json({ error: 'Full name and graduation year are required.' });
      return;
    }

    const current = getSection('alumni');
    const newRecord: AlumniProfile = {
      id: `alum-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
      name,
      gradYear,
      currentRole: String(body.currentRole || '').trim(),
      organization: String(body.organization || '').trim(),
      university: String(body.university || '').trim(),
      location: String(body.location || '').trim(),
      course: String(body.course || '').trim(),
      quote: String(body.quote || '').trim(),
      cambridgeHonors: String(body.cambridgeHonors || '').trim(),
      email: body.email ? String(body.email).trim() : undefined,
      phone: body.phone ? String(body.phone).trim() : undefined,
      willingToMentor: Boolean(body.willingToMentor),
      status: 'pending',
      submittedAt: new Date().toISOString().split('T')[0],
    };
    saveSection('alumni', [newRecord, ...current], 'public-alumni-form');
    res.status(201).json({
      ok: true,
      message: 'Your alumni profile has been submitted and is awaiting administrator approval.',
      id: newRecord.id,
    });
  });

  router.post('/public/enquiries', (req, res) => {
    const body = req.body || {};
    const type = String(body.type || 'general');
    const id = `enq-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();
    const db = getDb();
    db.prepare(`
      INSERT INTO enquiries (id, type, payload_json, status, created_at)
      VALUES (?, ?, ?, 'new', ?)
    `).run(id, type, JSON.stringify(body), now);
    res.status(201).json({ ok: true, id, createdAt: now });
  });

  router.post('/public/tours', (req, res) => {
    const body = req.body || {};
    const id = `tour-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();
    const db = getDb();
    db.prepare(`
      INSERT INTO tour_bookings (id, payload_json, status, created_at)
      VALUES (?, ?, 'requested', ?)
    `).run(id, JSON.stringify(body), now);
    res.status(201).json({ ok: true, id, createdAt: now });
  });

  // ────────────────────────────────────────────────────────────
  // PROTECTED ADMIN CMS ENDPOINTS (AUTH + PASSWORD UPDATE REQUIRED)
  // ────────────────────────────────────────────────────────────

  router.use('/admin', requireAuth, requirePasswordUpdated);

  router.get('/admin/overview', (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const allItems = listCmsItems({ status: 'all' });
    const sections = getAllSections();
    const media = listMediaWithReferences();
    const staff = listStaffMembers(false);
    const assignments = listAcademicAssignments(false);

    const enquiriesCount = (
      db.prepare('SELECT COUNT(*) as cnt FROM enquiries').get() as { cnt: number }
    ).cnt;
    const toursCount = (
      db.prepare('SELECT COUNT(*) as cnt FROM tour_bookings').get() as { cnt: number }
    ).cnt;
    const usersCount = (
      db.prepare('SELECT COUNT(*) as cnt FROM users WHERE active = 1').get() as { cnt: number }
    ).cnt;

    const statusCounts: Record<PublishStatus, number> = {
      draft: 0,
      pending: 0,
      published: 0,
      unpublished: 0,
      archived: 0,
    };
    let featuredCount = 0;
    let upcomingEventsCount = 0;
    for (const item of allItems) {
      statusCounts[item.status] = (statusCounts[item.status] || 0) + 1;
      if (item.featureOnHomepage && item.status === 'published') featuredCount += 1;
      if (item.pageKey === 'events' && item.status === 'published' && !item.eventCompleted) {
        upcomingEventsCount += 1;
      }
    }

    const headsOfYearCount = assignments.filter(
      (a) => a.assignmentType === 'head_of_year' && a.status !== 'archived'
    ).length;
    const coordinatorsCount = assignments.filter(
      (a) => a.assignmentType === 'a_level_coordinator' && a.status !== 'archived'
    ).length;
    const pastoralCount = assignments.filter(
      (a) => a.assignmentType === 'pastoral_care' && a.status !== 'archived'
    ).length;
    const incompleteStaffCount = staff.filter((s) => s.isIncomplete).length;

    const alumniPending = sections.alumni.filter((a) => a.status === 'pending').length;
    const alumniApproved = sections.alumni.filter((a) => a.status === 'approved').length;
    const announcementsCount = (sections.announcements || []).filter((a) => a.active).length;

    res.json({
      user: req.cmsUser,
      counts: {
        totalItems: allItems.length,
        publishedItems: statusCounts.published,
        draftItems: statusCounts.draft,
        pendingItems: statusCounts.pending,
        unpublishedItems: statusCounts.unpublished,
        archivedItems: statusCounts.archived,
        featuredOnHomepage: featuredCount,
        upcomingEventsCount,
        announcementsCount,
        departments: sections.departments.length,
        teachers: sections.teachers.length,
        staffCount: staff.length,
        incompleteStaffCount,
        headsOfYearCount,
        coordinatorsCount,
        pastoralCount,
        usersCount,
        alumniPending,
        alumniApproved,
        mediaCount: media.length,
        enquiriesCount,
        toursCount,
      },
      recentAuditLogs:
        req.cmsUser?.role === 'super_admin' || req.cmsUser?.role === 'admin'
          ? listAuditLogs(20)
          : [],
    });
  });

  router.get('/admin/bootstrap', (req: AuthenticatedRequest, res) => {
    const sections = getAllSections();
    sections.media = listMediaWithReferences();
    const allItems = listCmsItems({ status: 'all' });
    const visibleItems =
      req.cmsUser?.role === 'content_editor'
        ? allItems.filter((item) => canUserEditPage(req.cmsUser!, item.pageKey))
        : allItems;
    res.json({
      sections,
      items: visibleItems,
      academicLeadership: getAcademicLeadershipBundle(false),
      user: req.cmsUser,
    });
  });

  router.put('/admin/sections/:sectionKey', (req: AuthenticatedRequest, res) => {
    const sectionKey = req.params.sectionKey as CmsSectionKey;
    const defaults = createDefaultCmsDatabase();
    if (!(sectionKey in defaults)) {
      res.status(404).json({ error: `Unknown CMS section '${sectionKey}'.` });
      return;
    }

    if (!canUserAccessSection(req.cmsUser!, sectionKey)) {
      res.status(403).json({
        error: `Access denied. Your role '${req.cmsUser!.role}' cannot edit section '${sectionKey}'.`,
      });
      return;
    }

    if (sectionKey === 'departments') {
      const incoming = req.body;
      if (!Array.isArray(incoming) || incoming.length !== FIXED_DEPARTMENT_IDS.length) {
        res.status(400).json({
          error:
            'LKC strictly maintains exactly 8 academic departments. Adding or removing department buckets is prohibited.',
        });
        return;
      }
      const incomingIds = new Set(incoming.map((d: { id?: string }) => d?.id));
      for (const fixedId of FIXED_DEPARTMENT_IDS) {
        if (!incomingIds.has(fixedId)) {
          res.status(400).json({
            error: `Required fixed department ID '${fixedId}' cannot be removed or renamed.`,
          });
          return;
        }
      }
    }

    const saved = saveSection(sectionKey, req.body, req.cmsUser!.email);
    auditUserAction(
      req,
      'UPDATE_SECTION',
      'section',
      sectionKey,
      `Updated CMS section '${sectionKey}'`
    );
    res.json({ ok: true, sectionKey, data: saved });
  });

  // ────────────────────────────────────────────────────────────
  // RELATIONAL STAFF PROFILES & ACADEMIC LEADERSHIP CRUD
  // ────────────────────────────────────────────────────────────

  router.get('/admin/staff', (req: AuthenticatedRequest, res) => {
    if (!canUserAccessSection(req.cmsUser!, 'academic_leadership')) {
      res.status(403).json({ error: 'Access denied to staff management.' });
      return;
    }
    res.json({ staffMembers: listStaffMembers(false) });
  });

  router.post('/admin/staff', (req: AuthenticatedRequest, res) => {
    if (!canUserAccessSection(req.cmsUser!, 'academic_leadership')) {
      res.status(403).json({ error: 'Access denied to create staff profiles.' });
      return;
    }
    const body = req.body || {};
    const surname = String(body.surname || '').trim();
    const fullName = String(body.fullName || surname).trim();
    if (!surname || !fullName) {
      res.status(400).json({ error: 'Staff surname and name are required.' });
      return;
    }

    const now = new Date().toISOString();
    const status = ALLOWED_STATUSES.has(body.status) ? (body.status as PublishStatus) : 'published';
    const image = body.image && String(body.image).trim() ? String(body.image).trim() : null;
    const staff: StaffMember = {
      id: body.id ? String(body.id) : `staff-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
      surname,
      fullName,
      displayTitle: body.displayTitle ? String(body.displayTitle).trim() : undefined,
      department: body.department ? String(body.department).trim() : undefined,
      subjects: Array.isArray(body.subjects)
        ? body.subjects.map((s: unknown) => String(s).trim()).filter(Boolean)
        : [],
      image,
      bio: body.bio ? String(body.bio).trim() : undefined,
      qualifications: body.qualifications ? String(body.qualifications).trim() : undefined,
      email: body.email ? String(body.email).trim() : undefined,
      status,
      isIncomplete: typeof body.isIncomplete === 'boolean' ? body.isIncomplete : !image,
      incompleteReason: body.incompleteReason
        ? String(body.incompleteReason).trim()
        : !image
        ? 'Portrait photograph pending upload'
        : undefined,
      sortOrder: Number.isFinite(Number(body.sortOrder)) ? Number(body.sortOrder) : 50,
      createdAt: now,
      updatedAt: now,
    };

    const saved = saveStaffMember(staff);
    auditUserAction(
      req,
      'CREATE_STAFF',
      'staff_member',
      saved.id,
      `Created staff profile '${saved.fullName}'`
    );
    res.status(201).json({ staffMember: saved });
  });

  router.put('/admin/staff/:id', (req: AuthenticatedRequest, res) => {
    if (!canUserAccessSection(req.cmsUser!, 'academic_leadership')) {
      res.status(403).json({ error: 'Access denied to update staff profiles.' });
      return;
    }
    const existing = getStaffMemberById(req.params.id);
    if (!existing) {
      res.status(404).json({ error: 'Staff profile not found.' });
      return;
    }

    const body = req.body || {};
    const nextImage =
      body.image === null || body.image === ''
        ? null
        : body.image !== undefined
        ? String(body.image).trim()
        : existing.image ?? null;

    const updated = saveStaffMember({
      ...existing,
      surname: body.surname !== undefined ? String(body.surname).trim() : existing.surname,
      fullName: body.fullName !== undefined ? String(body.fullName).trim() : existing.fullName,
      displayTitle:
        body.displayTitle !== undefined
          ? String(body.displayTitle).trim() || undefined
          : existing.displayTitle,
      department:
        body.department !== undefined
          ? String(body.department).trim() || undefined
          : existing.department,
      subjects: Array.isArray(body.subjects)
        ? body.subjects.map((s: unknown) => String(s).trim()).filter(Boolean)
        : existing.subjects,
      image: nextImage,
      bio: body.bio !== undefined ? String(body.bio).trim() || undefined : existing.bio,
      qualifications:
        body.qualifications !== undefined
          ? String(body.qualifications).trim() || undefined
          : existing.qualifications,
      email: body.email !== undefined ? String(body.email).trim() || undefined : existing.email,
      status: ALLOWED_STATUSES.has(body.status) ? (body.status as PublishStatus) : existing.status,
      isIncomplete:
        typeof body.isIncomplete === 'boolean' ? body.isIncomplete : !nextImage,
      incompleteReason:
        body.incompleteReason !== undefined
          ? String(body.incompleteReason).trim() || undefined
          : !nextImage
          ? 'Portrait photograph pending upload'
          : undefined,
      sortOrder: Number.isFinite(Number(body.sortOrder)) ? Number(body.sortOrder) : existing.sortOrder,
      updatedAt: new Date().toISOString(),
    });

    auditUserAction(
      req,
      'UPDATE_STAFF',
      'staff_member',
      updated.id,
      `Updated staff profile '${updated.fullName}'`
    );
    res.json({ staffMember: updated });
  });

  router.delete(
    '/admin/staff/:id',
    requireRole(['super_admin', 'admin']),
    (req: AuthenticatedRequest, res) => {
      const existing = getStaffMemberById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'Staff profile not found.' });
        return;
      }
      const refCount = countAssignmentsForStaff(existing.id);
      if (refCount > 0 && req.query.force !== 'true') {
        res.status(409).json({
          error: `Staff profile '${existing.fullName}' is referenced by ${refCount} academic or pastoral assignment(s). Reassign or pass ?force=true to confirm cascading removal.`,
          assignmentCount: refCount,
        });
        return;
      }
      deleteStaffMember(existing.id);
      auditUserAction(
        req,
        'DELETE_STAFF',
        'staff_member',
        existing.id,
        `Deleted staff profile '${existing.fullName}'`
      );
      res.json({ ok: true });
    }
  );

  router.get('/admin/assignments', (req: AuthenticatedRequest, res) => {
    if (!canUserAccessSection(req.cmsUser!, 'academic_leadership')) {
      res.status(403).json({ error: 'Access denied to academic leadership assignments.' });
      return;
    }
    res.json({ assignments: listAcademicAssignments(false) });
  });

  router.post('/admin/assignments', (req: AuthenticatedRequest, res) => {
    if (!canUserAccessSection(req.cmsUser!, 'academic_leadership')) {
      res.status(403).json({ error: 'Access denied to create academic leadership assignments.' });
      return;
    }
    const body = req.body || {};
    const staffId = String(body.staffId || '').trim();
    const assignmentType = String(body.assignmentType || '') as AcademicAssignmentType;
    const roleTitle = String(body.roleTitle || '').trim();

    if (!staffId || !getStaffMemberById(staffId)) {
      res.status(400).json({ error: 'A valid staff profile must be selected.' });
      return;
    }
    if (!ALLOWED_ASSIGNMENT_TYPES.has(assignmentType)) {
      res.status(400).json({ error: `Invalid assignment type '${assignmentType}'.` });
      return;
    }
    if (!roleTitle) {
      res.status(400).json({ error: 'Designation / Role title is required.' });
      return;
    }
    const yearGroup = body.yearGroup ? (String(body.yearGroup) as YearGroupKey) : null;
    if (yearGroup && !ALLOWED_YEAR_GROUPS.has(yearGroup)) {
      res.status(400).json({ error: `Invalid year group '${yearGroup}'.` });
      return;
    }

    const now = new Date().toISOString();
    const status = ALLOWED_STATUSES.has(body.status) ? (body.status as PublishStatus) : 'published';
    const created = saveAcademicAssignment({
      id: body.id ? String(body.id) : `assign-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
      staffId,
      assignmentType,
      roleTitle,
      yearGroup,
      summary: body.summary ? String(body.summary).trim() : '',
      responsibilities: body.responsibilities ? String(body.responsibilities).trim() : '',
      welcomeMessage: body.welcomeMessage ? String(body.welcomeMessage).trim() : '',
      status,
      sortOrder: Number.isFinite(Number(body.sortOrder)) ? Number(body.sortOrder) : 10,
      archivedAt: status === 'archived' ? now : null,
      createdAt: now,
      updatedAt: now,
    });

    auditUserAction(
      req,
      'CREATE_ACADEMIC_ASSIGNMENT',
      'academic_assignment',
      created.id,
      `Assigned '${created.staff?.fullName || staffId}' to '${created.roleTitle}'${
        created.yearGroup ? ` (${created.yearGroup})` : ''
      }`
    );
    res.status(201).json({ assignment: created });
  });

  router.put('/admin/assignments/:id', (req: AuthenticatedRequest, res) => {
    if (!canUserAccessSection(req.cmsUser!, 'academic_leadership')) {
      res.status(403).json({ error: 'Access denied to update academic leadership assignments.' });
      return;
    }
    const existing = getAcademicAssignmentById(req.params.id);
    if (!existing) {
      res.status(404).json({ error: 'Academic assignment not found.' });
      return;
    }
    const body = req.body || {};
    const nextStaffId = body.staffId ? String(body.staffId).trim() : existing.staffId;
    if (!getStaffMemberById(nextStaffId)) {
      res.status(400).json({ error: 'Selected staff member does not exist.' });
      return;
    }
    const nextType = body.assignmentType
      ? (String(body.assignmentType) as AcademicAssignmentType)
      : existing.assignmentType;
    if (!ALLOWED_ASSIGNMENT_TYPES.has(nextType)) {
      res.status(400).json({ error: `Invalid assignment type '${nextType}'.` });
      return;
    }
    const nextYear =
      body.yearGroup === null || body.yearGroup === ''
        ? null
        : body.yearGroup !== undefined
        ? (String(body.yearGroup) as YearGroupKey)
        : existing.yearGroup ?? null;
    if (nextYear && !ALLOWED_YEAR_GROUPS.has(nextYear)) {
      res.status(400).json({ error: `Invalid year group '${nextYear}'.` });
      return;
    }

    const nextStatus = ALLOWED_STATUSES.has(body.status)
      ? (body.status as PublishStatus)
      : existing.status;
    const reassigned = nextStaffId !== existing.staffId || nextYear !== existing.yearGroup;

    const updated = saveAcademicAssignment({
      ...existing,
      staffId: nextStaffId,
      assignmentType: nextType,
      roleTitle: body.roleTitle !== undefined ? String(body.roleTitle).trim() : existing.roleTitle,
      yearGroup: nextYear,
      summary: body.summary !== undefined ? String(body.summary).trim() : existing.summary,
      responsibilities:
        body.responsibilities !== undefined
          ? String(body.responsibilities).trim()
          : existing.responsibilities,
      welcomeMessage:
        body.welcomeMessage !== undefined
          ? String(body.welcomeMessage).trim()
          : existing.welcomeMessage,
      status: nextStatus,
      sortOrder: Number.isFinite(Number(body.sortOrder))
        ? Number(body.sortOrder)
        : existing.sortOrder,
      updatedAt: new Date().toISOString(),
    });

    auditUserAction(
      req,
      reassigned ? 'REASSIGN_ACADEMIC_ROLE' : 'UPDATE_ACADEMIC_ASSIGNMENT',
      'academic_assignment',
      updated.id,
      `${reassigned ? 'Reassigned' : 'Updated'} '${updated.roleTitle}' -> '${
        updated.staff?.fullName || updated.staffId
      }'${updated.yearGroup ? ` (${updated.yearGroup})` : ''} [${updated.status}]`
    );
    res.json({ assignment: updated });
  });

  router.patch('/admin/assignments/:id/status', (req: AuthenticatedRequest, res) => {
    if (!canUserAccessSection(req.cmsUser!, 'academic_leadership')) {
      res.status(403).json({ error: 'Access denied.' });
      return;
    }
    const existing = getAcademicAssignmentById(req.params.id);
    if (!existing) {
      res.status(404).json({ error: 'Assignment not found.' });
      return;
    }
    const status = req.body?.status as PublishStatus;
    if (!ALLOWED_STATUSES.has(status)) {
      res.status(400).json({ error: `Invalid status '${status}'.` });
      return;
    }
    const updated = saveAcademicAssignment({
      ...existing,
      status,
      updatedAt: new Date().toISOString(),
    });
    auditUserAction(
      req,
      'STATUS_ACADEMIC_ASSIGNMENT',
      'academic_assignment',
      updated.id,
      `Set '${updated.roleTitle}' (${updated.staff?.fullName || updated.staffId}) status to '${status}'`
    );
    res.json({ assignment: updated });
  });

  router.delete(
    '/admin/assignments/:id',
    requireRole(['super_admin', 'admin']),
    (req: AuthenticatedRequest, res) => {
      const existing = getAcademicAssignmentById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'Assignment not found.' });
        return;
      }
      deleteAcademicAssignment(existing.id);
      auditUserAction(
        req,
        'DELETE_ACADEMIC_ASSIGNMENT',
        'academic_assignment',
        existing.id,
        `Deleted assignment '${existing.roleTitle}' (${existing.staff?.fullName || existing.staffId})`
      );
      res.json({ ok: true });
    }
  );

  // ────────────────────────────────────────────────────────────
  // PAGE-SCOPED CMS ITEMS (NEWS / ANNOUNCEMENTS / EVENTS / HIGHLIGHTS)
  // ────────────────────────────────────────────────────────────

  router.get('/admin/items', (req: AuthenticatedRequest, res) => {
    const pageKey = typeof req.query.pageKey === 'string' ? (req.query.pageKey as PageKey) : undefined;
    const status = typeof req.query.status === 'string' ? (req.query.status as PublishStatus | 'all') : 'all';
    const items = listCmsItems({ pageKey, status });
    const filtered =
      req.cmsUser?.role === 'content_editor'
        ? items.filter((item) => canUserEditPage(req.cmsUser!, item.pageKey))
        : items;
    res.json({ items: filtered });
  });

  router.post('/admin/items', (req: AuthenticatedRequest, res) => {
    const body = req.body || {};
    const pageKey = body.pageKey as PageKey;
    if (!ALLOWED_PAGE_KEYS.has(pageKey)) {
      res.status(400).json({ error: `Invalid pageKey '${pageKey}'.` });
      return;
    }
    if (!canUserEditPage(req.cmsUser!, pageKey)) {
      res.status(403).json({
        error: `You do not have permission to create content on page '${pageKey}'.`,
      });
      return;
    }

    const requestedStatus: PublishStatus = ALLOWED_STATUSES.has(body.status)
      ? body.status
      : 'draft';
    const requestedFeature = Boolean(body.featureOnHomepage);

    if (
      req.cmsUser!.role === 'content_editor' &&
      (requestedStatus === 'published' || requestedStatus === 'unpublished' || requestedFeature)
    ) {
      res.status(403).json({
        error:
          'Content Editors can create Draft or Pending Review items only. An Admin or Super Admin must publish or feature items on the Homepage.',
      });
      return;
    }

    const title = String(body.title || '').trim();
    if (!title) {
      res.status(400).json({ error: 'Item title is required.' });
      return;
    }

    const now = new Date().toISOString();
    const item: CmsItem = {
      id: body.id ? String(body.id) : `item-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
      pageKey,
      category: String(body.category || 'General').trim(),
      academicYear: body.academicYear ? String(body.academicYear).trim() : undefined,
      title,
      slug: body.slug ? slugify(String(body.slug)) : slugify(title),
      excerpt: String(body.excerpt || '').trim(),
      content:
        body.content && typeof body.content === 'object'
          ? (body.content as Record<string, unknown>)
          : { body: String(body.content || '') },
      thumbnailUrl: body.thumbnailUrl ? String(body.thumbnailUrl).trim() : undefined,
      mediaUrl: body.mediaUrl ? String(body.mediaUrl).trim() : undefined,
      status: requestedStatus,
      featureOnHomepage: requestedFeature,
      publishAt: body.publishAt ? String(body.publishAt) : undefined,
      eventDate: body.eventDate ? String(body.eventDate) : undefined,
      eventTime: body.eventTime ? String(body.eventTime) : undefined,
      eventLocation: body.eventLocation ? String(body.eventLocation) : undefined,
      eventCompleted: Boolean(body.eventCompleted),
      sortOrder: Number.isFinite(Number(body.sortOrder)) ? Number(body.sortOrder) : 10,
      createdBy: req.cmsUser!.email,
      updatedBy: req.cmsUser!.email,
      createdAt: now,
      updatedAt: now,
    };

    const saved = saveCmsItem(item);
    auditUserAction(
      req,
      'CREATE_ITEM',
      'cms_item',
      saved.id,
      `Created '${saved.title}' on page '${saved.pageKey}' (${saved.status}, featured=${saved.featureOnHomepage})`
    );
    res.status(201).json({ item: saved });
  });

  router.put('/admin/items/:id', (req: AuthenticatedRequest, res) => {
    const existing = getCmsItemById(req.params.id);
    if (!existing) {
      res.status(404).json({ error: 'CMS item not found.' });
      return;
    }
    const nextPageKey = (req.body?.pageKey || existing.pageKey) as PageKey;
    if (!ALLOWED_PAGE_KEYS.has(nextPageKey)) {
      res.status(400).json({ error: `Invalid pageKey '${nextPageKey}'.` });
      return;
    }
    if (!canUserEditPage(req.cmsUser!, nextPageKey)) {
      res.status(403).json({ error: `No permission to edit page '${nextPageKey}'.` });
      return;
    }

    const nextStatus = ALLOWED_STATUSES.has(req.body?.status)
      ? (req.body.status as PublishStatus)
      : existing.status;
    const nextFeatured =
      typeof req.body?.featureOnHomepage === 'boolean'
        ? req.body.featureOnHomepage
        : existing.featureOnHomepage;

    if (
      req.cmsUser!.role === 'content_editor' &&
      (nextStatus === 'published' ||
        nextStatus === 'unpublished' ||
        nextFeatured !== existing.featureOnHomepage)
    ) {
      res.status(403).json({
        error: 'Content Editors cannot publish/unpublish or change Homepage featuring.',
      });
      return;
    }

    const hasThumb = Object.prototype.hasOwnProperty.call(req.body || {}, 'thumbnailUrl');
    const resolvedThumbnailUrl = hasThumb
      ? req.body.thumbnailUrl
        ? String(req.body.thumbnailUrl).trim()
        : undefined
      : existing.thumbnailUrl;

    const hasMedia = Object.prototype.hasOwnProperty.call(req.body || {}, 'mediaUrl');
    const resolvedMediaUrl = hasMedia
      ? req.body.mediaUrl
        ? String(req.body.mediaUrl).trim()
        : undefined
      : existing.mediaUrl;

    const updated = saveCmsItem({
      ...existing,
      ...req.body,
      id: existing.id,
      pageKey: nextPageKey,
      status: nextStatus,
      featureOnHomepage: nextFeatured,
      thumbnailUrl: resolvedThumbnailUrl,
      mediaUrl: resolvedMediaUrl,
      slug: req.body?.slug ? slugify(String(req.body.slug)) : existing.slug,
      updatedBy: req.cmsUser!.email,
      updatedAt: new Date().toISOString(),
    });

    auditUserAction(
      req,
      'UPDATE_ITEM',
      'cms_item',
      updated.id,
      `Updated '${updated.title}' on '${updated.pageKey}' (${updated.status})`
    );
    res.json({ item: updated });
  });

  router.patch(
    '/admin/items/:id/feature',
    requireRole(['super_admin', 'admin']),
    (req: AuthenticatedRequest, res) => {
      const existing = getCmsItemById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'CMS item not found.' });
        return;
      }
      const featureOnHomepage = Boolean(req.body?.featureOnHomepage);
      const updated = saveCmsItem({
        ...existing,
        featureOnHomepage,
        updatedBy: req.cmsUser!.email,
        updatedAt: new Date().toISOString(),
      });
      auditUserAction(
        req,
        featureOnHomepage ? 'FEATURE_HOMEPAGE' : 'UNFEATURE_HOMEPAGE',
        'cms_item',
        updated.id,
        `${featureOnHomepage ? 'Featured' : 'Removed homepage feature for'} '${updated.title}' (kept on '${updated.pageKey}' page)`
      );
      res.json({ item: updated });
    }
  );

  router.patch('/admin/items/:id/status', (req: AuthenticatedRequest, res) => {
    const existing = getCmsItemById(req.params.id);
    if (!existing) {
      res.status(404).json({ error: 'CMS item not found.' });
      return;
    }
    const status = req.body?.status as PublishStatus;
    if (!ALLOWED_STATUSES.has(status)) {
      res.status(400).json({ error: `Invalid publish status '${status}'.` });
      return;
    }
    if (
      req.cmsUser!.role === 'content_editor' &&
      !['draft', 'pending'].includes(status)
    ) {
      res.status(403).json({
        error: 'Content Editors may only set status to Draft or Pending Review.',
      });
      return;
    }
    if (!canUserEditPage(req.cmsUser!, existing.pageKey)) {
      res.status(403).json({ error: `No permission for page '${existing.pageKey}'.` });
      return;
    }

    const updated = saveCmsItem({
      ...existing,
      status,
      updatedBy: req.cmsUser!.email,
      updatedAt: new Date().toISOString(),
    });
    auditUserAction(
      req,
      'STATUS_CHANGE',
      'cms_item',
      updated.id,
      `Changed '${updated.title}' status to '${status}'`
    );
    res.json({ item: updated });
  });

  router.delete(
    '/admin/items/:id',
    requireRole(['super_admin', 'admin']),
    (req: AuthenticatedRequest, res) => {
      const existing = getCmsItemById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'CMS item not found.' });
        return;
      }
      deleteCmsItem(existing.id);
      auditUserAction(
        req,
        'DELETE_ITEM',
        'cms_item',
        existing.id,
        `Deleted item '${existing.title}' from '${existing.pageKey}'`
      );
      res.json({ ok: true });
    }
  );

  // ────────────────────────────────────────────────────────────
  // MEDIA LIBRARY ENDPOINTS (PERSISTENT DISK + REFERENCE TRACKING)
  // ────────────────────────────────────────────────────────────

  router.get('/admin/media', (_req, res) => {
    res.json({ media: listMediaWithReferences() });
  });

  router.post(
    '/admin/media/upload',
    (req, res, next) => {
      uploadMiddleware.single('file')(req, res, (err) => {
        if (err) {
          res.status(400).json({ error: err.message || 'Upload rejected.' });
          return;
        }
        next();
      });
    },
    (req: AuthenticatedRequest, res) => {
      const file = req.file;
      if (!file) {
        res.status(400).json({ error: 'No file attached in multipart field "file".' });
        return;
      }
      const ext = path.extname(file.originalname || file.filename);
      const asset: MediaAsset = {
        id: `m-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
        name: String(req.body?.name || file.originalname).trim(),
        filename: file.filename,
        url: `/uploads/${file.filename}`,
        category: String(req.body?.category || 'General').trim(),
        mediaType: inferMediaType(ext),
        mimeType: file.mimetype,
        sizeBytes: file.size,
        description: String(req.body?.description || '').trim() || undefined,
        uploadedAt: new Date().toISOString().split('T')[0],
      };
      const saved = saveMediaAsset(asset);
      auditUserAction(
        req,
        'UPLOAD_MEDIA',
        'media',
        saved.id,
        `Uploaded media '${saved.name}' (${saved.mediaType})`
      );
      res.status(201).json({ asset: saved });
    }
  );

  router.post('/admin/media/embed', (req: AuthenticatedRequest, res) => {
    const name = String(req.body?.name || '').trim();
    const url = String(req.body?.url || '').trim();
    if (!name || !url) {
      res.status(400).json({ error: 'Name and URL are required for external media embed.' });
      return;
    }
    const asset: MediaAsset = {
      id: `m-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
      name,
      url,
      category: String(req.body?.category || 'Video & Embeds').trim(),
      mediaType: (req.body?.mediaType as MediaAsset['mediaType']) || 'embed',
      description: req.body?.description ? String(req.body.description).trim() : undefined,
      uploadedAt: new Date().toISOString().split('T')[0],
    };
    const saved = saveMediaAsset(asset);
    auditUserAction(req, 'ADD_EMBED_MEDIA', 'media', saved.id, `Added embed '${saved.name}'`);
    res.status(201).json({ asset: saved });
  });

  router.put('/admin/media/:id', (req: AuthenticatedRequest, res) => {
    const existing = getMediaById(req.params.id);
    if (!existing) {
      res.status(404).json({ error: 'Media asset not found.' });
      return;
    }
    const saved = saveMediaAsset({
      ...existing,
      name: String(req.body?.name || existing.name).trim(),
      category: String(req.body?.category || existing.category).trim(),
      description:
        req.body?.description !== undefined
          ? String(req.body.description).trim()
          : existing.description,
    });
    auditUserAction(req, 'UPDATE_MEDIA', 'media', saved.id, `Updated metadata for '${saved.name}'`);
    res.json({ asset: saved });
  });

  router.delete(
    '/admin/media/:id',
    requireRole(['super_admin', 'admin']),
    (req: AuthenticatedRequest, res) => {
      const existing = getMediaById(req.params.id);
      if (!existing) {
        res.status(404).json({ error: 'Media asset not found.' });
        return;
      }
      const usedIn = findMediaReferences(existing.url);
      if (usedIn.length > 0 && req.query.force !== 'true') {
        res.status(409).json({
          error: `This file is currently referenced by ${usedIn.length} record(s): ${usedIn.slice(0, 4).join(', ')}. Confirm deletion to proceed.`,
          usedIn,
        });
        return;
      }
      deleteMediaAsset(existing.id);
      auditUserAction(
        req,
        'DELETE_MEDIA',
        'media',
        existing.id,
        `Deleted media '${existing.name}' (refs=${usedIn.length})`
      );
      res.json({ ok: true });
    }
  );

  // ────────────────────────────────────────────────────────────
  // ENQUIRIES & TOUR BOOKINGS (ADMIN VIEW)
  // ────────────────────────────────────────────────────────────

  router.get('/admin/enquiries', requireRole(['super_admin', 'admin']), (_req, res) => {
    const db = getDb();
    const rows = db.prepare('SELECT * FROM enquiries ORDER BY created_at DESC LIMIT 200').all() as {
      id: string;
      type: string;
      payload_json: string;
      status: string;
      created_at: string;
    }[];
    res.json({
      enquiries: rows.map((r) => ({
        id: r.id,
        type: r.type,
        payload: JSON.parse(r.payload_json),
        status: r.status,
        createdAt: r.created_at,
      })),
    });
  });

  router.get('/admin/tours', requireRole(['super_admin', 'admin']), (_req, res) => {
    const db = getDb();
    const rows = db
      .prepare('SELECT * FROM tour_bookings ORDER BY created_at DESC LIMIT 200')
      .all() as {
      id: string;
      payload_json: string;
      status: string;
      created_at: string;
    }[];
    res.json({
      tours: rows.map((r) => ({
        id: r.id,
        payload: JSON.parse(r.payload_json),
        status: r.status,
        createdAt: r.created_at,
      })),
    });
  });

  // ────────────────────────────────────────────────────────────
  // USER & ROLE MANAGEMENT (STRICTLY SUPER ADMIN ONLY)
  // ────────────────────────────────────────────────────────────

  router.get('/admin/users', requireRole(['super_admin']), (_req, res) => {
    const db = getDb();
    const rows = db.prepare('SELECT * FROM users ORDER BY created_at ASC').all() as Record<
      string,
      unknown
    >[];
    res.json({ users: rows.map(mapUserRow) });
  });

  router.post('/admin/users', requireRole(['super_admin']), (req: AuthenticatedRequest, res) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const usernameRaw = String(req.body?.username || email.split('@')[0] || '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9._-]/g, '');
    const fullName = String(req.body?.fullName || '').trim();
    const password = String(req.body?.password || '');
    const role = String(req.body?.role || 'content_editor') as UserRole;
    const assignedPages = Array.isArray(req.body?.assignedPages)
      ? (req.body.assignedPages as PageKey[])
      : [];
    const mustChangePassword = Boolean(req.body?.mustChangePassword);

    if (!email || !email.includes('@')) {
      res.status(400).json({ error: 'Valid email is required.' });
      return;
    }
    if (!usernameRaw || usernameRaw.length < 2) {
      res.status(400).json({ error: 'A valid username (min 2 chars) is required.' });
      return;
    }
    if (!fullName) {
      res.status(400).json({ error: 'Full name is required.' });
      return;
    }
    if (!password || password.length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters.' });
      return;
    }
    if (!['super_admin', 'admin', 'content_editor'].includes(role)) {
      res.status(400).json({ error: 'Invalid role.' });
      return;
    }

    const db = getDb();
    const existing = db
      .prepare('SELECT id FROM users WHERE LOWER(email) = ? OR LOWER(username) = ?')
      .get(email, usernameRaw);
    if (existing) {
      res.status(409).json({ error: 'A user with this email or username already exists.' });
      return;
    }

    const id = `usr-${crypto.randomUUID()}`;
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO users (
        id, username, email, full_name, password_hash, role, assigned_pages_json,
        active, must_change_password, failed_login_attempts, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, 0, ?)
    `).run(
      id,
      usernameRaw,
      email,
      fullName,
      hashPassword(password),
      role,
      JSON.stringify(assignedPages),
      mustChangePassword ? 1 : 0,
      now
    );

    const user = mapUserRow(
      db.prepare('SELECT * FROM users WHERE id = ?').get(id) as Record<string, unknown>
    );
    auditUserAction(req, 'CREATE_USER', 'user', id, `Created user ${usernameRaw} (${email}, ${role})`);
    res.status(201).json({ user });
  });

  router.put('/admin/users/:id', requireRole(['super_admin']), (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id) as
      | Record<string, unknown>
      | undefined;
    if (!row) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    const current = mapUserRow(row);
    const nextRole = (req.body?.role || current.role) as UserRole;
    const nextActive =
      typeof req.body?.active === 'boolean' ? req.body.active : current.active;

    if (
      current.id === req.cmsUser!.id &&
      (nextRole !== 'super_admin' || !nextActive)
    ) {
      res.status(400).json({
        error: 'You cannot demote or deactivate your own active Super Administrator account.',
      });
      return;
    }

    const nextFullName = String(req.body?.fullName || current.fullName).trim();
    const nextUsername = req.body?.username
      ? String(req.body.username).trim().toLowerCase().replace(/[^a-z0-9._-]/g, '')
      : current.username || current.email.split('@')[0];
    const nextAssignedPages = Array.isArray(req.body?.assignedPages)
      ? req.body.assignedPages
      : current.assignedPages;

    db.prepare(`
      UPDATE users SET username = ?, full_name = ?, role = ?, assigned_pages_json = ?, active = ? WHERE id = ?
    `).run(
      nextUsername,
      nextFullName,
      nextRole,
      JSON.stringify(nextAssignedPages),
      nextActive ? 1 : 0,
      current.id
    );

    if (!nextActive) {
      revokeAllUserSessions(current.id);
    }

    if (typeof req.body?.password === 'string' && req.body.password.length >= 8) {
      db.prepare('UPDATE users SET password_hash = ?, must_change_password = 1 WHERE id = ?').run(
        hashPassword(req.body.password),
        current.id
      );
      revokeAllUserSessions(current.id);
    }

    const updated = mapUserRow(
      db.prepare('SELECT * FROM users WHERE id = ?').get(current.id) as Record<string, unknown>
    );
    auditUserAction(
      req,
      'UPDATE_USER',
      'user',
      updated.id,
      `Updated user ${updated.username || updated.email} (role=${updated.role}, active=${updated.active})`
    );
    res.json({ user: updated });
  });

  router.post(
    '/admin/users/:id/reset-password',
    requireRole(['super_admin']),
    (req: AuthenticatedRequest, res) => {
      const db = getDb();
      const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id) as
        | Record<string, unknown>
        | undefined;
      if (!row) {
        res.status(404).json({ error: 'User not found.' });
        return;
      }
      const newTemporaryPassword = String(req.body?.temporaryPassword || '');
      if (!newTemporaryPassword || newTemporaryPassword.length < 8) {
        res.status(400).json({
          error: 'A temporary password of at least 8 characters must be supplied.',
        });
        return;
      }

      db.prepare(`
        UPDATE users
        SET password_hash = ?, must_change_password = 1, failed_login_attempts = 0, locked_until = NULL
        WHERE id = ?
      `).run(hashPassword(newTemporaryPassword), String(row.id));

      revokeAllUserSessions(String(row.id));
      auditUserAction(
        req,
        'ADMIN_RESET_PASSWORD',
        'user',
        String(row.id),
        `Super Admin issued forced temporary password reset and revoked sessions for '${String(
          row.username || row.email
        )}'`
      );
      res.json({ ok: true, temporaryPasswordIssued: true });
    }
  );

  router.delete(
    '/admin/users/:id/sessions',
    requireRole(['super_admin']),
    (req: AuthenticatedRequest, res) => {
      const db = getDb();
      const row = db.prepare('SELECT id, email, username FROM users WHERE id = ?').get(req.params.id) as
        | { id: string; email: string; username: string | null }
        | undefined;
      if (!row) {
        res.status(404).json({ error: 'User not found.' });
        return;
      }
      const revoked = revokeAllUserSessions(row.id);
      auditUserAction(
        req,
        'REVOKE_SESSIONS',
        'user',
        row.id,
        `Revoked ${revoked} active session(s) for '${row.username || row.email}'`
      );
      res.json({ ok: true, revokedCount: revoked });
    }
  );

  router.delete(
    '/admin/users/:id',
    requireRole(['super_admin']),
    (req: AuthenticatedRequest, res) => {
      if (req.params.id === req.cmsUser!.id) {
        res.status(400).json({ error: 'You cannot delete your own account.' });
        return;
      }
      const db = getDb();
      const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id) as
        | Record<string, unknown>
        | undefined;
      if (!row) {
        res.status(404).json({ error: 'User not found.' });
        return;
      }
      if (String(row.role) === 'super_admin') {
        const otherSupers = (
          db
            .prepare("SELECT COUNT(*) as cnt FROM users WHERE role = 'super_admin' AND active = 1 AND id != ?")
            .get(req.params.id) as { cnt: number }
        ).cnt;
        if (otherSupers === 0) {
          res.status(400).json({
            error: 'Cannot delete the sole active Super Administrator account.',
          });
          return;
        }
      }
      db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);
      auditUserAction(
        req,
        'DELETE_USER',
        'user',
        req.params.id,
        `Deleted user ${String(row.email)}`
      );
      res.json({ ok: true });
    }
  );

  // ────────────────────────────────────────────────────────────
  // AUDIT LOGS, BACKUP / RECOVERY & STATIC WEBSITE EXPORT (.ZIP)
  // ────────────────────────────────────────────────────────────

  router.get('/admin/audit-logs', requireRole(['super_admin', 'admin']), (req, res) => {
    const limit = Math.min(500, Math.max(10, Number(req.query.limit || 150)));
    res.json({ logs: listAuditLogs(limit) });
  });

  router.get('/admin/backup/export', requireRole(['super_admin']), (req: AuthenticatedRequest, res) => {
    const snapshot = exportDatabaseSnapshot(req.cmsUser!.email);
    auditUserAction(
      req,
      'EXPORT_BACKUP',
      'system',
      'backup',
      'Exported full JSON CMS backup snapshot'
    );
    res.json(snapshot);
  });

  router.post(
    '/admin/backup/restore',
    requireRole(['super_admin']),
    (req: AuthenticatedRequest, res) => {
      const payload = req.body;
      if (!payload || typeof payload !== 'object' || !payload.sections) {
        res.status(400).json({ error: 'Invalid backup snapshot format. Expected { sections, items, media }.' });
        return;
      }
      restoreDatabaseSnapshot(payload, req.cmsUser!.email);
      auditUserAction(
        req,
        'RESTORE_BACKUP',
        'system',
        'backup',
        'Restored CMS database from JSON backup snapshot'
      );
      res.json({ ok: true });
    }
  );

  router.post(
    '/admin/reset-defaults',
    requireRole(['super_admin']),
    (req: AuthenticatedRequest, res) => {
      const defaults = createDefaultCmsDatabase();
      restoreDatabaseSnapshot(
        {
          sections: defaults,
          media: defaults.media,
        },
        req.cmsUser!.email
      );
      auditUserAction(
        req,
        'RESET_DEFAULTS',
        'system',
        'reset',
        'Reset CMS sections to verified factory defaults'
      );
      res.json({ ok: true, sections: getAllSections() });
    }
  );

  router.get(
    '/admin/export-static',
    requireRole(['super_admin', 'admin']),
    async (req: AuthenticatedRequest, res) => {
      try {
        const exportModule = await import('../../scripts/exportStaticSite.mjs');
        const outDir = await exportModule.buildStaticExport({ rebuildViteIfMissing: true });
        const entries = collectFilesRecursively(outDir, outDir);
        const zipBuf = createZipBuffer(entries);
        const stamp = new Date().toISOString().split('T')[0];

        auditUserAction(
          req,
          'EXPORT_STATIC_SITE',
          'system',
          'static-export',
          `Generated downloadable static public website archive (${entries.length} files)`
        );

        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', `attachment; filename="lkc-public-static-${stamp}.zip"`);
        res.setHeader('Content-Length', String(zipBuf.length));
        res.send(zipBuf);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Static website export failed.';
        res.status(500).json({ error: message });
      }
    }
  );

  return router;
}
