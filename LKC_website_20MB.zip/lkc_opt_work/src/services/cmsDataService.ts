import { useState, useEffect } from 'react';
import {
  createDefaultCmsDatabase,
  DEFAULT_CMS_ITEMS,
  type CmsDatabase,
  type CmsSectionKey,
  type AchieversSectionData,
  type FeesSectionData,
} from '../data/cmsDefaults';
import type {
  AcademicAssignment,
  AcademicLeadershipBundle,
  AlumniProfile,
  AuditLogEntry,
  CmsItem,
  CmsUser,
  MediaAsset,
  PageKey,
  PublishStatus,
  StaffMember,
  UserRole,
} from '../types';

export type { CmsDatabase, CmsSectionKey, AchieversSectionData, FeesSectionData };

const STORAGE_KEY = 'lkc_unified_cms_v1';
const ITEMS_STORAGE_KEY = 'lkc_unified_cms_items_v1';
const LEADERSHIP_STORAGE_KEY = 'lkc_unified_academic_leadership_v1';
const TOKEN_STORAGE_KEY = 'lkc_cms_session_token';
const CMS_EVENT = 'lkc-cms-updated';

export interface ApiError extends Error {
  status?: number;
  code?: string;
  usedIn?: string[];
  assignmentCount?: number;
}

interface StaticSnapshotPayload {
  sections?: Partial<CmsDatabase>;
  publishedItems?: CmsItem[];
  featuredItems?: CmsItem[];
  academicLeadership?: AcademicLeadershipBundle;
}

declare global {
  interface Window {
    __LKC_STATIC_MODE__?: boolean;
    __LKC_STATIC_SNAPSHOT__?: StaticSnapshotPayload;
  }
}

const API_TIMEOUT_MS = 5000;

export function isStaticSiteMode(): boolean {
  if (typeof window === 'undefined') {
    return import.meta.env.VITE_STATIC_MODE === 'true';
  }
  if (window.location.protocol === 'file:') return true;
  if (typeof window.__LKC_STATIC_MODE__ === 'boolean') {
    return window.__LKC_STATIC_MODE__;
  }
  return import.meta.env.VITE_STATIC_MODE === 'true';
}

export type CmsDataSource = 'static snapshot' | 'built-in defaults' | 'API';

export interface CmsDiagnosticsSnapshot {
  dataSource: CmsDataSource;
  errors: string[];
  lastUpdatedAt: string;
}

let memoryDb: CmsDatabase = createDefaultCmsDatabase();
let memoryItems: CmsItem[] = [...DEFAULT_CMS_ITEMS];
let memoryFeaturedItems: CmsItem[] = DEFAULT_CMS_ITEMS.filter(
  (i) => i.status === 'published' && i.featureOnHomepage
);
let memoryAcademicLeadership: AcademicLeadershipBundle = {
  staffMembers: [],
  assignments: [],
};
let bootstrapStarted = false;
let currentDataSource: CmsDataSource = 'built-in defaults';
let diagnosticErrors: string[] = [];
let diagnosticsUpdatedAt = new Date().toISOString();

export function recordDiagnosticError(message: string): void {
  const clean = (message || '').trim();
  if (!clean) return;
  if (!diagnosticErrors.includes(clean)) {
    diagnosticErrors = [...diagnosticErrors.slice(-9), clean];
  }
  diagnosticsUpdatedAt = new Date().toISOString();
  emitUpdate();
}

export function getCmsDiagnostics(): CmsDiagnosticsSnapshot {
  return {
    dataSource: currentDataSource,
    errors: [...diagnosticErrors],
    lastUpdatedAt: diagnosticsUpdatedAt,
  };
}

function getStoredToken(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    return (
      window.localStorage.getItem(TOKEN_STORAGE_KEY) ||
      window.sessionStorage.getItem(TOKEN_STORAGE_KEY)
    );
  } catch {
    return null;
  }
}

export function setStoredToken(token: string | null): void {
  if (typeof window === 'undefined') return;
  try {
    if (token) {
      window.localStorage.setItem(TOKEN_STORAGE_KEY, token);
      window.sessionStorage.setItem(TOKEN_STORAGE_KEY, token);
    } else {
      window.localStorage.removeItem(TOKEN_STORAGE_KEY);
      window.sessionStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  } catch {
    // Ignore storage errors
  }
}

function buildAuthHeaders(extra?: HeadersInit): HeadersInit {
  const token = getStoredToken();
  const base: Record<string, string> = {};
  if (token) base['Authorization'] = `Bearer ${token}`;
  if (extra && typeof extra === 'object' && !Array.isArray(extra)) {
    return { ...base, ...(extra as Record<string, string>) };
  }
  return base;
}

async function fetchWithTimeout(
  url: string,
  options?: RequestInit,
  timeoutMs = API_TIMEOUT_MS
): Promise<Response> {
  const controller = new AbortController();
  const timer = globalThis.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...options,
      signal: options?.signal ?? controller.signal,
    });
  } finally {
    globalThis.clearTimeout(timer);
  }
}

async function apiFetch<T>(url: string, options?: RequestInit): Promise<T> {
  if (isStaticSiteMode()) {
    throw new Error('Administrative CMS operations are unavailable in the static public website.');
  }
  const res = await fetchWithTimeout(url, {
    credentials: 'include',
    ...options,
    headers: buildAuthHeaders(options?.headers),
  });
  const text = await res.text();
  let parsed: Record<string, unknown> = {};
  if (text) {
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = { error: text };
    }
  }
  if (!res.ok) {
    const errMsg =
      (parsed && typeof parsed.error === 'string' && parsed.error) ||
      `Request failed with status ${res.status}`;
    const err = new Error(errMsg) as ApiError;
    err.status = res.status;
    if (typeof parsed.code === 'string') err.code = parsed.code;
    if (Array.isArray(parsed.usedIn)) err.usedIn = parsed.usedIn as string[];
    if (typeof parsed.assignmentCount === 'number') err.assignmentCount = parsed.assignmentCount;
    throw err;
  }
  return parsed as T;
}

function emitUpdate(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(CMS_EVENT));
  }
}

function hydrateLocalCachesFromMemory(): void {
  if (typeof window === 'undefined' || isStaticSiteMode()) return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryDb));
    window.localStorage.setItem(ITEMS_STORAGE_KEY, JSON.stringify(memoryItems));
    window.localStorage.setItem(LEADERSHIP_STORAGE_KEY, JSON.stringify(memoryAcademicLeadership));
  } catch {
    // Ignore quota errors
  }
}

function normalizeStaticAssetUrls<T>(value: T): T {
  if (!isStaticSiteMode()) return value;
  if (typeof value === 'string') {
    if (value.startsWith('/uploads/')) return `.${value}` as unknown as T;
    if (value.startsWith('/assets/')) return `.${value}` as unknown as T;
    return value;
  }
  if (Array.isArray(value)) {
    return value.map((item) => normalizeStaticAssetUrls(item)) as unknown as T;
  }
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = normalizeStaticAssetUrls(v);
    }
    return out as T;
  }
  return value;
}

function isMissingOrFallbackLogo(url?: string | null): boolean {
  if (!url || !url.trim()) return true;
  return /logo_33a39ff7\.png/i.test(url);
}

const AI_PLACEHOLDER_PHOTO_RE =
  /\/assets\/images\/(?:hero_lkc_campus_1792759534281|lkc_library_study_1792759536305|lkc_science_lab_1792759535206|lkc_sports_athletics_1792759535888)\.jpg$/i;

function stripAiPlaceholderPhotos<T extends { url?: string }>(photos?: T[]): T[] {
  if (!Array.isArray(photos)) return [];
  return photos.filter((p) => p && p.url && !AI_PLACEHOLDER_PHOTO_RE.test(p.url.trim()));
}

function repairKnownStaffSections(db: CmsDatabase): CmsDatabase {
  const repairedTeachers = Array.isArray(db.teachers)
    ? db.teachers.map((t) => {
        if (t.id === 't-hum-1' || /\bbokamoso\b/i.test(t.name)) {
          return {
            ...t,
            name:
              t.name === 'Mr K Bokamoso'
                ? 'Mr Bokamoso Kgosidintsi'
                : t.name,
            image: isMissingOrFallbackLogo(t.image)
              ? './assets/aistudio/image_a734d497.png'
              : t.image,
          };
        }
        if ((t.id === 't-ict-1' || /\bchivorese\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Chivorese_92d20e94.jpg' };
        }
        if ((t.id === 't-ict-4' || /\bmakoni\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Makoni_4a7d1146.jpg' };
        }
        if ((t.id === 't-sci-2' || /\bka?dembo\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Kadembo_34520bae.jpeg' };
        }
        if ((t.id === 't-com-4' || /\bmonyeki\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Monyeki_a7e063be.jpeg' };
        }
        if ((t.id === 't-math-5' || /\bmodimoo?file\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Modimofile_e9d13f63.jpeg' };
        }
        if ((t.id === 't-sci-1' || /\bchandra\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/ff292469-859b-447f-87d1-71b64a57fa64_728a86cc.webp' };
        }
        if ((t.id === 't-sci-4' || /\bkgosikwena\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/df962819-6680-4651-beb2-217b2d8f1758_3a298a9e.webp' };
        }
        if ((t.id === 't-art-2' || /\bjones\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/jones_e7c56bef.jpeg' };
        }
        if ((t.id === 't-art-3' || /\bmathodi\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Mathodi_7f51ea9a.jpeg' };
        }
        if ((t.id === 't-sci-12' || /\bnyateka\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Nyateka_400b2c05.jpeg' };
        }
        if ((t.id === 't-sci-11' || /\bsamuel\s+ndebele\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Ndebele_S_d3b46a90.jpeg' };
        }
        if ((t.id === 't-sci-10' || /\bncube\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Ncube_a80f777a.jpeg' };
        }
        if ((t.id === 't-com-1' || /\bgasha\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Gasha_7a156b12.jpeg' };
        }
        if ((t.id === 't-math-2' || /\bbar+ot\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Barrot_68d8dbf4.jpeg' };
        }
        if ((t.id === 't-math-9' || /\bsorofa\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/sorofa_dced6e8d.jpeg' };
        }
        if ((t.id === 't-com-7' || /\bmutero\b/i.test(t.name)) && (isMissingOrFallbackLogo(t.image) || /Mutero_823ea3f0\.jpg/i.test(t.image || ''))) {
          return { ...t, image: './assets/aistudio/Mutero_768af995.jpeg' };
        }
        if ((t.id === 't-lang-7' || /\btsetse\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/tsetse_de6b2999.jpeg' };
        }
        if ((t.id === 't-lang-1' || /\balex\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Alex_310606c2.jpeg' };
        }
        if (
          (t.id === 't-lang-5' || /\bngwenya\b/i.test(t.name)) &&
          (isMissingOrFallbackLogo(t.image) || /Ngwenya_8691aac9\.jpg/i.test(t.image || ''))
        ) {
          return { ...t, image: './assets/aistudio/Ngwenya_890cf4cf.jpeg' };
        }
        if ((t.id === 't-lang-6' || /\bshobashoba\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Shobashoba_9783c429.jpeg' };
        }
        if ((t.id === 't-lang-matlotse' || /\bmatlotse\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Matlotse_059db9aa.webp' };
        }
        if ((t.id === 't-hum-3' || /\bmagadi\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/magadi_cf1feea8.jpg' };
        }
        if ((t.id === 't-math-8' || /\both[io]mile\b/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Othimile_2008c070.jpeg' };
        }
        if ((t.id === 't-sci-8' || /\bkhumo/i.test(t.name)) && isMissingOrFallbackLogo(t.image)) {
          return { ...t, image: './assets/aistudio/Khumo_1d7ed1f6.jpeg' };
        }
        return t;
      })
    : db.teachers;

  const repairedDepartments = Array.isArray(db.departments)
    ? db.departments.map((d) => {
        if (
          (d.id === 'dept-ict' || /\bchivorese\b/i.test(d.headOfDepartment?.name || '')) &&
          isMissingOrFallbackLogo(d.headOfDepartment?.image)
        ) {
          return {
            ...d,
            headOfDepartment: {
              ...d.headOfDepartment,
              image: './assets/aistudio/Chivorese_92d20e94.jpg',
            },
          };
        }
        if (
          (d.id === 'dept-science' || /\bka?dembo\b/i.test(d.headOfDepartment?.name || '')) &&
          isMissingOrFallbackLogo(d.headOfDepartment?.image)
        ) {
          return {
            ...d,
            headOfDepartment: {
              ...d.headOfDepartment,
              image: './assets/aistudio/Kadembo_34520bae.jpeg',
            },
          };
        }
        if (
          (d.id === 'dept-creatives' || /\bjones\b/i.test(d.headOfDepartment?.name || '')) &&
          isMissingOrFallbackLogo(d.headOfDepartment?.image)
        ) {
          return {
            ...d,
            headOfDepartment: {
              ...d.headOfDepartment,
              image: './assets/aistudio/jones_e7c56bef.jpeg',
            },
          };
        }
        if (
          (d.id === 'dept-languages' || /\btsetse\b/i.test(d.headOfDepartment?.name || '')) &&
          isMissingOrFallbackLogo(d.headOfDepartment?.image)
        ) {
          return {
            ...d,
            headOfDepartment: {
              ...d.headOfDepartment,
              image: './assets/aistudio/tsetse_de6b2999.jpeg',
            },
          };
        }
        return d;
      })
    : db.departments;

  let repairedAbout = db.about;
  if (repairedAbout) {
    const repairedDirectors = Array.isArray(repairedAbout.directors)
      ? repairedAbout.directors.map((dir) =>
          (dir.id === 'dir-makoni' || /\bmakoni\b/i.test(dir.name)) && isMissingOrFallbackLogo(dir.image)
            ? { ...dir, image: './assets/aistudio/Makoni_4a7d1146.jpg' }
            : dir
        )
      : repairedAbout.directors;

    let repairedLeadership = Array.isArray(repairedAbout.leadership)
      ? [...repairedAbout.leadership]
      : [];

    const hasMurombedzi = repairedLeadership.some(
      (m) => m.id === 'lead-murombedzi' || /\bmurombedzi\b/i.test(m.name)
    );
    if (!hasMurombedzi) {
      repairedLeadership.push({
        id: 'lead-murombedzi',
        order: 6,
        status: 'published',
        name: 'Mr K Murombedzi',
        role: 'Vice Principal Examinations',
        title: 'Vice Principal (Examinations & Assessment Standards)',
        image: './assets/aistudio/Murombedzi_b26ea474.jpg',
        department: 'Cambridge Examinations & Assessment',
        isSMT: true,
        bio: 'Directs Cambridge IGCSE, AS, and A-Level examination administration, candidate entries, invigilation compliance, and assessment standards across the college.',
      });
    }
    repairedLeadership = repairedLeadership.map((m) => {
      if (m.id === 'lead-murombedzi' || /\bmurombedzi\b/i.test(m.name)) {
        return {
          ...m,
          status: 'published',
          isSMT: true,
          role: m.role || 'Vice Principal Examinations',
          order: m.order ?? 6,
          image: isMissingOrFallbackLogo(m.image)
            ? './assets/aistudio/Murombedzi_b26ea474.jpg'
            : m.image,
        };
      }
      if (m.id === 'lead-munodawafa' && m.order === 6) {
        return { ...m, order: 7 };
      }
      return m;
    });

    repairedAbout = {
      ...repairedAbout,
      leadership: repairedLeadership,
      directors: repairedDirectors,
    };
  }

  return {
    ...db,
    teachers: repairedTeachers,
    departments: repairedDepartments,
    about: repairedAbout,
    athletics: db.athletics
      ? { ...db.athletics, photos: stripAiPlaceholderPhotos(db.athletics.photos) }
      : db.athletics,
    jaguars: db.jaguars
      ? { ...db.jaguars, photos: stripAiPlaceholderPhotos(db.jaguars.photos) }
      : db.jaguars,
    sports: db.sports
      ? { ...db.sports, photos: stripAiPlaceholderPhotos(db.sports.photos) }
      : db.sports,
  };
}

function mergeSectionValue<T>(defVal: T, incoming: unknown): T {
  if (incoming === undefined || incoming === null) return defVal;
  if (Array.isArray(defVal)) {
    return (Array.isArray(incoming) ? incoming : defVal) as T;
  }
  if (
    defVal &&
    typeof defVal === 'object' &&
    typeof incoming === 'object' &&
    !Array.isArray(incoming)
  ) {
    const out: Record<string, unknown> = { ...(defVal as Record<string, unknown>) };
    const incObj = incoming as Record<string, unknown>;
    for (const [k, v] of Object.entries(incObj)) {
      if (v === undefined || v === null) continue;
      if (k in out) {
        out[k] = mergeSectionValue(out[k], v);
      } else {
        out[k] = v;
      }
    }
    return out as T;
  }
  return incoming as T;
}

function mergeCachedSections(parsed: Partial<CmsDatabase>): CmsDatabase {
  const defaults = createDefaultCmsDatabase();
  const merged: Record<string, unknown> = { ...defaults };
  for (const key of Object.keys(defaults) as CmsSectionKey[]) {
    const incoming = parsed[key];
    if (incoming === undefined || incoming === null) continue;
    merged[key] = mergeSectionValue(defaults[key], incoming);
  }
  return repairKnownStaffSections(normalizeStaticAssetUrls(merged as unknown as CmsDatabase));
}

function readInitialCache(): void {
  if (typeof window === 'undefined') {
    memoryDb = normalizeStaticAssetUrls(memoryDb);
    currentDataSource = 'built-in defaults';
    return;
  }
  if (isStaticSiteMode() && window.__LKC_STATIC_SNAPSHOT__) {
    try {
      const snap = window.__LKC_STATIC_SNAPSHOT__;
      if (snap.sections) {
        memoryDb = mergeCachedSections(snap.sections);
        currentDataSource = 'static snapshot';
      } else {
        memoryDb = normalizeStaticAssetUrls(createDefaultCmsDatabase());
        currentDataSource = 'built-in defaults';
      }
      if (Array.isArray(snap.publishedItems)) {
        memoryItems = normalizeStaticAssetUrls(snap.publishedItems);
      }
      if (Array.isArray(snap.featuredItems)) {
        memoryFeaturedItems = normalizeStaticAssetUrls(snap.featuredItems);
      } else {
        memoryFeaturedItems = memoryItems.filter(
          (i) => i.status === 'published' && i.featureOnHomepage
        );
      }
      if (snap.academicLeadership) {
        memoryAcademicLeadership = normalizeStaticAssetUrls(snap.academicLeadership);
      }
      diagnosticsUpdatedAt = new Date().toISOString();
      return;
    } catch (err) {
      recordDiagnosticError(
        `Static snapshot load failed (${err instanceof Error ? err.message : String(err)}); using built-in defaults.`
      );
      memoryDb = normalizeStaticAssetUrls(createDefaultCmsDatabase());
      currentDataSource = 'built-in defaults';
      return;
    }
  }

  if (isStaticSiteMode()) {
    memoryDb = normalizeStaticAssetUrls(createDefaultCmsDatabase());
    memoryItems = normalizeStaticAssetUrls([...DEFAULT_CMS_ITEMS]);
    memoryFeaturedItems = memoryItems.filter(
      (i) => i.status === 'published' && i.featureOnHomepage
    );
    currentDataSource = 'built-in defaults';
    diagnosticsUpdatedAt = new Date().toISOString();
    return;
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<CmsDatabase>;
      memoryDb = mergeCachedSections(parsed);
    }
    const rawItems = window.localStorage.getItem(ITEMS_STORAGE_KEY);
    if (rawItems) {
      const parsedItems = JSON.parse(rawItems) as CmsItem[];
      if (Array.isArray(parsedItems)) {
        memoryItems = parsedItems;
        memoryFeaturedItems = parsedItems.filter(
          (i) => i.status === 'published' && i.featureOnHomepage
        );
      }
    }
    const rawLeadership = window.localStorage.getItem(LEADERSHIP_STORAGE_KEY);
    if (rawLeadership) {
      const parsedLead = JSON.parse(rawLeadership) as AcademicLeadershipBundle;
      if (parsedLead && Array.isArray(parsedLead.assignments)) {
        memoryAcademicLeadership = parsedLead;
      }
    }
  } catch (err) {
    memoryDb = createDefaultCmsDatabase();
    recordDiagnosticError(
      `Local cache read failed (${err instanceof Error ? err.message : String(err)}); using built-in defaults.`
    );
  }
  currentDataSource = 'built-in defaults';
}

if (typeof window !== 'undefined') {
  readInitialCache();
}

export async function refreshPublicBootstrap(): Promise<void> {
  if (isStaticSiteMode()) return;
  try {
    const payload = await apiFetch<{
      sections: CmsDatabase;
      featuredItems: CmsItem[];
      publishedItems: CmsItem[];
      academicLeadership?: AcademicLeadershipBundle;
    }>('/api/public/bootstrap');
    if (payload.sections) {
      memoryDb = mergeCachedSections(payload.sections);
    }
    if (Array.isArray(payload.publishedItems)) {
      memoryItems = payload.publishedItems;
    }
    if (Array.isArray(payload.featuredItems)) {
      memoryFeaturedItems = payload.featuredItems;
    }
    if (payload.academicLeadership) {
      memoryAcademicLeadership = payload.academicLeadership;
    }
    currentDataSource = 'API';
    diagnosticsUpdatedAt = new Date().toISOString();
    hydrateLocalCachesFromMemory();
    emitUpdate();
  } catch (err) {
    recordDiagnosticError(
      `API bootstrap unavailable (${err instanceof Error ? err.message : String(err)}); using ${currentDataSource}.`
    );
  }
}

export async function refreshAdminBootstrap(): Promise<{
  sections: CmsDatabase;
  items: CmsItem[];
  academicLeadership?: AcademicLeadershipBundle;
  user: CmsUser | null;
}> {
  const payload = await apiFetch<{
    sections: CmsDatabase;
    items: CmsItem[];
    academicLeadership?: AcademicLeadershipBundle;
    user: CmsUser;
  }>('/api/admin/bootstrap');
  if (payload.sections) {
    memoryDb = mergeCachedSections(payload.sections);
  }
  if (Array.isArray(payload.items)) {
    memoryItems = payload.items;
    memoryFeaturedItems = payload.items.filter(
      (i) => i.status === 'published' && i.featureOnHomepage
    );
  }
  if (payload.academicLeadership) {
    memoryAcademicLeadership = payload.academicLeadership;
  }
  currentDataSource = 'API';
  diagnosticsUpdatedAt = new Date().toISOString();
  hydrateLocalCachesFromMemory();
  emitUpdate();
  return payload;
}

export function initializeDefaultData(): CmsDatabase {
  readInitialCache();
  emitUpdate();
  if (!bootstrapStarted && typeof window !== 'undefined' && !isStaticSiteMode()) {
    bootstrapStarted = true;
    void refreshPublicBootstrap();
  }
  return memoryDb;
}

export function getAllCmsData(): CmsDatabase {
  return memoryDb;
}

export function getAcademicLeadershipSnapshot(): AcademicLeadershipBundle {
  return memoryAcademicLeadership;
}

export function getSectionData<K extends CmsSectionKey>(section: K): CmsDatabase[K] {
  const value = memoryDb[section];
  if (value === undefined || value === null) {
    return normalizeStaticAssetUrls(createDefaultCmsDatabase()[section]);
  }
  return value;
}

export async function updateSectionData<K extends CmsSectionKey>(
  section: K,
  data: CmsDatabase[K]
): Promise<CmsDatabase[K]> {
  const prev = memoryDb[section];
  memoryDb = { ...memoryDb, [section]: data };
  hydrateLocalCachesFromMemory();
  emitUpdate();

  try {
    const res = await apiFetch<{ ok: boolean; data: CmsDatabase[K] }>(
      `/api/admin/sections/${String(section)}`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      }
    );
    memoryDb = { ...memoryDb, [section]: res.data };
    hydrateLocalCachesFromMemory();
    emitUpdate();
    return res.data;
  } catch (err) {
    memoryDb = { ...memoryDb, [section]: prev };
    hydrateLocalCachesFromMemory();
    emitUpdate();
    throw err;
  }
}

async function submitToPhpEndpoint<T extends Record<string, unknown>>(
  action: string,
  payload: Record<string, unknown>
): Promise<T> {
  if (typeof window !== 'undefined' && window.location.protocol === 'file:') {
    throw new Error(
      'Direct form delivery is unavailable when opening the local file directly. Please call +267 316 1140 / +267 316 2208 or message WhatsApp +267 78 465 196.'
    );
  }

  let res: Response;
  try {
    res = await fetchWithTimeout(`./api.php?action=${encodeURIComponent(action)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...payload }),
    });
  } catch {
    throw new Error(
      'Could not reach our form service right now. Please call +267 316 1140 or +267 316 2208, or message WhatsApp +267 78 465 196.'
    );
  }

  const rawText = await res.text();
  let parsed: Record<string, unknown> = {};
  try {
    parsed = rawText ? (JSON.parse(rawText) as Record<string, unknown>) : {};
  } catch {
    parsed = {};
  }

  if (!res.ok || (parsed.status !== 'success' && parsed.ok !== true)) {
    const serverMsg =
      typeof parsed.message === 'string' && parsed.message
        ? parsed.message
        : 'Unable to submit your form automatically. Please call +267 316 1140 / +267 316 2208 or message WhatsApp +267 78 465 196.';
    throw new Error(serverMsg);
  }

  return parsed as T;
}

export async function submitPendingAlumni(
  submission: Omit<AlumniProfile, 'id' | 'status' | 'submittedAt'>
): Promise<{ ok: boolean; message: string; id: string }> {
  if (isStaticSiteMode()) {
    const res = await submitToPhpEndpoint<{ ok?: boolean; message?: string; id?: string }>(
      'alumni',
      submission as unknown as Record<string, unknown>
    );
    return {
      ok: true,
      message: res.message || 'Alumni profile submitted for verification.',
      id: res.id || `LKC-ALU-${Date.now()}`,
    };
  }
  return apiFetch<{ ok: boolean; message: string; id: string }>(
    '/api/public/alumni/register',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(submission),
    }
  );
}

export async function submitPublicEnquiry(payload: Record<string, unknown>): Promise<void> {
  if (isStaticSiteMode()) {
    const action =
      payload.type === 'admission'
        ? 'admission'
        : payload.type === 'boarding'
          ? 'boarding'
          : 'contact';
    await submitToPhpEndpoint(action, payload);
    return;
  }
  await apiFetch('/api/public/enquiries', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

export async function submitCampusTourBooking(payload: Record<string, unknown>): Promise<void> {
  if (isStaticSiteMode()) {
    await submitToPhpEndpoint('tour', payload);
    return;
  }
  await apiFetch('/api/public/tours', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

export async function submitProspectusRequest(payload: {
  name: string;
  email: string;
  phone?: string;
  level?: string;
}): Promise<void> {
  if (isStaticSiteMode()) {
    await submitToPhpEndpoint('prospectus', payload);
    return;
  }
  await apiFetch('/api/public/enquiries', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'prospectus', ...payload }),
  });
}

export async function resetAllCmsData(): Promise<CmsDatabase> {
  const res = await apiFetch<{ ok: boolean; sections: CmsDatabase }>('/api/admin/reset-defaults', {
    method: 'POST',
  });
  memoryDb = res.sections;
  hydrateLocalCachesFromMemory();
  emitUpdate();
  return memoryDb;
}

export function exportCmsJson(): string {
  return JSON.stringify(memoryDb, null, 2);
}

export async function exportFullBackupSnapshot(): Promise<Record<string, unknown>> {
  return apiFetch<Record<string, unknown>>('/api/admin/backup/export');
}

export async function restoreFullBackupSnapshot(snapshot: unknown): Promise<void> {
  await apiFetch('/api/admin/backup/restore', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(snapshot),
  });
  await refreshAdminBootstrap();
}

export async function downloadStaticWebsiteZip(): Promise<void> {
  const token = getStoredToken();
  const headers: Record<string, string> = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch('/api/admin/export-static', {
    method: 'GET',
    credentials: 'include',
    headers,
  });
  if (!res.ok) {
    let errMsg = `Export failed with status ${res.status}`;
    try {
      const json = await res.json();
      if (json?.error) errMsg = json.error;
    } catch {
      // Ignore parse error
    }
    throw new Error(errMsg);
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `lkc-public-website-static-${new Date().toISOString().split('T')[0]}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ────────────────────────────────────────────────────────────
// AUTHENTICATION & USER MANAGEMENT API
// ────────────────────────────────────────────────────────────

export async function getAuthSetupStatus(): Promise<{ needsInitialSetup: boolean }> {
  return apiFetch('/api/auth/setup-status');
}

export async function setupInitialSuperAdmin(payload: {
  username?: string;
  email: string;
  fullName: string;
  password: string;
}): Promise<CmsUser> {
  const res = await apiFetch<{ user: CmsUser; token: string }>('/api/auth/setup-initial-admin', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (res.token) setStoredToken(res.token);
  await refreshAdminBootstrap();
  return res.user;
}

export async function loginCmsAdmin(identifier: string, password: string): Promise<CmsUser> {
  const res = await apiFetch<{ user: CmsUser; token: string }>('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier, email: identifier, password }),
  });
  if (res.token) setStoredToken(res.token);
  if (!res.user.mustChangePassword) {
    await refreshAdminBootstrap();
  }
  return res.user;
}

export async function changeCmsPassword(
  currentPassword: string,
  newPassword: string
): Promise<CmsUser> {
  const res = await apiFetch<{ ok: boolean; user: CmsUser }>('/api/auth/change-password', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ currentPassword, newPassword }),
  });
  await refreshAdminBootstrap();
  return res.user;
}

export async function requestPasswordReset(identifier: string): Promise<{ ok: boolean; message: string }> {
  return apiFetch('/api/auth/request-reset', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier }),
  });
}

export async function resetPasswordWithToken(
  identifier: string,
  token: string,
  newPassword: string
): Promise<{ ok: boolean; message: string }> {
  return apiFetch('/api/auth/reset-password', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier, token, newPassword }),
  });
}

export async function logoutCmsAdmin(): Promise<void> {
  try {
    await apiFetch('/api/auth/logout', { method: 'POST' });
  } finally {
    setStoredToken(null);
    await refreshPublicBootstrap();
  }
}

export async function fetchCurrentCmsUser(): Promise<CmsUser | null> {
  if (isStaticSiteMode()) return null;
  try {
    const res = await apiFetch<{ user: CmsUser | null }>('/api/auth/me');
    return res.user;
  } catch {
    return null;
  }
}

export async function fetchAdminOverview(): Promise<{
  user: CmsUser;
  counts: {
    totalItems: number;
    publishedItems: number;
    draftItems: number;
    pendingItems: number;
    unpublishedItems: number;
    archivedItems: number;
    featuredOnHomepage: number;
    upcomingEventsCount: number;
    announcementsCount: number;
    departments: number;
    teachers: number;
    staffCount: number;
    incompleteStaffCount: number;
    headsOfYearCount: number;
    coordinatorsCount: number;
    pastoralCount: number;
    usersCount: number;
    alumniPending: number;
    alumniApproved: number;
    mediaCount: number;
    enquiriesCount: number;
    toursCount: number;
  };
  recentAuditLogs: AuditLogEntry[];
}> {
  return apiFetch('/api/admin/overview');
}

export async function fetchUsers(): Promise<CmsUser[]> {
  const res = await apiFetch<{ users: CmsUser[] }>('/api/admin/users');
  return res.users;
}

export async function createCmsUser(payload: {
  username?: string;
  email: string;
  fullName: string;
  password: string;
  role: UserRole;
  assignedPages: PageKey[];
  mustChangePassword?: boolean;
}): Promise<CmsUser> {
  const res = await apiFetch<{ user: CmsUser }>('/api/admin/users', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return res.user;
}

export async function updateCmsUser(
  id: string,
  payload: Partial<{
    username: string;
    fullName: string;
    role: UserRole;
    assignedPages: PageKey[];
    active: boolean;
    password: string;
  }>
): Promise<CmsUser> {
  const res = await apiFetch<{ user: CmsUser }>(`/api/admin/users/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return res.user;
}

export async function resetCmsUserPassword(
  id: string,
  temporaryPassword: string
): Promise<{ ok: boolean; temporaryPasswordIssued: boolean }> {
  return apiFetch(`/api/admin/users/${id}/reset-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ temporaryPassword }),
  });
}

export async function revokeCmsUserSessions(id: string): Promise<{ ok: boolean; revokedCount: number }> {
  return apiFetch(`/api/admin/users/${id}/sessions`, { method: 'DELETE' });
}

export async function deleteCmsUser(id: string): Promise<void> {
  await apiFetch(`/api/admin/users/${id}`, { method: 'DELETE' });
}

export async function fetchAuditLogs(limit = 150): Promise<AuditLogEntry[]> {
  const res = await apiFetch<{ logs: AuditLogEntry[] }>(`/api/admin/audit-logs?limit=${limit}`);
  return res.logs;
}

export async function fetchEnquiriesAndTours(): Promise<{
  enquiries: { id: string; type: string; payload: Record<string, unknown>; status: string; createdAt: string }[];
  tours: { id: string; payload: Record<string, unknown>; status: string; createdAt: string }[];
}> {
  const [enqRes, tourRes] = await Promise.all([
    apiFetch<{ enquiries: { id: string; type: string; payload: Record<string, unknown>; status: string; createdAt: string }[] }>('/api/admin/enquiries'),
    apiFetch<{ tours: { id: string; payload: Record<string, unknown>; status: string; createdAt: string }[] }>('/api/admin/tours'),
  ]);
  return { enquiries: enqRes.enquiries, tours: tourRes.tours };
}

// ────────────────────────────────────────────────────────────
// RELATIONAL STAFF & ACADEMIC / PASTORAL LEADERSHIP API
// ────────────────────────────────────────────────────────────

export async function fetchAdminAcademicLeadership(): Promise<AcademicLeadershipBundle> {
  const [staffRes, assignRes] = await Promise.all([
    apiFetch<{ staffMembers: StaffMember[] }>('/api/admin/staff'),
    apiFetch<{ assignments: AcademicAssignment[] }>('/api/admin/assignments'),
  ]);
  memoryAcademicLeadership = {
    staffMembers: staffRes.staffMembers,
    assignments: assignRes.assignments,
  };
  hydrateLocalCachesFromMemory();
  emitUpdate();
  return memoryAcademicLeadership;
}

export async function createStaffMember(
  payload: Omit<Partial<StaffMember>, 'id' | 'createdAt' | 'updatedAt'> & {
    surname: string;
    fullName: string;
  }
): Promise<StaffMember> {
  const res = await apiFetch<{ staffMember: StaffMember }>('/api/admin/staff', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  await refreshAdminBootstrap();
  return res.staffMember;
}

export async function updateStaffMember(
  id: string,
  payload: Partial<StaffMember>
): Promise<StaffMember> {
  const res = await apiFetch<{ staffMember: StaffMember }>(`/api/admin/staff/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  await refreshAdminBootstrap();
  return res.staffMember;
}

export async function deleteStaffMemberById(id: string, force = false): Promise<void> {
  await apiFetch(`/api/admin/staff/${id}${force ? '?force=true' : ''}`, { method: 'DELETE' });
  await refreshAdminBootstrap();
}

export async function createAcademicAssignment(
  payload: Omit<Partial<AcademicAssignment>, 'id' | 'createdAt' | 'updatedAt' | 'staff'> & {
    staffId: string;
    assignmentType: AcademicAssignment['assignmentType'];
    roleTitle: string;
  }
): Promise<AcademicAssignment> {
  const res = await apiFetch<{ assignment: AcademicAssignment }>('/api/admin/assignments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  await refreshAdminBootstrap();
  return res.assignment;
}

export async function updateAcademicAssignment(
  id: string,
  payload: Partial<AcademicAssignment>
): Promise<AcademicAssignment> {
  const res = await apiFetch<{ assignment: AcademicAssignment }>(`/api/admin/assignments/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  await refreshAdminBootstrap();
  return res.assignment;
}

export async function updateAcademicAssignmentStatus(
  id: string,
  status: PublishStatus
): Promise<AcademicAssignment> {
  const res = await apiFetch<{ assignment: AcademicAssignment }>(
    `/api/admin/assignments/${id}/status`,
    {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    }
  );
  await refreshAdminBootstrap();
  return res.assignment;
}

export async function deleteAcademicAssignmentById(id: string): Promise<void> {
  await apiFetch(`/api/admin/assignments/${id}`, { method: 'DELETE' });
  await refreshAdminBootstrap();
}

// ────────────────────────────────────────────────────────────
// PAGE-SEPARATED CMS ITEMS & FEATURED CONTROL API
// ────────────────────────────────────────────────────────────

export async function fetchAdminItems(pageKey?: PageKey): Promise<CmsItem[]> {
  const q = pageKey ? `?pageKey=${encodeURIComponent(pageKey)}` : '';
  const res = await apiFetch<{ items: CmsItem[] }>(`/api/admin/items${q}`);
  return res.items;
}

export async function createCmsItem(payload: Partial<CmsItem> & { pageKey: PageKey; title: string }): Promise<CmsItem> {
  const res = await apiFetch<{ item: CmsItem }>('/api/admin/items', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  await refreshAdminBootstrap();
  return res.item;
}

export async function updateCmsItem(
  id: string,
  payload: Partial<Omit<CmsItem, 'thumbnailUrl' | 'mediaUrl'>> & {
    thumbnailUrl?: string | null;
    mediaUrl?: string | null;
  }
): Promise<CmsItem> {
  const res = await apiFetch<{ item: CmsItem }>(`/api/admin/items/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  await refreshAdminBootstrap();
  return res.item;
}

export async function toggleFeatureOnHomepage(id: string, featureOnHomepage: boolean): Promise<CmsItem> {
  const res = await apiFetch<{ item: CmsItem }>(`/api/admin/items/${id}/feature`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ featureOnHomepage }),
  });
  await refreshAdminBootstrap();
  return res.item;
}

export async function changeItemStatus(id: string, status: PublishStatus): Promise<CmsItem> {
  const res = await apiFetch<{ item: CmsItem }>(`/api/admin/items/${id}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status }),
  });
  await refreshAdminBootstrap();
  return res.item;
}

export async function deleteCmsItem(id: string): Promise<void> {
  await apiFetch(`/api/admin/items/${id}`, { method: 'DELETE' });
  await refreshAdminBootstrap();
}

// ────────────────────────────────────────────────────────────
// MEDIA LIBRARY API (REAL DISK UPLOAD & METADATA)
// ────────────────────────────────────────────────────────────

export async function uploadMediaFile(
  file: File,
  metadata: { name?: string; category?: string; description?: string }
): Promise<MediaAsset> {
  const form = new FormData();
  form.append('file', file);
  if (metadata.name) form.append('name', metadata.name);
  if (metadata.category) form.append('category', metadata.category);
  if (metadata.description) form.append('description', metadata.description);

  const token = getStoredToken();
  const headers: Record<string, string> = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch('/api/admin/media/upload', {
    method: 'POST',
    credentials: 'include',
    headers,
    body: form,
  });
  const body = await res.json();
  if (!res.ok) throw new Error(body.error || 'Media upload failed.');

  memoryDb = { ...memoryDb, media: [body.asset, ...memoryDb.media] };
  hydrateLocalCachesFromMemory();
  emitUpdate();
  return body.asset;
}

export async function addMediaEmbed(payload: {
  name: string;
  url: string;
  category: string;
  mediaType?: 'embed' | 'video' | 'image';
  description?: string;
}): Promise<MediaAsset> {
  const res = await apiFetch<{ asset: MediaAsset }>('/api/admin/media/embed', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  memoryDb = { ...memoryDb, media: [res.asset, ...memoryDb.media] };
  hydrateLocalCachesFromMemory();
  emitUpdate();
  return res.asset;
}

export async function updateMediaAsset(
  id: string,
  payload: { name: string; category: string; description?: string }
): Promise<MediaAsset> {
  const res = await apiFetch<{ asset: MediaAsset }>(`/api/admin/media/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  memoryDb = {
    ...memoryDb,
    media: memoryDb.media.map((m) => (m.id === id ? res.asset : m)),
  };
  hydrateLocalCachesFromMemory();
  emitUpdate();
  return res.asset;
}

export async function deleteMediaAssetById(id: string, force = false): Promise<void> {
  await apiFetch(`/api/admin/media/${id}${force ? '?force=true' : ''}`, { method: 'DELETE' });
  memoryDb = {
    ...memoryDb,
    media: memoryDb.media.filter((m) => m.id !== id),
  };
  hydrateLocalCachesFromMemory();
  emitUpdate();
}

// ────────────────────────────────────────────────────────────
// REACTIVE HOOKS
// ────────────────────────────────────────────────────────────

export function useCmsSection<K extends CmsSectionKey>(section: K): CmsDatabase[K] {
  const [data, setData] = useState<CmsDatabase[K]>(() => getSectionData(section));

  useEffect(() => {
    const sync = () => {
      setData(getSectionData(section));
    };
    window.addEventListener(CMS_EVENT, sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener(CMS_EVENT, sync);
      window.removeEventListener('storage', sync);
    };
  }, [section]);

  return data;
}

export function useAcademicLeadership(): AcademicLeadershipBundle {
  const [bundle, setBundle] = useState<AcademicLeadershipBundle>(() => memoryAcademicLeadership);

  useEffect(() => {
    const sync = () => setBundle({ ...memoryAcademicLeadership });
    sync();
    window.addEventListener(CMS_EVENT, sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener(CMS_EVENT, sync);
      window.removeEventListener('storage', sync);
    };
  }, []);

  return bundle;
}

export function useFeaturedCmsItems(): CmsItem[] {
  const [items, setItems] = useState<CmsItem[]>(() => memoryFeaturedItems);

  useEffect(() => {
    const sync = () => setItems([...memoryFeaturedItems]);
    window.addEventListener(CMS_EVENT, sync);
    return () => window.removeEventListener(CMS_EVENT, sync);
  }, []);

  return items;
}

export function usePublishedCmsItems(pageKey?: PageKey): CmsItem[] {
  const [items, setItems] = useState<CmsItem[]>(() =>
    pageKey ? memoryItems.filter((i) => i.pageKey === pageKey && i.status === 'published') : memoryItems
  );

  useEffect(() => {
    const sync = () => {
      setItems(
        pageKey
          ? memoryItems.filter((i) => i.pageKey === pageKey && i.status === 'published')
          : memoryItems
      );
    };
    sync();
    window.addEventListener(CMS_EVENT, sync);
    return () => window.removeEventListener(CMS_EVENT, sync);
  }, [pageKey]);

  return items;
}

export function useCmsDiagnostics(): CmsDiagnosticsSnapshot {
  const [diag, setDiag] = useState<CmsDiagnosticsSnapshot>(() => getCmsDiagnostics());

  useEffect(() => {
    const sync = () => setDiag(getCmsDiagnostics());
    sync();
    window.addEventListener(CMS_EVENT, sync);
    return () => window.removeEventListener(CMS_EVENT, sync);
  }, []);

  return diag;
}
