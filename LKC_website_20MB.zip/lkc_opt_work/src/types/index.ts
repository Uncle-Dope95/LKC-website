export interface SubjectInfo {
  code: string;
  name: string;
  stream: 'Sciences' | 'Commercial' | 'Humanities' | 'Languages' | 'Creative & Tech' | 'Early Years';
  description: string;
  cambridgeCode?: string;
  isCore?: boolean;
}

export interface DepartmentInfo {
  id: string;
  name: string;
  slug: string;
  headOfDepartment: {
    name: string;
    title: string;
    image?: string;
    welcomeMessage?: string;
    vision?: string;
    qualifications?: string;
    bio?: string;
    status?: PublishStatus;
  };
  shortDescription: string;
  curriculum: string;
  subjects: string[];
  keyAreas?: string[];
  features: string[];
  facilities?: string[];
  achievements?: string[];
  activities?: string[];
  news?: string[];
  cambridgeNote?: string;
  icon: string;
}

export interface LeadershipMember {
  id?: string;
  name: string;
  role: string;
  title: string;
  qualifications?: string;
  bio: string;
  image?: string;
  message?: string;
  department?: string;
  isSMT?: boolean;
  order?: number;
  status?: PublishStatus;
}

export interface HouseInfo {
  id?: string;
  name: string;
  colorName?: string;
  colorHex?: string;
  badgeUrl?: string;
  photoUrl?: string;
  color: string;
  textColor: string;
  bgColor: string;
  motto?: string;
  patron: string;
  points?: number;
  description: string;
  position?: number;
  positionLabel?: string;
}

export interface TermDate {
  term: string;
  title: string;
  start: string;
  end: string;
  midTermBreak: string;
  milestones: string[];
}

export interface AchievementItem {
  year: string;
  student: string;
  achievement: string;
  destination: string;
  course: string;
}

export interface ExcursionItem {
  id: string;
  title: string;
  category: 'International' | 'Regional' | 'National';
  year?: string;
  destination: string;
  targetForms: string;
  duration: string;
  description: string;
  curriculumLink: string;
  highlights: string[];
  image?: string;
}

export interface AlumniProfile {
  id: string;
  name: string;
  gradYear: string;
  currentRole: string;
  organization: string;
  university: string;
  location: string;
  course: string;
  quote: string;
  cambridgeHonors: string;
  email?: string;
  phone?: string;
  willingToMentor?: boolean;
  image?: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt?: string;
}

export interface ApplicationFormData {
  studentFirstName: string;
  studentLastName: string;
  dateOfBirth: string;
  gender: string;
  currentSchool: string;
  gradeApplying: string;
  entryTerm: string;
  status: 'Day' | 'Boarding';
  parentName: string;
  parentEmail: string;
  parentPhone: string;
  parentAddress: string;
  selectedStream?: string;
  specialNeedsNotes?: string;
}

export interface CambridgeLearnerAward {
  id: string;
  studentName: string;
  awardType: 'Top in the World' | 'Top in Botswana' | 'High Achievement';
  level: 'Cambridge IGCSE' | 'Cambridge AS Level' | 'Cambridge A2 Level';
  subject: string;
  image: string;
  year: string;
  grades?: string;
  highlightNote?: string;
}

export interface AchieverItem {
  id: string;
  studentName: string;
  level: 'Cambridge IGCSE' | 'Cambridge AS Level' | 'Cambridge A2 Level';
  grades: string;
  year?: string;
  starCount?: number;
  featuredAward?: string;
}

export type StaffLeadershipPosition = 'hod' | 'deputy_hod' | 'teacher' | 'support';

export interface TeacherProfile {
  id: string;
  name: string;
  departmentId: string;
  departmentName: string;
  role?: string;
  title?: string;
  subjects?: string[];
  image?: string;
  bio?: string;
  qualifications?: string;
  leadershipPosition?: StaffLeadershipPosition;
  order?: number;
  status?: PublishStatus;
}

export interface BoardingHostel {
  id: string;
  name: string;
  wing: string;
  capacityBadge: string;
  capacity: number;
  description: string;
  leaderName: string;
  leaderRole: string;
  leaderTitle: string;
  leaderImage?: string;
  quoteTitle: string;
  quote: string;
  features: string[];
  applyCta: string;
}

export interface BoardingRoutineStep {
  time: string;
  activity: string;
  notes: string;
}

export interface LightsOutGroup {
  group: string;
  grades: string;
  time: string;
  rationale: string;
}

export interface BoardingMeal {
  meal: string;
  time: string;
  details: string;
}

export interface BoardingData {
  capacity: number;
  currentResidents: number;
  spacesOpen: number;
  headline: string;
  subheadline: string;
  leadParagraph: string;
  capacityNotice: string;
  entranceBanner: string;
  officialTitle: string;
  bannerImage?: string;
  housesSubhead: string;
  housesLead: string;
  hostels: BoardingHostel[];
  morningRoutine: BoardingRoutineStep[];
  eveningRoutine: BoardingRoutineStep[];
  lightsOutSchedule: LightsOutGroup[];
  cafeteria: {
    title: string;
    headline: string;
    subheadline: string;
    description: string;
    meals: BoardingMeal[];
  };
  communityPillars: {
    title: string;
    desc: string;
  }[];
}

export interface CurriculumLevel {
  title: string;
  subtitle: string;
  description: string;
  subjects: SubjectInfo[];
}

export interface RugbyFixture {
  id: string;
  opponent: string;
  venue: string;
  date: string;
  tournament: string;
  status: string;
}

export interface HeroConfig {
  badgeText: string;
  headlineTop: string;
  headlineAccent: string;
  headlineBottom: string;
  description: string;
  heroImage: string;
  stat1Value: string;
  stat1Label: string;
  stat2Value: string;
  stat2Label: string;
  stat3Value: string;
  stat3Label: string;
  stat4Value: string;
  stat4Label: string;
  highlights: { label: string; sub: string }[];
}

export interface AboutConfig {
  heritageBadge: string;
  heritageHeading: string;
  heritageParagraph1: string;
  heritageParagraph2: string;
  heritagePoints: { title: string; subtitle: string }[];
  missionTitle: string;
  missionText: string;
  visionTitle: string;
  visionText: string;
  valuesList: string[];
  leadership: LeadershipMember[];
  directors?: LeadershipMember[];
}

export interface BuildingProjectData {
  title: string;
  subtitle: string;
  tagline: string;
  signature: string;
  status: string;
  timeline: {
    start: string;
    completion: string;
  };
  keyMetrics: { label: string; value: string; detail: string }[];
  images: { url: string; caption: string; tag: string }[];
  story: string;
  features: string[];
}

export interface SportsData {
  name: string;
  motto: string;
  identity: string;
  colors: string[];
  intro: string;
  facilities: { name: string; description: string; icon: string }[];
  codes: { name: string; division: string; season: string; accolades: string }[];
  photos?: { url: string; title: string; category: string; caption: string; location?: string; status?: PublishStatus }[];
  houseTrophyRace: {
    year: string;
    trophyName: string;
    description: string;
    standings: { house: string; color: string; colorName?: string; patron?: string; points?: number; leader?: boolean; highlight: string }[];
  };
}

export interface JaguarsRugbyData {
  name: string;
  clubName: string;
  shortName: string;
  motto: string;
  mottoLatin: string;
  tagline: string;
  identity: string;
  established: string;
  headCoach: string;
  forwardsCoach: string;
  backsCoach: string;
  homeGround: string;
  teamColors: {
    primary: string;
    accent: string;
    secondary: string;
  };
  overview: string;
  creed: { title: string; desc: string }[];
  squads: {
    name: string;
    tier: string;
    captain: string;
    viceCaptain?: string;
    description: string;
    record2025: string;
  }[];
  fixtures2026: RugbyFixture[];
  positionsPack: { unit: string; roles: string; duty: string }[];
  honours: { year: string; title: string; level: string }[];
  trainingSchedule: { day: string; time: string; focus: string; venue: string }[];
  photos?: { url: string; title: string; category: string; caption: string; location?: string; status?: PublishStatus }[];
}

export interface AchieversSummary {
  headline: string;
  subheadline: string;
  anniversary: string;
  igcsePassRate: string;
  igcseCreditPassRate: string;
  aLevelPassRate: string;
  description: string;
  bannerImages: {
    igcseHero: string;
    newspaperSpread: string;
    dozenAchievers: string;
  };
}

export interface BankAccount {
  bankName: string;
  accountName: string;
  accountNumber: string;
  branch: string;
  branchCode: string;
  swiftCode: string;
}

export interface TuitionBand {
  term: number;
  annual: number;
  termsCount: number;
  label: string;
  installments: {
    termName: string;
    pay1: number;
    due1: string;
    pay2: number;
    due2: string;
  }[];
}

export interface FeeStructureData {
  currency: string;
  academicYear: string;
  pdfDocumentUrl: string;
  oneOffFees: {
    entranceAssessment: number;
    registrationEnrollment: number;
    developmentLevyForms1to5: number;
    developmentLevyALevel: number;
  };
  tuitionPerTerm: Record<string, TuitionBand>;
  boardingSchedule: {
    annual: number;
    term1: number;
    term2: number;
    term3: number;
    description: string;
  };
  boardingPerTerm: number;
  annualDiscountPercentage: number;
  siblingDiscountPercentage: number;
  transportRoutes: { zone: string; costPerTerm: number }[];
  optionalServices: { id: string; name: string; costPerTerm: number }[];
}

export interface FaqItem {
  q: string;
  a: string;
}

export interface GeneralConfig {
  name: string;
  shortName: string;
  motto: string;
  mottoEnglish: string;
  cambridgeCentreNo: string;
  established: string;
  logoUrl: string;
  historicalRoots: string;
  mascot: string;
  admissionsPortalUrl: string;
  parentsPortalUrl: string;
  teachersPortalUrl: string;
  portalHomeUrl: string;
  googleMapsDirectionsUrl: string;
  socials: {
    tiktok: string;
    tiktokHandle: string;
    instagram: string;
    instagramHandle: string;
    facebook: string;
    facebookHandle: string;
    whatsapp: string;
    whatsappNumber: string;
  };
  address: {
    plot: string;
    area: string;
    city: string;
    country: string;
    postalBox: string;
    gps: string;
  };
  contacts: {
    phone: string;
    phoneSecondary: string;
    phoneAlternate: string;
    fax: string;
    mobile: string;
    whatsapp: string;
    bursarWhatsapp: string;
    bursarWhatsappLink: string;
    principalEmail: string;
    admissionsEmail: string;
    admissionsAltEmail: string;
    accountsEmail: string;
    feePolicyPdfUrl: string;
    officeHours: string;
  };
}

export interface AnnouncementItem {
  id: string;
  title: string;
  date: string;
  category: string;
  body: string;
  active: boolean;
  thumbnailUrl?: string;
  featureOnHomepage?: boolean;
  status?: PublishStatus;
  publishAt?: string;
}

export interface MediaAsset {
  id: string;
  name: string;
  filename?: string;
  url: string;
  category: string;
  mediaType?: 'image' | 'video' | 'pdf' | 'document' | 'embed';
  mimeType?: string;
  sizeBytes?: number;
  description?: string;
  uploadedAt: string;
  usedIn?: string[];
}

export type UserRole = 'super_admin' | 'admin' | 'content_editor';

export type PublishStatus = 'draft' | 'pending' | 'published' | 'unpublished' | 'archived';

export type PageKey =
  | 'home'
  | 'campus'
  | 'boarding'
  | 'excursions'
  | 'alumni'
  | 'achievers'
  | 'sports'
  | 'athletics'
  | 'jaguars'
  | 'departments'
  | 'curriculum'
  | 'fees'
  | 'contact'
  | 'news'
  | 'events';

export interface CmsUser {
  id: string;
  username?: string;
  email: string;
  fullName: string;
  role: UserRole;
  assignedPages: PageKey[];
  active: boolean;
  mustChangePassword?: boolean;
  failedLoginAttempts?: number;
  lockedUntil?: string | null;
  createdAt: string;
  lastLoginAt?: string | null;
}

export interface CmsItem {
  id: string;
  pageKey: PageKey;
  category: string;
  academicYear?: string;
  title: string;
  slug: string;
  excerpt: string;
  content: Record<string, unknown>;
  thumbnailUrl?: string;
  mediaUrl?: string;
  status: PublishStatus;
  featureOnHomepage: boolean;
  publishAt?: string;
  eventDate?: string;
  eventTime?: string;
  eventLocation?: string;
  eventCompleted?: boolean;
  sortOrder: number;
  createdBy?: string;
  updatedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface NavigationItemConfig {
  id: string;
  label: string;
  sublabel: string;
  pageKey: PageKey;
  badge?: string;
  visible: boolean;
  order: number;
}

export interface FooterConfig {
  tagline: string;
  bottomNotice: string;
  copyrightText: string;
  quickLinksTitle: string;
  admissionsTitle: string;
  showSocialLinks: boolean;
}

export interface WebsiteSettingsConfig {
  siteTitle: string;
  metaDescription: string;
  admissionsOpen: boolean;
  activeAchieversYear: string;
  maintenanceMode: boolean;
  allowPublicAlumniRegistration: boolean;
  homepageMaxFeaturedItems: number;
}

export interface AthleticsData {
  headline: string;
  subheadline: string;
  description: string;
  seasonSummary: string;
  events: { name: string; category: 'Track' | 'Field' | 'Relay'; records: string; ageGroups: string }[];
  competitions: { name: string; date: string; venue: string; highlights: string; status: string }[];
  records: { event: string; athlete: string; mark: string; year: string; category: string }[];
  photos: { url: string; title: string; category: string; caption: string; location?: string; status?: PublishStatus }[];
}

export interface AuditLogEntry {
  id: number;
  userId: string;
  userEmail: string;
  userRole: string;
  action: string;
  targetType: string;
  targetId: string;
  summary: string;
  createdAt: string;
}

export type YearGroupKey = 'Form 1' | 'Form 2' | 'Form 3' | 'Form 4' | 'Form 5' | 'A Level';
export type AcademicAssignmentType = 'head_of_year' | 'a_level_coordinator' | 'pastoral_care';

export interface StaffMember {
  id: string;
  surname: string;
  fullName: string;
  displayTitle?: string;
  department?: string;
  subjects?: string[];
  image?: string | null;
  bio?: string;
  qualifications?: string;
  email?: string;
  status: PublishStatus;
  isIncomplete?: boolean;
  incompleteReason?: string;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface AcademicAssignment {
  id: string;
  staffId: string;
  assignmentType: AcademicAssignmentType;
  roleTitle: string;
  yearGroup?: YearGroupKey | null;
  summary?: string;
  responsibilities?: string;
  welcomeMessage?: string;
  status: PublishStatus;
  sortOrder: number;
  archivedAt?: string | null;
  createdAt: string;
  updatedAt: string;
  staff?: StaffMember | null;
}

export interface AcademicLeadershipBundle {
  staffMembers: StaffMember[];
  assignments: AcademicAssignment[];
}

