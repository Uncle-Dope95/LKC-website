import type React from 'react';

export const FALLBACK_LOGO_SRC = './assets/aistudio/logo_33a39ff7.png';

export function handleImageFallback(e: React.SyntheticEvent<HTMLImageElement>): void {
  const img = e.currentTarget;
  const currentAttrSrc = img.getAttribute('src') || '';

  if (!currentAttrSrc || currentAttrSrc === FALLBACK_LOGO_SRC || img.src.endsWith('/logo_33a39ff7.png')) {
    return;
  }

  // Allow one clean retry (normalizing root-relative paths on subpaths or transient network glitches)
  if (img.dataset.lkcRetryAttempt !== currentAttrSrc) {
    img.dataset.lkcRetryAttempt = currentAttrSrc;
    const normalized =
      currentAttrSrc.startsWith('/assets/') || currentAttrSrc.startsWith('/uploads/')
        ? `.${currentAttrSrc}`
        : currentAttrSrc;
    const isHttp = typeof window !== 'undefined' && /^https?:$/i.test(window.location.protocol);
    if (isHttp && !normalized.startsWith('data:') && !normalized.startsWith('blob:')) {
      const sep = normalized.includes('?') ? '&' : '?';
      img.src = `${normalized}${sep}r=1`;
      return;
    }
    if (normalized !== currentAttrSrc) {
      img.src = normalized;
      return;
    }
  }

  if (img.dataset.lkcFallbackFor === currentAttrSrc) return;
  img.dataset.lkcFallbackFor = currentAttrSrc;
  img.src = FALLBACK_LOGO_SRC;
}
