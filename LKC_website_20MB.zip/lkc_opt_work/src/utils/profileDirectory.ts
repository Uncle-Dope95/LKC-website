import type {
  AboutConfig,
  AcademicLeadershipBundle,
  BoardingData,
  BoardingHostel,
  DepartmentInfo,
  LeadershipMember,
  PublishStatus,
  StaffMember,
  TeacherProfile,
} from '../types';
import { getSectionData, updateSectionData, updateStaffMember } from '../services/cmsDataService';
import { isMissingPortrait } from './profileSearch';
import { normalizePersonName } from './staffHierarchy';

export type UnifiedProfileKind =
  | 'staff_member'
  | 'teacher'
  | 'hod'
  | 'smt'
  | 'director'
  | 'boarding';

export interface UnifiedProfileEntry {
  uid: string;
  kind: UnifiedProfileKind;
  kindLabel: string;
  sourceId: string;
  name: string;
  surname: string;
  role: string;
  department: string;
  image: string;
  missingPortrait: boolean;
  status: PublishStatus;
  searchFields: string[];
  rawStaff?: StaffMember;
  rawTeacher?: TeacherProfile;
  rawDept?: DepartmentInfo;
  rawLeader?: LeadershipMember;
  rawHostel?: BoardingHostel;
}

function extractSurname(name: string): string {
  const parts = String(name || '')
    .replace(/^(Mr|Mrs|Ms|Miss|Dr|Prof)\.?\s+/i, '')
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  return parts.length > 0 ? parts[parts.length - 1] : name;
}

export function buildUnifiedProfileDirectory(params: {
  academicLeadership?: AcademicLeadershipBundle;
  teachers?: TeacherProfile[];
  departments?: DepartmentInfo[];
  about?: AboutConfig;
  boarding?: BoardingData;
}): UnifiedProfileEntry[] {
  const entries: UnifiedProfileEntry[] = [];

  for (const s of params.academicLeadership?.staffMembers || []) {
    const img = s.image || '';
    entries.push({
      uid: `staff:${s.id}`,
      kind: 'staff_member',
      kindLabel: 'Year-Group / Pastoral',
      sourceId: s.id,
      name: s.fullName,
      surname: s.surname || extractSurname(s.fullName),
      role: s.displayTitle || 'Academic / Pastoral Leadership',
      department: s.department || 'Academic & Pastoral Leadership',
      image: img,
      missingPortrait: isMissingPortrait(img),
      status: s.status,
      searchFields: [
        s.fullName,
        s.surname,
        s.displayTitle || '',
        s.department || '',
        (s.subjects || []).join(' '),
        s.qualifications || '',
      ],
      rawStaff: s,
    });
  }

  for (const l of params.about?.leadership || []) {
    const id = l.id || l.name;
    const img = l.image || '';
    entries.push({
      uid: `smt:${id}`,
      kind: 'smt',
      kindLabel: 'SMT Leader',
      sourceId: id,
      name: l.name,
      surname: extractSurname(l.name),
      role: l.role || l.title || 'Senior Management',
      department: l.department || 'Senior Management Team',
      image: img,
      missingPortrait: isMissingPortrait(img),
      status: l.status || 'published',
      searchFields: [l.name, l.role, l.title, l.department || '', l.qualifications || ''],
      rawLeader: l,
    });
  }

  for (const d of params.about?.directors || []) {
    const id = d.id || d.name;
    const img = d.image || '';
    entries.push({
      uid: `director:${id}`,
      kind: 'director',
      kindLabel: 'Director',
      sourceId: id,
      name: d.name,
      surname: extractSurname(d.name),
      role: d.role || d.title || 'College Director',
      department: d.department || 'Board of Directors',
      image: img,
      missingPortrait: isMissingPortrait(img),
      status: d.status || 'published',
      searchFields: [d.name, d.role, d.title, d.department || '', d.qualifications || ''],
      rawLeader: d,
    });
  }

  for (const dept of params.departments || []) {
    const hod = dept.headOfDepartment;
    if (!hod?.name) continue;
    const img = hod.image || '';
    entries.push({
      uid: `hod:${dept.id}`,
      kind: 'hod',
      kindLabel: 'Head of Dept (HOD)',
      sourceId: dept.id,
      name: hod.name,
      surname: extractSurname(hod.name),
      role: hod.title || `HOD · ${dept.name}`,
      department: dept.name,
      image: img,
      missingPortrait: isMissingPortrait(img),
      status: hod.status || 'published',
      searchFields: [hod.name, hod.title, dept.name, hod.qualifications || ''],
      rawDept: dept,
    });
  }

  for (const t of params.teachers || []) {
    const img = t.image || '';
    entries.push({
      uid: `teacher:${t.id}`,
      kind: 'teacher',
      kindLabel: 'Teacher',
      sourceId: t.id,
      name: t.name,
      surname: extractSurname(t.name),
      role: t.role || 'Subject Teacher',
      department: t.departmentName || 'Academic Department',
      image: img,
      missingPortrait: isMissingPortrait(img),
      status: t.status || 'published',
      searchFields: [
        t.name,
        t.title || '',
        t.role || '',
        t.departmentName,
        (t.subjects || []).join(' '),
        t.qualifications || '',
      ],
      rawTeacher: t,
    });
  }

  for (const h of params.boarding?.hostels || []) {
    const img = h.leaderImage || '';
    entries.push({
      uid: `boarding:${h.id}`,
      kind: 'boarding',
      kindLabel: 'Boarding Staff',
      sourceId: h.id,
      name: h.leaderName,
      surname: extractSurname(h.leaderName),
      role: h.leaderRole || h.leaderTitle || 'Boarding Master / Mistress',
      department: h.name,
      image: img,
      missingPortrait: isMissingPortrait(img),
      status: 'published',
      searchFields: [h.leaderName, h.leaderRole, h.leaderTitle, h.name],
      rawHostel: h,
    });
  }

  return entries;
}

export async function assignPortraitToUnifiedProfile(
  entry: UnifiedProfileEntry,
  imageUrl: string | null
): Promise<string[]> {
  const cleanUrl = (imageUrl || '').trim();
  const updatedTargets: string[] = [];
  const normTarget = normalizePersonName(entry.name);

  if (entry.kind === 'staff_member' && entry.rawStaff) {
    await updateStaffMember(entry.sourceId, {
      image: cleanUrl || null,
    });
    updatedTargets.push(`${entry.name} (Year-Group / Pastoral Staff)`);
  }

  if (entry.kind === 'teacher' && entry.rawTeacher) {
    const currentTeachers = getSectionData('teachers');
    const nextTeachers = currentTeachers.map((t) =>
      t.id === entry.sourceId ? { ...t, image: cleanUrl || undefined } : t
    );
    await updateSectionData('teachers', nextTeachers);
    updatedTargets.push(`${entry.name} (Teachers Directory)`);

    // Cross-sync matching HOD portrait in the same department when person names match
    const currentDepts = getSectionData('departments');
    let hodChanged = false;
    const nextDepts = currentDepts.map((d) => {
      if (
        d.id === entry.rawTeacher?.departmentId &&
        normalizePersonName(d.headOfDepartment?.name) === normTarget
      ) {
        hodChanged = true;
        return {
          ...d,
          headOfDepartment: {
            ...d.headOfDepartment,
            image: cleanUrl || undefined,
          },
        };
      }
      return d;
    });
    if (hodChanged) {
      await updateSectionData('departments', nextDepts);
      updatedTargets.push(`${entry.department} HOD card`);
    }
  }

  if (entry.kind === 'hod' && entry.rawDept) {
    const currentDepts = getSectionData('departments');
    const nextDepts = currentDepts.map((d) =>
      d.id === entry.sourceId
        ? {
            ...d,
            headOfDepartment: {
              ...d.headOfDepartment,
              image: cleanUrl || undefined,
            },
          }
        : d
    );
    await updateSectionData('departments', nextDepts);
    updatedTargets.push(`${entry.name} (${entry.department} HOD)`);

    // Cross-sync matching teacher record in that department
    const currentTeachers = getSectionData('teachers');
    let teacherChanged = false;
    const nextTeachers = currentTeachers.map((t) => {
      if (
        t.departmentId === entry.sourceId &&
        normalizePersonName(t.name) === normTarget
      ) {
        teacherChanged = true;
        return { ...t, image: cleanUrl || undefined };
      }
      return t;
    });
    if (teacherChanged) {
      await updateSectionData('teachers', nextTeachers);
      updatedTargets.push(`${entry.name} (Teachers Directory)`);
    }
  }

  if (entry.kind === 'smt' && entry.rawLeader) {
    const currentAbout = getSectionData('about');
    const nextLeadership = (currentAbout.leadership || []).map((l) =>
      (l.id || l.name) === entry.sourceId ? { ...l, image: cleanUrl || undefined } : l
    );
    await updateSectionData('about', { ...currentAbout, leadership: nextLeadership });
    updatedTargets.push(`${entry.name} (Senior Management Team)`);
  }

  if (entry.kind === 'director' && entry.rawLeader) {
    const currentAbout = getSectionData('about');
    const nextDirectors = (currentAbout.directors || []).map((d) =>
      (d.id || d.name) === entry.sourceId ? { ...d, image: cleanUrl || undefined } : d
    );
    await updateSectionData('about', { ...currentAbout, directors: nextDirectors });
    updatedTargets.push(`${entry.name} (College Directors)`);
  }

  if (entry.kind === 'boarding' && entry.rawHostel) {
    const currentBoarding = getSectionData('boarding');
    const nextHostels = (currentBoarding.hostels || []).map((h) =>
      h.id === entry.sourceId ? { ...h, leaderImage: cleanUrl || undefined } : h
    );
    await updateSectionData('boarding', { ...currentBoarding, hostels: nextHostels });
    updatedTargets.push(`${entry.name} (${entry.department})`);
  }

  return updatedTargets;
}
