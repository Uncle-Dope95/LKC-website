export function normalizeSearchText(value?: string | null): string {
  return String(value || '')
    .toLowerCase()
    .replace(/[.,;:'"()/\\_-]+/g, ' ')
    .replace(/\bothimile\b/g, 'othomile')
    .replace(/\bkandembo\b/g, 'kadembo')
    .replace(/\bmodimofile\b/g, 'modimoofile')
    .replace(/\bbarrot\b/g, 'barot')
    .replace(/\s+/g, ' ')
    .trim();
}

export function tokenizeSearchQuery(query?: string | null): string[] {
  const normalized = normalizeSearchText(query);
  if (!normalized) return [];
  return normalized.split(' ').filter(Boolean);
}

export function matchesSearchTokens(
  query: string,
  fields: Array<string | string[] | undefined | null>
): boolean {
  const tokens = tokenizeSearchQuery(query);
  if (tokens.length === 0) return true;

  const haystack = fields
    .map((field) => (Array.isArray(field) ? field.join(' ') : String(field || '')))
    .map((part) => normalizeSearchText(part))
    .filter(Boolean)
    .join(' ');

  if (!haystack) return false;
  return tokens.every((token) => haystack.includes(token));
}

export function isMissingPortrait(url?: string | null): boolean {
  if (!url || !url.trim()) return true;
  return /logo_33a39ff7\.png/i.test(url);
}
