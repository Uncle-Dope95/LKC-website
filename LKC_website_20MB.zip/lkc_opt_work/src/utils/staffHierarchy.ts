import type {
  DepartmentInfo,
  LeadershipMember,
  StaffLeadershipPosition,
  TeacherProfile,
} from '../types/index.ts';

export const DEFAULT_DIRECTORS: LeadershipMember[] = [
  {
    id: 'dir-dove',
    name: 'Mrs Dove',
    role: 'Director of Lower School',
    title: 'Director of Lower School',
    bio: '',
    image: './assets/aistudio/Dove_794935a1.jpg',
    order: 1,
    status: 'published',
  },
  {
    id: 'dir-wilson',
    name: 'Mr Wilson',
    role: 'Director of Upper School',
    title: 'Director of Upper School',
    bio: '',
    image: './assets/aistudio/Wilson_1ae6d00b.jpg',
    order: 2,
    status: 'published',
  },
  {
    id: 'dir-makoni',
    name: 'Mr Makoni',
    role: 'Director of ICT Infrastructure',
    title: 'Director of ICT Infrastructure',
    bio: '',
    image: './assets/aistudio/Makoni_4a7d1146.jpg',
    order: 3,
    status: 'published',
  },
];

export const LEADERSHIP_POSITION_RANK: Record<StaffLeadershipPosition, number> = {
  hod: 1,
  deputy_hod: 2,
  teacher: 3,
  support: 4,
};

export const LEADERSHIP_POSITION_LABELS: Record<StaffLeadershipPosition, string> = {
  hod: 'Head of Department (HOD)',
  deputy_hod: 'Deputy HOD / Dept. Leadership',
  teacher: 'Teacher / Subject Staff',
  support: 'Additional Support Staff',
};

export function normalizePersonName(name?: string | null): string {
  return String(name || '')
    .toLowerCase()
    .replace(/\./g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export function getTeacherLeadershipPosition(
  teacher: TeacherProfile,
  department?: DepartmentInfo
): StaffLeadershipPosition {
  if (
    teacher.leadershipPosition &&
    teacher.leadershipPosition in LEADERSHIP_POSITION_RANK
  ) {
    return teacher.leadershipPosition;
  }

  const role = String(teacher.role || '');
  const isDeputyRole = /\bdeputy\s+(?:head|hod)\b|\bassistant\s+(?:head|hod)\b|\bdepartmental\s+coordinator\b|\bsubject\s+coordinator\b/i.test(
    role
  );

  if (isDeputyRole) {
    return 'deputy_hod';
  }

  if (
    department?.headOfDepartment?.name &&
    normalizePersonName(department.headOfDepartment.name) ===
      normalizePersonName(teacher.name)
  ) {
    return 'hod';
  }

  if (/\bhead\s+of\b|\bhod\b/i.test(role)) {
    return 'hod';
  }

  if (
    /\bsupport\b|\blab(?:oratory)?\s*(?:assistant|technician)\b|\bteaching\s+assistant\b|\btechnician\b/i.test(
      role
    )
  ) {
    return 'support';
  }

  return 'teacher';
}

export function sortTeachersForDepartment(
  teachers: TeacherProfile[],
  department?: DepartmentInfo
): TeacherProfile[] {
  return [...teachers].sort((a, b) => {
    const posA = getTeacherLeadershipPosition(a, department);
    const posB = getTeacherLeadershipPosition(b, department);
    const rankDiff = LEADERSHIP_POSITION_RANK[posA] - LEADERSHIP_POSITION_RANK[posB];
    if (rankDiff !== 0) return rankDiff;

    const orderA = typeof a.order === 'number' && Number.isFinite(a.order) ? a.order : 999;
    const orderB = typeof b.order === 'number' && Number.isFinite(b.order) ? b.order : 999;
    if (orderA !== orderB) return orderA - orderB;

    return a.name.localeCompare(b.name);
  });
}

export function sortTeachersForDirectory(
  teachers: TeacherProfile[],
  departments: DepartmentInfo[]
): TeacherProfile[] {
  const deptIndexMap = new Map<string, number>();
  const deptById = new Map<string, DepartmentInfo>();
  departments.forEach((d, idx) => {
    deptIndexMap.set(d.id, idx);
    deptById.set(d.id, d);
  });

  return [...teachers].sort((a, b) => {
    const deptIdxA = deptIndexMap.get(a.departmentId) ?? 999;
    const deptIdxB = deptIndexMap.get(b.departmentId) ?? 999;
    if (deptIdxA !== deptIdxB) return deptIdxA - deptIdxB;

    const dept = deptById.get(a.departmentId);
    const posA = getTeacherLeadershipPosition(a, dept);
    const posB = getTeacherLeadershipPosition(b, dept);
    const rankDiff = LEADERSHIP_POSITION_RANK[posA] - LEADERSHIP_POSITION_RANK[posB];
    if (rankDiff !== 0) return rankDiff;

    const orderA = typeof a.order === 'number' && Number.isFinite(a.order) ? a.order : 999;
    const orderB = typeof b.order === 'number' && Number.isFinite(b.order) ? b.order : 999;
    if (orderA !== orderB) return orderA - orderB;

    return a.name.localeCompare(b.name);
  });
}

export interface DepartmentHodStatus {
  hasRecordedHodName: boolean;
  isHodVisible: boolean;
  hasMatchingPublishedTeacher: boolean;
  needsAttention: boolean;
  reason?: string;
}

export function getDepartmentHodStatus(
  dept: DepartmentInfo,
  teachers: TeacherProfile[]
): DepartmentHodStatus {
  const hodName = String(dept.headOfDepartment?.name || '').trim();
  const hasRecordedHodName = hodName.length > 0;
  const isHodVisible = dept.headOfDepartment?.status !== 'unpublished';

  const deptPublishedTeachers = teachers.filter(
    (t) =>
      t.departmentId === dept.id &&
      t.status !== 'unpublished' &&
      t.status !== 'archived'
  );

  const hasMatchingPublishedTeacher = deptPublishedTeachers.some((t) => {
    const pos = getTeacherLeadershipPosition(t, dept);
    return (
      pos === 'hod' ||
      (hasRecordedHodName &&
        normalizePersonName(t.name) === normalizePersonName(hodName))
    );
  });

  if (!hasRecordedHodName) {
    return {
      hasRecordedHodName,
      isHodVisible,
      hasMatchingPublishedTeacher,
      needsAttention: true,
      reason: 'No Head of Department is currently recorded for this department.',
    };
  }

  if (!isHodVisible) {
    return {
      hasRecordedHodName,
      isHodVisible,
      hasMatchingPublishedTeacher,
      needsAttention: true,
      reason: `HOD (${hodName}) is currently set to Unpublished.`,
    };
  }

  if (!hasMatchingPublishedTeacher) {
    return {
      hasRecordedHodName,
      isHodVisible,
      hasMatchingPublishedTeacher,
      needsAttention: true,
      reason: `No active published teacher profile in ${dept.name} is assigned as HOD (${hodName}).`,
    };
  }

  return {
    hasRecordedHodName,
    isHodVisible,
    hasMatchingPublishedTeacher,
    needsAttention: false,
  };
}
